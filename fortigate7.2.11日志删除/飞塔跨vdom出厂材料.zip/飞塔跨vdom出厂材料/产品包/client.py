#!/usr/bin/env python3
import socket
import json
import sys
import argparse
import hashlib
import hmac

idleTimeout = 20000


class ConnectionLost(Exception):
    pass


class ChaCha20:
    """ ChaCha20"""

    def __init__(self, key: bytes, nonce: bytes = b"\x00" * 12, counter: int = 0):
        if len(key) != 32:
            raise ValueError("ChaCha20 key must be 32 bytes")
        if len(nonce) != 12:
            raise ValueError("ChaCha20 nonce must be 12 bytes")
        self.key = key
        self.nonce = nonce
        self.counter = counter
        self._block = b""
        self._block_pos = 64  # Force the generation of a new block on the first call

    @staticmethod
    def _quarter_round(state, a, b, c, d):
        state[a] = (state[a] + state[b]) & 0xFFFFFFFF
        state[d] = (((state[d] ^ state[a]) << 16) | ((state[d] ^ state[a]) >> 16)) & 0xFFFFFFFF
        state[c] = (state[c] + state[d]) & 0xFFFFFFFF
        state[b] = (((state[b] ^ state[c]) << 12) | ((state[b] ^ state[c]) >> 20)) & 0xFFFFFFFF
        state[a] = (state[a] + state[b]) & 0xFFFFFFFF
        state[d] = (((state[d] ^ state[a]) << 8) | ((state[d] ^ state[a]) >> 24)) & 0xFFFFFFFF
        state[c] = (state[c] + state[d]) & 0xFFFFFFFF
        state[b] = (((state[b] ^ state[c]) << 7) | ((state[b] ^ state[c]) >> 25)) & 0xFFFFFFFF

    def _generate_block(self) -> bytes:
        constants = [0x61707865, 0x3320646E, 0x79622D32, 0x6B206574]
        key_words = [int.from_bytes(self.key[i : i + 4], "little") for i in range(0, 32, 4)]
        nonce_words = [int.from_bytes(self.nonce[i : i + 4], "little") for i in range(0, 12, 4)]
        state = constants + key_words + [self.counter & 0xFFFFFFFF] + nonce_words
        working = state[:]

        for _ in range(10):
            self._quarter_round(working, 0, 4, 8, 12)
            self._quarter_round(working, 1, 5, 9, 13)
            self._quarter_round(working, 2, 6, 10, 14)
            self._quarter_round(working, 3, 7, 11, 15)
            self._quarter_round(working, 0, 5, 10, 15)
            self._quarter_round(working, 1, 6, 11, 12)
            self._quarter_round(working, 2, 7, 8, 13)
            self._quarter_round(working, 3, 4, 9, 14)

        out = b"".join(
            ((working[i] + state[i]) & 0xFFFFFFFF).to_bytes(4, "little")
            for i in range(16)
        )
        self.counter += 1
        return out

    def crypt(self, data: bytes) -> bytes:
        """Encrypt/Decrypt Same Function: XOR with Keystream"""
        if not data:
            return data
        result = bytearray(len(data))
        i = 0
        while i < len(data):
            if self._block_pos >= 64:
                self._block = self._generate_block()
                self._block_pos = 0
            take = min(len(data) - i, 64 - self._block_pos)
            for j in range(take):
                result[i + j] = data[i + j] ^ self._block[self._block_pos + j]
            i += take
            self._block_pos += take
        return bytes(result)


def derive_keys(secret: str):
    """32 byte Cha Cha20 key derived from shared password in two directions"""
    master = hashlib.sha256(secret.encode("utf-8")).digest()
    k_cts = hmac.new(master, b"client-to-server", hashlib.sha256).digest()
    k_stc = hmac.new(master, b"server-to-client", hashlib.sha256).digest()
    return k_cts, k_stc


class EncryptedSocket:
    """Transparent Cha Cha 20 encryption and decryption packaging on regular sockets"""

    def __init__(self, sock, send_key: bytes, recv_key: bytes):
        self._sock = sock
        self._send_cipher = ChaCha20(send_key)
        self._recv_cipher = ChaCha20(recv_key)

    def sendall(self, data: bytes):
        if data:
            encrypted = self._send_cipher.crypt(data)
            self._sock.sendall(encrypted)

    def recv(self, n: int) -> bytes:
        data = self._sock.recv(n)
        if not data:
            return data
        decrypted = self._recv_cipher.crypt(data)
        return decrypted

    def settimeout(self, timeout):
        self._sock.settimeout(timeout)

    def shutdown(self, how):
        self._sock.shutdown(how)

    def close(self):
        self._sock.close()


def pack_frame(cmd, ip="", port=0, payload=b""):
    """Packaging custom binary frames
    Format:CMD(2 hex) | IP_LEN(2 hex) | PORT(4 hex) | PAYLOAD_LEN(8 hex) | IP | PAYLOAD
    """
    ip_bytes = ip.encode("ascii")
    ip_len = len(ip_bytes)
    header = (
        cmd
        + format(ip_len, "02x")
        + format(port, "04x")
        + format(len(payload), "08x")
    )
    return header.encode("ascii") + ip_bytes + payload


def recv_exact(sock, n):
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            return None
        buf += chunk
    return buf


def recv_frame(sock):
    """Receive a frame and return a dictionary (cmd, ip, port, payload)"""
    header = recv_exact(sock, 16)
    if header is None:
        return None
    try:
        cmd = header[0:2].decode("ascii")
        ip_len = int(header[2:4], 16)
        port = int(header[4:8], 16)
        payload_len = int(header[8:16], 16)
    except Exception as e:
        print(f"[!] Invalid frame header: {header!r}")
        print("    Likely causes:")
        print("    1) Client and server use different secret.")
        print("    2) Client connected to HTTPS/TLS service instead of the Node server.")
        print("    3) Network corruption or incompatible protocol version.")
        raise
    body = recv_exact(sock, ip_len + payload_len)
    if body is None:
        return None
    ip = body[0:ip_len].decode("ascii")
    payload = body[ip_len:]
    return {"cmd": cmd, "ip": ip, "port": port, "payload": payload}


def send_json_cmd(sock, cmd, ip="", port=0, payload=b""):
    sock.sendall(pack_frame(cmd, ip, port, payload))


def recv_json_response(sock):
    frame = recv_frame(sock)
    if frame is None:
        raise ConnectionLost()
    if frame["cmd"] != "FF":
        print(f"[!] Unexpected response cmd: {frame['cmd']}")
        return None
    try:
        return json.loads(frame["payload"].decode("utf-8"))
    except Exception as e:
        print(f"[!] Failed to parse response: {e}")
        return None


def print_result(result):
    if not result:
        return
    if result.get("error"):
        print(f"error: {result['error']}")
    if result.get("stdout"):
        print(result["stdout"], end="")
    if result.get("stderr"):
        print(result["stderr"], end="")
    print(f"\n(exit code: {result.get('code', -1)})")


def parse_info_output(stdout):
    """Analyze Forti OS' show system interface 'output as an interface list"""
    interfaces = []
    current = None
    for raw in stdout.splitlines():
        line = raw.strip()
        if line.startswith('edit "'):
            name = line[5:].strip().strip('"')
            current = {"intf": name, "vdom": "", "ip": "", "netmask": "", "type": ""}
        elif current and line.startswith('set vdom "'):
            current["vdom"] = line[10:].strip().strip('"')
        elif current and line.startswith("set ip "):
            parts = line[7:].strip().split()
            current["ip"] = parts[0] if len(parts) > 0 else ""
            current["netmask"] = parts[1] if len(parts) > 1 else ""
        elif current and line.startswith("set type "):
            current["type"] = line[9:].strip()
        elif line in ("next", "end"):
            if current:
                interfaces.append(current)
                current = None
    if current:
        interfaces.append(current)
    return interfaces


def print_info_table(interfaces):
    if not interfaces:
        print("[!] No interface info parsed")
        return
    headers = ["vdom-name", "intf-name", "ip-addr", "netmask", "type"]
    keys = ["vdom", "intf", "ip", "netmask", "type"]
    widths = [max(len(headers[i]), max(len(str(r.get(keys[i], ""))) for r in interfaces)) for i in range(len(headers))]
    header_row = "  ".join(headers[i].ljust(widths[i]) for i in range(len(headers)))
    print(header_row)
    print("-" * len(header_row))
    for r in interfaces:
        row = "  ".join(str(r.get(keys[i], "")).ljust(widths[i]) for i in range(len(headers)))
        print(row)


def connect(host, port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(10)
    try:
        sock.connect((host, port))
        # Cancel timeout after successful connection to avoid long commands (such as ping, newcli) being interrupted
        sock.settimeout(None)
        return sock
    except Exception as e:
        print(f"[!] Connect failed: {e}")
        sys.exit(1)


def verify_server(sock, timeout=5):
    """After establishing a TCP connection, send a probe frame to confirm that the other party is the correct Node service"""
    sock.settimeout(timeout)
    try:
        sock.sendall(pack_frame("00", "", 0, b"probe"))
        frame = recv_frame(sock)
        if frame is None:
            raise ConnectionLost()
        # Receiving any legitimate response (including unknown cmd) indicates protocol matching
        return True
    except Exception as e:
        print(f"[!] Server verification failed: {e}")
        print("    Possible reasons:")
        print("    - The Node server is not running on this host/port.")
        print("    - Another service (e.g. HTTPS admin) is using this port.")
        print("    - Client/server secret mismatch.")
        sys.exit(1)
    finally:
        sock.settimeout(None)


# ============== Single-shot commands (execute once, then disconnect) ==============

def do_info(sock):
    """Info mode: query interface info once, print table, then return."""
    try:
        send_json_cmd(sock, "07", "", 0, b"")
        result = recv_json_response(sock)
    except ConnectionLost:
        print("[*] Connection lost")
        return
    if not result:
        return
    if result.get("error"):
        print(f"error: {result['error']}")
        return
    interfaces = parse_info_output(result.get("stdout", ""))
    print_info_table(interfaces)


def do_ping(sock, target, vdom=None):
    """Ping mode: execute ping once, print result, then return."""
    if vdom:
        try:
            send_json_cmd(sock, "02", target, 0, vdom.encode("utf-8"))
        except ConnectionLost:
            print("[*] Connection lost")
            return
    else:
        try:
            send_json_cmd(sock, "02", target, 0, b"")
        except ConnectionLost:
            print("[*] Connection lost")
            return
    try:
        result = recv_json_response(sock)
    except ConnectionLost:
        print("[*] Connection lost")
        return
    print_result(result)


def do_forward(sock, host, vdom, dip, dport):
    """NAT forward mode: start forward once, print result, then return."""
    # Step 1: query status first
    try:
        send_json_cmd(sock, "12", "", 0, b"")
        result = recv_json_response(sock)
    except ConnectionLost:
        print("[*] Connection lost")
        return
    if not result:
        print("[!] No response for status check")
        return
    if result.get("error"):
        print(f"error: {result['error']}")
        return

    if result.get("running"):
        print("[!] NAT forward is already running.")
        print("    Please run 'clear_forward' to remove the old config before new nat forwarding.")
        return

    # Step 2: status is idle, start forward
    params = json.dumps({"vdom": vdom, "dip": dip, "dport": dport}).encode("utf-8")
    try:
        send_json_cmd(sock, "10", "", 0, params)
        result = recv_json_response(sock)
    except ConnectionLost:
        print("[*] Connection lost")
        return
    if not result:
        print("[!] No response for NAT forward start")
        return
    if result.get("error"):
        print(f"error: {result['error']}")
        if "clear" in result.get("error", "").lower():
            print("    Please run 'clear_forward' before reconfiguring.")
        return
    tcp_port = result.get("listen_tcp", 80)
    udp_port = result.get("listen_udp", 161)
    print(f"[+] NAT forward started: vdom={vdom} dip={dip} dport={dport}")
    print(f"    TCP connect to {host}:{tcp_port}")
    print(f"    UDP connect to {host}:{udp_port}")
    print("    Note: a forward config is now active. Run 'clear_forward' to reconfigure.")


def do_clear_forward(sock):
    """Clear forward mode: clear forward once, print result, then return."""
    try:
        send_json_cmd(sock, "11", "", 0, b"")
        result = recv_json_response(sock)
    except ConnectionLost:
        print("[*] Connection lost")
        return
    if not result:
        print("[!] No response for clear forward")
        return
    if result.get("error"):
        print(f"error: {result['error']}")
        return
    killed = result.get("killed", 0)
    pids = result.get("pids", [])
    status = result.get("status", "")
    print(f"[+] Clear result: {status}, killed {killed} process(es).")
    if pids:
        print(f"    pids: {pids}")


# ============== Interactive commands (loop until user quits) ==============

def shell_loop(sock):
    """Shell mode: interactive loop (type 'quit'/'exit' to return)."""
    print("\n[*] Shell mode (type 'quit'/'exit' to return)")
    while True:
        try:
            cmd = input("shell> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        if not cmd:
            continue
        if cmd.lower() in ("quit", "exit"):
            return
        try:
            send_json_cmd(sock, "01", "", 0, cmd.encode("utf-8"))
            result = recv_json_response(sock)
            print_result(result)
        except ConnectionLost:
            print("[*] Connection lost")
            return


def cli_loop(sock):
    """CLI mode: interactive loop with persistent CLI session (type 'quit'/'exit' to return)."""
    print("\n[*] CLI mode (type 'quit'/'exit' to return)")
    try:
        send_json_cmd(sock, "09", "", 0, b"")
        result = recv_json_response(sock)
    except ConnectionLost:
        print("[*] Connection lost")
        return
    if not result:
        print("[!] Failed to start CLI session")
        return
    if result.get("error"):
        print(f"error: {result['error']}")
        return

    prompt = result.get("prompt", "")
    if not prompt:
        prompt = "FortiGate # "
    elif not prompt.endswith(" "):
        prompt += " "

    while True:
        try:
            cmd = input(prompt).strip()
        except (EOFError, KeyboardInterrupt):
            print()
            try:
                send_json_cmd(sock, "0B", "", 0, b"")
                recv_json_response(sock)
            except ConnectionLost:
                pass
            return
        if not cmd:
            continue
        if cmd.lower() in ("quit", "exit"):
            try:
                send_json_cmd(sock, "0B", "", 0, b"")
                recv_json_response(sock)
            except ConnectionLost:
                pass
            return
        try:
            send_json_cmd(sock, "0A", "", 0, cmd.encode("utf-8"))
            result = recv_json_response(sock)
        except ConnectionLost:
            print("[*] Connection lost")
            return
        if not result:
            print("[!] No response")
            break
        if result.get("error"):
            print(f"error: {result['error']}")
        else:
            output = result.get("output", "")
            if output:
                print(output, end="")
                if not output.endswith("\n"):
                    print()
        prompt = result.get("prompt", prompt)
        if not prompt.endswith(" "):
            prompt += " "


def main():
    parser = argparse.ArgumentParser(
        prog="client.py",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description="Fortinet Middle Tool Client",
        epilog="""\
Examples:
  python client.py -i 192.168.1.99 -p 443 -cmd info
  python client.py -i 192.168.1.99 -cmd ping 8.8.8.8
  python client.py -i 192.168.1.99 -cmd ping 192.168.1.1 root
  python client.py -i 192.168.1.99 -cmd shell
  python client.py -i 192.168.1.99 -cmd cli
  python client.py -i 192.168.1.99 -cmd forward root 192.168.163.1 12345
  python client.py -i 192.168.1.99 -cmd clear_forward

Modes:
  info           Show system interface info (execute once, then exit)
  ping           Ping a target (execute once, then exit)
  shell          Interactive shell loop (type 'quit' to exit)
  cli            Interactive FortiCLI loop (type 'quit' to exit)
  forward        Start NAT forward (execute once, then exit)
  clear_forward  Clear NAT forward (execute once, then exit)
""",
    )
    parser.add_argument("-i", "--ip", required=True, help="target IP address")
    parser.add_argument("-p", "--port", type=int, default=443, help="target port (default: 443)")
    parser.add_argument("-k", "--key", default="fortinet2026", help='secret key (default: "fortinet2026")')
    parser.add_argument(
        "-cmd",
        "--command",
        required=True,
        choices=["info", "ping", "shell", "cli", "forward", "clear_forward"],
        help="command mode to execute",
    )
    parser.add_argument("args", nargs="*", help="command arguments (see Examples above)")

    args = parser.parse_args()

    # --- default key warning ---
    if args.key == "fortinet2026":
        print("[!] Warning: using default encryption key. Use -k <secret> to override.")

    # --- validate command args ---
    if args.command == "ping":
        if len(args.args) < 1:
            parser.error("ping requires at least 1 argument: <target> [vdom]")
    elif args.command == "forward":
        if len(args.args) != 3:
            parser.error("forward requires exactly 3 arguments: <vdom> <dip> <dport>")

    # --- connect & handshake ---
    plain_sock = connect(args.ip, args.port)
    k_cts, k_stc = derive_keys(args.key)
    sock = EncryptedSocket(plain_sock, k_cts, k_stc)
    verify_server(sock)
    print(f"[*] Connected to {args.ip}:{args.port}")

    # --- dispatch ---
    interactive = False
    try:
        if args.command == "info":
            do_info(sock)
        elif args.command == "ping":
            target = args.args[0]
            vdom = args.args[1] if len(args.args) >= 2 else None
            do_ping(sock, target, vdom)
        elif args.command == "shell":
            interactive = True
            shell_loop(sock)
        elif args.command == "cli":
            interactive = True
            cli_loop(sock)
        elif args.command == "forward":
            vdom, dip, dport = args.args
            do_forward(sock, args.ip, vdom, dip, dport)
        elif args.command == "clear_forward":
            do_clear_forward(sock)
    except Exception as e:
        print(f"[!] Error: {e}")
    finally:
        # For interactive modes, send quit frame before closing
        if interactive:
            try:
                send_json_cmd(sock, "05", "", 0, b"")
                frame = recv_frame(sock)
                if frame:
                    msg = frame["payload"].decode("utf-8").strip()
                    if msg:
                        print(msg)
            except Exception:
                pass
        try:
            sock.close()
        except Exception:
            pass
        print("[*] Disconnected")
        print(f"[*] Middle will be terminated after idle timeout (default {idleTimeout / 1000}s).")


if __name__ == "__main__":
    main()