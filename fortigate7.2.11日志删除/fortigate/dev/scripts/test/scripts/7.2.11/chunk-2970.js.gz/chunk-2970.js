(self.webpackChunkFOS_LIB = self.webpackChunkFOS_LIB || []).push([
  [2970],
  {
    18416: (module, exports, __webpack_require__) => {
      "use strict";
      var __WEBPACK_AMD_DEFINE_RESULT__;
      void 0 ===
        (__WEBPACK_AMD_DEFINE_RESULT__ = (() => {
          const fPolicyListIdTooltip = {
              controller: () => {},
              bindings: { entry: "<", warnings: "<" },
              templateUrl: __webpack_require__(19057),
            },
            fPolicyListStatsTooltip = {
              controller: () => {},
              bindings: {
                entry: "<",
                stats: "<",
                supportedKeys: "<",
                statsType: "<?",
                statsIpVersion: "<?",
              },
              templateUrl: __webpack_require__(49159),
            };
          return function (providers) {
            (providers.$compile.component(
              "fPolicyListIdTooltip",
              fPolicyListIdTooltip,
            ),
              providers.$compile.component(
                "fPolicyListStatsTooltip",
                fPolicyListStatsTooltip,
              ));
          };
        }).apply(exports, [])) ||
        (module.exports = __WEBPACK_AMD_DEFINE_RESULT__);
    },
    72378: (module, __unused_webpack_exports, __webpack_require__) => {
      "use strict";
      const inject = __webpack_require__(48858),
        fPatterns = __webpack_require__(13181),
        PROTOCOLS = ["ip"].concat(["tcp", "udp", "sctp"]),
        ICMP_PRESETS = {
          "ICMP ping request": { protocol: "icmp", icmptype: 8, icmpcode: 0 },
          "ICMPv6 ping request": {
            protocol: "icmp6",
            icmptype: 8,
            icmpcode: 0,
          },
          "ICMP ping reply": { protocol: "icmp", icmptype: 0, icmpcode: 0 },
          "ICMPv6 ping reply": { protocol: "icmp6", icmptype: 0, icmpcode: 0 },
        },
        getProtocols = function (ipVersion) {
          switch (ipVersion) {
            case "ipv4":
              return PROTOCOLS.concat([
                "icmp",
                "ICMP ping request",
                "ICMP ping reply",
              ]);
            case "ipv6":
              return PROTOCOLS.concat([
                "icmp6",
                "ICMPv6 ping request",
                "ICMPv6 ping reply",
              ]);
          }
        };
      class PolicyLookup extends inject.Collectable {
        async $onInit() {
          ((this.show = {}),
            (this.PORT_MIN = 1),
            (this.PORT_MAX = 65535),
            (this.model = {
              protocol: "ip",
              ipVersion: this.ipVersion || "ipv4",
            }),
            "both" === this.ipVersion &&
              ((this.show.ipVersion = !0), (this.model.ipVersion = "ipv4")),
            (this.showWarning = !1),
            (this.patterns = fPatterns.commonRegExp),
            this.ipPatterns(),
            await this.setup(),
            this.selectChanged(),
            this.fReadOnlyManager && this.fReadOnlyManager.setReadOnly(!1));
        }
        ipPatterns($INJECTABLE$, lang) {
          return () => {
            ((this.ipPattern = {
              src: {
                ipv4: { ip_pattern: [this.patterns.IP_HOST] },
                ipv6: { ip_pattern: [this.patterns.IP6_HOST] },
              },
              dest: {
                ipv4: {
                  ip_pattern: [this.patterns.IP_HOST, this.patterns.FQDN],
                },
                ipv6: {
                  ip_pattern: [this.patterns.IP6_HOST, this.patterns.FQDN],
                },
              },
            }),
              (this.ipPatternError = {
                src: {
                  ipv4: { ip_pattern: lang("err_ip4") },
                  ipv6: { ip_pattern: lang("err_ip6") },
                },
                dest: {
                  ipv4: { ip_pattern: lang("Invalid hostname.") },
                  ipv6: { ip_pattern: lang("Invalid hostname.") },
                },
              }));
          };
        }
        setup($INJECTABLE$, CMDB) {
          return async () => {
            ((this.selectintf = {
              sources: "firewallInterfaces",
              filterFunction: function (intf) {
                return (
                  "any" !== intf.name &&
                  intf.valid_in_policy &&
                  !intf.is_zone &&
                  !intf.is_sdwan_zone &&
                  !intf.is_virtual_wire_pair_member &&
                  !intf.is_nat_tunnel
                );
              },
              singleSelect: !0,
              insideSlide: !0,
            }),
              (this.options = {
                protocols: getProtocols(this.model.ipVersion),
                ipVersions: ["ipv4", "ipv6"],
              }));
            const cmdb = new CMDB("firewall", "address");
            this.address = await cmdb.defaults().$promise;
          };
        }
        _getPolicyOmniselectConfig($INJECTABLE$, policyOmniselectConfig) {
          return function (selector, processFn) {
            return policyOmniselectConfig.get(
              selector,
              this.policy,
              (settings) => (
                "function" == typeof processFn &&
                  (settings = processFn(settings)),
                (settings.meta.isDialog = !0),
                settings
              ),
            );
          };
        }
        selectChanged() {
          this.options.protocols = getProtocols(this.model.ipVersion);
          const temp = this.show.ipVersion;
          switch (this.model.protocol) {
            case "ip":
              this.show = { protocolNumber: !0, sourceip: !0, dest: !0 };
              break;
            case "tcp":
            case "udp":
            case "sctp":
              this.show = {
                sourceip: !0,
                sourceport: !0,
                dest: !0,
                destport: !0,
              };
              break;
            case "icmp":
            case "icmp6":
              this.show = {
                icmptype: !0,
                icmpcode: !0,
                sourceip: !0,
                dest: !0,
              };
              break;
            case "ICMP ping request":
            case "ICMP ping reply":
            case "ICMPv6 ping request":
            case "ICMPv6 ping reply":
              this.show = { sourceip: !0, dest: !0 };
          }
          this.show.ipVersion = temp;
        }
        lookupPolicy($INJECTABLE$, $q, lang, $http, $httpParamSerializer) {
          return async () => {
            const ipProtocol = "ip" === this.model.protocol,
              preset = ICMP_PRESETS[this.model.protocol],
              formData = this.model,
              ipv6 = "ipv6" === this.model.ipVersion,
              params = {};
            let failureReason = "";
            (Object.assign(params, formData, {
              protocol: ipProtocol
                ? formData.protocolNumber
                : formData.protocol,
              destport: ipProtocol ? 0 : formData.destport,
              srcintf: formData.srcintf.name,
              ipv6,
            }),
              delete params.protocolNumber,
              delete params.ipVersion,
              preset && Object.assign(params, preset));
            const failure = function () {
                return lang("Failed to perform policy lookup");
              },
              checkForRoute = function (dest = !0) {
                return (function (data) {
                  const url = `/api/v2/monitor/router/lookup?${$httpParamSerializer(data)}`;
                  return $http.get(url);
                })({
                  destination: dest ? formData.dest : formData.sourceip,
                  ipv6,
                }).then(({ data }) => data.results, failure);
              },
              url = `/api/v2/monitor/firewall/policy-lookup?${$httpParamSerializer(params)}`,
              results = (await $http.get(url)).data.results;
            if (results.success) {
              if (results.policy_id) return results.policy_id;
              {
                const routeData = await checkForRoute();
                failureReason = routeData.success
                  ? lang(
                      "Policy lookup matches the implicit deny policy. No explicit policy exists from source interface {0} to destination interface {1} as determined by a route lookup to {2}",
                      [formData.srcintf.name, routeData.interface, params.dest],
                    )
                  : lang("No route exists to the destination {0}", [
                      params.dest,
                    ]);
              }
            } else {
              const routeData = await checkForRoute();
              if (routeData.success) {
                const sourceRouteData = await checkForRoute(!1),
                  intfMismatch =
                    sourceRouteData.interface !== formData.srcintf.name,
                  failedLookupIP =
                    !sourceRouteData.success || intfMismatch
                      ? formData.sourceip
                      : params.dest;
                failureReason = lang(
                  "Policy lookup failed to match any policies from source interface {0} to destination interface {1} as determined by a route lookup to {2}",
                  [formData.srcintf.name, routeData.interface, failedLookupIP],
                );
              } else if (results.error_code)
                switch (results.error_code) {
                  case "error_unresolved_dns":
                    failureReason = lang("Failed to resolve FQDN");
                    break;
                  case "error_unknown_route":
                    failureReason = lang(
                      "No route exists to the destination {0}",
                      [params.dest],
                    );
                    break;
                  default:
                    failureReason = lang(
                      "Policy match failed due to internal error",
                    );
                }
            }
            throw new Error(failureReason || failure());
          };
        }
        async submit() {
          this.loading = !0;
          try {
            ((this.showWarning = !1), (this.warningMessage = ""));
            return await this.lookupPolicy();
          } catch (error) {
            return (
              (this.showWarning = !0),
              (this.loading = !1),
              (this.warningMessage = error.message),
              Promise.reject(error)
            );
          }
        }
        close() {
          this.slideController.slide.close();
        }
      }
      ((PolicyLookup.prototype.ipPatterns.$inject = ["$INJECTABLE$", "lang"]),
        (PolicyLookup.prototype.setup.$inject = ["$INJECTABLE$", "CMDB"]),
        (PolicyLookup.prototype._getPolicyOmniselectConfig.$inject = [
          "$INJECTABLE$",
          "policyOmniselectConfig",
        ]),
        (PolicyLookup.prototype.lookupPolicy.$inject = [
          "$INJECTABLE$",
          "$q",
          "lang",
          "$http",
          "$httpParamSerializer",
        ]),
        (module.exports = (providers) => {
          providers.$compile.component("fPolicyLookup", {
            controller: PolicyLookup,
            templateUrl: __webpack_require__(78398),
            require: { slideController: "?^fSlideContainer" },
            bindings: { ipVersion: "<" },
          });
        }));
    },
    72970: (module, exports, __webpack_require__) => {
      "use strict";
      var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;
      ((__WEBPACK_AMD_DEFINE_ARRAY__ = [
        __webpack_require__(26554),
        __webpack_require__(95829),
        __webpack_require__(57513),
        __webpack_require__(48858),
        __webpack_require__(34198),
        __webpack_require__(58718),
      ]),
        void 0 ===
          (__WEBPACK_AMD_DEFINE_RESULT__ = ((
            fLog,
            fLocation,
            fStructure,
            inject,
            csfModels,
            notify,
          ) => {
            const MENU_ITEMS_STATS = __webpack_require__(53715),
              MENU_ITEMS_SEQ = __webpack_require__(44428),
              logError = (error, customLog) => {
                var errorMsg;
                ((errorMsg =
                  "string" == typeof error
                    ? error
                    : error
                      ? error.message
                      : ""),
                  fLog.error(`${customLog} ${errorMsg}`));
              };
            class PolicyList extends inject.Collectable {
              async $onInit() {
                (this.setupControllerProperties(),
                  await this.loadData(),
                  await this.loadIssueNotifications(),
                  this.setupWatchers(),
                  this.setupTableSettings(),
                  this._locateOnNextRender());
              }
              $onDestroy(
                $INJECTABLE$,
                PolicySource,
                policyStats,
                policyListTableSettings,
                policyListViewType,
                policyInit,
                policyListIpVersionFilter,
              ) {
                return () => {
                  (PolicySource.invalidateCache(),
                    policyStats.clearListeners(),
                    policyStats.clearCache(),
                    policyInit.resetTypes(),
                    policyListTableSettings.clearCache(),
                    this.source &&
                      (this.source.destroy(), (this.source = null)),
                    (this.settings = null),
                    (this.notifications = null),
                    policyListViewType.clearCache(),
                    policyListIpVersionFilter.clearCache());
                };
              }
              refresh(clearCache) {
                try {
                  clearCache
                    ? this.loadPolicies()
                    : this.mutableInstance.updateSource(this.source);
                } catch (e) {
                  logError(e, "Failed to refresh policy list for: ");
                }
              }
              showLoadingMask() {
                this.mutableInstance.showLoadingMask();
              }
              deleteRows(rows) {
                this.mutableInstance.deleteRows(rows);
              }
              _cmdbGet($INJECTABLE$, $http) {
                return async (path, name, mkey) => {
                  const url = `/api/v2/cmdb/${path}/${name}/${(mkey = mkey ? encodeURIComponent(mkey) : "")}?with_meta=1&datasource=1`;
                  try {
                    return (await $http.get(url)).data.results;
                  } catch (e) {
                    return (
                      logError(
                        e,
                        `Failed to fetch ${path}.${name}.${mkey} for: `,
                      ),
                      e
                    );
                  }
                };
              }
              _locateOnNextRender() {
                let showInList = this.routeParams.showInList;
                if (showInList)
                  try {
                    ((showInList = JSON.parse(showInList)),
                      (this.locateFunction = (entry) =>
                        entry.policyId === Number(showInList.q_origin_key)));
                  } catch (e) {
                    fLog.error("Failed to parse showInList");
                  }
                else this.locateFunction = null;
              }
              setupControllerProperties(
                $INJECTABLE$,
                $routeParams,
                state,
                policyVWP,
                policyInit,
              ) {
                return () => {
                  ((this.routeParams =
                    this.explicitRouteParams || $routeParams),
                    policyInit.setType(this.type || this.routeParams.type),
                    policyInit.setSubType(
                      this.subType || this.routeParams.subType,
                    ),
                    (this.showImplicitPolicy =
                      state.featureVisible("implicit_policy") &&
                      policyInit.IMPLICIT_POLICY[policyInit.type]),
                    (this.isVirtualWirePolicy =
                      policyVWP.isVirtualWirePolicy()));
                };
              }
              allowDrilldownFromSlide($INJECTABLE$, state) {
                return () =>
                  (!this.slideController || state.isVdomModeDisabled()) &&
                  !state.isFullPolicyOffload();
              }
              setupWatchers(
                $INJECTABLE$,
                $scope,
                policyVWP,
                policyListViewType,
                policyListIpVersionFilter,
              ) {
                return () => {
                  if (this.isVirtualWirePolicy) {
                    const vwpFilterName = this.routeParams.vwpname;
                    (vwpFilterName && policyVWP.setCurrent(vwpFilterName),
                      $scope.$watch(
                        () => policyVWP.current,
                        (value, previous) => {
                          value !== previous &&
                            (this.refresh(!0), this._locateOnNextRender());
                        },
                      ));
                  }
                  ($scope.$watch(
                    () => policyListViewType.value,
                    (value, previous) => {
                      value &&
                        value !== previous &&
                        (this.refresh(),
                        this.setupTableSettings(),
                        this._locateOnNextRender());
                    },
                  ),
                    policyListIpVersionFilter.supported(
                      this.routeParams.type,
                    ) &&
                      $scope.$watch(
                        () => policyListIpVersionFilter.current.value,
                        (value, previous) => {
                          value &&
                            value !== previous &&
                            (this.refresh(!0), this._locateOnNextRender());
                        },
                      ));
                };
              }
              _cacheData({
                systemGlobal,
                logSettings,
                webProxy,
                ftpProxy,
                systemSettings,
              }) {
                ((this.systemGlobal = systemGlobal),
                  (this.logSettings = logSettings),
                  (this.webProxy = webProxy),
                  (this.ftpProxy = ftpProxy),
                  (this.systemSettings = systemSettings));
              }
              loadData(
                $INJECTABLE$,
                CMDB,
                policyStats,
                policyVWP,
                $q,
                policyOmniselectConfig,
                policyInit,
                state,
              ) {
                return async () => {
                  CMDB.model(csfModels);
                  const systemCsfCMDB = new CMDB("system", "csf"),
                    logSettingsCMDB = this._cmdbGet("log", "setting"),
                    webProxyCMDB = this._cmdbGet("web-proxy", "explicit"),
                    ftpProxyCMDB = this._cmdbGet("ftp-proxy", "explicit"),
                    systemSettingsCMDB = this._cmdbGet("system", "settings"),
                    systemGlobalCMDB = this._cmdbGet("system", "global"),
                    type = policyInit.type,
                    policyStatsType =
                      state.isFullPolicyOffload() && "policy" === type
                        ? "hyperscale-policy"
                        : type;
                  this.systemCsf = systemCsfCMDB.fetch();
                  let cmdbPromises = {
                    systemCsf:
                      ((promise = this.systemCsf.$promise),
                      (logName = "system.csf"),
                      promise.then(
                        () => {},
                        function () {
                          logName && fLog(`Failed to retrieve ${logName}`);
                        },
                      )),
                  };
                  var promise, logName;
                  let promises = {
                    systemGlobal: systemGlobalCMDB,
                    logSettings: logSettingsCMDB,
                    policyOmniselectConfig: policyOmniselectConfig.init(),
                  };
                  (this.showImplicitPolicy &&
                    "proxy-policy" === type &&
                    ((promises.webProxy = webProxyCMDB),
                    (promises.ftpProxy = ftpProxyCMDB)),
                    "policy" !== type ||
                      state.isNgfwPolicyMode() ||
                      (promises.systemSettings = systemSettingsCMDB),
                    policyStats.SUPPORTED[policyStatsType] &&
                      policyStats.load(policyStatsType),
                    this.isVirtualWirePolicy &&
                      (promises.policyVWP = policyVWP.init()));
                  try {
                    const results = await $q.all(
                      Object.assign(promises, cmdbPromises),
                    );
                    (this._cacheData(results), await this.loadPolicies());
                  } catch (e) {
                    return (
                      logError(e, "Failed to load data"),
                      Promise.reject(e)
                    );
                  }
                };
              }
              setupTableSettings(
                $INJECTABLE$,
                policyListTableSettings,
                $scope,
              ) {
                return () => {
                  const defaultColumnsOverride =
                      this.systemSettings &&
                      (
                        this.systemSettings["gui-default-policy-columns"] || []
                      ).map((entry) => entry.name),
                    defaultPolicyExpiryDays =
                      this.systemSettings &&
                      this.systemSettings["default-policy-expiry-days"];
                  try {
                    this.settings = policyListTableSettings.create({
                      defaultColumnsOverride,
                      ctrlScope: $scope,
                      isDefaultSyncMode:
                        this.systemCsf && this.systemCsf.isDefaultSyncMode(),
                      slideController: this.slideController,
                      defaultPolicyExpiryDays,
                    });
                  } catch (e) {
                    logError(e, "Failed to create muTable settings for: ");
                  }
                };
              }
              loadIssueNotifications(
                $INJECTABLE$,
                securityAudit,
                csfTopology,
                $location,
              ) {
                return async () => {
                  const route = $location.path(),
                    { serial, vdom, state } =
                      csfTopology.selectedFortigate || {};
                  this.notifications =
                    await securityAudit.getIssuesForDeviceAndRoute({
                      deviceSerial: serial,
                      route,
                      vdom: state.vdom_mode ? vdom : null,
                    });
                };
              }
              loadPolicies(
                $INJECTABLE$,
                PolicySource,
                policyInit,
                lang,
                state,
                policyListViewType,
                policyListIpVersionFilter,
              ) {
                return async () => {
                  const type = policyInit.type,
                    policySupportsIpVersionFilter =
                      policyListIpVersionFilter.supported(type),
                    generateImplicitPolicy = () => {
                      let implicitPolicy;
                      ((implicitPolicy = policyInit.implicitPolicy(type)),
                        (implicitPolicy.name = lang(
                          "Implicit Proxy Policy",
                        ).toString()),
                        (implicitPolicy.category =
                          lang("implicit").toString()));
                      const LOG_OPTION =
                        policyInit.IMPLICIT_POLICY_LOG_PROPERTY[type];
                      if (
                        ((implicitPolicy.logtraffic =
                          this.logSettings[LOG_OPTION] || "unknown"),
                        "proxy-policy" === type)
                      ) {
                        const actionMatched =
                            this.webProxy["sec-default-action"] ===
                            this.ftpProxy["sec-default-action"],
                          PROXY_POLICY_PROTOCOL_KEY = "ProxyPolicy::protocol.";
                        implicitPolicy.action = actionMatched
                          ? this.webProxy["sec-default-action"]
                          : [
                              {
                                title: lang(
                                  `${PROXY_POLICY_PROTOCOL_KEY}web`,
                                ).toString(),
                                value: this.webProxy["sec-default-action"],
                              },
                              {
                                title: lang(
                                  `${PROXY_POLICY_PROTOCOL_KEY}ftp`,
                                ).toString(),
                                value: this.ftpProxy["sec-default-action"],
                              },
                            ];
                      } else if (
                        ("policy" === type && !state.isNgfwPolicyMode()) ||
                        "security-policy" === type
                      ) {
                        const v4LogSetting =
                            this.logSettings[
                              policyInit.IMPLICIT_POLICY_LOG_PROPERTY.policy
                            ],
                          v6LogSetting =
                            this.logSettings[
                              policyInit.IMPLICIT_POLICY_LOG_PROPERTY.policy6
                            ],
                          logSettingMatched = v4LogSetting === v6LogSetting;
                        implicitPolicy.logtraffic =
                          !state.featureVisible("ipv6") || logSettingMatched
                            ? v4LogSetting
                            : [
                                {
                                  title: lang("IPv4").toString(),
                                  value: v4LogSetting,
                                },
                                {
                                  title: lang("IPv6").toString(),
                                  value: v6LogSetting,
                                },
                              ];
                      }
                      return !state.featureVisible("ipv6") ||
                        policySupportsIpVersionFilter
                        ? ((implicitPolicy) => (
                            state.featureVisible("ipv6") ||
                              ((implicitPolicy.srcaddr6 =
                                implicitPolicy.srcaddr6 && []),
                              (implicitPolicy.dstaddr6 =
                                implicitPolicy.dstaddr6 && [])),
                            policySupportsIpVersionFilter &&
                              ("ipv4" ===
                                policyListIpVersionFilter.current.value &&
                                ((implicitPolicy.srcaddr6 = []),
                                (implicitPolicy.dstaddr6 = [])),
                              "ipv6" ===
                                policyListIpVersionFilter.current.value &&
                                ((implicitPolicy.srcaddr = []),
                                (implicitPolicy.dstaddr = []))),
                            implicitPolicy
                          ))(implicitPolicy)
                        : implicitPolicy;
                    };
                  try {
                    const cmdbPath = "firewall",
                      cmdbName = type;
                    (policySupportsIpVersionFilter &&
                      policyListIpVersionFilter.update(
                        type,
                        policyInit.subType,
                        state.current_vdom,
                      ),
                      (this.source = new PolicySource(cmdbPath, cmdbName, {
                        skip: "proxy-policy" === type,
                        extraEntries: this.showImplicitPolicy
                          ? generateImplicitPolicy()
                          : [],
                        filter: this.filter,
                        datasourceFormat: {
                          "system.external-resource": "type",
                        },
                        onFetchComplete: () => policyListViewType.update(),
                      })),
                      PolicySource.cacheInstance(this.source),
                      await this.source.manuallyFetchEntries());
                  } catch (e) {
                    logError(e, "Failed to process policies for: ");
                  }
                };
              }
            }
            ((PolicyList.prototype.$onDestroy.$inject = [
              "$INJECTABLE$",
              "PolicySource",
              "policyStats",
              "policyListTableSettings",
              "policyListViewType",
              "policyInit",
              "policyListIpVersionFilter",
            ]),
              (PolicyList.prototype._cmdbGet.$inject = [
                "$INJECTABLE$",
                "$http",
              ]),
              (PolicyList.prototype.setupControllerProperties.$inject = [
                "$INJECTABLE$",
                "$routeParams",
                "state",
                "policyVWP",
                "policyInit",
              ]),
              (PolicyList.prototype.allowDrilldownFromSlide.$inject = [
                "$INJECTABLE$",
                "state",
              ]),
              (PolicyList.prototype.setupWatchers.$inject = [
                "$INJECTABLE$",
                "$scope",
                "policyVWP",
                "policyListViewType",
                "policyListIpVersionFilter",
              ]),
              (PolicyList.prototype.loadData.$inject = [
                "$INJECTABLE$",
                "CMDB",
                "policyStats",
                "policyVWP",
                "$q",
                "policyOmniselectConfig",
                "policyInit",
                "state",
              ]),
              (PolicyList.prototype.setupTableSettings.$inject = [
                "$INJECTABLE$",
                "policyListTableSettings",
                "$scope",
              ]),
              (PolicyList.prototype.loadIssueNotifications.$inject = [
                "$INJECTABLE$",
                "securityAudit",
                "csfTopology",
                "$location",
              ]),
              (PolicyList.prototype.loadPolicies.$inject = [
                "$INJECTABLE$",
                "PolicySource",
                "policyInit",
                "lang",
                "state",
                "policyListViewType",
                "policyListIpVersionFilter",
              ]));
            const POLICY_LOOKUP = { policy: !0 };
            class PolicyListMenu extends inject.Collectable {
              constructor() {
                (super(),
                  (this.MENU_ITEMS_STATS = MENU_ITEMS_STATS),
                  (this.MENU_ITEMS_SEQ = MENU_ITEMS_SEQ));
              }
              $onInit(
                $INJECTABLE$,
                policyStats,
                policyListViewType,
                state,
                policyVWP,
                policyListIpVersionFilter,
                policyInit,
                datetime,
              ) {
                return () => {
                  const type = policyInit.type,
                    subType = policyInit.subType,
                    policyStatsType = this.isHyperscalePolicy()
                      ? "hyperscale-policy"
                      : type;
                  ((this.policyType = type),
                    (this.policyStats = policyStats),
                    (this.policyStatsSupported =
                      policyStats.SUPPORTED[policyStatsType]),
                    (this.viewType = policyListViewType),
                    (this.policyVWP = policyVWP),
                    (this.dialogURI = `/ng/firewall/policy/${type}/${subType}/edit/`),
                    (this.policyLookupSupported =
                      POLICY_LOOKUP[type] &&
                      "standard" === policyInit.subType &&
                      state.getOperationMode() !==
                        state.OPERATION_MODE.TRANSPARENT),
                    (this.ipVersionFilter = policyListIpVersionFilter));
                  const date = datetime
                    .formatDate(Date.now())
                    .replace(/\//g, "_");
                  ((this.filename = `${type}_${subType}_list_${date}`),
                    this.setupWatchers());
                };
              }
              setupWatchers($INJECTABLE$, $routeParams, $scope) {
                return () => {
                  this.ipVersionFilter &&
                    this.ipVersionFilter.supported($routeParams.type) &&
                    $scope.$watch(
                      () => this.listCtrl.settings,
                      (value, previous) => {
                        value &&
                          value !== previous &&
                          this.setupCustomSequenceGrouping();
                      },
                    );
                };
              }
              setupCustomSequenceGrouping() {
                this.listCtrl.settings.sequenceGroupingValueFunction = (
                  entry,
                ) =>
                  (this.listCtrl.settings.customSequenceGrouping &&
                    "both" === this.ipVersionFilter.current.value &&
                    entry.cmdbModel["global-label"]) ||
                  "";
              }
              isHyperscalePolicy($INJECTABLE$, policyInit, state) {
                return () =>
                  state.isFullPolicyOffload() && "policy" === policyInit.type;
              }
              ipVersionFilterSetCurrent(option) {
                ("both" === option.value
                  ? (this.listCtrl.settings.customSequenceGrouping = !0)
                  : (this.listCtrl.settings.customSequenceGrouping = !1),
                  this.ipVersionFilter.setCurrent(option));
              }
              ipVersionFilterSupported() {
                return this.ipVersionFilter.supported(this.policyType);
              }
              policyIncompatibleForLogs($INJECTABLE$, state) {
                return () =>
                  ["acl", "acl6"].includes(this.policyType) ||
                  ("policy" === this.policyType &&
                    (state.isNgfwPolicyMode() || state.isFullPolicyOffload()));
              }
              policyCompatibleForFortiView($INJECTABLE$, state) {
                return () =>
                  ("policy" === this.policyType && !state.isNgfwPolicyMode()) ||
                  "proxy-policy" === this.policyType;
              }
              insertEnabled() {
                return [
                  "policy",
                  "multicast-policy",
                  "proxy-policy",
                  "security-policy",
                  "multicast-policy6",
                ].includes(this.policyType);
              }
              insertSequenceGroupingEnabled($INJECTABLE$, state) {
                return () =>
                  (!state.has_hyperscale_license ||
                    !state.isFullPolicyOffload()) &&
                  (!this.ipVersionFilterSupported() ||
                    (this.ipVersionFilter.current &&
                      "both" === this.ipVersionFilter.current.value));
              }
              cloneReverseEnabled($INJECTABLE$, Omniselect) {
                return function () {
                  let addrs, addr6s;
                  try {
                    ((addrs =
                      Omniselect.getSourceDataSync("firewall.address").mapping),
                      (addr6s =
                        Omniselect.getSourceDataSync(
                          "firewall.address6",
                        ).mapping));
                  } catch (e) {
                    return !1;
                  }
                  const isAny = (obj) => "any" === obj.name,
                    isVIP = (addr) =>
                      (
                        addr.datasource || `${addr.q_path}.${addr.q_name}`
                      ).includes("firewall.vip"),
                    isMacAddress = (addr) => (
                      addr.type ||
                        (addr = addrs[addr.name] || addr6s[addr.name]),
                      "mac" === addr.type
                    ),
                    entry = this.menu.lastSelectedEntry;
                  if (null == entry) return !1;
                  const cmdbPolicy = entry.cmdbModel;
                  var policy;
                  return !(
                    "disable" !== cmdbPolicy.nat ||
                    "enable" === cmdbPolicy.nat64 ||
                    "enable" === cmdbPolicy.nat46 ||
                    "ipsec" === cmdbPolicy.action ||
                    ((policy = cmdbPolicy),
                    policy.srcintf.some(isAny) || policy.dstintf.some(isAny)) ||
                    ((policy) =>
                      (Array.isArray(policy.dstaddr) &&
                        policy.dstaddr.some(isVIP)) ||
                      (Array.isArray(policy.dstaddr6) &&
                        policy.dstaddr6.some(isVIP)))(cmdbPolicy) ||
                    ((policy) =>
                      (Array.isArray(policy.srcaddr) &&
                        policy.srcaddr.some(isMacAddress)) ||
                      (Array.isArray(policy.srcaddr6) &&
                        policy.srcaddr6.some(isMacAddress)))(cmdbPolicy)
                  );
                };
              }
              multiplePoliciesSelected() {
                return this.menu.entries && this.menu.entries.length > 1;
              }
              implicitPolicySelected() {
                return (
                  this.menu.entries &&
                  this.menu.entries.some((entry) => entry.implicit)
                );
              }
              create($INJECTABLE$, $location) {
                return () => {
                  $location.url(this.dialogURI);
                };
              }
              canCreate() {
                return this.listCtrl && !this.listCtrl.slideController;
              }
              isCreateEnabled() {
                return !(
                  this.isHyperscalePolicy() &&
                  this.listCtrl &&
                  this.listCtrl.source &&
                  this.listCtrl.source.getEntriesSize() >= 15e3
                );
              }
              edit($INJECTABLE$, $location) {
                return ($entry) => {
                  $entry.implicit
                    ? $location.url(`${this.dialogURI}implicit`)
                    : $location.url(`${this.dialogURI}${$entry.policyId}`);
                };
              }
              deleteEntries($INJECTABLE$, $http) {
                return (rows) => {
                  this.listCtrl.showLoadingMask();
                  const promises = rows.map((row) => {
                    const entry = row.entry,
                      uri = `/api/v2/cmdb/${entry.cmdbModel.q_path}/${entry.cmdbModel.q_name}/${entry.policyId}`;
                    return $http.delete(uri);
                  });
                  return Promise.all(promises)
                    .then(this._postChangeSuccess, this._postChangeFailure)
                    .finally(() => {
                      this.listCtrl.deleteRows(rows);
                    });
                };
              }
              editCliEnabled($entries) {
                return (
                  $entries &&
                  1 === $entries.length &&
                  $entries[0] &&
                  $entries[0].cmdbModel &&
                  void 0 !== $entries[0].cmdbModel.q_type
                );
              }
              editCli($INJECTABLE$, terminalService) {
                return (entry) =>
                  terminalService.editCMDBObjectInTerminal({
                    path: entry.cmdbModel.q_path,
                    name: entry.cmdbModel.q_name,
                    mkey: entry.cmdbModel.q_origin_key,
                    vdom: entry.cmdbModel.vdom,
                  });
              }
              createEmptyPolicy($INJECTABLE$, PolicyEntry) {
                return (entry) => PolicyEntry.createNewFrom(entry);
              }
              cloneReverse(entry) {
                return entry.reverse();
              }
              saveCMDBEntry(entry) {
                entry
                  .$save()
                  .$promise.then(
                    this._postChangeSuccess,
                    this._postChangeFailure,
                  );
              }
              _postChangeSuccess($INJECTABLE$, lang) {
                return () =>
                  notify.post(lang("changes_saved").toString(), "success");
              }
              _postChangeFailure($INJECTABLE$, lang) {
                return (err) => (
                  notify.post(
                    lang("Failed to save some changes").toString(),
                    "error",
                  ),
                  Promise.reject(err)
                );
              }
              showAuditTrail($INJECTABLE$, state) {
                return () => {
                  const entries = this.menu.entries;
                  return (
                    state.featureVisible("workflow_management") &&
                    state.adminHasReadPermission(
                      state.ACCESS_GROUP.LOG_DATA_ACCESS,
                    ) &&
                    1 === entries.length &&
                    entries[0].cmdbModel &&
                    !entries[0].implicit &&
                    entries[0].isFirewallPolicy() &&
                    (state.isLogDeviceEnabled(state.LOG_DEVICES.DISK) ||
                      state.isLogDeviceEnabled(
                        state.LOG_DEVICES.FORTIANALYZER,
                      ) ||
                      state.isLogDeviceEnabled(
                        state.LOG_DEVICES.FORTIANALYZER_CLOUD,
                      ))
                  );
                };
              }
              openAuditTrail($INJECTABLE$, state, slide) {
                return () => {
                  const entry = this.menu.entries[0];
                  return slide.openAuditTrailSlide({
                    fortigate: state.serial,
                    cmdbPath: `${entry.cmdbModel.q_path}.${entry.cmdbModel.q_name}`,
                    mkey: entry.cmdbModel.q_origin_key,
                    uuid: entry.cmdbModel.uuid,
                  });
                };
              }
              showMatchingLogs(
                $INJECTABLE$,
                logViewerService,
                LogMainType,
                TrafficLogSubType,
                SecurityEventLogSubType,
              ) {
                return () => {
                  const entry = this.menu.entries[0],
                    policyType = entry.isZTNAProxyPolicy()
                      ? "ztna-rule"
                      : this.policyType,
                    uuid = entry.cmdbModel.uuid,
                    mkey = entry.policyId.toString(),
                    briefTrafficFormat =
                      this.listCtrl.logSettings &&
                      "enable" ===
                        this.listCtrl.logSettings["brief-traffic-format"];
                  let logSubType = TrafficLogSubType.Forward;
                  const logMainType = ["DoS-policy", "DoS-policy6"].includes(
                    policyType,
                  )
                    ? LogMainType.Security
                    : LogMainType.Traffic;
                  (logMainType === LogMainType.Security &&
                    (logSubType = SecurityEventLogSubType.Anomaly),
                    ["multicast-policy", "multicast-policy6"].includes(
                      policyType,
                    ) && (logSubType = TrafficLogSubType.Multicast),
                    "ztna-rule" === policyType &&
                      (logSubType = TrafficLogSubType.ZTNA));
                  const filters = {};
                  ("central-snat-map" === policyType
                    ? Object.assign(filters, { centralnatid: { value: mkey } })
                    : uuid && !briefTrafficFormat
                      ? Object.assign(filters, { poluuid: { value: uuid } })
                      : Object.assign(filters, {
                          policyid: { value: mkey },
                          policytype: { value: policyType },
                        }),
                    logViewerService.showMatchingLogs(
                      logMainType,
                      logSubType,
                      filters,
                    ));
                };
              }
              showInFortiview($INJECTABLE$, state, fortiviewService) {
                return () => {
                  const entry = this.menu.entries[0];
                  entry.isZTNAProxyPolicy()
                    ? fortiviewService.drilldownFortiviewZTNAPolicy(
                        entry.cmdbModel["access-proxy"][0].name,
                        { fortigate: state.serial, vdom: state.current_vdom },
                      )
                    : entry.isProxyPolicy()
                      ? fortiviewService.drilldownFortiviewProxyPolicy(
                          entry.policyId,
                          { fortigate: state.serial, vdom: state.current_vdom },
                        )
                      : fortiviewService.drilldownFortiviewPolicy(
                          {
                            policyId: entry.policyId || 0,
                            policyType: entry.cmdbModel.q_name,
                          },
                          { fortigate: state.serial, vdom: state.current_vdom },
                        );
                };
              }
              policyLookup($INJECTABLE$, slide, $rootScope, lang) {
                return function () {
                  const ipVersion = this.ipVersionFilter.current
                      ? this.ipVersionFilter.current.value
                      : "ipv4",
                    title = lang("Policy lookup"),
                    scope = $rootScope.$new(!0);
                  return (
                    (scope.ipVersion = ipVersion),
                    slide
                      .open("F_POLICY_LOOKUP", {
                        template:
                          '<f-policy-lookup\n                                    ip-version="::ipVersion"\n                                    f-read-only-manager>\n                                </f-policy-lookup>',
                        parentScope: scope,
                        options: { fullHeight: !0, title },
                      })
                      .then((policyid) => {
                        this.listCtrl.mutableInstance.locate(
                          (entry) =>
                            Number(entry.cmdbModel.policyid) ===
                            Number(policyid),
                        );
                      })
                      .finally(function () {
                        scope.$destroy();
                      })
                  );
                };
              }
              showClearCounters() {
                return "active_sessions" !== this.menu.targetColumnID;
              }
            }
            return (
              (PolicyListMenu.$inject = []),
              (PolicyListMenu.prototype.$onInit.$inject = [
                "$INJECTABLE$",
                "policyStats",
                "policyListViewType",
                "state",
                "policyVWP",
                "policyListIpVersionFilter",
                "policyInit",
                "datetime",
              ]),
              (PolicyListMenu.prototype.setupWatchers.$inject = [
                "$INJECTABLE$",
                "$routeParams",
                "$scope",
              ]),
              (PolicyListMenu.prototype.policyIncompatibleForLogs.$inject = [
                "$INJECTABLE$",
                "state",
              ]),
              (PolicyListMenu.prototype.policyCompatibleForFortiView.$inject = [
                "$INJECTABLE$",
                "state",
              ]),
              (PolicyListMenu.prototype.create.$inject = [
                "$INJECTABLE$",
                "$location",
              ]),
              (PolicyListMenu.prototype.cloneReverseEnabled.$inject = [
                "$INJECTABLE$",
                "Omniselect",
              ]),
              (PolicyListMenu.prototype.edit.$inject = [
                "$INJECTABLE$",
                "$location",
              ]),
              (PolicyListMenu.prototype.deleteEntries.$inject = [
                "$INJECTABLE$",
                "$http",
              ]),
              (PolicyListMenu.prototype.editCli.$inject = [
                "$INJECTABLE$",
                "terminalService",
              ]),
              (PolicyListMenu.prototype.createEmptyPolicy.$inject = [
                "$INJECTABLE$",
                "PolicyEntry",
              ]),
              (PolicyListMenu.prototype._postChangeSuccess.$inject = [
                "$INJECTABLE$",
                "lang",
              ]),
              (PolicyListMenu.prototype._postChangeFailure.$inject = [
                "$INJECTABLE$",
                "lang",
              ]),
              (PolicyListMenu.prototype.showMatchingLogs.$inject = [
                "$INJECTABLE$",
                "logViewerService",
                "LogMainType",
                "TrafficLogSubType",
                "SecurityEventLogSubType",
              ]),
              (PolicyListMenu.prototype.showInFortiview.$inject = [
                "$INJECTABLE$",
                "state",
                "fortiviewService",
              ]),
              (PolicyListMenu.prototype.policyLookup.$inject = [
                "$INJECTABLE$",
                "slide",
                "$rootScope",
                "lang",
              ]),
              (PolicyListMenu.prototype.showAuditTrail.$inject = [
                "$INJECTABLE$",
                "state",
              ]),
              (PolicyListMenu.prototype.openAuditTrail.$inject = [
                "$INJECTABLE$",
                "state",
                "slide",
              ]),
              (PolicyListMenu.prototype.insertSequenceGroupingEnabled.$inject =
                ["$INJECTABLE$", "state"]),
              (PolicyListMenu.prototype.isHyperscalePolicy.$inject = [
                "$INJECTABLE$",
                "policyInit",
                "state",
              ]),
              (providers, loaderProvider) => (
                providers.$compile.component("fPolicyList", {
                  controller: PolicyList,
                  templateUrl: __webpack_require__(91073),
                  require: { slideController: "?^fSlideContainer" },
                  bindings: {
                    explicitRouteParams: "<routeParams",
                    filter: "<?",
                    type: "<?",
                    subType: "<?",
                  },
                }),
                providers.$compile.component("fPolicyListMenu", {
                  controller: PolicyListMenu,
                  bindings: { menu: "<", listCtrl: "<" },
                  templateUrl: __webpack_require__(89804),
                }),
                loaderProvider.initModules([
                  __webpack_require__(86120),
                  __webpack_require__(18416),
                  __webpack_require__(70255),
                  __webpack_require__(38413),
                  __webpack_require__(40016),
                  __webpack_require__(56225),
                  __webpack_require__(98270),
                  __webpack_require__(54082),
                  __webpack_require__(70922),
                  __webpack_require__(69471),
                  __webpack_require__(43902),
                  __webpack_require__(33623),
                  __webpack_require__(50237),
                  __webpack_require__(75034),
                  __webpack_require__(10910),
                  __webpack_require__(72378),
                  __webpack_require__(22967),
                  __webpack_require__(47616),
                  providers.$injector.get("loadLogViewerService"),
                  providers.$injector.get("loadFortiviewService"),
                ])
              )
            );
          }).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) ||
          (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
    },
    56225: (module, exports, __webpack_require__) => {
      "use strict";
      var __WEBPACK_AMD_DEFINE_RESULT__;
      void 0 ===
        (__WEBPACK_AMD_DEFINE_RESULT__ = function () {
          PolicyListIpVersionFilterFactory.$inject = [
            "policyInit",
            "persistentStorage",
            "state",
          ];
          const SUPPORTED = { policy: !0, "security-policy": !0 },
            BASE_KEY = "policyListIpVersionFilter-";
          function PolicyListIpVersionFilterFactory(
            policyInit,
            persistentStorage,
            state,
          ) {
            return new (class {
              constructor() {
                ((this.OPTION_VALUE = {
                  BOTH: "both",
                  IPV4: "ipv4",
                  IPV6: "ipv6",
                }),
                  (this.options = [
                    { value: this.OPTION_VALUE.BOTH, label: "IPv4 + IPv6" },
                    { value: this.OPTION_VALUE.IPV4, label: "IPv4" },
                    { value: this.OPTION_VALUE.IPV6, label: "IPv6" },
                  ]),
                  (this.current = null));
              }
              update(policyType, subType, vdom) {
                ((this.policyType = policyType || policyInit.type),
                  (this.subType = subType || policyInit.subType),
                  (this.vdom = vdom || state.current_vdom),
                  (this.current = persistentStorage.get(this.storageKey)),
                  this._isValid(this.current) ||
                    this.setCurrent(this.options[0], !0));
              }
              _isValid(filter) {
                return (
                  filter &&
                  this.options.some((option) => option.value === filter.value)
                );
              }
              get storageKey() {
                return `${BASE_KEY}-${this.policyType}-${this.subType}-${this.vdom}`;
              }
              supported(policyType) {
                return (
                  SUPPORTED[policyType || this.policyType] &&
                  state.featureVisible("ipv6")
                );
              }
              setCurrent(filterOption, notPersistent) {
                if (!this._isValid(filterOption))
                  throw new Error(
                    "Invalid policy list IP version filter value",
                  );
                (notPersistent ||
                  persistentStorage.put(this.storageKey, filterOption),
                  (this.current = filterOption));
              }
              hasInternetServiceSrc(cmdbPolicy) {
                if ("enable" !== cmdbPolicy["internet-service-src"]) return !1;
                return [
                  "internet-service-src-name",
                  "internet-service-src-group",
                  "internet-service-src-custom",
                  "internet-service-src-custom-group",
                  "network-service-src-dynamic",
                ].some(
                  (source) =>
                    Array.isArray(cmdbPolicy[source]) &&
                    cmdbPolicy[source].length,
                );
              }
              hasInternetServiceDst(cmdbPolicy) {
                if ("enable" !== cmdbPolicy["internet-service"]) return !1;
                return [
                  "internet-service-name",
                  "internet-service-group",
                  "internet-service-custom",
                  "internet-service-custom-group",
                  "network-service-dynamic",
                ].some(
                  (source) =>
                    Array.isArray(cmdbPolicy[source]) &&
                    cmdbPolicy[source].length,
                );
              }
              isPolicyVisible(cmdbPolicy, policyType) {
                if (!this.current || !this.supported(policyType)) return !0;
                if (this.current.value === this.OPTION_VALUE.BOTH) return !0;
                if (this.current.value === this.OPTION_VALUE.IPV4) {
                  const srcAvailable =
                      (Array.isArray(cmdbPolicy.srcaddr) &&
                        cmdbPolicy.srcaddr.length) ||
                      this.hasInternetServiceSrc(cmdbPolicy),
                    dstAvailable =
                      (Array.isArray(cmdbPolicy.dstaddr) &&
                        cmdbPolicy.dstaddr.length) ||
                      this.hasInternetServiceSrc(cmdbPolicy);
                  return srcAvailable || dstAvailable;
                }
                return (
                  (Array.isArray(cmdbPolicy.srcaddr6) &&
                    cmdbPolicy.srcaddr6.length) ||
                  (Array.isArray(cmdbPolicy.dstaddr6) &&
                    cmdbPolicy.dstaddr6.length)
                );
              }
              clearCache() {
                ((this.current = null),
                  (this.policyType = null),
                  (this.subType = null),
                  (this.vdom = null));
              }
            })();
          }
          return function (providers, loader) {
            return (
              providers.$provide.factory(
                "policyListIpVersionFilter",
                PolicyListIpVersionFilterFactory,
              ),
              loader.initModules([__webpack_require__(35396)])
            );
          };
        }.apply(exports, [])) ||
        (module.exports = __WEBPACK_AMD_DEFINE_RESULT__);
    },
    54082: (module, exports, __webpack_require__) => {
      "use strict";
      var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;
      ((__WEBPACK_AMD_DEFINE_ARRAY__ = [
        __webpack_require__(66695),
        __webpack_require__(26554),
        __webpack_require__(77180),
        __webpack_require__(40108),
      ]),
        void 0 ===
          (__WEBPACK_AMD_DEFINE_RESULT__ = ((
            angular,
            fLog,
            Cloneable,
            formatters,
          ) => {
            PolicyEntryFactory.$inject = [
              "policyStats",
              "policyVWP",
              "policyInit",
              "state",
              "policyOmniselectConfig",
              "ftntCopy",
              "$http",
              "utmProfileConfig",
              "CMDB",
              "policyListIpVersionFilter",
              "Omniselect",
              "slide",
            ];
            const DEFAULT_POLICY_EXPIRY = "0000-00-00 00:00:00",
              POLICY_INTF_KEYS = [
                "srcintf",
                "dstintf",
                "destination",
                "interface",
              ],
              AGGREGATED_ADDR_KEYS = [
                "source",
                "destination",
                "proxy-source",
                "proxy-destination",
                "consolidated-srcaddr",
                "consolidated-dstaddr",
                "consolidated-source",
                "consolidated-destination",
                "security-source",
                "security-srcaddr",
                "security-dstaddr",
                "security-destination",
              ];
            function PolicyEntryFactory(
              policyStats,
              policyVWP,
              policyInit,
              state,
              policyOmniselectConfig,
              ftntCopy,
              $http,
              utmProfileConfig,
              CMDB,
              policyListIpVersionFilter,
              Omniselect,
              slide,
            ) {
              const deepCopy = (srcObj) =>
                  angular.copy(ftntCopy.strip$Properties(srcObj, {})),
                UTM_PROFILE_EDITABLE_COLUMN_IDS = new Set([
                  "av-profile",
                  "emailfilter-profile",
                  "webfilter-profile",
                  "videofilter-profile",
                  "dlp-profile",
                  "file-filter-profile",
                  "dnsfilter-profile",
                  "waf-profile",
                  "application-list",
                  "ips-sensor",
                  "icap-profile",
                  "voip-profile",
                  "profile-group",
                  "profile",
                  "virtual-patch-profile",
                  "casb-profile",
                ]),
                filterIpv4Address = (entry) =>
                  !["firewall.address", "firewall.addrgrp"].includes(
                    entry.datasource,
                  ),
                filterIpv6Address = (entry) =>
                  !["firewall.address6", "firewall.addrgrp6"].includes(
                    entry.datasource,
                  );
              class PolicyEntry extends Cloneable {
                static isVisible(cmdbPolicy) {
                  if (cmdbPolicy.name && cmdbPolicy.name.startsWith("T-"))
                    return !1;
                  if (!cmdbPolicy || "wanopt" === cmdbPolicy.proxy) return !1;
                  const policyType = policyInit.type,
                    subType = policyInit.subType,
                    isZTNAProxyPolicy =
                      "proxy-policy" === policyType &&
                      "access-proxy" === cmdbPolicy.proxy;
                  if (
                    !policyListIpVersionFilter.isPolicyVisible(
                      cmdbPolicy,
                      policyType,
                    )
                  )
                    return !1;
                  if (
                    "proxy-policy" === policyType &&
                    "ztna" === subType &&
                    "access-proxy" !== cmdbPolicy.proxy
                  )
                    return !1;
                  if (!state.featureVisible("ipv6")) {
                    if (
                      "central-snat-map" === policyType &&
                      ("ipv6" === cmdbPolicy.type ||
                        ("enable" === cmdbPolicy.nat &&
                          "enable" === cmdbPolicy.nat46))
                    )
                      return !1;
                    if (
                      !(
                        "proxy-policy" !== policyType ||
                        (Array.isArray(cmdbPolicy.srcaddr) &&
                          cmdbPolicy.srcaddr.length) ||
                        (Array.isArray(cmdbPolicy.dstaddr) &&
                          cmdbPolicy.dstaddr.length)
                      )
                    )
                      return !1;
                    if (
                      !(
                        ("policy" !== policyType &&
                          "security-policy" !== policyType) ||
                        (Array.isArray(cmdbPolicy.srcaddr) &&
                          cmdbPolicy.srcaddr.length) ||
                        policyListIpVersionFilter.hasInternetServiceSrc(
                          cmdbPolicy,
                        )
                      )
                    )
                      return !1;
                  }
                  let visible = !0;
                  return (
                    isZTNAProxyPolicy ||
                      POLICY_INTF_KEYS.some((key) => {
                        let interfaces = cmdbPolicy[key];
                        return (
                          interfaces &&
                            ((interfaces = Array.isArray(interfaces)
                              ? interfaces
                              : [interfaces]),
                            (visible =
                              "virtual-wire" === subType
                                ? policyVWP.matchCurrentVWP(
                                    interfaces.map((intf) => intf.name),
                                  )
                                : interfaces.some((intf) => {
                                    try {
                                      const mapping =
                                        Omniselect.getSourceDataSync(
                                          "firewallInterfaces",
                                        ).mapping;
                                      visible =
                                        !mapping[intf.q_origin_key]
                                          .is_virtual_wire_pair_member ||
                                        !policyVWP.SUPPORTED[policyType];
                                    } catch (e) {
                                      fLog.warn(
                                        `Firewall interfaces cannot be accessed for ${e.message}`,
                                      );
                                    }
                                    return visible;
                                  }))),
                          visible
                        );
                      }),
                    visible
                  );
                }
                static createNewFrom(policyEntry) {
                  let newCmdbModel = Object.assign(
                    {},
                    policyInit.BASE_POLICY,
                    policyInit.BASE_POLICY_ADDRESSES[policyEntry.policyType],
                    {
                      srcintf: policyEntry.cmdbModel.srcintf,
                      dstintf: policyEntry.cmdbModel.dstintf,
                    },
                  );
                  return (
                    "proxy-policy" === policyEntry.policyType &&
                      ((newCmdbModel.proxy =
                        policyEntry.cmdbModel.proxy || "explicit-web"),
                      (newCmdbModel.service = [
                        {
                          name: "webproxy",
                          q_origin_key: "webproxy",
                          datasource: "firewall.service.custom",
                        },
                      ]),
                      "access-proxy" === newCmdbModel.proxy &&
                        (Array.isArray(policyEntry.cmdbModel["ztna-ems-tag"]) &&
                          (newCmdbModel["ztna-ems-tag"] = policyEntry.cmdbModel[
                            "ztna-ems-tag"
                          ].map((tag) => Object.assign({}, tag))),
                        Array.isArray(policyEntry.cmdbModel["access-proxy"]) &&
                          (newCmdbModel["access-proxy"] = policyEntry.cmdbModel[
                            "access-proxy"
                          ].map((accessProxy) =>
                            Object.assign({}, accessProxy),
                          )),
                        Array.isArray(policyEntry.cmdbModel["access-proxy6"]) &&
                          policyEntry.cmdbModel["access-proxy6"].length &&
                          ((newCmdbModel["access-proxy6"] =
                            policyEntry.cmdbModel["access-proxy6"].map(
                              (accessProxy) => Object.assign({}, accessProxy),
                            )),
                          Object.assign(newCmdbModel, {
                            srcaddr6: [
                              {
                                name: "all",
                                datasource: "firewall.address6",
                                "css-class": "ftnt-address-ipv6",
                                q_origin_key: "all",
                              },
                            ],
                            dstaddr6: [
                              {
                                name: "all",
                                datasource: "firewall.address6",
                                "css-class": "ftnt-address-ipv6",
                                q_origin_key: "all",
                              },
                            ],
                          })))),
                    (newCmdbModel.status = "disable"),
                    (newCmdbModel.action = "accept"),
                    (newCmdbModel.q_path = policyEntry.cmdbModel.q_path),
                    (newCmdbModel.q_name = policyEntry.cmdbModel.q_name),
                    (newCmdbModel["policy-expiry"] =
                      policyEntry.cmdbModel["policy-expiry"]),
                    state.featureVisible("ipv6") ||
                      ((newCmdbModel.srcaddr6 = []),
                      (newCmdbModel.dstaddr6 = [])),
                    new PolicyEntry(newCmdbModel)
                  );
                }
                constructor(rawEntry, params = {}) {
                  (super(), (this.cmdbModel = rawEntry));
                  const original = deepCopy(rawEntry);
                  ((this.cmdbModel.$original = original),
                    (this.cmdbModel.$$original = original),
                    (this.implicit = rawEntry.implicit || !1),
                    (this.policyType = policyInit.type),
                    this._init(params));
                }
                clone() {
                  let cloned = new PolicyEntry(deepCopy(this.cmdbModel));
                  return (
                    (cloned._originalLabel =
                      this.policyLabel || this._originalLabel),
                    cloned
                  );
                }
                _handleAny() {
                  if (
                    ["multicast-policy", "multicast-policy6"].includes(
                      this.policyType,
                    )
                  )
                    for (let intf of ["srcintf", "dstintf"])
                      "any" === this.cmdbModel[intf] &&
                        (this.cmdbModel[intf] = {
                          name: "any",
                          q_origin_key: "any",
                          datasource: "system.interface",
                        });
                }
                _init(params = {}) {
                  ((this.URI = `/api/v2/cmdb/${this.cmdbModel.q_path}/${this.cmdbModel.q_name}`),
                    (this._editMeta = null),
                    this.updatePolicyStats(),
                    this.implicit && this._setupLogSetting(),
                    this.isProxyPolicy() &&
                      this._setupListenOnInterfaces(params.listenOnInterfaces),
                    this._handleAny(),
                    this._handleLearningMode(),
                    this._handleZtnaPolicyMode(),
                    this.setupWarnings());
                }
                _handleLearningMode() {
                  "security-policy" === this.policyType &&
                    "enable" === this.cmdbModel["learning-mode"] &&
                    (this.cmdbModel =
                      policyInit.updateLearningModeSecurityPolicy(
                        this.cmdbModel,
                      ));
                }
                _handleZtnaPolicyMode() {
                  this.isZTNAFirewallPolicy() &&
                    (this._setupZtnaVipMap(),
                    this._updateZtnaVipPolicyDstaddrForGUI());
                }
                _setupListenOnInterfaces(listenOnInterfaces = {}) {
                  let srcintf = this.cmdbModel.srcintf;
                  (!srcintf ||
                    (Array.isArray(srcintf) && 0 === srcintf.length)) &&
                    Array.isArray(listenOnInterfaces[this.cmdbModel.proxy]) &&
                    (this.cmdbModel.srcintf =
                      listenOnInterfaces[this.cmdbModel.proxy]);
                }
                _updateZtnaVipPolicyDstaddrForGUI() {
                  const processZtnaDestinationDatasource = (
                    newDatasource,
                    address,
                  ) => {
                    const updatedAddr = Object.assign({}, address);
                    return (
                      this.ztnaVipMap[address.q_origin_key] &&
                        (updatedAddr.datasource = newDatasource),
                      updatedAddr
                    );
                  };
                  (Array.isArray(this.cmdbModel.dstaddr) &&
                    (this.cmdbModel.dstaddr = this.cmdbModel.dstaddr.map(
                      (addr) =>
                        processZtnaDestinationDatasource("ztna-vip", addr),
                    )),
                    state.featureVisible("ipv6") &&
                      Array.isArray(this.cmdbModel.dstaddr6) &&
                      (this.cmdbModel.dstaddr6 = this.cmdbModel.dstaddr6.map(
                        (addr) =>
                          processZtnaDestinationDatasource("ztna-vip6", addr),
                      )));
                }
                _updateZtnaVipPolicyDstaddrForCMDB() {
                  const processZtnaVipDatasource = (
                    entry,
                    ztnaDatasource,
                    vipDatasource,
                  ) => {
                    const updatedEntry = Object.assign({}, entry);
                    return (
                      updatedEntry.datasource === ztnaDatasource &&
                        (updatedEntry.datasource = vipDatasource),
                      updatedEntry
                    );
                  };
                  (Array.isArray(this.cmdbModel.dstaddr) &&
                    (this.cmdbModel.dstaddr = this.cmdbModel.dstaddr.map(
                      (entry) =>
                        processZtnaVipDatasource(
                          entry,
                          "ztna-vip",
                          "firewall.vip",
                        ),
                    )),
                    state.featureVisible("ipv6") &&
                      Array.isArray(this.cmdbModel.dstaddr6) &&
                      (this.cmdbModel.dstaddr6 = this.cmdbModel.dstaddr6.map(
                        (entry) =>
                          processZtnaVipDatasource(
                            entry,
                            "ztna-vip6",
                            "firewall.vip6",
                          ),
                      )));
                }
                _updateZtnaPolicyDstaddrForGUI() {
                  (Array.isArray(this.cmdbModel.dstaddr) &&
                    (this.cmdbModel.dstaddr = this.cmdbModel.dstaddr.map(
                      (addr) => {
                        const updatedAddr = Object.assign({}, addr),
                          ztnaServers =
                            this.ztnaServerVipMaps[addr.q_origin_key],
                          vdom =
                            (state.vdom_mode && state.current_vdom) || void 0,
                          ztnaServer =
                            Array.isArray(ztnaServers) &&
                            ztnaServers.find((zs) => !vdom || zs.vdom === vdom);
                        return (
                          ztnaServer &&
                            ((updatedAddr.name = ztnaServer.name),
                            (updatedAddr.q_origin_key =
                              ztnaServer.q_origin_key),
                            (updatedAddr.datasource = "ztna-servers")),
                          updatedAddr
                        );
                      },
                    )),
                    state.featureVisible("ipv6") &&
                      Array.isArray(this.cmdbModel.dstaddr6) &&
                      (this.cmdbModel.dstaddr6 = this.cmdbModel.dstaddr6.map(
                        (addr) => {
                          const updatedAddr = Object.assign({}, addr),
                            ztnaServers =
                              this.ztnaServerVipMaps[addr.q_origin_key],
                            vdom =
                              (state.vdom_mode && state.current_vdom) || void 0,
                            ztnaServer =
                              Array.isArray(ztnaServers) &&
                              ztnaServers.find(
                                (zs) => !vdom || zs.vdom === vdom,
                              );
                          return (
                            ztnaServer &&
                              ((updatedAddr.name = ztnaServer.name),
                              (updatedAddr.q_origin_key =
                                ztnaServer.q_origin_key),
                              (updatedAddr.datasource = "ztna-servers6")),
                            updatedAddr
                          );
                        },
                      )));
                }
                _updateZtnaPolicyDstaddrForCMDB() {
                  if (Array.isArray(this.cmdbModel.dstaddr)) {
                    const mapping =
                      Omniselect.getSourceDataSync("ztna-servers").mapping;
                    this.cmdbModel.dstaddr = this.cmdbModel.dstaddr.map(
                      (entry) => {
                        const ztnaServer = mapping[entry.q_origin_key];
                        return ztnaServer && ztnaServer.$vip
                          ? ztnaServer.$vip
                          : entry;
                      },
                    );
                  }
                  if (
                    state.featureVisible("ipv6") &&
                    Array.isArray(this.cmdbModel.dstaddr)
                  ) {
                    const mapping =
                      Omniselect.getSourceDataSync("ztna-servers").mapping;
                    this.cmdbModel.dstaddr6 = this.cmdbModel.dstaddr6.map(
                      (entry) => {
                        const ztnaServer = mapping[entry.q_origin_key];
                        return ztnaServer && ztnaServer.$vip
                          ? ztnaServer.$vip
                          : entry;
                      },
                    );
                  }
                }
                _setupLogSetting() {
                  const logSettingCMDB = new CMDB("log", "setting");
                  this.logSetting = logSettingCMDB.fetch();
                }
                isZtnaServerUpdate(column) {
                  return (
                    "proxy-policy" === this.policyType &&
                    column &&
                    "access-proxy" === column.id
                  );
                }
                _sortAccessProxyEntries(newValue) {
                  ((this.cmdbModel["access-proxy"] = []),
                    (this.cmdbModel["access-proxy6"] = []),
                    newValue.forEach((ap) => {
                      "access-proxy" === ap.q_name
                        ? this.cmdbModel["access-proxy"].push(ap)
                        : this.cmdbModel["access-proxy6"].push(ap);
                    }));
                }
                _preSaveSecurityPolicy() {
                  Array.isArray(this.cmdbModel["url-category"]) &&
                    (this.cmdbModel["url-category"] =
                      this.cmdbModel["url-category"]
                        .map((cat) => cat.id)
                        .join(" ") || null);
                }
                isNafSourceUpdate(column) {
                  return (
                    this.isNafEnabled &&
                    column &&
                    "consolidated-source" === column.id
                  );
                }
                isNafDestinationUpdate(column) {
                  return (
                    this.isNafEnabled &&
                    column &&
                    "consolidated-destination" === column.id
                  );
                }
                updateNafSource() {
                  const key =
                    "enable" === this.cmdbModel.nat46 ? "srcaddr6" : "srcaddr";
                  this.cmdbModel[key] = this.cmdbModel.$$original[key];
                }
                updateNafDestination() {
                  const key =
                    "enable" === this.cmdbModel.nat46 ? "dstaddr6" : "dstaddr";
                  this.cmdbModel[key] = this.cmdbModel.$$original[key];
                }
                _profileIsDeepInspection(profile) {
                  const sslProtocols = [
                    "https",
                    "smtps",
                    "ftps",
                    "imaps",
                    "pop3s",
                  ];
                  if (profile && profile.ssl) {
                    const ssl = profile.ssl;
                    if (ssl)
                      return (
                        "deep-inspection" === ssl["inspect-all"] ||
                        ("disable" === ssl["inspect-all"] &&
                          sslProtocols.some(
                            (proto) =>
                              profile[proto] &&
                              "deep-inspection" === profile[proto].status,
                          ))
                      );
                  }
                  return !1;
                }
                async preSave(row, column) {
                  if (!row || !column) return;
                  const original = angular.copy(this.cmdbModel.$original);
                  "profile" === column.id &&
                    original["videofilter-profile"] &&
                    !this.cmdbModel["videofilter-profile"] &&
                    this.cmdbModel["ssl-ssh-profile"] &&
                    !this._profileIsDeepInspection(
                      this.cmdbModel["ssl-ssh-profile"],
                    ) &&
                    ((original["videofilter-profile"] = ""),
                    await this._save(original));
                }
                _save(model, changeSummary) {
                  let $req = $http.post,
                    uri = this.URI;
                  const mkey = this.policyId;
                  return (
                    mkey && ((uri = `${uri}/${mkey}`), ($req = $http.put)),
                    changeSummary && (uri += `?changeSummary=${changeSummary}`),
                    $req(uri, ftntCopy.strip$Properties(model, {}))
                  );
                }
                edit(row, column, newValue, changeSummary) {
                  try {
                    return (
                      this.isZTNAFirewallPolicy() &&
                        this._updateZtnaVipPolicyDstaddrForCMDB(),
                      this.isExternalDataUpdate(column)
                        ? this.updateExternalData(column, newValue)
                        : (this.isNafDestinationUpdate(column) &&
                            this.updateNafDestination(),
                          this.isNafSourceUpdate(column) &&
                            this.updateNafSource(),
                          this.isZtnaServerUpdate(column) &&
                            this._sortAccessProxyEntries(newValue),
                          this.isSecurityPolicy() &&
                            this._preSaveSecurityPolicy(column, newValue),
                          this.preSave(row, column)
                            .then(() =>
                              this._save(this.cmdbModel, changeSummary),
                            )
                            .then((result) => {
                              this._editMeta = result.data;
                            }))
                    );
                  } catch (e) {
                    return (
                      fLog.error(
                        `Editing policy entry failed for ${e.message}.`,
                      ),
                      Promise.reject()
                    );
                  }
                }
                reverse() {
                  (this.prepareCopiedPolicy("Reverse of "),
                    this.policyExpired() && this.removeExpirationConfig());
                  const dstAddr = this.cmdbModel.dstaddr;
                  if (
                    ((this.cmdbModel.dstaddr = this.cmdbModel.srcaddr),
                    (this.cmdbModel.srcaddr = dstAddr),
                    this.cmdbModel.srcaddr6 && this.cmdbModel.dstaddr6)
                  ) {
                    const dstAddr6 = this.cmdbModel.dstaddr6;
                    ((this.cmdbModel.dstaddr6 = this.cmdbModel.srcaddr6),
                      (this.cmdbModel.srcaddr6 = dstAddr6));
                  }
                  const dstAddrNegate = this.cmdbModel["dstaddr-negate"];
                  ((this.cmdbModel["dstaddr-negate"] =
                    this.cmdbModel["srcaddr-negate"]),
                    (this.cmdbModel["srcaddr-negate"] = dstAddrNegate));
                  const dstIntf = this.cmdbModel.dstintf;
                  ((this.cmdbModel.dstintf = this.cmdbModel.srcintf),
                    (this.cmdbModel.srcintf = dstIntf));
                  return (
                    ["users", "groups"].forEach((key) => {
                      this.cmdbModel[key] = null;
                    }),
                    this
                  );
                }
                async processUpdatedEntry() {
                  let entry = this;
                  if (
                    this._editMeta &&
                    ["POST", "PUT"].includes(this._editMeta.http_method)
                  ) {
                    const mkey = this._editMeta.mkey,
                      uri = `${this.URI}/${mkey}`,
                      updatedEntry = (
                        await $http.post(
                          uri,
                          {
                            datasource_format: {
                              "system.external-resource": "type",
                            },
                          },
                          {
                            params: {
                              skip: !this.isZTNAProxyPolicy(),
                              datasource: 1,
                              with_meta: 1,
                            },
                            headers: { "X-HTTP-Method-Override": "GET" },
                          },
                        )
                      ).data.results[0];
                    Object.assign(entry.cmdbModel, updatedEntry);
                  }
                  return (
                    (this._editMeta = null),
                    this.updatePolicyStats(),
                    this.setupWarnings(),
                    this._handleAny(),
                    this._handleZtnaPolicyMode(),
                    entry
                  );
                }
                isInterfacesSectionable() {
                  function interfacesSectionable(interfaces) {
                    let sectionable = !0;
                    return (
                      interfaces &&
                        (Array.isArray(interfaces) ||
                          (interfaces = [interfaces]),
                        (sectionable = 1 === interfaces.length)),
                      sectionable
                    );
                  }
                  const srcSectionable = interfacesSectionable(
                      this.cmdbModel.srcintf,
                    ),
                    destSectionable = interfacesSectionable(
                      this.cmdbModel.dstintf,
                    );
                  return !!(
                    this.implicit ||
                    (srcSectionable && destSectionable)
                  );
                }
                processExternalResource(addrs, originalKey) {
                  let parsed = addrs;
                  const SUPPORTED_POLICY_TYPES = [
                    "policy",
                    "proxy-policy",
                    "security-policy",
                  ];
                  return (
                    Array.isArray(addrs) &&
                      (parsed = addrs.map((addr) => {
                        if (PolicyEntry.isExternalResource(addr))
                          if (
                            SUPPORTED_POLICY_TYPES.includes(this.policyType)
                          ) {
                            const ipSuffix = originalKey.includes("addr6")
                              ? "6"
                              : "";
                            addr.datasource = `${addr.datasource}.${addr.type}${ipSuffix}`;
                          } else
                            fLog.warn(
                              `Unsupported policy type "${this.policyType}" for external-resource`,
                            );
                        return addr;
                      })),
                    parsed
                  );
                }
                processApplications(apps, originalKey) {
                  let parsed = apps;
                  const customAppMap =
                    Omniselect.getSourceDataSync("application.custom").mapping;
                  switch (originalKey) {
                    case "application":
                      parsed = apps.map((app) => {
                        const isCustomApp = customAppMap[app.q_origin_key];
                        return (
                          (app.datasource = isCustomApp
                            ? "application.custom"
                            : "application.name"),
                          app
                        );
                      });
                      break;
                    case "app-category":
                      parsed = apps.map(
                        (app) => (
                          (app.datasource = "application.category"),
                          app
                        ),
                      );
                      break;
                    case "app-group":
                      parsed = apps.map(
                        (app) => ((app.datasource = "application.group"), app),
                      );
                      break;
                    default:
                      throw new Error("Unsupported application property key");
                  }
                  return parsed;
                }
                processSecurityProfiles(profile, originalKey) {
                  let parsed = profile;
                  return (
                    utmProfileConfig.visible(this.cmdbModel, originalKey) ||
                      (parsed = []),
                    parsed
                  );
                }
                _getAggregateValues(aggregateKey, originalKey) {
                  const values = this.cmdbModel[originalKey];
                  let parsed;
                  if (
                    (AGGREGATED_ADDR_KEYS.includes(aggregateKey) &&
                      (parsed = this.processExternalResource(
                        values,
                        originalKey,
                      )),
                    "applications" === aggregateKey)
                  )
                    try {
                      parsed = this.processApplications(values, originalKey);
                    } catch (e) {
                      fLog.warn(
                        `Failed to process applications for ${e.message}`,
                      );
                    }
                  return (
                    "profile" !== aggregateKey ||
                      state.featureVisible("vpn_firewall_only") ||
                      (parsed = this.processSecurityProfiles(
                        values,
                        originalKey,
                      )),
                    parsed || values
                  );
                }
                _aggregateOmniselectModel(aggregateKey) {
                  let values = [];
                  return (
                    policyOmniselectConfig
                      .splitKeys(aggregateKey)
                      .forEach((key) => {
                        if (this.cmdbModel.hasOwnProperty(key)) {
                          const _values = this._getAggregateValues(
                            aggregateKey,
                            key,
                          );
                          values = values.concat(_values);
                        }
                      }),
                    values
                  );
                }
                _splitAggregatedValues(aggregateKey, values, singleSelect) {
                  let parsed = policyOmniselectConfig.splitValues(
                    aggregateKey,
                    values,
                    singleSelect,
                  );
                  return (
                    "profile" === aggregateKey &&
                      (parsed = Object.keys(parsed).reduce(
                        (_parsed, key) => (
                          utmProfileConfig.visible(this.cmdbModel, key) &&
                            (_parsed[key] = parsed[key]),
                          _parsed
                        ),
                        {},
                      )),
                    parsed
                  );
                }
                _overrideFallbackKey(key) {
                  return (
                    ["poolname", "consolidated-poolname"].includes(key) &&
                      (key = "nat"),
                    "service" === key && (key = "enforce-default-app-port"),
                    key
                  );
                }
                _updateCmdbProperty(key, newValue, isFallback) {
                  let policy = this.cmdbModel;
                  newValue &&
                  policy[key] &&
                  newValue.hasOwnProperty("q_origin_key") &&
                  newValue.q_origin_key === policy[key].q_origin_key
                    ? Object.assign(policy[key], newValue)
                    : (isFallback && (key = this._overrideFallbackKey(key)),
                      (policy[key] = newValue));
                }
                _updateSplitCmdbProperties(updated) {
                  Object.keys(updated).forEach((key) => {
                    this._updateCmdbProperty(key, updated[key]);
                  });
                }
                noSslInspection() {
                  return (
                    (this.isProxyPolicy() && "ftp" === this.cmdbModel.proxy) ||
                    this.isSecurityPolicy()
                  );
                }
                _urlCategoryToSelect(
                  urlCategory,
                  localCategories,
                  externalCategories,
                ) {
                  let datasource = "webfilter.ftgd-cat";
                  return (
                    "string" === urlCategory && urlCategory.startsWith("g")
                      ? (datasource = "webfilter.ftgd-cat.group")
                      : localCategories[urlCategory]
                        ? (datasource = "webfilter.ftgd-local-cat")
                        : externalCategories[urlCategory] &&
                          (datasource = "system.external-resource.category"),
                    { q_origin_key: urlCategory, id: urlCategory, datasource }
                  );
                }
                get source() {
                  return (
                    this._source ||
                      (this._source = this._aggregateOmniselectModel("source")),
                    this._source
                  );
                }
                get destination() {
                  return (
                    this._destination ||
                      (this._destination =
                        this._aggregateOmniselectModel("destination")),
                    this._destination
                  );
                }
                get proxySource() {
                  return (
                    this["_proxy-source"] ||
                      (this["_proxy-source"] =
                        this._aggregateOmniselectModel("proxy-source")),
                    this["_proxy-source"]
                  );
                }
                get proxyDestination() {
                  return (
                    this["_proxy-destination"] ||
                      (this["_proxy-destination"] =
                        this._aggregateOmniselectModel("proxy-destination")),
                    this["_proxy-destination"]
                  );
                }
                get applications() {
                  return (
                    this._applications ||
                      (this._applications =
                        this._aggregateOmniselectModel("applications")),
                    this._applications
                  );
                }
                get urlCategory() {
                  if (!this._urlCategory)
                    try {
                      const localFtgdCatMap =
                          Omniselect.getSourceDataSync(
                            "webfilter.ftgd-local-cat",
                          ).alternativeMappings.id || {},
                        externalFtgdCats = state.isNgfwPolicyMode()
                          ? Omniselect.getSourceDataSync(
                              "system.external-resource.category",
                            ).mapping
                          : {},
                        cmdbModelCategory = this.cmdbModel["url-category"];
                      ((this._urlCategory = []),
                        "string" == typeof cmdbModelCategory
                          ? (this._urlCategory = (cmdbModelCategory || "")
                              .split(" ")
                              .filter((cat) => cat)
                              .map((cat) => String(cat).toLowerCase())
                              .map((urlCat) =>
                                this._urlCategoryToSelect(
                                  urlCat,
                                  localFtgdCatMap,
                                  externalFtgdCats,
                                ),
                              ))
                          : Array.isArray(cmdbModelCategory) &&
                            (this._urlCategory = (cmdbModelCategory || []).map(
                              (url) =>
                                this._urlCategoryToSelect(
                                  url.id,
                                  localFtgdCatMap,
                                  externalFtgdCats,
                                ),
                            )));
                    } catch (e) {
                      fLog.warn(
                        `Failed to process URL categories for ${e.message}`,
                      );
                    }
                  return this._urlCategory;
                }
                get profile() {
                  return ["accept", "ipsec"].includes(this.cmdbModel.action)
                    ? this.noSslInspection() ||
                      "enable" === this.cmdbModel["utm-status"]
                      ? (this._profile ||
                          ("single" === this.cmdbModel["profile-type"]
                            ? (this._profile =
                                this._aggregateOmniselectModel("profile"))
                            : (this._profile = [
                                this.cmdbModel["profile-group"],
                              ])),
                        this._profile)
                      : [this.cmdbModel["ssl-ssh-profile"]]
                    : [];
                }
                get videoFilter() {
                  return this.profile.find(
                    (profile) => "videofilter.profile" === profile.datasource,
                  );
                }
                get dlp() {
                  return this.profile.find(
                    (profile) => "dlp.profile" === profile.datasource,
                  );
                }
                get sslSshProfile() {
                  return this.profile.find(
                    (profile) =>
                      "firewall.ssl-ssh-profile" === profile.datasource,
                  );
                }
                get action() {
                  return this.cmdbModel.action;
                }
                get policyId() {
                  return (
                    this.cmdbModel.q_origin_key ||
                    this.cmdbModel.policyid ||
                    this.cmdbModel.id ||
                    0
                  );
                }
                get policyLabel() {
                  return this.cmdbModel.name || this.policyId;
                }
                get isNatDisabled() {
                  return "multicast-policy" === this.policyType
                    ? "disable" === this.cmdbModel.snat
                    : "policy" === this.policyType
                      ? "disable" === this.cmdbModel.nat &&
                        "disable" === this.cmdbModel.nat64 &&
                        "disable" === this.cmdbModel.nat46
                      : "disable" === this.cmdbModel.nat;
                }
                get isNafEnabled() {
                  return (
                    "enable" === this.cmdbModel.nat64 ||
                    "enable" === this.cmdbModel.nat46
                  );
                }
                get hasDestinationAddress() {
                  return (
                    !(
                      !this.cmdbModel.dstaddr || !this.cmdbModel.dstaddr.length
                    ) ||
                    !(
                      !this.cmdbModel.dstaddr6 ||
                      !this.cmdbModel.dstaddr6.length
                    )
                  );
                }
                get consolidatedSource() {
                  return (
                    this._consolidatedSource ||
                      ((this._consolidatedSource =
                        this._aggregateOmniselectModel("consolidated-source")),
                      "enable" === this.cmdbModel.nat64
                        ? (this._consolidatedSource =
                            this._consolidatedSource.filter(filterIpv4Address))
                        : "enable" === this.cmdbModel.nat46 &&
                          (this._consolidatedSource =
                            this._consolidatedSource.filter(
                              filterIpv6Address,
                            ))),
                    this._consolidatedSource
                  );
                }
                get consolidatedSourceAddress() {
                  return (
                    this._consolidatedSourceAddress ||
                      (this._consolidatedSourceAddress =
                        this._aggregateOmniselectModel("consolidated-srcaddr")),
                    this._consolidatedSourceAddress
                  );
                }
                get consolidatedDestination() {
                  return (
                    this._consolidatedDestination ||
                      ((this._consolidatedDestination =
                        this._aggregateOmniselectModel(
                          "consolidated-destination",
                        )),
                      "enable" === this.cmdbModel.nat64
                        ? (this._consolidatedDestination =
                            this._consolidatedDestination.filter(
                              filterIpv4Address,
                            ))
                        : "enable" === this.cmdbModel.nat46 &&
                          (this._consolidatedDestination =
                            this._consolidatedDestination.filter(
                              filterIpv6Address,
                            ))),
                    this._consolidatedDestination
                  );
                }
                get consolidatedDestinationAddress() {
                  return (
                    this._consolidatedDestinationAddress ||
                      (this._consolidatedDestinationAddress =
                        this._aggregateOmniselectModel("consolidated-dstaddr")),
                    this._consolidatedDestinationAddress
                  );
                }
                get consolidatedPoolname() {
                  return (
                    this._consolidatedPoolname ||
                      (this._consolidatedPoolname =
                        this._aggregateOmniselectModel(
                          "consolidated-poolname",
                        )),
                    this._consolidatedPoolname
                  );
                }
                get securitySource() {
                  return (
                    this._ngfwSource ||
                      (this._ngfwSource =
                        this._aggregateOmniselectModel("security-source")),
                    this._ngfwSource
                  );
                }
                get securitySourceAddress() {
                  return (
                    this._ngfwSourceAddress ||
                      (this._ngfwSourceAddress =
                        this._aggregateOmniselectModel("security-srcaddr")),
                    this._ngfwSourceAddress
                  );
                }
                get securityDestination() {
                  return (
                    this._ngfwDestination ||
                      (this._ngfwDestination = this._aggregateOmniselectModel(
                        "security-destination",
                      )),
                    this._ngfwDestination
                  );
                }
                get securityDestinationAddress() {
                  return (
                    this._ngfwDestinationAddress ||
                      (this._ngfwDestinationAddress =
                        this._aggregateOmniselectModel("security-dstaddr")),
                    this._ngfwDestinationAddress
                  );
                }
                getFirstUsed(stats = this.stats) {
                  if (stats && (stats.cgn_first_used || stats.first_used))
                    return (
                      1e3 *
                      (Math.min(stats.first_used, stats.cgn_first_used) ||
                        stats.first_used ||
                        stats.cgn_first_used)
                    );
                }
                getLastUsed(stats = this.stats) {
                  if (stats && (stats.cgn_last_used || stats.last_used))
                    return (
                      1e3 *
                      (Math.max(stats.last_used, stats.cgn_last_used) ||
                        stats.last_used ||
                        stats.cgn_last_used)
                    );
                }
                getHitCount(stats = this.stats) {
                  if (stats) {
                    let hitCount = 0;
                    if (stats) {
                      const cgnCount = stats.cgn_hit_count || 0;
                      hitCount = (stats.hit_count || 0) + cgnCount;
                    }
                    return hitCount;
                  }
                }
                getBytes(stats = this.stats) {
                  const { bytes, cgn_bytes } = stats || {};
                  return (bytes || 0) + (cgn_bytes || 0);
                }
                getPackets(stats = this.stats) {
                  const { packets, cgn_packets } = stats || {};
                  return (packets || 0) + (cgn_packets || 0);
                }
                getSoftwareUsage(stats = this.stats) {
                  const { software_bytes } = stats || {};
                  return formatters.percentage(
                    software_bytes || 0,
                    this.getBytes(this.stats),
                  );
                }
                getAsicUsage(stats = this.stats) {
                  const { asic_bytes } = stats || {};
                  return formatters.percentage(
                    asic_bytes || 0,
                    this.getBytes(this.stats),
                  );
                }
                getNturboUsage(stats = this.stats) {
                  const { nturbo_bytes } = stats || {};
                  return formatters.percentage(
                    nturbo_bytes || 0,
                    this.getBytes(this.stats),
                  );
                }
                getCgnUsage(stats = this.stats) {
                  const { cgn_bytes } = stats || {};
                  return formatters.percentage(
                    cgn_bytes || 0,
                    this.getBytes(this.stats),
                  );
                }
                updateAggregatedProperty(row, column, newEntryValue) {
                  const selectSettings = row
                      .getCellValueSync(column)
                      .getEditingSettings(),
                    updated = this._splitAggregatedValues(
                      column.id,
                      newEntryValue,
                      selectSettings.singleSelect || selectSettings.allSolitary,
                    );
                  (this._updateSplitCmdbProperties(updated),
                    (this[`_${column.id}`] = newEntryValue));
                }
                _updateOmniselectValue(row, column, newEntryValue) {
                  const key = column.id,
                    selectSettings = row
                      .getCellValueSync(column)
                      .getEditingSettings();
                  policyOmniselectConfig.VALUE_SPLIT_MAP[column.id]
                    ? this.updateAggregatedProperty(row, column, newEntryValue)
                    : selectSettings.singleSelect &&
                        !Array.isArray(this.cmdbModel[key])
                      ? this._updateCmdbProperty(key, newEntryValue[0] || null)
                      : this._updateCmdbProperty(key, newEntryValue);
                }
                _getEntryDatasource(entry) {
                  return entry.datasource || `${entry.q_path}.${entry.q_name}`;
                }
                _utmStatusHidden() {
                  return this.isSecurityPolicy();
                }
                _getCurrentSecurityProfileCount() {
                  let count = 0;
                  return (
                    UTM_PROFILE_EDITABLE_COLUMN_IDS.forEach((profile) => {
                      const cmdbProfileLength = this.cmdbModel[profile] ? 1 : 0;
                      count += cmdbProfileLength;
                    }),
                    count
                  );
                }
                _updateUtmStatus(column, newEntryValue) {
                  if (
                    !(
                      Array.isArray(newEntryValue) &&
                      1 === newEntryValue.length &&
                      "firewall.ssl-ssh-profile" ===
                        this._getEntryDatasource(newEntryValue[0])
                    )
                  ) {
                    let profilesSelected =
                      Array.isArray(newEntryValue) && newEntryValue.length;
                    ("profile" === column.id ||
                      profilesSelected ||
                      (profilesSelected =
                        this._getCurrentSecurityProfileCount()),
                      this._utmStatusHidden() ||
                        (this.cmdbModel["utm-status"] = profilesSelected
                          ? "enable"
                          : "disable"),
                      profilesSelected
                        ? "profile-group" === column.id &&
                          (this.cmdbModel["profile-type"] = "group")
                        : (this.cmdbModel["profile-type"] = "single"));
                  }
                }
                _updateDependencyData(column, newEntryValue) {
                  const consolidatedAddressColumns = new Set([
                      "consolidated-source",
                      "consolidated-destination",
                    ]),
                    securityConsolidatedAddressColumns = new Set([
                      "security-source",
                      "security-destination",
                    ]),
                    internetServiceSources = new Set([
                      "firewall.internet-service-name",
                      "firewall.internet-service-group",
                      "firewall.internet-service-custom",
                      "firewall.internet-service-custom-group",
                      "firewall.network-service-dynamic",
                    ]),
                    internetService6Sources = new Set([
                      "firewall.internet-service6-name",
                      "firewall.internet-service6-group",
                      "firewall.internet-service6-custom",
                      "firewall.internet-service6-custom-group",
                    ]);
                  if (
                    (UTM_PROFILE_EDITABLE_COLUMN_IDS.has(column.id) &&
                      this._updateUtmStatus(column, newEntryValue),
                    "poolname" !== column.id ||
                      (Array.isArray(newEntryValue) && newEntryValue.length) ||
                      (this.cmdbModel.ippool = "disable"),
                    (consolidatedAddressColumns.has(column.id) ||
                      securityConsolidatedAddressColumns.has(column.id) ||
                      "proxy-destination" === column.id) &&
                      Array.isArray(newEntryValue) &&
                      newEntryValue.length)
                  ) {
                    let hasInternetService = !1,
                      hasInternetService6 = !1;
                    for (const entry of newEntryValue) {
                      if (hasInternetService && hasInternetService6) break;
                      const datasource =
                        entry.datasource || `${entry.q_path}.${entry.q_name}`;
                      (internetServiceSources.has(datasource) &&
                        (hasInternetService = !0),
                        internetService6Sources.has(datasource) &&
                          (hasInternetService6 = !0));
                    }
                    if (
                      ("consolidated-source" === column.id ||
                      "security-source" === column.id
                        ? ((this.cmdbModel["internet-service-src"] =
                            hasInternetService ? "enable" : "disable"),
                          (this.cmdbModel["internet-service6-src"] =
                            hasInternetService6 ? "enable" : "disable"))
                        : ((this.cmdbModel["internet-service"] =
                            hasInternetService ? "enable" : "disable"),
                          (this.cmdbModel["internet-service6"] =
                            hasInternetService6 ? "enable" : "disable")),
                      consolidatedAddressColumns.has(column.id) ||
                        securityConsolidatedAddressColumns.has(column.id))
                    ) {
                      const hasInternetServicesDisabled =
                        "enable" !== this.cmdbModel["internet-service-src"] &&
                        "enable" !== this.cmdbModel["internet-service6-src"] &&
                        "enable" !== this.cmdbModel["internet-service"] &&
                        "enable" !== this.cmdbModel["internet-service6"];
                      hasInternetServicesDisabled || this.hasDestinationAddress
                        ? (this.hasDestinationAddress ||
                            hasInternetServicesDisabled) &&
                          0 === this.cmdbModel.service.length &&
                          (this.cmdbModel.service = [
                            {
                              "css-class": "ftnt-service ftnt-color-0",
                              datasource: "firewall.service.custom",
                              name: "ALL",
                              q_origin_key: "ALL",
                            },
                          ])
                        : consolidatedAddressColumns.has(column.id)
                          ? (this.cmdbModel.service = [])
                          : (this.cmdbModel["enforce-default-app-port"] =
                              "enable");
                    } else
                      ((hasInternetService || hasInternetService6) &&
                        (this.cmdbModel.service = []),
                        hasInternetService ||
                          hasInternetService6 ||
                          0 !== this.cmdbModel.service.length ||
                          (this.cmdbModel.service = [
                            {
                              "css-class": "ftnt-service ftnt-color-0",
                              datasource: "firewall.service.custom",
                              name: "webproxy",
                              q_origin_key: "webproxy",
                            },
                          ]));
                  }
                  (["ssh-ssh-profile", "profile"].includes(column.id) &&
                    ["policy", "proxy-policy"].includes(this.policyType) &&
                    !policyOmniselectConfig.hasDeepInspectionProfile(
                      this.cmdbModel,
                    ) &&
                    (this.cmdbModel["decrypted-traffic-mirror"] = ""),
                    "action" === column.id &&
                      "deny" === newEntryValue &&
                      ((this.cmdbModel.logtraffic = "disable"),
                      "policy" === this.policyType &&
                        (this.cmdbModel.ippool = "disable")),
                    "service" === column.id &&
                      "disable" === newEntryValue &&
                      (this.cmdbModel.service = [
                        {
                          datasource: "firewall.service.custom",
                          q_origin_key: "ALL",
                          name: "ALL",
                        },
                      ]));
                }
                async _setImplicitLogSetting(newValue) {
                  if (!this.logSetting) {
                    const errMsg =
                      "Cannot update without access to log setting.";
                    return (fLog.error(errMsg), Promise.reject(errMsg));
                  }
                  const mixedLogOption = ["policy", "security-policy"].includes(
                    this.policyType,
                  );
                  await this.logSetting.$promise;
                  const logOption =
                      policyInit.IMPLICIT_POLICY_LOG_PROPERTY[this.policyType],
                    originalValue = this.cmdbModel.logtraffic;
                  let result;
                  try {
                    (mixedLogOption
                      ? ((this.cmdbModel.logtraffic = this.logSetting[
                          policyInit.IMPLICIT_POLICY_LOG_PROPERTY.policy
                        ] =
                          newValue),
                        state.featureVisible("ipv6") &&
                          (this.logSetting[
                            policyInit.IMPLICIT_POLICY_LOG_PROPERTY.policy6
                          ] = newValue))
                      : (this.cmdbModel.logtraffic = this.logSetting[
                          logOption
                        ] =
                          newValue),
                      (result = this.logSetting.$save()));
                  } catch (e) {
                    const errMsg = `Failed to save log setting for ${e.message}`;
                    (fLog.error(errMsg),
                      (this.cmdbModel.logtraffic = originalValue),
                      this._setupLogSetting(),
                      (result = Promise.reject(errMsg)));
                  }
                  return result;
                }
                updateExternalData(column, newValue) {
                  let handler;
                  return (
                    this.implicit &&
                      "logtraffic" === column.id &&
                      (handler = this._setImplicitLogSetting),
                    handler ? handler.call(this, newValue) : Promise.resolve()
                  );
                }
                isExternalDataUpdate(column) {
                  return this.implicit && "logtraffic" === column.id;
                }
                setNewEntryValue(row, column, newEntryValue) {
                  this.isExternalDataUpdate(column) ||
                    (column.type === column.TYPE.OMNISELECT
                      ? row.isCollectionFallback(column)
                        ? this._updateCmdbProperty(column.id, newEntryValue, !0)
                        : this._updateOmniselectValue(
                            row,
                            column,
                            newEntryValue,
                          )
                      : this._updateCmdbProperty(column.id, newEntryValue),
                    this._updateDependencyData(column, newEntryValue));
                }
                meetValueDependencies(policyValueDependencies) {
                  return policyValueDependencies.every((dependency) =>
                    dependency.passed(this.cmdbModel),
                  );
                }
                isInternetServicePolicy() {
                  return (
                    "enable" === this.cmdbModel["internet-service"] ||
                    "enable" === this.cmdbModel["internet-service6"]
                  );
                }
                isInternetServiceSourcePolicy() {
                  return "enable" === this.cmdbModel["internet-service-src"];
                }
                isDenyPolicy() {
                  return "deny" === this.cmdbModel.action;
                }
                isFlowModePolicy() {
                  return "flow" === this.cmdbModel["inspection-mode"];
                }
                enforceDefaultAppPort() {
                  return (
                    "enable" === this.cmdbModel["enforce-default-app-port"]
                  );
                }
                updatePolicyStats() {
                  this.stats = policyStats.getStats(this.policyId).then(
                    (stats) => (Object.assign(this.stats, stats), stats),
                    () => ({}),
                  );
                }
                isAclPolicy() {
                  return this.policyType.includes("acl");
                }
                isDosPolicy() {
                  return this.policyType.includes("DoS");
                }
                isCentralSnatMap() {
                  return "central-snat-map" === this.policyType;
                }
                isProxyPolicy() {
                  return "proxy-policy" === this.policyType;
                }
                isSecurityPolicy() {
                  return "security-policy" === this.policyType;
                }
                isProfileTypeGroup() {
                  return "group" === this.cmdbModel["profile-type"];
                }
                isNgfwFirewallPolicy() {
                  return (
                    "policy" === this.policyType && state.isNgfwPolicyMode()
                  );
                }
                isZTNAProxyPolicy() {
                  return (
                    "proxy-policy" === this.policyType &&
                    "access-proxy" === this.cmdbModel.proxy
                  );
                }
                isZTNAFirewallPolicy() {
                  return (
                    "policy" === this.policyType &&
                    "ztna" === this.cmdbModel["policy-behaviour-type"]
                  );
                }
                isFirewallPolicy() {
                  return (
                    "policy" === this.policyType && !state.isNgfwPolicyMode()
                  );
                }
                isHyperscalePolicy() {
                  return (
                    "policy" === this.policyType && state.isFullPolicyOffload()
                  );
                }
                prepareCopiedPolicy(prefix = "") {
                  ((prefix = prefix || "Copy of "),
                    (this.cmdbModel.comments += ` (${prefix}${this._originalLabel || this.policyLabel})`),
                    [
                      "id",
                      "policyid",
                      "q_origin_key",
                      "name",
                      "label",
                      "global-label",
                    ].forEach((key) => {
                      delete this.cmdbModel[key];
                    }),
                    (this.cmdbModel.status = "disable"));
                }
                policyExpired() {
                  return (
                    "enable" === this.cmdbModel["policy-expiry"] &&
                    this.cmdbModel["policy-expiry-date"] !==
                      DEFAULT_POLICY_EXPIRY &&
                    new Date(
                      Number(1e3 * this.cmdbModel["policy-expiry-date-utc"]),
                    ) < new Date()
                  );
                }
                removeExpirationConfig() {
                  ((this.cmdbModel["policy-expiry"] = "disable"),
                    (this.cmdbModel["policy-expiry-date"] =
                      DEFAULT_POLICY_EXPIRY));
                }
                _hasExpiredSchedule() {
                  return (
                    this.cmdbModel.schedule &&
                    this.cmdbModel.schedule["css-class"] &&
                    this.cmdbModel.schedule["css-class"].includes("expired")
                  );
                }
                _allInterfacesEmpty(interfaces) {
                  const mapping =
                    Omniselect.getSourceDataSync("firewallInterfaces").mapping;
                  return interfaces.every(
                    (intf) => (
                      (intf = mapping[intf.q_origin_key] || intf),
                      Array.isArray(intf.members) && !intf.members.length
                    ),
                  );
                }
                _setupZtnaVipMap() {
                  const ztnaVipMap = {};
                  for (const ztnaVip of Omniselect.getSourceDataSync(
                    "ztna-vip",
                  ))
                    ztnaVip &&
                      !ztnaVipMap[ztnaVip.q_origin_key] &&
                      (ztnaVipMap[ztnaVip.q_origin_key] = ztnaVip);
                  if (state.featureVisible("ipv6"))
                    for (const ztnaVip6 of Omniselect.getSourceDataSync(
                      "ztna-vip6",
                    ))
                      ztnaVip6 &&
                        !ztnaVipMap[ztnaVip6.q_origin_key] &&
                        (ztnaVipMap[ztnaVip6.q_origin_key] = ztnaVip6);
                  this.ztnaVipMap = ztnaVipMap;
                }
                _setupZtnaServerVipMaps() {
                  const ztnaServerVipMaps = {};
                  for (const ztnaServer of Omniselect.getSourceDataSync(
                    "ztna-servers",
                  ))
                    ztnaServer.$vip &&
                      (ztnaServerVipMaps[ztnaServer.$vip.q_origin_key]
                        ? ztnaServerVipMaps[ztnaServer.$vip.q_origin_key].push(
                            ztnaServer,
                          )
                        : (ztnaServerVipMaps[ztnaServer.$vip.q_origin_key] = [
                            ztnaServer,
                          ]));
                  if (state.featureVisible("ipv6"))
                    for (const ztnaServer of Omniselect.getSourceDataSync(
                      "ztna-servers6",
                    ))
                      ztnaServer.$vip &&
                        (ztnaServerVipMaps[ztnaServer.$vip.q_origin_key]
                          ? ztnaServerVipMaps[
                              ztnaServer.$vip.q_origin_key
                            ].push(ztnaServer)
                          : (ztnaServerVipMaps[ztnaServer.$vip.q_origin_key] = [
                              ztnaServer,
                            ]));
                  this.ztnaServerVipMaps = ztnaServerVipMaps;
                }
                _allInterfacesDown(interfaces) {
                  const mapping =
                    Omniselect.getSourceDataSync("firewallInterfaces").mapping;
                  return interfaces.every(
                    (intf) =>
                      "down" ===
                      (intf = mapping[intf.q_origin_key] || intf).link,
                  );
                }
                _getAddressKeys() {
                  return PolicyEntry.getAddressKeys(this.policyType);
                }
                _hasInvalidFqdnAddress() {
                  const addressKeys = this._getAddressKeys();
                  let hasInvalid = !1;
                  return (
                    addressKeys.some((key) => {
                      const addresses = this.cmdbModel[key];
                      if (
                        Array.isArray(addresses) &&
                        addresses.some((addr) =>
                          PolicyEntry.isInvalidFqdn(addr),
                        )
                      )
                        return ((hasInvalid = !0), !0);
                    }),
                    hasInvalid
                  );
                }
                _hasInvalidDynamicSdnAddress() {
                  const addressKeys = this._getAddressKeys();
                  let hasInvalid = !1;
                  return (
                    addressKeys.some((key) => {
                      const addresses = this.cmdbModel[key];
                      if (
                        Array.isArray(addresses) &&
                        addresses.some((addr) =>
                          PolicyEntry.isInvalidDynamicSdn(addr),
                        )
                      )
                        return ((hasInvalid = !0), !0);
                    }),
                    hasInvalid
                  );
                }
                _hasNoInspectionWithUtmProfiles() {
                  const cmdbPolicy = this.cmdbModel,
                    INSPECTION_BYPASS = [
                      "ssl-ssh-profile",
                      "dnsfilter-profile",
                    ];
                  return (
                    Object.keys(policyInit.UTM_PROFILES).some(
                      (key) =>
                        !INSPECTION_BYPASS.includes(key) && !!cmdbPolicy[key],
                    ) &&
                    cmdbPolicy["ssl-ssh-profile"] &&
                    (cmdbPolicy["ssl-ssh-profile"].q_origin_key
                      ? "no-inspection" ===
                        cmdbPolicy["ssl-ssh-profile"].q_origin_key
                      : "no-inspection" === cmdbPolicy["ssl-ssh-profile"])
                  );
                }
                _hasProxyUtmProfilesInFlowPolicy() {
                  const cmdbPolicy = this.cmdbModel;
                  return (
                    !utmProfileConfig.skipProfileFeatureSetCheck({
                      isNgfwPolicyMode: state.isNgfwPolicyMode(),
                      policyType: this.policyType,
                      policyInspectionMode: cmdbPolicy["inspection-mode"],
                    }) &&
                    (this.isProfileTypeGroup()
                      ? utmProfileConfig.profileGroupHasProxyProfiles(
                          cmdbPolicy["profile-group"],
                        )
                      : utmProfileConfig.policyHasProxyProfiles(cmdbPolicy))
                  );
                }
                setupWarnings() {
                  this.warnings = [];
                  const isZTNAProxyPolicy =
                    "proxy-policy" === policyInit.type &&
                    "access-proxy" === this.cmdbModel.proxy;
                  (this.stats.oversize && this.warnings.push("policy_oversize"),
                    this._hasExpiredSchedule() &&
                      this.warnings.push("policy_expired_sch"),
                    this.policyExpired() &&
                      this.warnings.push("It is past the policy expiry date."),
                    this._hasInvalidFqdnAddress() &&
                      this.warnings.push("policy_invalid_fqdn"),
                    this._hasInvalidDynamicSdnAddress() &&
                      this.warnings.push("policy_invalid_dynamic"),
                    this._hasNoInspectionWithUtmProfiles() &&
                      this.warnings.push(
                        "The no-inspection profile doesn't perform SSL inspection, so it shouldn't be selected with other UTM profiles.",
                      ),
                    this._hasProxyUtmProfilesInFlowPolicy() &&
                      this.warnings.push(
                        "policy_flow_policy_with_proxy_profiles",
                      ));
                  try {
                    isZTNAProxyPolicy ||
                      POLICY_INTF_KEYS.forEach((key) => {
                        let intfs = this.cmdbModel[key];
                        intfs &&
                          ((intfs = Array.isArray(intfs) ? intfs : [intfs]),
                          this._allInterfacesEmpty(intfs)
                            ? this.warnings.push(`policy_${key}_empty`)
                            : this._allInterfacesDown(intfs) &&
                              this.warnings.push(`policy_${key}_down`));
                      });
                  } catch (e) {
                    fLog.warn(
                      `Interface warnings cannot be setup for ${e.message}`,
                    );
                  }
                  try {
                    const poolMeta =
                        Omniselect.getSourceMetaDataSync("firewall.ippool"),
                      poolnameKey = "poolname";
                    (this.cmdbModel["nat-ippool"] ||
                      ("enable" === this.cmdbModel.ippool &&
                        this.cmdbModel[poolnameKey])) &&
                      (
                        this.cmdbModel[poolnameKey] ||
                        this.cmdbModel["nat-ippool"]
                      ).forEach((pool) => {
                        const poolStats =
                          poolMeta && poolMeta.poolStats[pool.name];
                        poolStats &&
                          poolStats.available < 10 &&
                          this.warnings.push(
                            0 === poolStats.available
                              ? "policy_ip_pool_exhausted"
                              : "policy_ip_pool_nearing_exhaustion",
                          );
                      });
                  } catch (e) {
                    fLog.warn(
                      `IP pool warnings cannot be setup for ${e.message}`,
                    );
                  }
                }
                async getChangeSummary() {
                  return this.isFirewallPolicy() &&
                    state.featureVisible("workflow_management") &&
                    (await this._policyChangeSummaryEnforced())
                    ? await slide.openChangeSummaryDialog(
                        "require" === this._changeSummaryEnforced,
                        `${this.cmdbModel.q_path}.${this.cmdbModel.q_name}`,
                        this.cmdbModel.q_origin_key,
                      )
                    : Promise.resolve();
                }
                async _policyChangeSummaryEnforced() {
                  if (!this._changeSummaryEnforced) {
                    const uri = `/api/v2/cmdb/system/settings?format=${"gui-enforce-change-summary"}&vdom=${state.current_vdom}`,
                      res = await $http.get(uri);
                    this._changeSummaryEnforced =
                      res.data.results["gui-enforce-change-summary"];
                  }
                  return ["require", "optional"].some(
                    (e) => e === this._changeSummaryEnforced,
                  );
                }
              }
              return (
                (PolicyEntry.PolicyValueDependency = class {
                  constructor(key, candidateValues) {
                    ((this._key = key),
                      (this._candidateValues = candidateValues));
                  }
                  passed(model) {
                    return (
                      model[this._key] &&
                      this._candidateValues.includes(model[this._key])
                    );
                  }
                }),
                (PolicyEntry.getAddressKeys = (policyType) => {
                  let addressKeys = ["srcaddr", "dstaddr"];
                  return (
                    "central-snat-map" === policyType
                      ? (addressKeys = ["orig-addr", "dst-addr"])
                      : ("security-policy" !== policyType &&
                          "policy" !== policyType) ||
                        (addressKeys = [
                          "srcaddr",
                          "srcaddr6",
                          "dstaddr",
                          "dstaddr6",
                        ]),
                    addressKeys
                  );
                }),
                (PolicyEntry.isInvalidFqdn = (address) => {
                  try {
                    if (
                      address["css-class"] &&
                      address["css-class"].includes("address-fqdn")
                    ) {
                      const resolved =
                          Omniselect.getSourceMetaDataSync(
                            address.datasource,
                          ) &&
                          Omniselect.getSourceMetaDataSync(address.datasource)
                            .resolvedFqdn,
                        resolvedFqdnInfo = resolved && resolved[address.name],
                        isWildcardFqdn =
                          resolvedFqdnInfo && resolvedFqdnInfo.wildcard,
                        resolvedAddrsCount =
                          (resolvedFqdnInfo && resolvedFqdnInfo.addrs_count) ||
                          0;
                      return !isWildcardFqdn && resolvedAddrsCount <= 0;
                    }
                    return !1;
                  } catch (e) {
                    return (
                      fLog.warn(
                        `Failed to check resolved FQDN for ${e.message}`,
                      ),
                      !1
                    );
                  }
                }),
                (PolicyEntry.isInvalidDynamicSdn = (address) => {
                  try {
                    if (
                      address["css-class"] &&
                      address["css-class"].includes("address-dynamic")
                    ) {
                      const resolved =
                          Omniselect.getSourceMetaDataSync(
                            address.datasource,
                          ) &&
                          Omniselect.getSourceMetaDataSync(address.datasource)
                            .resolvedDynamic,
                        resolvedAddrs = resolved && resolved[address.name],
                        skipInvalid = "ems-tag" === resolvedAddrs.subtype;
                      if (resolvedAddrs && !skipInvalid)
                        return (
                          !Array.isArray(resolvedAddrs.addrs) ||
                          !resolvedAddrs.addrs.length
                        );
                    }
                    return !1;
                  } catch (e) {
                    return (
                      fLog.warn(
                        `Failed to check dynamic address for ${e.message}`,
                      ),
                      !1
                    );
                  }
                }),
                (PolicyEntry.isExternalResource = (address) =>
                  "system.external-resource" === address.datasource),
                PolicyEntry
              );
            }
            return (providers) => {
              providers.$provide.factory("PolicyEntry", PolicyEntryFactory);
            };
          }).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) ||
          (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
    },
    98270: (module, exports, __webpack_require__) => {
      "use strict";
      var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;
      ((__WEBPACK_AMD_DEFINE_ARRAY__ = [
        __webpack_require__(26554),
        __webpack_require__(95083),
      ]),
        void 0 ===
          (__WEBPACK_AMD_DEFINE_RESULT__ = ((fLog, MuTable) => {
            function PolicySourceFactory(
              state,
              $http,
              PolicyEntry,
              $q,
              policyInit,
              selectSetup,
              Omniselect,
            ) {
              class PolicySource extends MuTable.FixedStreamableSource {
                constructor(path, name, params) {
                  (super(),
                    (this._path = path),
                    (this._name = name),
                    params &&
                      ((this._skip = params.skip),
                      (this._filter = params.filter),
                      (this._datasourceFormat = params.datasourceFormat),
                      Array.isArray(params.extraEntries)
                        ? (this._extraEntries = params.extraEntries)
                        : (this._extraEntries = params.extraEntries
                            ? [params.extraEntries]
                            : []),
                      (this._onFetchComplete = params.onFetchComplete)));
                }
                async manuallyFetchEntries() {
                  try {
                    const policyPromise = selectSetup.getCMDBTable(
                        this._path,
                        this._name,
                        {
                          optimizeForLargeDataset: !0,
                          datasourceFormat: this._datasourceFormat,
                        },
                      ),
                      omniSelectPromise = this._loadOmniselectData();
                    let policies = await policyPromise;
                    return (
                      await omniSelectPromise,
                      this._filter &&
                        (policies = this._filterPolicies(
                          policies,
                          this._filter,
                        )),
                      this._processEntries(policies.concat(this._extraEntries))
                    );
                  } catch (e) {
                    return (fLog.error(e), []);
                  }
                }
                fetchEntries() {
                  if (Array.isArray(this._policies)) {
                    const entries = this._policies;
                    return ((this._policies = null), Promise.resolve(entries));
                  }
                  return this.manuallyFetchEntries();
                }
                _processEntries(rawEntries) {
                  this._interfacesSectionable = !0;
                  let listenOnInterfaces = {};
                  if ("proxy-policy" === policyInit.type) {
                    const interfaces =
                      Omniselect.getSourceDataSync("firewallInterfaces");
                    listenOnInterfaces = { "explicit-web": [], ftp: [] };
                    for (const intf of interfaces)
                      (intf.explicit_ftp_proxy_enabled &&
                        listenOnInterfaces.ftp.push(intf),
                        intf.explicit_web_proxy_enabled &&
                          listenOnInterfaces["explicit-web"].push(intf));
                  }
                  return (
                    (this._policies = rawEntries.reduce(
                      (filteredEntries, rawEntry) => {
                        if (PolicyEntry.isVisible(rawEntry)) {
                          const policy = new PolicyEntry(rawEntry, {
                            listenOnInterfaces,
                          });
                          if (
                            (this._interfacesSectionable &&
                              !policy.isInterfacesSectionable() &&
                              (this._interfacesSectionable = !1),
                            !state.featureVisible("ipv6") &&
                              "ipv6" === policy.cmdbModel.type)
                          )
                            return filteredEntries;
                          filteredEntries.push(policy);
                        }
                        return filteredEntries;
                      },
                      [],
                    )),
                    "function" == typeof this._onFetchComplete &&
                      this._onFetchComplete(),
                    this._policies
                  );
                }
                destroy() {
                  ((this._policies = null),
                    (this._extraEntries = null),
                    (this._onFetchComplete = null));
                }
                _loadOmniselectData() {
                  let promises = {};
                  const isHyperscaleVdom = state.isFullPolicyOffload();
                  if (
                    ((promises["firewall.address"] =
                      Omniselect.getSourceData("firewall.address")),
                    (["policy", "proxy-policy"].includes(policyInit.type) ||
                      state.featureVisible("ipv6")) &&
                      (promises["firewall.address6"] =
                        Omniselect.getSourceData("firewall.address6")),
                    !state.isNgfwPolicyMode() &&
                      !isHyperscaleVdom &&
                      "policy" === policyInit.type &&
                      !state.featureVisible("vpn_firewall_only"))
                  ) {
                    const proxyUtmProfileDatasources = [
                      "antivirus.profile",
                      "emailfilter.profile",
                      "firewall.profile-protocol-options",
                      "webfilter.profile",
                      "firewall.profile-group",
                    ];
                    for (const datasource of proxyUtmProfileDatasources)
                      promises[datasource] =
                        Omniselect.getSourceData(datasource);
                  }
                  return (
                    (promises["firewall.ippool"] =
                      Omniselect.getSourceData("firewall.ippool")),
                    (promises["firewall.vip"] =
                      Omniselect.getSourceData("firewall.vip")),
                    (promises["firewall.vip6"] =
                      Omniselect.getSourceData("firewall.vip6")),
                    (promises.firewallInterfaces =
                      Omniselect.getSourceData("firewallInterfaces")),
                    isHyperscaleVdom ||
                      ((promises["ztna-servers"] =
                        Omniselect.getSourceData("ztna-servers")),
                      (promises["ztna-servers6"] =
                        Omniselect.getSourceData("ztna-servers6")),
                      (promises["ztna-vip"] =
                        Omniselect.getSourceData("ztna-vip")),
                      (promises["ztna-vip6"] =
                        Omniselect.getSourceData("ztna-vip6")),
                      (promises.customApplications =
                        Omniselect.getSourceData("application.custom")),
                      (promises.localFtgdCat = Omniselect.getSourceData(
                        "webfilter.ftgd-local-cat",
                      ))),
                    this._filter &&
                      (this._filter.sdn &&
                        ((promises["firewall.addrgrp"] =
                          Omniselect.getSourceData("firewall.addrgrp")),
                        (promises["firewall.network-service-dynamic"] =
                          Omniselect.getSourceData(
                            "firewall.network-service-dynamic",
                          ))),
                      this._filter.fsso &&
                        ((promises["user.group"] =
                          Omniselect.getSourceData("user.group")),
                        (promises["user.adgrp"] =
                          Omniselect.getSourceData("user.adgrp")))),
                    $q.all(promises)
                  );
                }
                _filterPolicies(policies, filters) {
                  let filtered = policies;
                  if (filters.sdn) {
                    const sdnFilter = filters.sdn,
                      addresses =
                        Omniselect.getSourceDataSync("firewall.address"),
                      addrGrps =
                        Omniselect.getSourceDataSync("firewall.addrgrp"),
                      networkServiceDynamic = Omniselect.getSourceDataSync(
                        "firewall.network-service-dynamic",
                      ),
                      sdnName = sdnFilter.name || sdnFilter,
                      networkServiceNamesWithMatchedSDN = networkServiceDynamic
                        .filter(
                          (entry) => entry.sdn && entry.sdn.name === sdnName,
                        )
                        .map((entry) => entry.name);
                    filtered = filtered.filter((policy) =>
                      [
                        "dstaddr",
                        "srcaddr",
                        "network-service-src-dynamic",
                        "network-service-dynamic",
                      ].some((attr) =>
                        policy[attr].some((entry) => {
                          if ("firewall.address" === entry.datasource) {
                            const addr = addresses.mapping[entry.q_origin_key];
                            return addr.sdn && addr.sdn.name === sdnName;
                          }
                          if ("firewall.addrgrp" === entry.datasource) {
                            return addrGrps.mapping[
                              entry.q_origin_key
                            ].member.some((member) => {
                              const addr =
                                addresses.mapping[member.q_origin_key];
                              return addr.sdn && addr.sdn.name === sdnName;
                            });
                          }
                          return (
                            "firewall.network-service-dynamic" ===
                              entry.datasource &&
                            networkServiceNamesWithMatchedSDN.includes(
                              entry.name,
                            )
                          );
                        }),
                      ),
                    );
                  }
                  if (filters.fsso) {
                    const fssoFilter = filters.fsso,
                      adGroups = Omniselect.getSourceDataSync("user.adgrp"),
                      userGroups = Omniselect.getSourceDataSync("user.group"),
                      fssoName = fssoFilter.name || fssoFilter;
                    filtered = filtered.filter((policy) => {
                      const inUserGroup = (policy.groups || []).some(
                        (entry) => {
                          const group = userGroups.mapping[entry.q_origin_key];
                          return (
                            "fsso-service" === group["group-type"] &&
                            (group.member || []).some(
                              (member) =>
                                adGroups.mapping[member.q_origin_key][
                                  "server-name"
                                ] === fssoName,
                            )
                          );
                        },
                      );
                      if (inUserGroup) return inUserGroup;
                      return (policy["fsso-groups"] || []).some((entry) => {
                        const group = adGroups.mapping[entry.q_origin_key];
                        return group && group["server-name"] === fssoName;
                      });
                    });
                  }
                  return filtered;
                }
                copyEntry(entry) {
                  return (
                    (entry = super.copyEntry(entry)).prepareCopiedPolicy(),
                    entry
                  );
                }
                processUpdatedEntry(entry) {
                  return entry.processUpdatedEntry();
                }
                setNewEntryValue(policyEntry, row, column, newValue) {
                  try {
                    policyEntry.setNewEntryValue(row, column, newValue);
                  } catch (e) {
                    fLog.error(
                      `Failed to call setNewEntryValue in PolicySource for: ${e.message}`,
                    );
                  }
                }
                async externallyUpdateEntry(
                  policyEntry,
                  row,
                  column,
                  newValue,
                ) {
                  const changeSummary =
                    row && (await policyEntry.getChangeSummary());
                  return (
                    policyEntry &&
                    policyEntry.edit(row, column, newValue, changeSummary)
                  );
                }
                async externallyReorderEntry(params) {
                  const changeSummary = await params.entry.getChangeSummary();
                  return (
                    (params.entry = params.entry.cmdbModel),
                    params.beforeEntry
                      ? (params.beforeEntry = params.beforeEntry.cmdbModel)
                      : (params.afterEntry = params.afterEntry.cmdbModel),
                    changeSummary && (params.changeSummary = changeSummary),
                    super.externallyReorderEntry(params)
                  );
                }
                setNewSequenceGroupingValue(entry, value) {
                  return super.setNewSequenceGroupingValue(
                    entry.cmdbModel,
                    value,
                  );
                }
                isInterfacesSectionable() {
                  return this._interfacesSectionable;
                }
                static cacheInstance(policySourceInstance) {
                  policySourceInstance instanceof PolicySource &&
                    (PolicySource._CACHED_INSTANCE = policySourceInstance);
                }
                static getCachedInstance() {
                  return PolicySource._CACHED_INSTANCE;
                }
                static invalidateCache() {
                  PolicySource._CACHED_INSTANCE = null;
                }
              }
              return ((PolicySource._CACHED_INSTANCE = null), PolicySource);
            }
            return (
              (PolicySourceFactory.$inject = [
                "state",
                "$http",
                "PolicyEntry",
                "$q",
                "policyInit",
                "selectSetup",
                "Omniselect",
              ]),
              (providers) => {
                providers.$provide.factory("PolicySource", PolicySourceFactory);
              }
            );
          }).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) ||
          (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
    },
    70922: (module, exports, __webpack_require__) => {
      "use strict";
      var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;
      ((__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(26554)]),
        void 0 ===
          (__WEBPACK_AMD_DEFINE_RESULT__ = ((fLog) => {
            PolicyListTableColumnFactory.$inject = [
              "policyListTableColumnConfigs",
              "state",
              "policyInit",
            ];
            const DEFAULT_COLUMNS = {
              policy: [
                "name",
                "srcintf",
                "dstintf",
                "consolidated-source",
                "consolidated-destination",
                "schedule",
                "service",
                "action",
                "consolidated-poolname",
                "profile",
                "logtraffic",
                "bytes",
                "policy-behaviour-type",
              ],
              "ngfw-firewall-policy": [
                "name",
                "srcintf",
                "dstintf",
                "consolidated-source",
                "consolidated-destination",
                "service",
                "ssl-ssh-profile",
                "ngfw-consolidated-nat",
                "bytes",
              ],
              "DoS-policy": [
                "policyid",
                "name",
                "interface",
                "srcaddr",
                "dstaddr",
                "service",
              ],
              acl: [
                "policyid",
                "name",
                "interface",
                "srcaddr",
                "dstaddr",
                "service",
                "acl_action",
                "packets_dropped",
              ],
              "multicast-policy": [
                "policyid",
                "name",
                "srcintf",
                "dstintf",
                "srcaddr",
                "dstaddr",
                "protocol",
                "action",
                "logtraffic",
                "snat",
                "bytes",
              ],
              "multicast-policy6": [
                "policyid",
                "name",
                "srcintf",
                "dstintf",
                "srcaddr",
                "dstaddr",
                "protocol",
                "action",
                "logtraffic",
                "bytes",
              ],
              "proxy-policy": [
                "policyid",
                "name",
                "proxy",
                "dstintf",
                "proxy-source",
                "proxy-destination",
                "schedule",
                "action",
                "profile",
                "access-proxy",
                "logtraffic",
                "bytes",
              ],
              "central-snat-map": [
                "policyid",
                "srcintf",
                "dstintf",
                "orig-addr",
                "dst-addr",
                "nat-ippool",
                "orig-port",
                "nat-port",
                "poolname",
                "hit_count",
              ],
              "security-policy": [
                "name",
                "srcintf",
                "dstintf",
                "security-source",
                "security-destination",
                "schedule",
                "service",
                "applications",
                "url-category",
                "action",
                "profile",
                "logtraffic",
                "hit_count",
              ],
              "hyperscale-policy": [
                "policyid",
                "name",
                "srcintf",
                "dstintf",
                "consolidated-source",
                "consolidated-destination",
                "service",
                "action",
                "consolidated-poolname",
                "traffic-shaper",
                "traffic-shaper-reverse",
                "cgn-log-server-grp",
              ],
            };
            function PolicyListTableColumnFactory(
              policyListTableColumnConfigs,
              state,
              policyInit,
            ) {
              return new (class {
                getColumns(params) {
                  try {
                    return policyListTableColumnConfigs.generate(params);
                  } catch (e) {
                    return (
                      fLog.error(
                        `Failed to get columns for ${e.message || ""}, return empty list instead.`,
                      ),
                      []
                    );
                  }
                }
                getDefaultColumns(defaultColumnsOverride) {
                  try {
                    if (
                      Array.isArray(defaultColumnsOverride) &&
                      defaultColumnsOverride.length
                    )
                      return defaultColumnsOverride.map(
                        (id) => ({ "#": "policyid" })[id] || id,
                      );
                    let type = policyInit.type;
                    return (
                      "policy" === type &&
                        state.isNgfwPolicyMode() &&
                        (type = "ngfw-firewall-policy"),
                      DEFAULT_COLUMNS[type]
                    );
                  } catch (e) {
                    return (
                      fLog.error(
                        `Failed to get default columns for ${e.message || ""}, return empty list instead.`,
                      ),
                      []
                    );
                  }
                }
                clearCache() {
                  policyListTableColumnConfigs.clearCache();
                }
              })();
            }
            return (
              (DEFAULT_COLUMNS["DoS-policy6"] = DEFAULT_COLUMNS["DoS-policy"]),
              (DEFAULT_COLUMNS.acl6 = DEFAULT_COLUMNS.acl),
              (providers) => {
                providers.$provide.factory(
                  "policyListTableColumn",
                  PolicyListTableColumnFactory,
                );
              }
            );
          }).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) ||
          (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
    },
    69471: (module, exports, __webpack_require__) => {
      "use strict";
      var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;
      ((__WEBPACK_AMD_DEFINE_ARRAY__ = [
        __webpack_require__(26554),
        __webpack_require__(6649),
        __webpack_require__(95083),
        __webpack_require__(55214),
      ]),
        void 0 ===
          (__WEBPACK_AMD_DEFINE_RESULT__ = ((fLog, fDom, MuTable, fObject) => {
            PolicyListTableColumnConfigsFactory.$inject = [
              "state",
              "lang",
              "$http",
              "$q",
              "policyOmniselectConfig",
              "PolicyEntry",
              "$compile",
              "policyStats",
              "policyVWP",
              "VisibilityCheck",
              "utmProfileConfig",
              "policyInit",
              "datetime",
              "Omniselect",
              "policyShared",
            ];
            const Tooltip = __webpack_require__(6117),
              CMDB_API = "/api/v2/cmdb",
              POLICY_ACTION_BASE_KEY = "Firewall::policyAction.",
              DEFAULT_POLICY_EXPIRY = "0000-00-00 00:00:00",
              logError = (error, customLog) => {
                var errorMsg;
                ((errorMsg =
                  "string" == typeof error
                    ? error
                    : error
                      ? error.message
                      : ""),
                  fLog.error(`${customLog} ${errorMsg}`));
              },
              UTM_PROFILE_COLUMN_IDS = [
                "av-profile",
                "emailfilter-profile",
                "webfilter-profile",
                "videofilter-profile",
                "dlp-profile",
                "file-filter-profile",
                "dnsfilter-profile",
                "waf-profile",
                "application-list",
                "ips-sensor",
                "icap-profile",
                "voip-profile",
                "ssl-ssh-profile",
                "virtual-patch-profile",
                "casb-profile",
                "profile-group",
              ],
              SUPPORTED_COMPARE_TOOLTIP_KEYS = [
                "bytes",
                "packets",
                "last_used",
                "first_used",
                "active_sessions",
                "hit_count",
                "packets_dropped",
                "software_bytes",
                "software_packets",
                "asic_bytes",
                "asic_packets",
                "nturbo_bytes",
                "nturbo_packets",
                "cgn_bytes",
                "cgn_packets",
              ],
              TOOLTIP_HINT_CLASS = "tooltip-hint",
              LAZY_TEMPLATE_TIP_CLASS = "lazy-tip",
              SIMPLE_TIP_CLASS = "simple-tip",
              INFO_CENTRAL_SNAT =
                "Central NAT is enabled so NAT settings from matching Central SNAT policies will be applied.";
            function PolicyListTableColumnConfigsFactory(
              state,
              lang,
              $http,
              $q,
              policyOmniselectConfig,
              PolicyEntry,
              $compile,
              policyStats,
              policyVWP,
              VisibilityCheck,
              utmProfileConfig,
              policyInit,
              datetime,
              Omniselect,
              policyShared,
            ) {
              let policyType;
              const entryHasLearnMode = (entry) =>
                  "security-policy" === policyType &&
                  entry.cmdbModel &&
                  "enable" === entry.cmdbModel["learning-mode"],
                getColumnPolicyType = () => {
                  let type = policyType;
                  return (
                    "policy" === policyType &&
                      (state.isNgfwPolicyMode()
                        ? (type = "ngfw-firewall-policy")
                        : state.isFullPolicyOffload() &&
                          (type = "hyperscale-policy")),
                    type
                  );
                };
              let configParams;
              const CANDIDATE_COLUMNS = {
                  policy: [
                    "policyid",
                    "name",
                    "srcintf",
                    "dstintf",
                    "consolidated-srcaddr",
                    "consolidated-source",
                    "consolidated-dstaddr",
                    "consolidated-destination",
                    "consolidated-poolname",
                    "action",
                    "logtraffic",
                    "schedule",
                    "service",
                    "profile",
                    "av-profile",
                    "emailfilter-profile",
                    "webfilter-profile",
                    "videofilter-profile",
                    "dnsfilter-profile",
                    "casb-profile",
                    "waf-profile",
                    "application-list",
                    "ips-sensor",
                    "icap-profile",
                    "voip-profile",
                    "file-filter-profile",
                    "dlp-profile",
                    "profile-protocol-options",
                    "ssl-ssh-profile",
                    "profile-group",
                    "bytes",
                    "packets",
                    "software_bytes",
                    "software_packets",
                    "asic_bytes",
                    "asic_packets",
                    "nturbo_bytes",
                    "nturbo_packets",
                    "last_used",
                    "first_used",
                    "active_sessions",
                    "hit_count",
                    "status",
                    "groups",
                    "users",
                    "vpntunnel",
                    "comments",
                    "inspection-mode",
                    "gtp-profile",
                    "ztna-ems-tag",
                    "ztna-status",
                    "policy-expiry-date",
                    "policy-behaviour-type",
                    "virtual-patch-profile",
                  ],
                  "ngfw-firewall-policy": [
                    "policyid",
                    "name",
                    "srcintf",
                    "dstintf",
                    "consolidated-srcaddr",
                    "consolidated-source",
                    "consolidated-dstaddr",
                    "consolidated-destination",
                    "ngfw-consolidated-nat",
                    "service",
                    "comments",
                    "status",
                    "groups",
                    "users",
                    "ssl-ssh-profile",
                    "bytes",
                    "packets",
                    "software_bytes",
                    "software_packets",
                    "asic_bytes",
                    "asic_packets",
                    "nturbo_bytes",
                    "nturbo_packets",
                    "last_used",
                    "first_used",
                    "active_sessions",
                    "hit_count",
                    "ztna-ems-tag",
                    "ztna-status",
                  ],
                  "security-policy": [
                    "policyid",
                    "name",
                    "srcintf",
                    "dstintf",
                    "security-srcaddr",
                    "security-source",
                    "security-dstaddr",
                    "security-destination",
                    "schedule",
                    "service",
                    "applications",
                    "url-category",
                    "action",
                    "logtraffic",
                    "profile",
                    "av-profile",
                    "webfilter-profile",
                    "videofilter-profile",
                    "dlp-profile",
                    "file-filter-profile",
                    "dnsfilter-profile",
                    "casb-profile",
                    "ips-sensor",
                    "emailfilter-profile",
                    "profile-protocol-options",
                    "profile-group",
                    "status",
                    "groups",
                    "users",
                    "comments",
                    "hit_count",
                    "virtual-patch-profile",
                  ],
                  "DoS-policy": [
                    "policyid",
                    "name",
                    "service",
                    "interface",
                    "srcaddr",
                    "dstaddr",
                    "status",
                    "comments",
                  ],
                  "DoS-policy6": [
                    "policyid",
                    "name",
                    "service",
                    "interface",
                    "srcaddr",
                    "dstaddr",
                    "status",
                    "comments",
                  ],
                  "multicast-policy": [
                    "policyid",
                    "name",
                    "srcintf",
                    "dstintf",
                    "action",
                    "logtraffic",
                    "srcaddr",
                    "dstaddr",
                    "status",
                    "snat",
                    "dnat",
                    "protocol",
                    "ips-sensor",
                    "bytes",
                    "packets",
                    "last_used",
                    "first_used",
                    "active_sessions",
                    "hit_count",
                  ],
                  "multicast-policy6": [
                    "policyid",
                    "name",
                    "srcintf",
                    "dstintf",
                    "action",
                    "logtraffic",
                    "srcaddr",
                    "dstaddr",
                    "status",
                    "protocol",
                    "ips-sensor",
                    "bytes",
                    "packets",
                    "last_used",
                    "first_used",
                    "active_sessions",
                    "hit_count",
                  ],
                  "proxy-policy": [
                    "policyid",
                    "name",
                    "srcintf",
                    "dstintf",
                    "proxy-source",
                    "proxy-destination",
                    "schedule",
                    "action",
                    "profile",
                    "logtraffic",
                    "bytes",
                    "service",
                    "av-profile",
                    "dlp-profile",
                    "webfilter-profile",
                    "videofilter-profile",
                    "file-filter-profile",
                    "waf-profile",
                    "application-list",
                    "ips-sensor",
                    "icap-profile",
                    "profile-protocol-options",
                    "ssl-ssh-profile",
                    "profile-group",
                    "last_used",
                    "first_used",
                    "active_sessions",
                    "hit_count",
                    "proxy",
                    "status",
                    "groups",
                    "users",
                    "comments",
                    "access-proxy",
                    "ztna-ems-tag",
                    "virtual-patch-profile",
                    "casb-profile",
                  ],
                  "central-snat-map": [
                    "policyid",
                    "srcintf",
                    "dstintf",
                    "poolname",
                    "orig-addr",
                    "dst-addr",
                    "nat-ippool",
                    "status",
                    "ip-version",
                    "comments",
                    "orig-port",
                    "nat-port",
                    "protocol",
                    "last_used",
                    "first_used",
                    "hit_count",
                  ],
                  acl: [
                    "policyid",
                    "name",
                    "interface",
                    "service",
                    "packets_dropped",
                    "srcaddr",
                    "dstaddr",
                    "acl_action",
                    "status",
                    "comments",
                  ],
                  acl6: [
                    "policyid",
                    "name",
                    "interface",
                    "service",
                    "packets_dropped",
                    "srcaddr",
                    "dstaddr",
                    "acl_action",
                    "status",
                    "comments",
                  ],
                  "hyperscale-policy": [
                    "policyid",
                    "name",
                    "srcintf",
                    "dstintf",
                    "consolidated-srcaddr",
                    "consolidated-source",
                    "consolidated-dstaddr",
                    "consolidated-destination",
                    "service",
                    "action",
                    "consolidated-poolname",
                    "traffic-shaper",
                    "traffic-shaper-reverse",
                    "cgn-log-server-grp",
                    "status",
                    "comments",
                    "bytes",
                    "active_sessions",
                    "first_used",
                    "last_used",
                    "hit_count",
                    "cgn_bytes",
                    "cgn_packets",
                    "software_bytes",
                    "software_packets",
                    "asic_bytes",
                    "asic_packets",
                  ],
                },
                VISIBILITY_CHECKS = {
                  applications: new VisibilityCheck({
                    dependencyChecks: ["applicationAndCategoryCheck"],
                  }),
                  "url-category": new VisibilityCheck({
                    dependencyChecks: ["applicationAndCategoryCheck"],
                  }),
                  poolname: new VisibilityCheck({
                    dependencyChecks: ["natMode"],
                  }),
                  "consolidated-poolname": new VisibilityCheck({
                    dependencyChecks: ["natMode"],
                  }),
                  "ngfw-consolidated-nat": new VisibilityCheck({
                    dependencyChecks: ["natMode"],
                  }),
                  software_bytes: new VisibilityCheck({
                    dependencyChecks: ["haveNetNpu"],
                  }),
                  software_packets: new VisibilityCheck({
                    dependencyChecks: ["haveNetNpu"],
                  }),
                  asic_bytes: new VisibilityCheck({
                    dependencyChecks: ["haveNetNpu"],
                  }),
                  asic_packets: new VisibilityCheck({
                    dependencyChecks: ["haveNetNpu"],
                  }),
                  nturbo_bytes: new VisibilityCheck({
                    dependencyChecks: ["haveNturbo"],
                  }),
                  nturbo_packets: new VisibilityCheck({
                    dependencyChecks: ["haveNturbo"],
                  }),
                  cgn_bytes: new VisibilityCheck({
                    dependencyChecks: [
                      "haveNpuCgn",
                      "haveNetNpu",
                      "fullPolicyOffloadMode",
                    ],
                  }),
                  cgn_packets: new VisibilityCheck({
                    dependencyChecks: [
                      "haveNpuCgn",
                      "haveNetNpu",
                      "fullPolicyOffloadMode",
                    ],
                  }),
                  vpntunnel: new VisibilityCheck({ featureChecks: ["vpn"] }),
                  "gtp-profile": new VisibilityCheck({
                    dependencyChecks: ["carrier", "ngfwProfileMode"],
                  }),
                  "inspection-mode": new VisibilityCheck({
                    dependencyChecks: [
                      "ngfwProfileMode",
                      "isNotFirewallAndVPNOnlyBuild",
                    ],
                  }),
                  "cgn-log-server-grp": new VisibilityCheck({
                    dependencyChecks: ["haveNpuCgn", "fullPolicyOffloadMode"],
                  }),
                  "ztna-ems-tag": new VisibilityCheck({
                    featureChecks: ["ztna"],
                  }),
                  "ztna-status": new VisibilityCheck({
                    featureChecks: ["ztna"],
                  }),
                  "policy-expiry": new VisibilityCheck({
                    featureChecks: ["workflow_management"],
                  }),
                  profile: new VisibilityCheck({
                    dependencyChecks: ["isNotFirewallAndVPNOnlyBuild"],
                  }),
                },
                visibilityCheckPassed = (columnId, cmdbPolicy) =>
                  VISIBILITY_CHECKS[columnId]
                    ? VISIBILITY_CHECKS[columnId].checkPassed(cmdbPolicy)
                    : !utmProfileConfig.isUtmProfile(columnId) ||
                      utmProfileConfig.visible(cmdbPolicy, columnId),
                cmdbGet = (
                  path,
                  name,
                  mkey,
                  params = { with_meta: 1, datasource: 1 },
                ) => {
                  mkey = mkey ? `/${encodeURIComponent(mkey)}` : "";
                  const uri = `${CMDB_API}/${path}/${name}${mkey}`;
                  return $http.get(uri, { params }).then(
                    (result) => result.data.results,
                    (err) => {
                      logError(
                        err,
                        `Failed to fetch ${path}.${name}.${mkey} for: `,
                      );
                    },
                  );
                },
                translate = (langKey) => lang(langKey).toString(),
                defaultEditableCheck = (entry) =>
                  !entry.implicit &&
                  !entry.isAclPolicy() &&
                  !entry.isDosPolicy(),
                getOmniselectSettings = (entry, column, datasource) => {
                  const cmdbPolicy = entry.cmdbModel;
                  return (
                    datasource || (datasource = column.id),
                    policyOmniselectConfig.get(
                      datasource,
                      cmdbPolicy,
                      (config) =>
                        policyOmniselectConfig.postProcessSelect(
                          config,
                          datasource,
                        ),
                    )
                  );
                },
                utmProfileEditable = (entry, column) =>
                  !entryHasLearnMode(entry) &&
                  utmProfileConfig.editable(entry, column.id),
                cmdbCellValue = (entry, column) => {
                  if ("central-snat-map" === entry.policyType) {
                    if ("orig-addr" === column.id)
                      return entry.cmdbModel[column.id].concat(
                        entry.cmdbModel["orig-addr6"],
                      );
                    if ("dst-addr" === column.id)
                      return entry.cmdbModel[column.id].concat(
                        entry.cmdbModel["dst-addr6"],
                      );
                    if ("nat-ippool" === column.id)
                      return entry.cmdbModel[column.id].concat(
                        entry.cmdbModel["nat-ippool6"],
                      );
                  }
                  return entry.cmdbModel[column.id];
                },
                statsCellValue = (entry, column) =>
                  fObject.objectIsThenable(entry.stats)
                    ? entry.stats.then(
                        (stats) => stats[column.id] || 0,
                        () => 0,
                      )
                    : entry.stats[column.id] || 0,
                utmProfileCellValue = (entry, column) =>
                  utmProfileEditable(entry, column)
                    ? cmdbCellValue(entry, column)
                    : "",
                enableDisableCellValue = (entry, column) => {
                  let value = entry.cmdbModel[column.id];
                  return ((value = value ? translate(`${value}d`) : ""), value);
                },
                createOmniselectCellValueFunction =
                  (datasource, valueFn, processFn) => (entry, column) => {
                    const transformDatasource = (input) =>
                      "object" == typeof datasource
                        ? datasource[input]
                        : datasource;
                    return (
                      "function" != typeof valueFn && (valueFn = cmdbCellValue),
                      "function" != typeof processFn &&
                        (processFn = (_entry, _column, _valueFn) => {
                          let rawValue = _valueFn(_entry, _column) || [];
                          return Array.isArray(rawValue)
                            ? rawValue.map((value) => ({
                                q_origin_key: value.q_origin_key,
                                datasource: transformDatasource(
                                  value.datasource,
                                ),
                              }))
                            : {
                                q_origin_key: rawValue.q_origin_key,
                                datasource: transformDatasource(
                                  rawValue.datasource,
                                ),
                              };
                        }),
                      processFn(entry, column, valueFn)
                    );
                  },
                defaultIntfOmniselectCellValueFunction =
                  createOmniselectCellValueFunction("firewallInterfaces"),
                defaultAddrOmniselectCellValueFunction =
                  createOmniselectCellValueFunction(
                    null,
                    null,
                    (entry, column, valueFn) => {
                      let addrs = valueFn(entry, column);
                      return (
                        (addrs = entry.processExternalResource(
                          addrs,
                          column.id,
                        )),
                        addrs
                      );
                    },
                  ),
                ippoolNotUsed = (cmdbPolicy, column) => {
                  const isConsolidated = "policy" === policyType;
                  return (
                    "disable" === cmdbPolicy.ippool ||
                    (isConsolidated &&
                      !cmdbPolicy.poolname &&
                      !cmdbPolicy.poolname6) ||
                    (!isConsolidated && !cmdbPolicy[column.id])
                  );
                },
                natEnabledIsCollection = function (entry, column) {
                  const cmdbPolicy = entry.cmdbModel;
                  return (
                    "deny" !== cmdbPolicy.action &&
                    "multicast-policy" !== policyType &&
                    !entry.isNatDisabled &&
                    !ippoolNotUsed(cmdbPolicy, column)
                  );
                },
                natEnabledFallback = (entry, column) => {
                  const cmdbPolicy = entry.cmdbModel;
                  if ("deny" === cmdbPolicy.action) return "";
                  let elem;
                  const natOptionDisabled = entry.isNatDisabled,
                    natOption = natOptionDisabled ? "disable" : "enable";
                  return "multicast-policy" === policyType || natOptionDisabled
                    ? fDom.elem("span", null, {
                        children: [
                          fDom.elem("f-icon", {
                            className: `fa-${natOption}d`,
                          }),
                          fDom.elem("span", {
                            textContent: translate(`${natOption}d`),
                          }),
                        ],
                      })
                    : ippoolNotUsed(cmdbPolicy, column)
                      ? ((elem = fDom.elem(
                          "span",
                          { className: SIMPLE_TIP_CLASS },
                          {
                            children: [
                              fDom.elem("f-icon", { className: "fa-enabled" }),
                              fDom.elem("span", {
                                textContent: translate("enabled"),
                              }),
                            ],
                          },
                        )),
                        elem)
                      : void 0;
                };
              let actionOptions = [];
              ("central-snat-map" !== policyType
                ? actionOptions.push(
                    new MuTable.EditableOption({
                      label: translate(`${POLICY_ACTION_BASE_KEY}accept`),
                      entryValue: "accept",
                    }),
                  )
                : actionOptions.push(
                    new MuTable.EditableOption({
                      label: translate(`${POLICY_ACTION_BASE_KEY}permit`),
                      entryValue: "permit",
                    }),
                  ),
                actionOptions.push(
                  new MuTable.EditableOption({
                    label: translate(`${POLICY_ACTION_BASE_KEY}deny`),
                    entryValue: "deny",
                  }),
                ));
              const enableDisableOptions = [
                  new MuTable.EditableOption({
                    label: translate("enable"),
                    cellValue: translate("enabled"),
                    entryValue: "enable",
                    iconClass: "fa-enabled",
                  }),
                  new MuTable.EditableOption({
                    label: translate("disable"),
                    cellValue: translate("disabled"),
                    entryValue: "disable",
                    iconClass: "fa-disabled",
                  }),
                ],
                formatOneAction = (iconKey, actionText, title) => {
                  const icon =
                      {
                        accept: "fa-accepted",
                        deny: "fa-denied",
                        authenticate: "ftnt-ipsec-vpn-custom",
                        ipsec: "ftnt-ipsec-vpn-custom",
                        permit: "fa-accepted",
                        learn: "fa-graduation-cap",
                      }[iconKey] || "",
                    actionElems = [
                      fDom.elem("f-icon", { className: icon }),
                      fDom.elem("span", { textContent: actionText || "" }),
                    ];
                  return title
                    ? fDom.elem("div", null, {
                        children: [
                          fDom.elem("span", { textContent: `${title}: ` }),
                        ].concat(actionElems),
                      })
                    : fDom.elem("span", null, { children: actionElems });
                },
                logTrafficCellValue = (logtraffic) =>
                  (logtraffic = configParams.isDefaultSyncMode
                    ? translate("all")
                    : state.featureVisible("vpn_firewall_only")
                      ? translate(
                          "disable" !== logtraffic ? "enabled" : "disabled",
                        )
                      : translate(
                          {
                            enable: "enabled",
                            disable: "disabled",
                            utm: "UTM",
                          }[logtraffic] || logtraffic,
                        )),
                formatOneLogTraffic = (
                  iconKey,
                  iconOverride,
                  logTrafficText,
                  className,
                  title,
                ) => {
                  let icon =
                    iconOverride ||
                    (iconKey &&
                      {
                        all: "fa-enabled",
                        enable: "fa-enabled",
                        utm: "fa-shield",
                        disable: "fa-disabled",
                        unknown: "fa-unknown",
                      }[iconKey]) ||
                    "";
                  state.featureVisible("vpn_firewall_only") &&
                    "fa-shield" === icon &&
                    (icon = "fa-enabled");
                  const children = [
                    fDom.elem("f-icon", { className: icon }),
                    fDom.elem("span", { textContent: logTrafficText }),
                  ];
                  let cellElem;
                  return (
                    (cellElem = title
                      ? fDom.elem("div", null, {
                          children: [
                            fDom.elem("span", { textContent: `${title}: ` }),
                          ].concat(children),
                        })
                      : fDom.elem("span", null, { children })),
                    className && (cellElem.className = className),
                    cellElem
                  );
                },
                DEFAULT_TOOLTIP_CONFIG = { showDelay: !0 },
                addTemplateTooltipToElement = (element, params) => {
                  if (!element || !params) return;
                  (element =
                    element.querySelector(`.${LAZY_TEMPLATE_TIP_CLASS}`) ||
                    element).classList.add(TOOLTIP_HINT_CLASS);
                  const content = fDom.elem("div", null, {
                      children: [
                        fDom.elem("f-icon", { className: "fa-loading" }),
                      ],
                    }),
                    tooltip = Tooltip.addToElement(
                      element,
                      content,
                      DEFAULT_TOOLTIP_CONFIG,
                    );
                  let rendered = !1;
                  const tooltipScope = configParams.ctrlScope.$new();
                  return (
                    tooltip.onShow(() => {
                      rendered ||
                        tooltipScope.$apply(() => {
                          if (!params.data || !params.template)
                            throw new Error(
                              'Invalid "params" for generating template based tooltips',
                            );
                          Object.assign(tooltipScope, params.data);
                          const tooltipContent = $compile(params.template)(
                            tooltipScope,
                          );
                          ((content.innerHTML = ""),
                            content.appendChild(tooltipContent[0]),
                            (rendered = !0));
                        });
                    }),
                    tooltip.onDestroy(() => {
                      (tooltipScope.$destroy(), (rendered = !1));
                    }),
                    tooltip
                  );
                },
                addSimpleTooltipToElement = (
                  element,
                  tooltipContentElement,
                ) => {
                  if (
                    element &&
                    tooltipContentElement &&
                    (element = element.querySelector(`.${SIMPLE_TIP_CLASS}`))
                  )
                    return (
                      element.classList.add(TOOLTIP_HINT_CLASS),
                      Tooltip.addToElement(element, tooltipContentElement)
                    );
                },
                columnMeetsDependencies = (columnId, cmdbPolicy) =>
                  CANDIDATE_COLUMNS[getColumnPolicyType()] &&
                  CANDIDATE_COLUMNS[getColumnPolicyType()].includes(columnId) &&
                  visibilityCheckPassed(columnId, cmdbPolicy);
              function policyStatsCellRendered(element, entry, column) {
                const row = this;
                if (!entry.stats[column.id]) return;
                (policyStats.addListener(entry.policyId, () => {
                  (entry.updatePolicyStats(), row.updateEntry({}));
                }),
                  (element =
                    element.querySelector(".compare-bar-caption-text") ||
                    element));
                const supportedKeys = SUPPORTED_COMPARE_TOOLTIP_KEYS.reduce(
                  (keys, columnId) => (
                    (keys[columnId] = columnMeetsDependencies(columnId)),
                    keys
                  ),
                  {},
                );
                let statsType, statsIpVersion;
                return (
                  columnMeetsDependencies(column.id) &&
                    policyStats.supportRollingStats(policyType) &&
                    ((statsType = policyStats.getRollingStatsType(column.id)),
                    (statsIpVersion =
                      policyStats.getRollingStatsDefaultIpversion(
                        policyType,
                        entry.cmdbModel,
                      ))),
                  addTemplateTooltipToElement(element, {
                    data: {
                      stats: entry.stats,
                      entry: {
                        "auto-asic-offload":
                          entry.cmdbModel["auto-asic-offload"],
                        policyId: entry.policyId,
                        policyType: entry.policyType,
                        "policy-offload": entry.cmdbModel["policy-offload"],
                        hitCount: entry.getHitCount(),
                        firstUsed: entry.getFirstUsed(),
                        lastUsed: entry.getLastUsed(),
                        bytes: entry.getBytes(),
                        packets: entry.getPackets(),
                        software_usage: entry.getSoftwareUsage(),
                        asic_usage: entry.getAsicUsage(),
                        nturbo_usage: entry.getNturboUsage(),
                        cgn_usage: entry.getCgnUsage(),
                      },
                      supportedKeys,
                      statsType,
                      statsIpVersion,
                    },
                    template:
                      '<f-policy-list-stats-tooltip stats-type=::statsType stats-ip-version=::statsIpVersion entry="::entry" stats="::stats" supported-keys="::supportedKeys"></f-policy-list-stats-tooltip>',
                  })
                );
              }
              function processInternetServicesDatasource(policy, direction) {
                const internetServiceDatasourceMap = new Map([
                  [
                    "firewall.internet-service-name",
                    "firewall.internet-service6-name",
                  ],
                  [
                    "firewall.internet-service-group",
                    "firewall.internet-service6-group",
                  ],
                  [
                    "firewall.internet-service-custom",
                    "firewall.internet-service6-custom",
                  ],
                  [
                    "firewall.internet-service-custom-group",
                    "firewall.internet-service6-custom-group",
                  ],
                ]);
                ("source" === direction
                  ? [
                      "internet-service6-src-name",
                      "internet-service6-src-group",
                      "internet-service6-src-custom",
                      "internet-service6-src-custom-group",
                    ]
                  : [
                      "internet-service6-name",
                      "internet-service6-group",
                      "internet-service6-custom",
                      "internet-service6-custom-group",
                    ]
                ).forEach((key) => {
                  const entries = policy[key];
                  entries &&
                    Array.isArray(entries) &&
                    entries.forEach((_entry) => {
                      const processedDatasource =
                        internetServiceDatasourceMap.get(_entry.datasource);
                      processedDatasource &&
                        (_entry.datasource = processedDatasource);
                    });
                });
              }
              function applyNegateStyle(element, collectionEntry, column) {
                if (
                  ((policy, collectionEntry, columnId) => {
                    let property;
                    "service" === columnId
                      ? (property = "service")
                      : ((property = [
                          "srcaddr",
                          "proxy-source",
                          "consolidated-source",
                          "security-source",
                          "consolidated-srcaddr",
                          "security-srcaddr",
                        ].includes(columnId)
                          ? "source"
                          : "destination"),
                        policyShared.isIpv6ConsolidatedAddr(collectionEntry) &&
                          (property = `${property}6`));
                    const negateKey = policyOmniselectConfig.getPolicyNegateKey(
                        policy,
                        property,
                      ),
                      datasource =
                        collectionEntry.datasource ||
                        `${collectionEntry.q_path}.${collectionEntry.q_name}`;
                    return (
                      "enable" === policy[negateKey] &&
                      ("service" === columnId || !datasource.includes("user"))
                    );
                  })(this.entry.cmdbModel, collectionEntry, column.id)
                ) {
                  let iconElement = element.querySelector("f-icon");
                  const negateIcon = "fa-negate";
                  if (iconElement) iconElement.className = negateIcon;
                  else if (
                    ((iconElement = element.querySelector(
                      ".app-icon-container",
                    )),
                    iconElement)
                  ) {
                    let container = iconElement.parentNode;
                    iconElement.remove();
                    const textElement = container.querySelector("span");
                    ((iconElement = fDom.elem("f-icon", {
                      className: negateIcon,
                    })),
                      container.insertBefore(iconElement, textElement));
                  }
                }
              }
              function applyPoolExhaustStyle(element, collectionEntry) {
                if (
                  ((ippoolEntry) => {
                    if (
                      (
                        ippoolEntry.datasource ||
                        `${ippoolEntry.q_path}.${ippoolEntry.q_name}`
                      ).includes("6")
                    )
                      return !1;
                    let poolMeta;
                    try {
                      poolMeta =
                        Omniselect.getSourceMetaDataSync("firewall.ippool");
                    } catch (e) {}
                    const poolStats =
                      poolMeta && poolMeta.poolStats[ippoolEntry.name];
                    return !!(poolStats && poolStats.available < 10);
                  })(collectionEntry)
                ) {
                  let iconElement = element.querySelector("f-icon");
                  const negateIcon = "ftnt-ip-pool-exhausted";
                  iconElement && (iconElement.className = negateIcon);
                }
              }
              const onIPPoolCellRendered = (element) =>
                  addSimpleTooltipToElement(
                    element,
                    fDom.elem(
                      "table",
                      { className: "table key-value" },
                      {
                        children: [
                          fDom.elem("tbody", null, {
                            children: [
                              fDom.elem("tr", null, {
                                children: [
                                  fDom.elem("td", {
                                    textContent: translate(
                                      "IP Pool Configuration",
                                    ),
                                  }),
                                  fDom.elem("td", {
                                    textContent: translate(
                                      "Use Outgoing Interface Address",
                                    ),
                                  }),
                                ],
                              }),
                            ],
                          }),
                        ],
                      },
                    ),
                  ),
                CONFIGS = {
                  policyid: {
                    langKey: "field_policyid",
                    type: "number",
                    numberType: "unformatted",
                    cellValueFunction: (entry) => entry.policyId,
                  },
                  name: {
                    langKey: "field_name",
                    cellValueFunction: cmdbCellValue,
                    editable: (entry) => !entry.implicit,
                    editableValidateFunction: (newValue, entry) => {
                      let cmdbRequests = [];
                      const isEmpty =
                        null == newValue ||
                        ("string" == typeof newValue && !newValue);
                      if (!state.featureVisible("unnamed_policy") && isEmpty)
                        return "This field is required";
                      return (
                        (cmdbRequests = ((entry) => {
                          const requestParams = { format: "name" };
                          let cmdbRequests = [];
                          switch (entry.policyType) {
                            case "hyperscale-policy":
                              cmdbRequests = [
                                cmdbGet(
                                  "firewall",
                                  "policy",
                                  null,
                                  requestParams,
                                ),
                              ];
                              break;
                            case "DoS-policy":
                            case "DoS-policy6":
                              cmdbRequests = [
                                cmdbGet(
                                  "firewall",
                                  "DoS-policy",
                                  null,
                                  requestParams,
                                ),
                                cmdbGet(
                                  "firewall",
                                  "DoS-policy6",
                                  null,
                                  requestParams,
                                ),
                              ];
                              break;
                            case "multicast-policy":
                            case "multicast-policy6":
                              cmdbRequests = [
                                cmdbGet(
                                  "firewall",
                                  "multicast-policy",
                                  null,
                                  requestParams,
                                ),
                                cmdbGet(
                                  "firewall",
                                  "multicast-policy6",
                                  null,
                                  requestParams,
                                ),
                              ];
                              break;
                            case "acl":
                            case "acl6":
                              cmdbRequests = [
                                cmdbGet("firewall", "acl", null, requestParams),
                                cmdbGet(
                                  "firewall",
                                  "acl6",
                                  null,
                                  requestParams,
                                ),
                              ];
                              break;
                            case "proxy-policy":
                              cmdbRequests = [
                                cmdbGet(
                                  "firewall",
                                  "proxy-policy",
                                  null,
                                  requestParams,
                                ),
                              ];
                              break;
                            default:
                              cmdbRequests = [
                                cmdbGet(
                                  "firewall",
                                  "policy",
                                  null,
                                  requestParams,
                                ),
                                cmdbGet(
                                  "firewall",
                                  "security-policy",
                                  null,
                                  requestParams,
                                ),
                              ];
                          }
                          return cmdbRequests;
                        })(entry)),
                        newValue &&
                          newValue !== entry.cmdbModel.name &&
                          $q
                            .all(cmdbRequests)
                            .then(
                              (policyLists) =>
                                policyLists.some((policyList) =>
                                  policyList.some(
                                    (policy) => policy.name === newValue,
                                  ),
                                ) && "-15",
                            )
                      );
                    },
                    cellFormatter: (entry, column, value) => {
                      let children = [];
                      return (
                        "disable" === entry.cmdbModel.status &&
                          children.push(
                            fDom.elem("f-icon", { className: "fa-disabled" }),
                          ),
                        entry.warnings &&
                          entry.warnings.length > 0 &&
                          children.push(
                            fDom.elem("f-icon", { className: "fa-warning" }),
                          ),
                        fDom.elem(
                          "label",
                          {
                            className: LAZY_TEMPLATE_TIP_CLASS,
                            textContent: value,
                          },
                          { children },
                        )
                      );
                    },
                    onCellRendered: (element, entry, column, cellValue) =>
                      addTemplateTooltipToElement(element, {
                        data: {
                          entry: {
                            policyId: entry.policyId,
                            name: cellValue,
                            status: entry.cmdbModel.status,
                            action: entry.cmdbModel.action,
                          },
                          warnings: entry.warnings,
                        },
                        template:
                          '<f-policy-list-id-tooltip entry="::entry" warnings="::warnings"></f-policy-list-id-tooltip>',
                      }),
                  },
                  proxy: {
                    langKey: "Type",
                    cellValueFunction: (entry) => {
                      let value = entry.cmdbModel.proxy;
                      return (
                        null != value &&
                          (value = translate(`proxy_type_${value}`)),
                        value
                      );
                    },
                  },
                  srcintf: {
                    langKey: "field_srcintf",
                    type: "omniselect",
                    cellValueFunction: defaultIntfOmniselectCellValueFunction,
                    editable: (entry) =>
                      !policyVWP.isVirtualWirePolicy() &&
                      !entry.implicit &&
                      !entry.isCentralSnatMap(),
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  dstintf: {
                    langKey: "field_dstintf",
                    type: "omniselect",
                    cellValueFunction: defaultIntfOmniselectCellValueFunction,
                    editable: (entry) =>
                      !(
                        policyVWP.isVirtualWirePolicy() ||
                        entry.implicit ||
                        entry.isCentralSnatMap() ||
                        entry.isZTNAFirewallPolicy() ||
                        entry.isZTNAProxyPolicy()
                      ),
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  interface: {
                    langKey: "field_interface",
                    type: "omniselect",
                    cellValueFunction: defaultIntfOmniselectCellValueFunction,
                    editable: defaultEditableCheck,
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  status: {
                    langKey: "field_status",
                    cellValueFunction: enableDisableCellValue,
                    cellFormatter: (entry, column, translatedValue) => {
                      const icon =
                          { enable: "fa-enabled", disable: "fa-disabled" }[
                            entry.cmdbModel.status
                          ] || "",
                        actionElems = [
                          fDom.elem("f-icon", { className: icon }),
                          fDom.elem("span", { textContent: translatedValue }),
                        ];
                      return fDom.elem("span", null, { children: actionElems });
                    },
                    editable: (entry) => !entry.implicit,
                    editableType: "selection",
                    editableOptions: enableDisableOptions,
                  },
                  "proxy-source": {
                    langKey: "field_source",
                    type: "omniselect",
                    collectionEntryOnRender: applyNegateStyle,
                    cellValueFunction: (entry) => entry.proxySource,
                    editable: (entry) =>
                      !entry.implicit && !entry.isZTNAFirewallPolicy(),
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "proxy-destination": {
                    langKey: "field_destination",
                    type: "omniselect",
                    collectionEntryOnRender: applyNegateStyle,
                    cellValueFunction: (entry) => (
                      "enable" === entry.cmdbModel["internet-service6"] &&
                        processInternetServicesDatasource(entry.cmdbModel),
                      entry.proxyDestination
                    ),
                    editable: (entry) =>
                      !entry.implicit && !entry.isZTNAFirewallPolicy(),
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  srcaddr: {
                    langKey: "src_addr",
                    type: "omniselect",
                    cellValueFunction: defaultAddrOmniselectCellValueFunction,
                    collectionEntryOnRender: applyNegateStyle,
                    editable: (entry) =>
                      defaultEditableCheck(entry) &&
                      !entry.isInternetServiceSourcePolicy(),
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "consolidated-source": {
                    langKey: "field_source",
                    type: "omniselect",
                    collectionEntryOnRender: applyNegateStyle,
                    cellValueFunction: (entry) => (
                      "enable" === entry.cmdbModel["internet-service6-src"] &&
                        processInternetServicesDatasource(
                          entry.cmdbModel,
                          "source",
                        ),
                      entry.consolidatedSource
                    ),
                    editable: (entry) => !entry.implicit,
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "consolidated-srcaddr": {
                    langKey: "src_addr",
                    type: "omniselect",
                    collectionEntryOnRender: applyNegateStyle,
                    cellValueFunction: (entry) =>
                      entry.consolidatedSourceAddress,
                    editable: (entry) => !entry.implicit,
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "consolidated-dstaddr": {
                    langKey: "field_dstaddr",
                    type: "omniselect",
                    collectionEntryOnRender: applyNegateStyle,
                    cellValueFunction: (entry) =>
                      entry.consolidatedDestinationAddress,
                    editable: (entry) =>
                      !entry.implicit && !entry.isZTNAFirewallPolicy(),
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "consolidated-destination": {
                    langKey: "field_destination",
                    type: "omniselect",
                    collectionEntryOnRender: applyNegateStyle,
                    cellValueFunction: (entry) => (
                      "enable" === entry.cmdbModel["internet-service6"] &&
                        processInternetServicesDatasource(
                          entry.cmdbModel,
                          "destination",
                        ),
                      entry.consolidatedDestination
                    ),
                    editable: (entry) =>
                      !entry.implicit && !entry.isZTNAFirewallPolicy(),
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "security-source": {
                    langKey: "field_source",
                    type: "omniselect",
                    collectionEntryOnRender: applyNegateStyle,
                    cellValueFunction: (entry) => entry.securitySource,
                    editable: (entry) =>
                      !entry.implicit && !entryHasLearnMode(entry),
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "security-srcaddr": {
                    langKey: "src_addr",
                    type: "omniselect",
                    collectionEntryOnRender: applyNegateStyle,
                    cellValueFunction: (entry) => entry.securitySourceAddress,
                    editable: (entry) =>
                      !entry.implicit && !entryHasLearnMode(entry),
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "security-destination": {
                    langKey: "field_destination",
                    type: "omniselect",
                    collectionEntryOnRender: applyNegateStyle,
                    cellValueFunction: (entry) => entry.securityDestination,
                    editable: (entry) =>
                      !entry.implicit && !entryHasLearnMode(entry),
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "security-dstaddr": {
                    langKey: "field_dstaddr",
                    type: "omniselect",
                    collectionEntryOnRender: applyNegateStyle,
                    cellValueFunction: (entry) =>
                      entry.securityDestinationAddress,
                    editable: (entry) =>
                      !entry.implicit && !entryHasLearnMode(entry),
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "orig-addr": {
                    langKey: "src_addr",
                    type: "omniselect",
                    cellValueFunction: cmdbCellValue,
                  },
                  dstaddr: {
                    langKey: "field_dstaddr",
                    type: "omniselect",
                    cellValueFunction: defaultAddrOmniselectCellValueFunction,
                    collectionEntryOnRender: applyNegateStyle,
                    editable: (entry) =>
                      defaultEditableCheck(entry) &&
                      !entry.isInternetServicePolicy(),
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "dst-addr": {
                    langKey: "field_dstaddr",
                    type: "omniselect",
                    cellValueFunction: cmdbCellValue,
                  },
                  "ztna-status": {
                    langKey: "Enforce ZTNA",
                    cellValueFunction: (entry) => {
                      if (entry.isZTNAFirewallPolicy()) return "";
                      let value = entry.cmdbModel["ztna-status"];
                      return value ? translate(`${value}d`) : "";
                    },
                    cellFormatter: (entry, column, translatedValue) => {
                      if (entry.isZTNAFirewallPolicy()) return "";
                      const icon =
                          { enable: "fa-enabled", disable: "fa-disabled" }[
                            entry.cmdbModel["ztna-status"]
                          ] || "",
                        actionElems = [
                          fDom.elem("f-icon", { className: icon }),
                          fDom.elem("span", { textContent: translatedValue }),
                        ];
                      return fDom.elem("span", null, { children: actionElems });
                    },
                    editable: (entry) =>
                      !entry.implicit &&
                      "ipv4" === entry.cmdbModel["ip-version-type"] &&
                      !entry.isZTNAFirewallPolicy(),
                    editableType: "selection",
                    editableOptions: enableDisableOptions,
                  },
                  "policy-behaviour-type": {
                    langKey: "Type",
                    cellValueFunction: (entry) => {
                      let type = "Standard";
                      return (
                        "ztna" === entry.cmdbModel["policy-behaviour-type"]
                          ? (type = "ZTNA")
                          : "vwp" ===
                              entry.cmdbModel["policy-behaviour-type"] &&
                            (type = "Virtual Wire Pair"),
                        entry.implicit ? "" : lang(type)
                      );
                    },
                  },
                  "policy-expiry-date": {
                    langKey: "Expiration Date",
                    type: "date",
                    cellValueFunction: (entry) => {
                      const expiry = entry.cmdbModel["policy-expiry-date"];
                      if ("enable" === entry.cmdbModel["policy-expiry"]) {
                        if (expiry === DEFAULT_POLICY_EXPIRY)
                          return new Date().setDate(
                            new Date().getDate() +
                              configParams.defaultPolicyExpiryDays,
                          );
                        {
                          let expiryDate = new Date(expiry);
                          isNaN(expiryDate.getTime()) &&
                            (expiryDate = new Date());
                          const offset =
                            "system" === state.date_format_device
                              ? -1 * state.getDisplayTzOffset(expiryDate)
                              : state.getDisplayTzOffset(expiryDate);
                          return expiryDate.getTime() + offset;
                        }
                      }
                    },
                  },
                  "ztna-ems-tag": {
                    langKey: "Security Posture Tag",
                    type: "omniselect",
                    cellValueFunction: createOmniselectCellValueFunction({
                      "firewall.address": "ztna-tags",
                      "firewall.addrgrp": "ztna-tag-groups",
                    }),
                    editable: (entry) =>
                      !entry.implicit &&
                      (entry.isZTNAProxyPolicy() ||
                        "enable" === entry.cmdbModel["ztna-status"] ||
                        entry.isZTNAFirewallPolicy()),
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  schedule: {
                    langKey: "field_schedule",
                    type: "omniselect",
                    cellValueFunction: cmdbCellValue,
                    editable: (entry) =>
                      !entry.implicit && !entryHasLearnMode(entry),
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  service: {
                    langKey: "field_service",
                    type: "omniselect",
                    cellValueFunction: cmdbCellValue,
                    cellIsValidCollectionFunction: (entry) =>
                      !(
                        entry.enforceDefaultAppPort() ||
                        (entry.isInternetServicePolicy() &&
                          !entry.hasDestinationAddress) ||
                        (entry.isProxyPolicy() &&
                          "ftp" === entry.cmdbModel.proxy)
                      ),
                    collectionEntryOnRender: applyNegateStyle,
                    collectionFallbackFormatter: (entry) =>
                      entry.enforceDefaultAppPort()
                        ? translate("App Default")
                        : entry.isInternetServicePolicy() &&
                            !entry.hasDestinationAddress
                          ? translate("Internet Service")
                          : entry.isProxyPolicy() &&
                              "ftp" === entry.cmdbModel.proxy
                            ? translate("ftp-proxy")
                            : "",
                    editable: (entry) =>
                      defaultEditableCheck(entry) &&
                      (entry.enforceDefaultAppPort() ||
                        (!entry.isInternetServicePolicy() &&
                          (!entry.isProxyPolicy() ||
                            "ftp" !== entry.cmdbModel.proxy))) &&
                      !entryHasLearnMode(entry),
                    editableOmniselectSettings: getOmniselectSettings,
                    editableType: "selection",
                    editableOptions: [
                      new MuTable.EditableOption({
                        label: translate("App Default"),
                        cellValue: translate("App Default").toString(),
                        entryValue: "enable",
                      }),
                      new MuTable.EditableOption({
                        label: translate("Specify"),
                        cellValue: translate("Specify").toString(),
                        entryValue: "disable",
                      }),
                    ],
                  },
                  applications: {
                    langKey: "field_application",
                    type: "omniselect",
                    editable: (entry) =>
                      !entry.implicit && !entryHasLearnMode(entry),
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "url-category": {
                    langKey: "URL Category",
                    type: "omniselect",
                    cellValueFunction: (entry) => entry.urlCategory,
                    editable: (entry) =>
                      !entry.implicit && !entryHasLearnMode(entry),
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  groups: {
                    langKey: "field_groups",
                    type: "omniselect",
                    cellValueFunction: cmdbCellValue,
                    editable: (entry) =>
                      !entry.implicit &&
                      "ipsec" !== entry.cmdbModel.action &&
                      !entryHasLearnMode(entry),
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  users: {
                    langKey: "field_users",
                    type: "omniselect",
                    cellValueFunction: cmdbCellValue,
                    editable: (entry) =>
                      !entry.implicit &&
                      "ipsec" !== entry.cmdbModel.action &&
                      !entryHasLearnMode(entry),
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  vpntunnel: {
                    langKey: "field_vpntunnel",
                    type: "omniselect",
                    cellValueFunction: cmdbCellValue,
                    editable: (entry) =>
                      !entry.implicit && "ipsec" === entry.cmdbModel.action,
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  action: {
                    langKey: "field_action",
                    type: "collection",
                    cellIsValidCollectionFunction: (entry) =>
                      Array.isArray(entry.action),
                    collectionFallbackValueFunction: (entry) =>
                      entryHasLearnMode(entry)
                        ? translate(`${POLICY_ACTION_BASE_KEY}learn`)
                        : translate(POLICY_ACTION_BASE_KEY + entry.action),
                    collectionFallbackFormatter: (entry, column, cellValue) =>
                      entryHasLearnMode(entry)
                        ? formatOneAction("learn", cellValue)
                        : formatOneAction(entry.action, cellValue),
                    collectionEntryValueFunction: (collectionEntry) => ({
                      value: translate(
                        POLICY_ACTION_BASE_KEY + collectionEntry.value,
                      ),
                      rawValue: collectionEntry.value,
                      title: collectionEntry.title,
                    }),
                    collectionEntryFormatter: (
                      entry,
                      collectionEntryValueObject,
                    ) =>
                      formatOneAction(
                        collectionEntryValueObject.rawValue,
                        collectionEntryValueObject.value,
                        collectionEntryValueObject.title,
                      ),
                    collectionEntryMatchesSearch: (
                      collectionEntry,
                      searchValue,
                    ) =>
                      translate(POLICY_ACTION_BASE_KEY + collectionEntry.value)
                        .toLowerCase()
                        .indexOf(searchValue) >= 0,
                    editable: (entry) =>
                      !(
                        entry.implicit ||
                        Array.isArray(entry.action) ||
                        entryHasLearnMode(entry) ||
                        entry.isHyperscalePolicy()
                      ),
                    editableType: "selection",
                    editableOptions: actionOptions,
                  },
                  acl_action: {
                    langKey: "field_action",
                    cellValueFunction: () => translate("deny"),
                    cellFormatter: (entry, column, translatedValue) => {
                      const actionElems = [
                        fDom.elem("f-icon", { className: "fa-denied" }),
                        fDom.elem("span", { textContent: translatedValue }),
                      ];
                      return fDom.elem("span", null, { children: actionElems });
                    },
                  },
                  poolname: {
                    langKey: "field_nat",
                    type: "omniselect",
                    cellValueFunction: cmdbCellValue,
                    cellIsValidCollectionFunction: (entry, column) =>
                      natEnabledIsCollection(entry, column),
                    collectionEntryOnRender: applyPoolExhaustStyle,
                    collectionFallbackFormatter: (entry, column) =>
                      natEnabledFallback(entry, column),
                    editable: (entry) => {
                      const centralNatEnabled = state.centralNatEnabled({
                        skipNgfwCheck: !0,
                      });
                      if (entry.implicit) return !1;
                      if (
                        !centralNatEnabled &&
                        "central-snat-map" !== policyType
                      ) {
                        const dependencies = [
                          new PolicyEntry.PolicyValueDependency("action", [
                            "accept",
                          ]),
                        ];
                        if (!entry.meetValueDependencies(dependencies))
                          return !1;
                      }
                      return !0;
                    },
                    editableType: "selection",
                    editableOptions: enableDisableOptions,
                    editableOmniselectSettings: getOmniselectSettings,
                    onCellRendered: onIPPoolCellRendered,
                  },
                  "consolidated-poolname": {
                    langKey: "field_nat",
                    type: "omniselect",
                    cellValueFunction: (entry) => entry.consolidatedPoolname,
                    cellIsValidCollectionFunction: (entry, column) =>
                      !state.centralNatEnabled({ skipNgfwCheck: !0 }) &&
                      natEnabledIsCollection(entry, column),
                    collectionEntryOnRender: applyPoolExhaustStyle,
                    collectionFallbackFormatter: (entry, column) => {
                      const cmdbPolicy = entry.cmdbModel;
                      return state.centralNatEnabled({ skipNgfwCheck: !0 })
                        ? "deny" === cmdbPolicy.action
                          ? ""
                          : fDom.elem(
                              "span",
                              {
                                title: translate(INFO_CENTRAL_SNAT),
                                className: SIMPLE_TIP_CLASS,
                              },
                              {
                                children: [
                                  fDom.elem("f-icon", {
                                    className: "fa-help-info",
                                  }),
                                  fDom.elem("span", {
                                    textContent: translate("Custom"),
                                  }),
                                ],
                              },
                            )
                        : natEnabledFallback(entry, column);
                    },
                    editable: (entry) => {
                      const centralNatEnabled = state.centralNatEnabled({
                        skipNgfwCheck: !0,
                      });
                      if (entry.implicit || centralNatEnabled) return !1;
                      if (!centralNatEnabled) {
                        const dependencies = [
                          new PolicyEntry.PolicyValueDependency("action", [
                            "accept",
                          ]),
                        ];
                        if (!entry.meetValueDependencies(dependencies))
                          return !1;
                        if (entry.isHyperscalePolicy())
                          return "enable" === entry.cmdbModel.ippool;
                        if (policyVWP.isVirtualWirePolicy())
                          return "enable" === entry.cmdbModel.nat;
                      }
                      return !0;
                    },
                    editableOmniselectSettings: getOmniselectSettings,
                    editableType: "selection",
                    editableOptions: enableDisableOptions,
                    onCellRendered: onIPPoolCellRendered,
                  },
                  "ngfw-consolidated-nat": {
                    langKey: "field_nat",
                    cellValueFunction: () => translate("Custom"),
                    cellFormatter: (entry, column, translatedValue) =>
                      entry.implicit
                        ? ""
                        : fDom.elem(
                            "span",
                            {
                              title: translate(INFO_CENTRAL_SNAT),
                              className: SIMPLE_TIP_CLASS,
                            },
                            {
                              children: [
                                fDom.elem("f-icon", {
                                  className: "fa-help-info",
                                }),
                                fDom.elem("span", {
                                  textContent: translatedValue,
                                }),
                              ],
                            },
                          ),
                    onCellRendered: (element, entry) => {
                      if (!entry.implicit)
                        return addSimpleTooltipToElement(
                          element,
                          translate(INFO_CENTRAL_SNAT),
                        );
                    },
                  },
                  "nat-ippool": {
                    langKey: "trnsaddr",
                    type: "omniselect",
                    hidden: (entry) => "ipv6" === entry.cmdbModel.type,
                    cellValueFunction: cmdbCellValue,
                    cellIsValidCollectionFunction: (entry, column) =>
                      natEnabledIsCollection(entry, column),
                    collectionEntryOnRender: applyPoolExhaustStyle,
                    collectionFallbackFormatter: (entry, column) =>
                      natEnabledFallback(entry, column),
                    editable: (entry, column) => {
                      const cmdbModel = entry.cmdbModel;
                      if (
                        entry.implicit ||
                        !natEnabledIsCollection(entry, column)
                      )
                        return !1;
                      if (
                        "ipv6" === entry.cmdbModel.type ||
                        "enable" === entry.cmdbModel.nat46
                      )
                        return !1;
                      return (
                        ("0" === cmdbModel["orig-port"]) ===
                        ("0" === cmdbModel["nat-port"])
                      );
                    },
                    editableOmniselectSettings: (entry) =>
                      ("ipv6" === entry.cmdbModel.type &&
                        "enable" !== entry.cmdbModel.nat64) ||
                      "enable" === entry.cmdbModel.nat46
                        ? {
                            sources: ["firewall.ippool6"],
                            filterFunction: (ippool) =>
                              "enable" === entry.cmdbModel.nat46
                                ? "enable" === ippool.nat46
                                : "enable" !== ippool.nat46,
                          }
                        : {
                            sources: ["firewall.ippool"],
                            filterFunction: (ippool) =>
                              "enable" === entry.cmdbModel.nat64
                                ? "enable" === ippool.nat64
                                : "enable" !== ippool.nat64,
                          },
                    editableRequired: !0,
                  },
                  snat: {
                    langKey: "field_snat",
                    cellValueFunction: enableDisableCellValue,
                    cellFormatter: (entry, column) =>
                      natEnabledFallback(entry, column),
                    editable: (entry) =>
                      !entry.implicit && !entry.isDenyPolicy(),
                    editableType: "selection",
                    editableOptions: enableDisableOptions,
                  },
                  dnat: {
                    langKey: "field_dnat",
                    cellValueFunction: cmdbCellValue,
                  },
                  "orig-port": {
                    langKey: "srcport",
                    cellValueFunction: cmdbCellValue,
                    cellFormatter: (entry, column, value) => (
                      0 === Number(value) && (value = ""),
                      value
                    ),
                  },
                  "nat-port": {
                    langKey: "trnsport",
                    cellValueFunction: cmdbCellValue,
                    cellFormatter: (entry, column, value) => (
                      0 === Number(value) && (value = ""),
                      value
                    ),
                  },
                  profile: {
                    langKey: "field_profile",
                    type: "omniselect",
                    collectionEntryHeight: 20,
                    editable: (entry) =>
                      !(
                        entry.implicit ||
                        entry.isDenyPolicy() ||
                        state.featureVisible("vpn_firewall_only") ||
                        entryHasLearnMode(entry)
                      ),
                    editableOmniselectSettings: (entry) => {
                      const filteredColumnIds = UTM_PROFILE_COLUMN_IDS.filter(
                        (columnId) =>
                          columnMeetsDependencies(columnId, entry.cmdbModel),
                      );
                      return policyOmniselectConfig.getProfilesSettings(
                        filteredColumnIds,
                        entry.cmdbModel,
                      );
                    },
                  },
                  "av-profile": {
                    langKey: "field_av-profile",
                    type: "omniselect",
                    cellValueFunction: utmProfileCellValue,
                    editable: utmProfileEditable,
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "emailfilter-profile": {
                    langKey: "field_emailfilter-profile",
                    type: "omniselect",
                    cellValueFunction: utmProfileCellValue,
                    editable: utmProfileEditable,
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "webfilter-profile": {
                    langKey: "field_webfilter-profile",
                    type: "omniselect",
                    cellValueFunction: utmProfileCellValue,
                    editable: utmProfileEditable,
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "videofilter-profile": {
                    langKey: "Video Filter",
                    type: "omniselect",
                    cellValueFunction: utmProfileCellValue,
                    editable: utmProfileEditable,
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "dlp-profile": {
                    langKey: "dlp.profile",
                    type: "omniselect",
                    cellValueFunction: utmProfileCellValue,
                    editable: utmProfileEditable,
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "file-filter-profile": {
                    langKey: "File Filter",
                    type: "omniselect",
                    cellValueFunction: utmProfileCellValue,
                    editable: utmProfileEditable,
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "virtual-patch-profile": {
                    langKey: "Virtual Patching",
                    type: "omniselect",
                    cellValueFunction: utmProfileCellValue,
                    editable: utmProfileEditable,
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "dnsfilter-profile": {
                    langKey: "field_dnsfilter-profile",
                    type: "omniselect",
                    cellValueFunction: utmProfileCellValue,
                    editable: utmProfileEditable,
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "casb-profile": {
                    langKey: "field_casb-profile",
                    type: "omniselect",
                    cellValueFunction: utmProfileCellValue,
                    editable: utmProfileEditable,
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "waf-profile": {
                    langKey: "field_waf-profile",
                    type: "omniselect",
                    cellValueFunction: utmProfileCellValue,
                    editable: utmProfileEditable,
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "application-list": {
                    langKey: "field_application-list",
                    type: "omniselect",
                    cellValueFunction: utmProfileCellValue,
                    editable: utmProfileEditable,
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "ips-sensor": {
                    langKey: "field_ips-sensor",
                    type: "omniselect",
                    cellValueFunction: utmProfileCellValue,
                    editable: utmProfileEditable,
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "icap-profile": {
                    langKey: "field_icap-profile",
                    type: "omniselect",
                    cellValueFunction: utmProfileCellValue,
                    editable: utmProfileEditable,
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "voip-profile": {
                    langKey: "field_voip-profile",
                    type: "omniselect",
                    cellValueFunction: utmProfileCellValue,
                    editable: utmProfileEditable,
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "profile-protocol-options": {
                    langKey: "field_profile-protocol-options",
                    type: "omniselect",
                    cellValueFunction: utmProfileCellValue,
                    editable: utmProfileEditable,
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "ssl-ssh-profile": {
                    langKey: "field_ssl-ssh-profile",
                    type: "omniselect",
                    cellValueFunction: utmProfileCellValue,
                    editable: utmProfileEditable,
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "profile-group": {
                    langKey: "field_profile-group",
                    type: "omniselect",
                    cellValueFunction: utmProfileCellValue,
                    editable: utmProfileEditable,
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "gtp-profile": {
                    langKey: "field_gtp-profile",
                    type: "omniselect",
                    cellValueFunction: cmdbCellValue,
                    editable: (entry) => !entry.implicit,
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "access-proxy": {
                    langKey: "ZTNA Server",
                    type: "omniselect",
                    cellValueFunction: createOmniselectCellValueFunction(
                      {
                        "firewall.access-proxy": "ztna-servers",
                        "firewall.access-proxy6": "ztna-servers6",
                      },
                      (_entry) => [
                        ...(_entry.cmdbModel["access-proxy"] || []),
                        ...((state.featureVisible("ipv6") &&
                          _entry.cmdbModel["access-proxy6"]) ||
                          []),
                      ],
                    ),
                    editable: (entry) =>
                      !entry.implicit &&
                      "access-proxy" === entry.cmdbModel.proxy,
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  protocol: {
                    langKey: "field_protocol",
                    cellValueFunction: (entry, x) => {
                      const mappedObj = policyOmniselectConfig
                        .get("protocol", entry)
                        .options.find((m) => entry.cmdbModel.protocol === m.id);
                      let protocolName;
                      protocolName = mappedObj
                        ? "any" === mappedObj.name
                          ? translate("Any")
                          : translate(mappedObj.name)
                        : translate("Other");
                      return `${mappedObj ? mappedObj.id : cmdbCellValue(entry, x)} (${protocolName})`;
                    },
                  },
                  "cgn-log-server-grp": {
                    langKey: "Log Server Group",
                    type: "omniselect",
                    cellValueFunction: cmdbCellValue,
                    collectionFallbackFormatter: () => "",
                    editable: (entry) =>
                      !entry.implicit &&
                      "deny" !== entry.cmdbModel.action &&
                      "enable" === entry.cmdbModel["policy-offload"],
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  logtraffic: {
                    langKey: "field_logtraffic",
                    type: "collection",
                    cellIsValidCollectionFunction: (entry) =>
                      Array.isArray(entry.cmdbModel.logtraffic),
                    cellValueFunction: cmdbCellValue,
                    collectionFallbackValueFunction: (entry) =>
                      logTrafficCellValue(entry.cmdbModel.logtraffic),
                    collectionFallbackFormatter: (
                      entry,
                      column,
                      translatedValue,
                    ) => {
                      let cellElem;
                      return (
                        (cellElem = configParams.isDefaultSyncMode
                          ? formatOneLogTraffic(
                              null,
                              "fa-help-info",
                              translatedValue,
                              SIMPLE_TIP_CLASS,
                            )
                          : formatOneLogTraffic(
                              entry.cmdbModel.logtraffic,
                              null,
                              translatedValue,
                            )),
                        cellElem
                      );
                    },
                    collectionEntryValueFunction: (collectionEntry) => ({
                      value: logTrafficCellValue(collectionEntry.value),
                      rawValue: collectionEntry.value,
                      title: collectionEntry.title,
                    }),
                    collectionEntryFormatter: (
                      entry,
                      collectionEntryValueObject,
                    ) =>
                      formatOneLogTraffic(
                        collectionEntryValueObject.rawValue,
                        null,
                        collectionEntryValueObject.value,
                        null,
                        collectionEntryValueObject.title,
                      ),
                    collectionEntryMatchesSearch: (
                      collectionEntry,
                      searchValue,
                    ) =>
                      logTrafficCellValue(collectionEntry.value)
                        .toLowerCase()
                        .indexOf(searchValue) >= 0,
                    onCellRendered: (element) =>
                      addSimpleTooltipToElement(
                        element,
                        translate(
                          "Security Fabric is enabled so logging will exempt traffic from downstream FortiGates.",
                        ),
                      ),
                    editable: (entry) =>
                      !configParams.isDefaultSyncMode &&
                      !entryHasLearnMode(entry),
                    editableType: "selection",
                    editableOptions: (entry) => {
                      if (entry.implicit) return enableDisableOptions;
                      {
                        let options = [];
                        if (
                          [
                            "policy",
                            "proxy-policy",
                            "security-policy",
                            "multicast-policy6",
                            "multicast-policy",
                          ].includes(policyType)
                        ) {
                          state.featureVisible("vpn_firewall_only")
                            ? options.push(
                                new MuTable.EditableOption({
                                  label: translate("enable"),
                                  entryValue: "all",
                                }),
                              )
                            : options.push(
                                new MuTable.EditableOption({
                                  label: translate("all"),
                                  entryValue: "all",
                                }),
                              );
                          const dependencies = [
                            new PolicyEntry.PolicyValueDependency("action", [
                              "accept",
                              "ipsec",
                            ]),
                          ];
                          entry.meetValueDependencies(dependencies) &&
                            !state.featureVisible("vpn_firewall_only") &&
                            options.push(
                              new MuTable.EditableOption({
                                label: translate("UTM"),
                                entryValue: "utm",
                              }),
                            );
                        } else
                          options.push(
                            new MuTable.EditableOption({
                              label: translate("enable"),
                              entryValue: "enable",
                            }),
                          );
                        return (
                          options.push(
                            new MuTable.EditableOption({
                              label: translate("disable"),
                              entryValue: "disable",
                            }),
                          ),
                          options
                        );
                      }
                    },
                  },
                  bytes: {
                    type: "number",
                    numberType: "metricBytes",
                    numberCompareBar: !0,
                    langKey: "field_bytes",
                    cellValueFunction: (entry) => entry.getBytes(),
                    onCellRendered: policyStatsCellRendered,
                  },
                  packets: {
                    type: "number",
                    numberCompareBar: !0,
                    cellValueFunction: (entry) => entry.getPackets(),
                    onCellRendered: policyStatsCellRendered,
                  },
                  software_bytes: {
                    langKey: "CPU Bytes",
                    type: "number",
                    numberType: "metricBytes",
                    numberCompareBar: !0,
                    getCompareBarMax: (entry) => entry.stats.bytes,
                    cellValueFunction: statsCellValue,
                    onCellRendered: policyStatsCellRendered,
                  },
                  software_packets: {
                    langKey: "CPU Packets",
                    type: "number",
                    numberCompareBar: !0,
                    getCompareBarMax: (entry) => entry.stats.packets,
                    cellValueFunction: statsCellValue,
                    onCellRendered: policyStatsCellRendered,
                  },
                  asic_bytes: {
                    langKey: "SPU Bytes",
                    type: "number",
                    numberType: "metricBytes",
                    cellValueFunction: statsCellValue,
                    onCellRendered: policyStatsCellRendered,
                  },
                  asic_packets: {
                    langKey: "SPU Packets",
                    type: "number",
                    cellValueFunction: statsCellValue,
                    onCellRendered: policyStatsCellRendered,
                  },
                  nturbo_bytes: {
                    langKey: "nTurbo Bytes",
                    type: "number",
                    numberType: "metricBytes",
                    cellValueFunction: statsCellValue,
                    onCellRendered: policyStatsCellRendered,
                  },
                  nturbo_packets: {
                    langKey: "nTurbo Packets",
                    type: "number",
                    cellValueFunction: statsCellValue,
                    onCellRendered: policyStatsCellRendered,
                  },
                  cgn_bytes: {
                    langKey: "Hyperscale SPU Bytes",
                    type: "number",
                    numberType: "metricBytes",
                    numberCompareBar: !0,
                    cellValueFunction: statsCellValue,
                    onCellRendered: policyStatsCellRendered,
                  },
                  cgn_packets: {
                    langKey: "Hyperscale SPU Packets",
                    type: "number",
                    numberCompareBar: !0,
                    cellValueFunction: statsCellValue,
                    onCellRendered: policyStatsCellRendered,
                  },
                  last_used: {
                    type: "date",
                    dateType: "fromNow",
                    cellValueFunction: (entry) => entry.getLastUsed(),
                    onCellRendered: policyStatsCellRendered,
                  },
                  first_used: {
                    type: "date",
                    dateType: "fromNow",
                    cellValueFunction: (entry) => entry.getFirstUsed(),
                    onCellRendered: policyStatsCellRendered,
                  },
                  active_sessions: {
                    type: "number",
                    numberCompareBar: !0,
                    cellValueFunction: statsCellValue,
                    onCellRendered: policyStatsCellRendered,
                  },
                  hit_count: {
                    type: "number",
                    numberCompareBar: !0,
                    cellValueFunction: async (entry) => (
                      await entry.stats,
                      entry.getHitCount()
                    ),
                    onCellRendered: policyStatsCellRendered,
                  },
                  packets_dropped: {
                    langKey: "Packets Dropped",
                    type: "number",
                    numberCompareBar: !0,
                    cellValueFunction: statsCellValue,
                    onCellRendered: policyStatsCellRendered,
                  },
                  comments: Object.assign(
                    {},
                    MuTable.STANDARD_COLUMNS.comments,
                    {
                      editable: (entry) => !entry.implicit,
                      cellValueFunction: cmdbCellValue,
                    },
                  ),
                  "inspection-mode": {
                    langKey: "inspect_mode",
                    cellValueFunction: (entry) => {
                      const inspectionMode = entry.cmdbModel["inspection-mode"];
                      if (inspectionMode)
                        return translate(`inspection_mode::${inspectionMode}`);
                    },
                  },
                  "ip-version": {
                    langKey: "IP Version",
                    type: "standard",
                    cellValueFunction: (entry) => {
                      if (entry.implicit) return translate("implicit");
                      if ("central-snat-map" === policyType) {
                        const ipVersion = entry.cmdbModel.type;
                        return translate(ipVersion);
                      }
                      const ipVersion = entry.cmdbModel["ip-version"];
                      return translate(`IPv${ipVersion}`);
                    },
                    cellFormatter: function (entry, column, value) {
                      return entry.implicit
                        ? fDom.elem("div", {
                            className: "empty-sequence-grouping",
                            textContent: value,
                          })
                        : value;
                    },
                    sortComparator: function (a, b, entryA, entryB) {
                      return entryA.implicit
                        ? 1
                        : entryB.implicit
                          ? -1
                          : a.compareTo(b);
                    },
                  },
                  "traffic-shaper": {
                    langKey: "traffic_fwd",
                    type: "omniselect",
                    cellValueFunction: cmdbCellValue,
                    cellIsValidCollectionFunction: function (entry) {
                      return !entry.implicit;
                    },
                    collectionFallbackFormatter: function (entry, column) {
                      return cmdbCellValue(entry, column);
                    },
                    editable: (entry) =>
                      !(
                        entry.implicit ||
                        (entry.isHyperscalePolicy() && "deny" === entry.action)
                      ),
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                  "traffic-shaper-reverse": {
                    langKey: "Reverse Shaper",
                    type: "omniselect",
                    cellValueFunction: cmdbCellValue,
                    editable: (entry) =>
                      !(
                        entry.implicit ||
                        (entry.isHyperscalePolicy() && "deny" === entry.action)
                      ),
                    editableOmniselectSettings: getOmniselectSettings,
                  },
                };
              return new (class {
                generate(params) {
                  ((configParams = params), (policyType = policyInit.type));
                  const columnPolicyType = getColumnPolicyType();
                  return (
                    CANDIDATE_COLUMNS[columnPolicyType] &&
                    CANDIDATE_COLUMNS[columnPolicyType].reduce(
                      (columns, columnId) => (
                        visibilityCheckPassed(columnId) &&
                          (CONFIGS[columnId]
                            ? columns.push(
                                Object.assign(
                                  {
                                    id: columnId,
                                    hidden:
                                      params.interfacePair &&
                                      params.interfacePairKeys.includes(
                                        columnId,
                                      ),
                                  },
                                  CONFIGS[columnId],
                                ),
                              )
                            : columns.push(columnId)),
                        columns
                      ),
                      [],
                    )
                  );
                }
                clearCache() {
                  configParams = null;
                }
              })();
            }
            return (providers) => {
              providers.$provide.factory(
                "policyListTableColumnConfigs",
                PolicyListTableColumnConfigsFactory,
              );
            };
          }).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) ||
          (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
    },
    43902: (module, exports, __webpack_require__) => {
      "use strict";
      var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;
      ((__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(6649)]),
        void 0 ===
          (__WEBPACK_AMD_DEFINE_RESULT__ = ((fDom) => {
            function PolicyListTableSettingsFactory(
              policyListTableColumn,
              policyListViewType,
              lang,
              policyInit,
              state,
              Omniselect,
            ) {
              return new (class {
                create(params) {
                  return (
                    (this.ctrlScope = params.ctrlScope),
                    (this.type = policyInit.type),
                    (this.subType = policyInit.subType),
                    (this.viewType = policyListViewType.value),
                    (this.interfacePair =
                      this.viewType ===
                      policyListViewType.VIEW_TYPE.INTERFACE_PAIR),
                    (this.interfacePairKeys =
                      "proxy-policy" === this.type
                        ? ["proxy", "dstintf"]
                        : ["srcintf", "dstintf"]),
                    (this.settings = {
                      id: `policyList-${this.type}-${this.subType}-${this.viewType}`,
                      reordering: !state.readOnlyForPage,
                      editable:
                        !state.readOnlyForPage && !params.slideController,
                      editingNeedsExternalUpdate: !0,
                      canReorderFunction: (policyEntry) =>
                        !policyEntry.implicit,
                      collectionLimit: 30,
                      sorting: !1,
                      userDefinedSections: !1,
                      expandSections: !1,
                      onRowRendered: (rowElement, entry) => {
                        ("disable" === entry.cmdbModel.status &&
                          rowElement.classList.add("disabled"),
                          entry.error && rowElement.classList.add("error"),
                          entry.implicit &&
                            rowElement.classList.add("implicit"));
                      },
                    }),
                    (this.settings.columns = policyListTableColumn.getColumns(
                      Object.assign(
                        {
                          interfacePair: this.interfacePair,
                          interfacePairKeys: this.interfacePairKeys,
                        },
                        params,
                      ),
                    )),
                    (this.settings.defaultColumns =
                      policyListTableColumn.getDefaultColumns(
                        params.defaultColumnsOverride,
                      )),
                    this._setupViewType(),
                    this.settings
                  );
                }
                clearCache() {
                  (policyListTableColumn.clearCache(),
                    (this.ctrlScope = null),
                    (this.settings = null));
                }
                _setupViewType() {
                  const listSettings = this;
                  if (listSettings.interfacePair) {
                    let intfPairColumnSetting = { id: "intfpair", hidden: !0 };
                    const getInterfaceLabel = (intf, intfMap) => {
                      if (intf) {
                        return (
                          (intf = intfMap[intf.q_origin_key] || intf).label ||
                          intf.name ||
                          ""
                        );
                      }
                      return "";
                    };
                    ((intfPairColumnSetting.cellValueFunction = (entry) => {
                      if (entry.implicit) return lang("implicit").toString();
                      {
                        let intfMap = {};
                        try {
                          intfMap =
                            Omniselect.getSourceDataSync(
                              "firewallInterfaces",
                            ).mapping;
                        } catch (e) {}
                        return listSettings.interfacePairKeys
                          .map((key) => {
                            if ("proxy" === key)
                              return `${entry.cmdbModel.proxy} proxy`;
                            {
                              let objects = entry.cmdbModel[key];
                              return (
                                Array.isArray(objects) || (objects = [objects]),
                                getInterfaceLabel(objects[0], intfMap)
                              );
                            }
                          })
                          .join(" →");
                      }
                    }),
                      (intfPairColumnSetting.cellFormatter = (
                        entry,
                        column,
                        value,
                      ) => {
                        if (entry.implicit) return value;
                        {
                          let interfaces = {};
                          try {
                            interfaces =
                              Omniselect.getSourceDataSync(
                                "firewallInterfaces",
                              ).mapping;
                          } catch (e) {}
                          const children =
                            listSettings.interfacePairKeys.reduce(
                              (elems, key, index) => {
                                let elem;
                                if ("proxy" === key)
                                  elem = fDom.elem("span", {
                                    textContent: `${entry.cmdbModel.proxy} proxy`,
                                  });
                                else {
                                  let objects = entry.cmdbModel[key];
                                  Array.isArray(objects) ||
                                    (objects = [objects]);
                                  let intfChildrenElem = [];
                                  const mkey = objects[0].q_origin_key;
                                  (interfaces[mkey] &&
                                    intfChildrenElem.push(
                                      fDom.elem("f-icon", {
                                        className:
                                          interfaces[mkey].icon ||
                                          interfaces[mkey]["css-class"],
                                      }),
                                    ),
                                    intfChildrenElem.push(
                                      fDom.elem("span", {
                                        textContent: getInterfaceLabel(
                                          objects[0],
                                          interfaces,
                                        ),
                                      }),
                                    ),
                                    (elem = fDom.elem("span", null, {
                                      children: intfChildrenElem,
                                    })));
                                }
                                return (
                                  elems.push(elem),
                                  index <
                                    listSettings.interfacePairKeys.length - 1 &&
                                    elems.push(
                                      fDom.elem("span", { textContent: " →" }),
                                    ),
                                  elems
                                );
                              },
                              [],
                            );
                          return fDom.elem("span", null, { children });
                        }
                      }),
                      (intfPairColumnSetting.sortComparator = (
                        valueA,
                        valueB,
                        entryA,
                        entryB,
                      ) =>
                        entryA.implicit
                          ? 1
                          : entryB.implicit
                            ? -1
                            : valueA.compareTo(valueB)),
                      listSettings.settings.columns.push(intfPairColumnSetting),
                      (listSettings.settings.defaultSectionColumn =
                        "intfpair"));
                  } else if (
                    policyListViewType.SECTIONS_ENABLED[listSettings.type]
                  ) {
                    let sectionsSetting =
                      policyListViewType.SECTIONS_ENABLED[listSettings.type];
                    "string" == typeof sectionsSetting
                      ? (listSettings.settings.defaultSectionColumn =
                          sectionsSetting)
                      : ((listSettings.settings.customSequenceGrouping = !0),
                        (listSettings.settings.sequenceGroupingValueFunction = (
                          entry,
                        ) => entry.cmdbModel["global-label"] || ""),
                        (listSettings.settings.implicitSequenceGroupingValueFunction =
                          (entry) => {
                            if (entry.implicit) return "Implicit";
                          }));
                  }
                }
              })();
            }
            return (
              (PolicyListTableSettingsFactory.$inject = [
                "policyListTableColumn",
                "policyListViewType",
                "lang",
                "policyInit",
                "state",
                "Omniselect",
              ]),
              (providers) => {
                providers.$provide.factory(
                  "policyListTableSettings",
                  PolicyListTableSettingsFactory,
                );
              }
            );
          }).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) ||
          (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
    },
    40016: (module, exports, __webpack_require__) => {
      "use strict";
      var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;
      ((__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(1190)]),
        void 0 ===
          (__WEBPACK_AMD_DEFINE_RESULT__ = function (browser) {
            PolicyListViewType.$inject = [
              "PolicySource",
              "persistentStorage",
              "policyInit",
            ];
            var INTERFACE_PAIR_VIEW_SUPPORT = {
              policy: !0,
              "multicast-policy": !0,
              "multicast-policy6": !0,
              "proxy-policy": { standard: !0, ztna: !1 },
              "security-policy": !0,
            };
            function PolicyListViewType(
              PolicySource,
              persistentStorage,
              policyInit,
            ) {
              ((this._PolicySource = PolicySource),
                (this._persistentStorage = persistentStorage),
                (this._policyInit = policyInit),
                (this.value = null));
            }
            return (
              (PolicyListViewType.prototype.VIEW_TYPE = {
                SEQUENTIAL: "sequential",
                INTERFACE_PAIR: "interface-pair",
              }),
              (PolicyListViewType.prototype.SECTIONS_ENABLED = {
                policy: !0,
                "explicit-proxy-policy": !0,
                "security-policy": !0,
                "central-snat-map": "ip-version",
              }),
              (PolicyListViewType.prototype._validViewType = function (value) {
                return (
                  Object.keys(this.VIEW_TYPE)
                    .map(
                      function (key) {
                        return this.VIEW_TYPE[key];
                      }.bind(this),
                    )
                    .indexOf(value) >= 0
                );
              }),
              (PolicyListViewType.prototype._isInterfacePairViewSupported =
                function (type, subtype) {
                  let supported = INTERFACE_PAIR_VIEW_SUPPORT[type];
                  return (
                    "object" == typeof supported &&
                      (supported = supported[subtype]),
                    supported
                  );
                }),
              (PolicyListViewType.prototype.update = function () {
                if (browser.isMobile())
                  return void (this.value = this.VIEW_TYPE.INTERFACE_PAIR);
                const policySource = this._PolicySource.getCachedInstance();
                ((this._key =
                  "policyViewType-" +
                  this._policyInit.type +
                  this._policyInit.subType),
                  (this.value = this._persistentStorage.get(this._key)),
                  (this.supported = this._isInterfacePairViewSupported(
                    this._policyInit.type,
                    this._policyInit.subType,
                  )),
                  this._validViewType(this.value) ||
                    (this.value = this.VIEW_TYPE.INTERFACE_PAIR),
                  this.supported && policySource.isInterfacesSectionable()
                    ? (this.supportInterfacePairView = !0)
                    : ((this.supportInterfacePairView = !1),
                      (this.value = this.VIEW_TYPE.SEQUENTIAL)));
              }),
              (PolicyListViewType.prototype.set = function (value) {
                if (!this._validViewType(value))
                  throw new Error("Invalid view type value");
                (this._persistentStorage.put(this._key, value),
                  (this.value = value));
              }),
              (PolicyListViewType.prototype.clearCache = function () {
                this.value = null;
              }),
              function (providers, loader) {
                return (
                  providers.$provide.service(
                    "policyListViewType",
                    PolicyListViewType,
                  ),
                  loader.initModules([__webpack_require__(35396)])
                );
              }
            );
          }.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) ||
          (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
    },
    34198: (module) => {
      "use strict";
      function model(CMDB, $http, state, $window) {
        var csfPrototype = {
          wasJoinExisting: function () {
            return !!this.$original.upstream;
          },
          joinExisting: function (value) {
            if (1 !== arguments.length)
              return "_joinExisting" in this
                ? this._joinExisting
                : !!this.upstream;
            ((this._joinExisting = value),
              this._joinExisting
                ? ((this["group-name"] = ""),
                  (this["group-password"] = ""),
                  (this.upstream && "disable" !== this.$original.status) ||
                    (this.upstream = this.$systemDefaultGateway))
                : this._joinExisting ||
                  (this.$original["group-name"] &&
                    (this["group-name"] = this.$original["group-name"]),
                  this.$original["group-password"] &&
                    (this["group-password"] = this.$original["group-password"]),
                  this.$trustedList || this._initTrustedList()));
          },
          _initTrustedList: function () {
            this.joinExisting()
              ? (this.$trustedList = void 0)
              : ((this.$trustedList = this["trusted-list"] || []),
                this.$trustedList.length ||
                  this.$trustedList.push({ serial: "", action: "accept" }));
          },
          preSave: function () {
            if (this.joinExisting()) this["trusted-list"] = void 0;
            else {
              this.upstream = "";
              var trustedList = this.$trustedList.slice();
              (1 !== trustedList.length ||
                trustedList[0].serial ||
                (trustedList = []),
                (this["trusted-list"] = trustedList));
            }
            ("default" === this.managementIpOption()() &&
              (this["management-ip"] = ""),
              "default" === this.managementPortOption()() &&
                (this["management-port"] = 0));
          },
          isDefaultSyncMode: function () {
            return (
              "default" === this["configuration-sync"] &&
              "enable" === this.status
            );
          },
          isLocalSyncMode: function () {
            return (
              "local" === this["configuration-sync"] && "enable" === this.status
            );
          },
          $status: function (value) {
            if (void 0 === value) return "enable" === this.status;
            this.status = value ? "enable" : "disable";
          },
          managementIpOption: function (setDefault = !0) {
            const defaultValue = setDefault ? $window.location.hostname : "";
            return function (value) {
              if (1 !== arguments.length)
                return "_managementIpOption" in this
                  ? this._managementIpOption
                  : this["management-ip"]
                    ? "specify"
                    : "default";
              ((this._managementIpOption = value),
                "specify" !== value ||
                  this.$original["management-ip"] ||
                  this["management-ip"] ||
                  !defaultValue ||
                  (this["management-ip"] = defaultValue));
            }.bind(this);
          },
          managementPortOption: function (setDefault = !0) {
            const defaultValue = setDefault ? $window.location.port : 0;
            return function (value) {
              if (1 !== arguments.length)
                return "_managementPortOption" in this
                  ? this._managementPortOption
                  : 0 !== this["management-port"]
                    ? "specify"
                    : "default";
              ("specify" === value &&
                0 === this.$original["management-port"] &&
                0 === this["management-port"] &&
                defaultValue &&
                (this["management-port"] = Number(defaultValue)),
                (this._managementPortOption = value));
            }.bind(this);
          },
          _initSystemDefaultGateway: function (routeLookupResults) {
            let gateway = "";
            (routeLookupResults.success &&
              (gateway = routeLookupResults.gateway),
              (this.$systemDefaultGateway = gateway));
          },
        };
        return [
          new CMDB.Model("system", "csf", csfPrototype, function (entry) {
            entry.$promise = $http
              .get("/api/v2/monitor/router/lookup", {
                params: {
                  vdom: state.management_vdom,
                  destination: "0.0.0.0",
                  ipv6: !1,
                },
              })
              .then(
                (response) => {
                  entry._initSystemDefaultGateway(response.data.results);
                },
                function () {
                  entry._initSystemDefaultGateway({});
                },
              )
              .finally(function () {
                (entry["group-name"]
                  ? (entry["confirm-password"] = entry["group-password"])
                  : (entry["group-password"] = ""),
                  entry._initTrustedList());
              });
          }),
        ];
      }
      ((model.$inject = ["CMDB", "$http", "state", "$window"]),
        (module.exports = model));
    },
    78398: (module) => {
      var path = "/migadmin/ng/firewall/policy/lookup/f-policy-lookup.html";
      (window.angular.module("ng").run([
        "$templateCache",
        function (c) {
          c.put(
            path,
            '<f-dialog hide-title="::true"\n        form="$ctrl.form"\n        valid-submit="$ctrl.submit()">\n    <dialog-content>\n        <section>\n            <div class="warning-message"\n                ng-if="$ctrl.showWarning && $ctrl.warningMessage">\n                <f-icon class="fa-warning"></f-icon>\n                <label class="message-content">\n                    {{:: $ctrl.warningMessage }}\n                </label>\n            </div>\n        </section>\n        <section>\n            <f-field>\n                <field-label>\n                    <span>{{:: \'in-interface\' | lang }}</span>\n                </field-label>\n                <field-value>\n                    <div f-omniselect="$ctrl.selectintf"\n                        ng-model="$ctrl.model.srcintf"\n                        required>\n                    </div>\n                </field-value>\n            </f-field>\n            <f-field >\n                <field-label>\n                    <span>\n                        {{:: \'IP Version\' | lang }}\n                    </span>\n                </field-label>\n                <field-value>\n                    <select ng-model="$ctrl.model.ipVersion"\n                        ng-change="$ctrl.selectChanged()"\n                        ng-disabled="!$ctrl.show.ipVersion"\n                        required>\n                        <option ng-repeat="option in ::$ctrl.options.ipVersions"\n                            value="{{ option }}">\n                            {{ option | lang }}\n                        </option>\n                    </select>\n                </field-value>\n            </f-field>\n            <f-field>\n                <field-label>\n                    <span>\n                        {{:: \'Protocol\' | lang }}\n                    </span>\n                </field-label>\n                <field-value>\n                    <select ng-model="$ctrl.model.protocol" ng-change="$ctrl.selectChanged()" required>\n                        <option ng-repeat="option in $ctrl.options.protocols"\n                            value="{{ option }}">\n                            {{ option | lang }}\n                        </option>\n                    </select>\n                </field-value>\n            </f-field>\n            <f-field ng-if="$ctrl.show.protocolNumber">\n                <field-label>\n                    <span>\n                        {{:: \'Protocol Number\' | lang }}\n                    </span>\n                </field-label>\n                <field-value>\n                    <input type="number"\n                        ng-model="$ctrl.model.protocolNumber"\n                        min=0 max=255\n                        placeholder="1-255"\n                        required>\n                </field-value>\n            </f-field>\n            <f-field ng-if="$ctrl.show.icmptype">\n                <field-label>\n                    <span>\n                        {{:: \'icmptype\' | lang }}\n                    </span>\n                </field-label>\n                <field-value>\n                    <input type="number"\n                        ng-model="$ctrl.model.icmptype"\n                        min=0 max=255\n                        placeholder="0-255"\n                        required>\n                </field-value>\n            </f-field>\n            <f-field ng-if="$ctrl.show.icmpcode">\n                <field-label>\n                    <span>\n                        {{:: \'icmpcode\' | lang }}\n                    </span>\n                </field-label>\n                <field-value>\n                    <input type="number"\n                        ng-model="$ctrl.model.icmpcode"\n                        min=0 max=255\n                        placeholder="0-255"\n                        required>\n                </field-value>\n            </f-field>\n            <f-field ng-if="$ctrl.show.sourceip" error-messages="$ctrl.ipPatternError.src[$ctrl.model.ipVersion]">\n                <field-label>\n                    <span>\n                        {{:: \'Source\' | lang }}\n                    </span>\n                </field-label>\n                <field-value ng-if="$ctrl.model.ipVersion === \'ipv4\'">\n                    <input type="text"\n                        ng-model="$ctrl.model.sourceip"\n                        placeholder="{{::\'ipaddr\' | lang}}"\n                        f-patterns="$ctrl.ipPattern.src.ipv4"\n                        required>\n                </field-value>\n                <field-value ng-if="$ctrl.model.ipVersion === \'ipv6\'">\n                    <input type="text"\n                        ng-model="$ctrl.model.sourceip"\n                        placeholder="{{::\'ipaddr\' | lang}}"\n                        f-patterns="$ctrl.ipPattern.src.ipv6"\n                        required>\n                </field-value>\n            </f-field>\n            <f-field ng-if="$ctrl.show.sourceport">\n                <field-label>\n                    <span>\n                        {{:: \'Source Port\' | lang }}\n                    </span>\n                </field-label>\n                <field-value>\n                    <input type="number"\n                        ng-model="$ctrl.model.sourceport"\n                        min="{{:: $ctrl.PORT_MIN }}" max="{{:: $ctrl.PORT_MAX }}"\n                        placeholder="{{::\'Optional\' | lang}} (1-65535)">\n                </field-value>\n            </f-field>\n            <f-field ng-if="$ctrl.show.dest" error-messages="$ctrl.ipPatternError.dest[$ctrl.model.ipVersion]">\n                <field-label>\n                    <span>\n                        {{:: \'Destination\' | lang }}\n                    </span>\n                </field-label>\n                <field-value ng-if="$ctrl.model.ipVersion === \'ipv4\'">\n                    <input type="text"\n                        f-max-length="$ctrl.address.$schema.children.fqdn.size"\n                        ng-model="$ctrl.model.dest"\n                        placeholder="{{::\'IP Address/FQDN\' | lang}}"\n                        f-patterns="$ctrl.ipPattern.dest.ipv4"\n                        required>\n                </field-value>\n                <field-value ng-if="$ctrl.model.ipVersion === \'ipv6\'">\n                    <input type="text"\n                        f-max-length="$ctrl.address.$schema.children.fqdn.size"\n                        ng-model="$ctrl.model.dest"\n                        placeholder="{{::\'IP Address/FQDN\' | lang}}"\n                        f-patterns="$ctrl.ipPattern.dest.ipv6"\n                        required>\n                </field-value>\n            </f-field>\n            <f-field ng-if="$ctrl.show.destport">\n                <field-label>\n                    <span>\n                        {{:: \'Destination Port\' | lang }}\n                    </span>\n                </field-label>\n                <field-value>\n                    <input type="number"\n                        ng-model="$ctrl.model.destport"\n                        min="{{:: $ctrl.PORT_MIN }}" max="{{:: $ctrl.PORT_MAX }}"\n                        placeholder="1-65535"\n                        required>\n                </field-value>\n            </f-field>\n        </section>\n    </dialog-content>\n    <dialog-footer>\n        <button type="submit" class="primary" ng-disabled="$ctrl.loading">\n            <f-icon class="fa-loading" ng-show="$ctrl.loading"></f-icon>\n            <span f-lang="Search"></span>\n        </button>\n        <button type="button"\n            ng-click="$ctrl.close()" f-lang="close"></button>\n    </dialog-footer>\n</f-dialog>',
          );
        },
      ]),
        (module.exports = path));
    },
    49159: (module) => {
      var path = "/migadmin/ng/firewall/policy/partials/compare_qtip.html";
      (window.angular.module("ng").run([
        "$templateCache",
        function (c) {
          c.put(
            path,
            '<table class="table key-value">\n    <tbody>\n        <tr ng-if="$ctrl.supportedKeys.bytes && $ctrl.stats.bytes != null">\n            <td>{{::\'Bytes\' | lang}}/{{::\'Packets\' | lang}}</td>\n            <td>{{$ctrl.entry.bytes | bytes}}</td>\n            <td>{{$ctrl.entry.packets || 0 | number}}</td>\n        </tr>\n        <tr class="child"\n            ng-if="$ctrl.supportedKeys.software_bytes && $ctrl.stats.software_bytes != null &&\n                   $ctrl.entry[\'auto-asic-offload\'] === \'enable\'">\n            <td>{{::\'Software\' | lang}}</td>\n            <td>{{$ctrl.stats.software_bytes | bytes}}</td>\n            <td>{{$ctrl.stats.software_packets | number}}</td>\n            <td>{{$ctrl.entry.software_usage}}</td>\n        </tr>\n        <tr class="child"\n            ng-if="$ctrl.supportedKeys.asic_bytes && $ctrl.stats.asic_bytes != null &&\n                   $ctrl.entry[\'auto-asic-offload\'] === \'enable\'">\n            <td>{{::\'SPU\' | lang}}</td>\n            <td>{{$ctrl.stats.asic_bytes | bytes}}</td>\n            <td>{{$ctrl.stats.asic_packets | number}}</td>\n            <td>{{$ctrl.entry.asic_usage}}</td>\n        </tr>\n        <tr class="child"\n            ng-if="$ctrl.supportedKeys.nturbo_bytes && $ctrl.stats.nturbo_bytes != null &&\n                   $ctrl.entry[\'auto-asic-offload\'] === \'enable\'">\n            <td>{{::\'nTurbo\' | lang}}</td>\n            <td>{{$ctrl.stats.nturbo_bytes | bytes}}</td>\n            <td>{{$ctrl.stats.nturbo_packets | number}}</td>\n            <td>{{$ctrl.entry.nturbo_usage}}</td>\n        </tr>\n        <tr class="child"\n            ng-if="$ctrl.supportedKeys.cgn_bytes && $ctrl.stats.cgn_bytes != null">\n            <td>{{::\'Hyperscale SPU\' | lang}}</td>\n            <td>{{$ctrl.stats.cgn_bytes | bytes}}</td>\n            <td>{{$ctrl.stats.cgn_packets || 0 | number}}</td>\n            <td>{{$ctrl.entry.cgn_usage}}</td>\n        </tr>\n        <tr ng-if="$ctrl.entry[\'auto-asic-offload\'] === \'disable\'">\n            <td>{{::\'SPU\' | lang}}</td>\n            <td colspan="3">{{::\'disabled\' | lang}}</td>\n        </tr>\n        <tr ng-if="$ctrl.supportedKeys.hit_count">\n            <td>{{::\'hit_count\' | lang}}</td>\n            <td colspan="3">{{$ctrl.entry.hitCount | number}}</td>\n        </tr>\n        <tr ng-if="$ctrl.supportedKeys.first_used && $ctrl.stats.first_used">\n            <td>{{::\'first_used\' | lang}}</td>\n            <td colspan="3">{{$ctrl.entry.firstUsed | fDateTime }}</td>\n        </tr>\n        <tr ng-if="$ctrl.supportedKeys.active_sessions && $ctrl.entry.policyId">\n            <td>{{::\'active_sessions\' | lang}}</td>\n            <td colspan="3">{{$ctrl.stats.active_sessions || 0 | number}}</td>\n        </tr>\n        <tr ng-if="$ctrl.supportedKeys.last_used && $ctrl.stats.last_used">\n            <td>{{::\'last_used\' | lang}}</td>\n            <td colspan="3">{{$ctrl.entry.lastUsed | fDateTime }}</td>\n        </tr>\n        <tr ng-if="$ctrl.supportedKeys.packets_dropped && $ctrl.stats.packets_dropped != null">\n            <td>{{::\'Packets Dropped\' | lang}}</td>\n            <td colspan="3">{{$ctrl.stats.packets_dropped || 0 | number}}</td>\n        </tr>\n    </tbody>\n</table>\n<table class="table" ng-if="$ctrl.statsType">\n   <tbody>\n        <tr>\n            <td>\n                <f-policy-rolling-stat-chart\n                    stats="$ctrl.stats"\n                    stat-type="$ctrl.statsType"\n                    ip-version="$ctrl.statsIpVersion"\n                    show-chart-title="\'true\'"\n                    resize-less-dynamic="\'true\'"\n                    policy-type="$ctrl.entry.policyType">\n                </f-policy-rolling-stat-chart>\n            </td>\n        </tr>\n   </tbody>\n</table>\n',
          );
        },
      ]),
        (module.exports = path));
    },
    19057: (module) => {
      var path =
        "/migadmin/ng/firewall/policy/partials/firewall_policy_warnings.html";
      (window.angular.module("ng").run([
        "$templateCache",
        function (c) {
          c.put(
            path,
            '<div>\n    <table class="table key-value">\n        <tbody>\n            <tr ng-show=":: $ctrl.entry.policyId !== 0">\n                <td>{{:: \'Policy ID\' | lang}}</td>\n                <td>\n                    {{:: $ctrl.entry.policyId }}\n                    <span ng-show=":: $ctrl.entry.status === \'disable\'">\n                        ({{:: \'disabled\' | lang }})\n                    </span>\n                </td>\n            </tr>\n            <tr ng-show=":: $ctrl.entry.policyId === 0">\n                <td>{{:: \'implicit\' | lang}}</td>\n                <td>{{:: $ctrl.entry.action | lang }}</td>\n            </tr>\n            <tr ng-show=":: $ctrl.entry.policyId !== 0 && $ctrl.entry.name">\n                <td>{{:: \'Policy Name\' | lang}}</td>\n                <td>{{:: $ctrl.entry.name }}</td>\n            </tr>\n        </tbody>\n    </table>\n    <table class="table" ng-if=":: $ctrl.warnings.length > 0">\n        <tbody>\n            <tr>\n                <td>\n                    <span f-lang="policy_issues"></span>\n                    <ul>\n                        <li ng-repeat="warning in ::$ctrl.warnings">\n                            <span>{{:: warning | lang }}</span>\n                        </li>\n                    </ul>\n                </td>\n            </tr>\n        </tbody>\n    </table>\n</div>\n',
          );
        },
      ]),
        (module.exports = path));
    },
    44428: (module) => {
      var path = "/migadmin/ng/firewall/policy/partials/menu_items_seq.html";
      (window.angular.module("ng").run([
        "$templateCache",
        function (c) {
          c.put(
            path,
            '<div class="heading">\n    {{::\'Policy\' | lang}}\n</div>\n<div>\n    <f-mutable-edit-column column-id="::\'status\'"></f-mutable-edit-column>\n    <f-mutable-filter></f-mutable-filter>\n    <f-mutable-copy-insert ng-if="!$ctrl.implicitPolicySelected() && $ctrl.isCreateEnabled()">\n    </f-mutable-copy-insert>\n    <f-mutable-processed-insert\n        ng-if="!$ctrl.implicitPolicySelected() && $ctrl.insertEnabled() && $ctrl.isCreateEnabled()"\n        label="::\'Insert Empty Policy\' | lang"\n        icon="::\'fa-plus\'"\n        process-entry="$ctrl.createEmptyPolicy(entry)">\n    </f-mutable-processed-insert>\n    <f-mutable-processed-insert\n        ng-if="!$ctrl.implicitPolicySelected() && $ctrl.cloneReverseEnabled() && $ctrl.isCreateEnabled()"\n        label="::\'Clone Reverse\' | lang"\n        icon="::\'ftnt-clone\'"\n        process-entry="$ctrl.cloneReverse(entry)"\n        always-insert-after="::true"\n        locate-after-insert="::true">\n    </f-mutable-processed-insert>\n    <f-mutable-insert-sequence-grouping ng-if="$ctrl.insertSequenceGroupingEnabled()"></f-mutable-insert-sequence-grouping>\n</div>\n',
          );
        },
      ]),
        (module.exports = path));
    },
    53715: (module) => {
      var path = "/migadmin/ng/firewall/policy/partials/menu_items_stats.html";
      (window.angular.module("ng").run([
        "$templateCache",
        function (c) {
          c.put(
            path,
            '<div f-menu-item-button click="$ctrl.policyStats.update()">\n    <f-icon class="fa-refresh"></f-icon>\n    {{::\'Update Statistics\' | lang}}\n</div>\n<div f-menu-item-button\n     click="$ctrl.policyStats.clearCounters($ctrl.menu.entries)"\n     ng-show="$ctrl.showClearCounters()">\n    <f-icon class="ftnt-purge"></f-icon>\n    {{::\'clear_counters\' | lang}}\n</div>\n',
          );
        },
      ]),
        (module.exports = path));
    },
    89804: (module) => {
      var path = "/migadmin/ng/firewall/policy/partials/policy-list-menu.html";
      (window.angular.module("ng").run([
        "$templateCache",
        function (c) {
          c.put(
            path,
            '<div ng-if=":: $ctrl.menu.popUpMenu && !$root.ADMIN_RO && !$ctrl.listCtrl.slideController">\n    <div ng-show="$ctrl.policyStatsSupported &&\n                  $ctrl.policyStats.KEYS.includes($ctrl.menu.targetColumnID)"\n       ng-include=":: $ctrl.MENU_ITEMS_STATS">\n    </div>\n    <div ng-include=":: $ctrl.MENU_ITEMS_SEQ">\n    </div>\n    <div class="separator"></div>\n</div>\n\n<div ng-if=":: $ctrl.menu.popUpMenu">\n    <div f-menu-item-button click="$ctrl.openAuditTrail()"\n        ng-if="$ctrl.showAuditTrail()"\n        class="mini-hide">\n        <f-icon class="fa-undo"></f-icon>\n        {{::\'Audit Trail\' | lang}}\n    </div>\n    <div f-menu-item-button click="$ctrl.showMatchingLogs()"\n        ng-if="!$ctrl.policyIncompatibleForLogs() && $ctrl.listCtrl.allowDrilldownFromSlide()"\n        enabled="$ctrl.menu.entries.length === 1"  class="mini-hide">\n        <f-icon class="ftnt-eventlog"></f-icon>\n        {{::\'view_log\' | lang}}\n    </div>\n    <div f-menu-item-button\n         click="$ctrl.showInFortiview()"\n         ng-if="::$ctrl.policyCompatibleForFortiView() && $ctrl.listCtrl.allowDrilldownFromSlide()"\n        enabled="$ctrl.menu.entries.length === 1 && !$ctrl.implicitPolicySelected()"\n        class="mini-hide">\n        <f-icon class="fa-area-chart"></f-icon>\n        {{::\'Show in FortiView\' | lang}}\n    </div>\n</div>\n\n<div class="left-menu-items">\n    <span f-tip-target>\n        <div f-menu-item-create\n             action="$ctrl.create()"\n             ng-if="$ctrl.canCreate()"\n             enabled="$ctrl.isCreateEnabled()">\n        </div>\n        <div f-tip ng-if="!$ctrl.isCreateEnabled()">\n            {{::\'The policy table has reached the maximum amount (15000) that is allowed in hyperscale VDOM.\' | lang}}\n        </div>\n    </span>\n    <div f-menu-item-edit action="$ctrl.edit($entry)" ng-if="!$ctrl.listCtrl.slideController"></div>\n    <div f-menu-item-edit-cli enabled="$ctrl.editCliEnabled($entries)" action="$ctrl.editCli($entry)"></div>\n    <div f-menu-item-delete delete-entries="$ctrl.deleteEntries($rows)"\n        label-key="{{::$ctrl.menu.popUpMenu ? \'delete_policy\' : \'\'}}"\n        entries-label-key="policies">\n    </div>\n</div>\n\n<div class="center-menu-items" ng-if="::$ctrl.menu.menuBar">\n    <div f-menu-item-button click="$ctrl.policyLookup()" class="mini-hide" emphasized="::true"\n        ng-show="::$ctrl.menu.menuBar && $ctrl.policyLookupSupported">\n        <f-icon class="fa-search"></f-icon>\n        <span f-lang="Policy lookup"></span>\n    </div>\n    <f-mutable-search></f-mutable-search>\n</div>\n\n<div class="right-menu-items mini-hide" ng-if="::$ctrl.menu.menuBar">\n    <div f-menu-item-submenu="$parent.virtualWireMenu"\n        ng-if="::$ctrl.listCtrl.isVirtualWirePolicy" title="{{::\'virtual_wire_pair\' | lang}}">\n        <f-icon class="ftnt-virtual-wire-pair"></f-icon>\n        <span>{{$ctrl.policyVWP.current}}</span>\n        <span ng-if="$ctrl.policyVWP.isAllVWPsMode()">{{:: \'All VWPs\' | lang}}</span>\n    </div>\n    <f-mutable-export file-name="$ctrl.filename"></f-mutable-export>\n    <div f-pop-up-menu="$parent.virtualWireMenu" ng-if="::$ctrl.listCtrl.isVirtualWirePolicy">\n        <div ng-repeat="name in $ctrl.policyVWP.all" f-menu-item-button\n             click="$ctrl.policyVWP.setCurrent(name)" selected="name === $ctrl.policyVWP.current">\n            <f-icon class="ftnt-virtual-wire-pair"></f-icon>\n            <span>{{::name}}</span>\n        </div>\n        <div class="separator" ng-if="$ctrl.policyVWP.isAllVWPsVisible()"></div>\n        <div ng-if="$ctrl.policyVWP.isAllVWPsVisible()"\n             f-menu-item-button\n             click="$ctrl.policyVWP.setAllVWPsMode(true)" selected="$ctrl.policyVWP.isAllVWPsMode()">\n            <f-icon class="ftnt-virtual-wire-pair"></f-icon>\n            <span>{{:: \'All VWPs\' | lang}}</span>\n        </div>\n    </div>\n    <div class="radio-buttons" ng-if="$ctrl.viewType.supported">\n        <div class="menu-item" ng-if="!$ctrl.viewType.supportInterfacePairView">\n            <button class="disabled" type="button" f-tip-target>\n                {{::\'Interface Pair View\' | lang}}\n                <div f-tip>\n                    {{::\'disable_interface_view\' | lang}}\n                    <ul>\n                        <li f-lang="disable_reason1"></li>\n                        <li f-lang="disable_reason2"></li>\n                    </ul>\n                </div>\n            </button>\n        </div>\n        <div f-menu-item-button ng-if="$ctrl.viewType.supportInterfacePairView"\n            selected="$ctrl.viewType.value === $ctrl.viewType.VIEW_TYPE.INTERFACE_PAIR"\n            click="$ctrl.viewType.set($ctrl.viewType.VIEW_TYPE.INTERFACE_PAIR)"\n            enabled="$ctrl.viewType.supportInterfacePairView">\n            {{::\'Interface Pair View\' | lang}}\n        </div>\n        <div f-menu-item-button selected="$ctrl.viewType.value === $ctrl.viewType.VIEW_TYPE.SEQUENTIAL"\n            click="$ctrl.viewType.set($ctrl.viewType.VIEW_TYPE.SEQUENTIAL)">\n            {{::\'By Sequence\' | lang}}\n        </div>\n    </div>\n    <div f-menu-item-submenu="$parent.ipVersionFilterMenu"\n        ng-if="::$ctrl.ipVersionFilterSupported()" title="{{::\'IP Version\' | lang}}">\n        <span>{{ $ctrl.ipVersionFilter.current.label | lang }}</span>\n    </div>\n    <div f-pop-up-menu="$parent.ipVersionFilterMenu"\n        ng-if="::$ctrl.ipVersionFilterSupported()">\n        <div ng-repeat="option in $ctrl.ipVersionFilter.options" f-menu-item-button\n             click="$ctrl.ipVersionFilterSetCurrent(option)"\n             selected="option.value === $ctrl.ipVersionFilter.current.value">\n            <span>{{::option.label | lang}}</span>\n        </div>\n    </div>\n</div>\n',
          );
        },
      ]),
        (module.exports = path));
    },
    91073: (module) => {
      var path = "/migadmin/ng/firewall/policy/partials/policy-list.html";
      (window.angular.module("ng").run([
        "$templateCache",
        function (c) {
          c.put(
            path,
            '<f-mutable source="$ctrl.source" settings="$ctrl.settings"\n    initial-locate="$ctrl.locateFunction"\n    notifications="$ctrl.notifications"\n    context-menu="::true" instance="$ctrl.mutableInstance">\n    <f-policy-list-menu list-ctrl="$ctrl"\n        menu="menu"\n        class="menu-bar-component">\n    </f-policy-list-menu>\n</f-mutable>\n',
          );
        },
      ]),
        (module.exports = path));
    },
  },
]);
