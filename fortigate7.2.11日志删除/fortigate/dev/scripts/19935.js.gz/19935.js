"use strict";
(self.webpackChunkfos_webui_angular =
  self.webpackChunkfos_webui_angular || []).push([
  [19935, 84435, 62469, 40970, 74042, 40300, 75522, 41260, 7151],
  {
    19935: (ne, U, c) => {
      (c.r(U),
        c.d(U, {
          PolicyLookupSlideinDialogComponent: () => vt,
          PolicyTableModule: () => $l,
          SLIDE_WIDTH: () => m.Tw,
        }));
      var O = c(69808),
        S = c(93075),
        w = c(35357),
        D = c(57892),
        I = c(30705),
        f = c(26919),
        x = c(18419),
        E = c(82256),
        y = c(67829),
        _ = c(29730),
        A = c(90652),
        G = c(22638),
        R = c(24532),
        Z = c(91565),
        q = c(35503),
        W = c(62469),
        b = c(29234),
        v = c(7846),
        d = c(70655),
        C = c(40520),
        p = c(14342),
        z = c(29142),
        M = c(41833),
        $ = c(10797),
        Y = c(69051),
        F = c(66776),
        le = c(66783),
        ge = c(24518),
        de = c(4707),
        Oe = c(56451),
        he = c(61135),
        Ee = c(39841),
        lt = c(92718),
        ke = c(39646),
        be = c(83905),
        De = c(49808),
        ce = c(63900),
        We = c(82722),
        ye = c(34782),
        Se = c(54004),
        je = c(78372),
        Ae = c(68675),
        Ge = c(71884),
        Rt = c(18505),
        _t = c(97001),
        me = c(52059),
        Vt = c(52674),
        gt = c(35599),
        Bt = c(67198),
        ft = c(35320),
        X = c(49860),
        qe = c(46815),
        He = c(38301),
        yt = c(27225),
        rt = c(43069),
        m = c(3073),
        e = c(5e3),
        at = c(98384),
        Qe = c(3604),
        Jt = c(75133),
        kt = c(46202),
        Qt = c(33935),
        Yt = c(60277),
        Kt = c(30365),
        Wt = c(84435),
        jt = c(72815),
        qt = c(81242),
        Ht = c(94040),
        $t = c(87428),
        zt = c(39560);
      class Xt extends zt.mT {}
      class mt extends $t.WF {
        constructor(o, t, i) {
          (super({
            path: "webfilter",
            name: "urlfilter",
            label: "Static URL Web Filter",
            cmdbSourceDi: o,
            variant: t,
            pool: i,
            EntryClass: Xt,
          }),
            (this.tooltipProperties = [
              this.tooltipFactory.createReferences(),
            ]));
        }
      }
      var ei = c(32422);
      let ti = (() => {
        class r extends _.Dp {
          constructor(t) {
            (super(), (this.cmdbSourceDi = t), (this.OmniSourceClass = mt));
          }
          createSource(t, i) {
            return new mt(this.cmdbSourceDi, t, i);
          }
        }
        return (
          (r.ɵfac = function (t) {
            return new (t || r)(e.LFG(ei.y));
          }),
          (r.ɵprov = e.Yz7({ token: r, factory: r.ɵfac, providedIn: "root" })),
          r
        );
      })();
      var Re = c(74929);
      function ii(r, o) {
        if (
          (1 & r &&
            (e.ynx(0),
            e.TgZ(1, "label", 6),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "nu-field"),
            e._UZ(5, "nu-omni-select", 10, 11),
            e.qZA(),
            e.BQk()),
          2 & r)
        ) {
          const t = o.ngIf,
            i = e.MAs(6),
            n = e.oxw(6);
          (e.xp6(1),
            e.Q6J("nuFor", i),
            e.xp6(1),
            e.Oqu(
              e.lcZ(
                3,
                5,
                n.FORM_CONTROL_LABELS[n.FormControlNames.IncomingInterface],
              ),
            ),
            e.xp6(3),
            e.Q6J("formControlName", n.FormControlNames.IncomingInterface)(
              "sources",
              t.selectSources,
            )("settings", t.selectSettings));
        }
      }
      function ni(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "nu-radio-input", 12),
            e._uU(1),
            e.ALo(2, "translate"),
            e.qZA()),
          2 & r)
        ) {
          const t = o.$implicit;
          (e.Q6J("value", t), e.xp6(1), e.hij(" ", e.lcZ(2, 2, t), " "));
        }
      }
      function oi(r, o) {
        if (
          (1 & r &&
            (e.ynx(0),
            e.TgZ(1, "label"),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "nu-field")(5, "nu-radio-group", 7),
            e.YNc(6, ni, 3, 4, "nu-radio-input", 9),
            e.qZA()(),
            e.BQk()),
          2 & r)
        ) {
          const t = o.ngIf,
            i = e.oxw(6);
          (e.xp6(2),
            e.Oqu(
              e.lcZ(3, 3, i.FORM_CONTROL_LABELS[i.FormControlNames.IPVersion]),
            ),
            e.xp6(3),
            e.Q6J("formControlName", i.FormControlNames.IPVersion),
            e.xp6(1),
            e.Q6J("ngForOf", t));
        }
      }
      function li(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "option", 12), e._uU(1), e.ALo(2, "translate"), e.qZA()),
          2 & r)
        ) {
          const t = o.$implicit;
          (e.Q6J("value", t), e.xp6(1), e.hij(" ", e.lcZ(2, 2, t), " "));
        }
      }
      const Pe = function (r) {
          return [r];
        },
        $e = function (r, o) {
          return { min: r, max: o };
        };
      function ri(r, o) {
        if (
          (1 & r &&
            (e.ynx(0),
            e.TgZ(1, "label", 6),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "nu-field", 13),
            e.ALo(5, "translate"),
            e.ALo(6, "translate"),
            e._UZ(7, "input", 14, 15),
            e.qZA(),
            e.BQk()),
          2 & r)
        ) {
          const t = e.MAs(8),
            i = e.oxw(6);
          (e.xp6(1),
            e.Q6J("nuFor", t),
            e.xp6(1),
            e.Oqu(e.lcZ(3, 5, "Protocol number")),
            e.xp6(2),
            e.Q6J(
              "errorMessages",
              e.WLB(
                17,
                $e,
                e.xi3(5, 7, "err_min_value", e.VKq(13, Pe, i.PROTO_RANGE.MIN)),
                e.xi3(6, 10, "err_max_value", e.VKq(15, Pe, i.PROTO_RANGE.MAX)),
              ),
            ),
            e.xp6(3),
            e.Q6J("formControlName", i.FormControlNames.ProtocolNumber)(
              "placeholder",
              i.PROTO_RANGE_HELP_TEXT,
            ));
        }
      }
      function ai(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "nu-radio-input", 12),
            e._uU(1),
            e.ALo(2, "translate"),
            e.qZA()),
          2 & r)
        ) {
          const t = o.$implicit;
          (e.Q6J("value", t.value),
            e.xp6(1),
            e.hij(" ", e.lcZ(2, 2, t.value), " "));
        }
      }
      function si(r, o) {
        if (
          (1 & r &&
            (e.ynx(0),
            e.TgZ(1, "label"),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "nu-field")(5, "nu-radio-group", 7),
            e.YNc(6, ai, 3, 4, "nu-radio-input", 9),
            e.ALo(7, "keyvalue"),
            e.qZA()(),
            e.BQk()),
          2 & r)
        ) {
          const t = e.oxw(6);
          (e.xp6(2),
            e.hij(
              " ",
              e.lcZ(3, 3, t.FORM_CONTROL_LABELS[t.FormControlNames.ICMPType]),
              " ",
            ),
            e.xp6(3),
            e.Q6J("formControlName", t.FormControlNames.ICMPType),
            e.xp6(1),
            e.Q6J(
              "ngForOf",
              e.xi3(7, 5, t.ICMPTypeOption, t.defaultKeyValueComparator),
            ));
        }
      }
      function ci(r, o) {
        if (
          (1 & r &&
            (e.ynx(0),
            e.TgZ(1, "label", 16),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "nu-field", 13),
            e.ALo(5, "translate"),
            e.ALo(6, "translate"),
            e._UZ(7, "input", 14, 17),
            e.qZA(),
            e.BQk()),
          2 & r)
        ) {
          const t = e.MAs(8),
            i = e.oxw(6);
          (e.xp6(1),
            e.Q6J("nuFor", t),
            e.xp6(1),
            e.Oqu(
              e.lcZ(
                3,
                5,
                i.FORM_CONTROL_LABELS[i.FormControlNames.ICMPTypeNumber],
              ),
            ),
            e.xp6(2),
            e.Q6J(
              "errorMessages",
              e.WLB(
                17,
                $e,
                e.xi3(5, 7, "err_min_value", e.VKq(13, Pe, i.PROTO_RANGE.MIN)),
                e.xi3(6, 10, "err_max_value", e.VKq(15, Pe, i.PROTO_RANGE.MAX)),
              ),
            ),
            e.xp6(3),
            e.Q6J("formControlName", i.FormControlNames.ICMPTypeNumber)(
              "placeholder",
              i.PROTO_RANGE_HELP_TEXT,
            ));
        }
      }
      function ui(r, o) {
        if (
          (1 & r &&
            (e.ynx(0),
            e.TgZ(1, "label", 16),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "nu-field", 13),
            e.ALo(5, "translate"),
            e.ALo(6, "translate"),
            e._UZ(7, "input", 14, 18),
            e.qZA(),
            e.BQk()),
          2 & r)
        ) {
          const t = e.MAs(8),
            i = e.oxw(6);
          (e.xp6(1),
            e.Q6J("nuFor", t),
            e.xp6(1),
            e.Oqu(
              e.lcZ(3, 5, i.FORM_CONTROL_LABELS[i.FormControlNames.ICMPCode]),
            ),
            e.xp6(2),
            e.Q6J(
              "errorMessages",
              e.WLB(
                17,
                $e,
                e.xi3(5, 7, "err_min_value", e.VKq(13, Pe, i.PROTO_RANGE.MIN)),
                e.xi3(6, 10, "err_max_value", e.VKq(15, Pe, i.PROTO_RANGE.MAX)),
              ),
            ),
            e.xp6(3),
            e.Q6J("formControlName", i.FormControlNames.ICMPCode)(
              "placeholder",
              i.PROTO_RANGE_HELP_TEXT,
            ));
        }
      }
      const di = function (r) {
        return { pattern: r };
      };
      function pi(r, o) {
        if (
          (1 & r &&
            (e.ynx(0),
            e.TgZ(1, "label", 6),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "nu-field", 13),
            e.ALo(5, "async"),
            e._UZ(6, "input", 19, 20),
            e.ALo(8, "translate"),
            e.qZA(),
            e.BQk()),
          2 & r)
        ) {
          const t = e.MAs(7),
            i = e.oxw(6);
          (e.xp6(1),
            e.Q6J("nuFor", t),
            e.xp6(1),
            e.Oqu(
              e.lcZ(3, 5, i.FORM_CONTROL_LABELS[i.FormControlNames.SourceIP]),
            ),
            e.xp6(2),
            e.Q6J(
              "errorMessages",
              e.VKq(
                11,
                di,
                e.lcZ(5, 7, i.policyLookupIpVersionObs) === i.IpVersion.IPv6
                  ? "Invalid IPv6 address"
                  : "Invalid IPv4 address",
              ),
            ),
            e.xp6(2),
            e.Q6J("formControlName", i.FormControlNames.SourceIP)(
              "placeholder",
              e.lcZ(8, 9, "IP address"),
            ));
        }
      }
      function _i(r, o) {
        if (
          (1 & r &&
            (e.ynx(0),
            e.TgZ(1, "label", 6),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "nu-field", 13),
            e.ALo(5, "translate"),
            e.ALo(6, "translate"),
            e._UZ(7, "input", 14, 21),
            e.qZA(),
            e.BQk()),
          2 & r)
        ) {
          const t = e.MAs(8),
            i = e.oxw(6);
          (e.xp6(1),
            e.Q6J("nuFor", t),
            e.xp6(1),
            e.Oqu(
              e.lcZ(3, 5, i.FORM_CONTROL_LABELS[i.FormControlNames.SourcePort]),
            ),
            e.xp6(2),
            e.Q6J(
              "errorMessages",
              e.WLB(
                17,
                $e,
                e.xi3(5, 7, "err_min_value", e.VKq(13, Pe, i.PORT_RANGE.MIN)),
                e.xi3(6, 10, "err_max_value", e.VKq(15, Pe, i.PORT_RANGE.MAX)),
              ),
            ),
            e.xp6(3),
            e.Q6J("formControlName", i.FormControlNames.SourcePort)(
              "placeholder",
              i.SOURCE_PORT_RANGE_HELP_TEXT,
            ));
        }
      }
      function gi(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "nu-radio-input", 12),
            e._uU(1),
            e.ALo(2, "translate"),
            e.qZA()),
          2 & r)
        ) {
          const t = o.$implicit;
          (e.Q6J("value", t.value),
            e.xp6(1),
            e.hij(" ", e.lcZ(2, 2, t.value), " "));
        }
      }
      function fi(r, o) {
        if ((1 & r && e._UZ(0, "nu-omni-select", 10), 2 & r)) {
          const t = o.ngIf,
            i = e.oxw(7);
          e.Q6J("formControlName", i.FormControlNames.User)(
            "sources",
            t.selectSources,
          )("settings", t.selectSettings);
        }
      }
      function yi(r, o) {
        if (
          (1 & r &&
            (e.ynx(0),
            e.TgZ(1, "label"),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "nu-field")(5, "nu-radio-group", 7),
            e.YNc(6, gi, 3, 4, "nu-radio-input", 9),
            e.ALo(7, "keyvalue"),
            e.qZA()(),
            e.TgZ(8, "nu-field"),
            e.YNc(9, fi, 1, 3, "nu-omni-select", 22),
            e.qZA(),
            e.BQk()),
          2 & r)
        ) {
          const t = e.oxw(3).ngIf,
            i = e.oxw(2).ngIf,
            n = e.oxw();
          (e.xp6(2),
            e.hij(
              " ",
              e.lcZ(3, 4, n.FORM_CONTROL_LABELS[n.FormControlNames.UserType]),
              " ",
            ),
            e.xp6(3),
            e.Q6J("formControlName", n.FormControlNames.UserType),
            e.xp6(1),
            e.Q6J(
              "ngForOf",
              e.xi3(7, 6, n.UserOption, n.defaultKeyValueComparator),
            ),
            e.xp6(3),
            e.Q6J("ngIf", t.user && i.userSelectConfig));
        }
      }
      function mi(r, o) {
        if (
          (1 & r &&
            (e.ynx(0),
            e.TgZ(1, "label"),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "nu-field"),
            e._UZ(5, "nu-omni-select", 10),
            e.qZA(),
            e.BQk()),
          2 & r)
        ) {
          const t = o.ngIf,
            i = e.oxw(6);
          (e.xp6(2),
            e.hij(
              " ",
              e.lcZ(3, 4, i.FORM_CONTROL_LABELS[i.FormControlNames.LDAPServer]),
              " ",
            ),
            e.xp6(3),
            e.Q6J("formControlName", i.FormControlNames.LDAPServer)(
              "sources",
              t.selectSources,
            )("settings", t.selectSettings));
        }
      }
      function vi(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.ynx(0),
            e.TgZ(1, "label"),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "nu-field", 23),
            e._UZ(5, "input", 19),
            e.TgZ(6, "button", 24),
            e.NdJ("click", function () {
              e.CHM(t);
              const n = e.oxw(4).ngIf,
                l = e.oxw(2);
              return e.KtG(l.browseLdapFilters(n));
            }),
            e.TgZ(7, "span"),
            e._uU(8),
            e.ALo(9, "translate"),
            e.qZA()()(),
            e.BQk());
        }
        if (2 & r) {
          const t = e.oxw(6);
          (e.xp6(2),
            e.hij(
              " ",
              e.lcZ(
                3,
                4,
                t.FORM_CONTROL_LABELS[t.FormControlNames.CustomLDAPFilter],
              ),
              " ",
            ),
            e.xp6(3),
            e.Q6J("formControlName", t.FormControlNames.CustomLDAPFilter)(
              "placeholder",
              "(objectClass=*)",
            ),
            e.xp6(3),
            e.Oqu(e.lcZ(9, 6, "Browse")));
        }
      }
      const hi = function () {
        return { fosPatterns: "Invalid hostname." };
      };
      function bi(r, o) {
        if (
          (1 & r &&
            (e.ynx(0),
            e.TgZ(1, "label", 6),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "nu-field", 13),
            e._UZ(5, "input", 19, 25),
            e.ALo(7, "translate"),
            e.qZA(),
            e.BQk()),
          2 & r)
        ) {
          const t = e.MAs(6),
            i = e.oxw(6);
          (e.xp6(1),
            e.Q6J("nuFor", t),
            e.xp6(1),
            e.Oqu(
              e.lcZ(
                3,
                5,
                i.FORM_CONTROL_LABELS[i.FormControlNames.Destination],
              ),
            ),
            e.xp6(2),
            e.Q6J("errorMessages", e.DdM(9, hi)),
            e.xp6(1),
            e.Q6J("formControlName", i.FormControlNames.Destination)(
              "placeholder",
              e.lcZ(7, 7, "IP address/FQDN"),
            ));
        }
      }
      function Si(r, o) {
        if (
          (1 & r &&
            (e.ynx(0),
            e.TgZ(1, "label", 6),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "nu-field", 13),
            e.ALo(5, "translate"),
            e.ALo(6, "translate"),
            e._UZ(7, "input", 14, 26),
            e.qZA(),
            e.BQk()),
          2 & r)
        ) {
          const t = e.MAs(8),
            i = e.oxw(6);
          (e.xp6(1),
            e.Q6J("nuFor", t),
            e.xp6(1),
            e.Oqu(
              e.lcZ(
                3,
                5,
                i.FORM_CONTROL_LABELS[i.FormControlNames.DestinationPort],
              ),
            ),
            e.xp6(2),
            e.Q6J(
              "errorMessages",
              e.WLB(
                17,
                $e,
                e.xi3(5, 7, "err_min_value", e.VKq(13, Pe, i.PORT_RANGE.MIN)),
                e.xi3(6, 10, "err_max_value", e.VKq(15, Pe, i.PORT_RANGE.MAX)),
              ),
            ),
            e.xp6(3),
            e.Q6J("formControlName", i.FormControlNames.DestinationPort)(
              "placeholder",
              i.PORT_RANGE_HELP_TEXT,
            ));
        }
      }
      function Pi(r, o) {
        if (
          (1 & r &&
            (e.YNc(0, ii, 7, 7, "ng-container", 0),
            e.YNc(1, oi, 7, 5, "ng-container", 0),
            e.ALo(2, "async"),
            e.ALo(3, "async"),
            e.TgZ(4, "label", 6),
            e._uU(5),
            e.ALo(6, "translate"),
            e.qZA(),
            e.TgZ(7, "nu-field")(8, "select", 7, 8),
            e.YNc(10, li, 3, 4, "option", 9),
            e.ALo(11, "async"),
            e.qZA()(),
            e.YNc(12, ri, 9, 20, "ng-container", 0),
            e.YNc(13, si, 8, 8, "ng-container", 0),
            e.YNc(14, ci, 9, 20, "ng-container", 0),
            e.YNc(15, ui, 9, 20, "ng-container", 0),
            e.YNc(16, pi, 9, 13, "ng-container", 0),
            e.YNc(17, _i, 9, 20, "ng-container", 0),
            e.YNc(18, yi, 10, 9, "ng-container", 0),
            e.YNc(19, mi, 6, 6, "ng-container", 0),
            e.YNc(20, vi, 10, 8, "ng-container", 0),
            e.YNc(21, bi, 8, 10, "ng-container", 0),
            e.YNc(22, Si, 9, 20, "ng-container", 0)),
          2 & r)
        ) {
          const t = e.MAs(9),
            i = e.oxw(2).ngIf,
            n = e.oxw(2).ngIf,
            l = e.oxw();
          let a;
          (e.Q6J("ngIf", n.interfaceSelectConfig),
            e.xp6(1),
            e.Q6J(
              "ngIf",
              (null == (a = e.lcZ(2, 17, l.guiFeatureVisibilityObs))
                ? null
                : a.ipv6Enabled) && e.lcZ(3, 19, l.ipVersionsObs),
            ),
            e.xp6(3),
            e.Q6J("nuFor", t),
            e.xp6(1),
            e.Oqu(
              e.lcZ(6, 21, l.FORM_CONTROL_LABELS[l.FormControlNames.Protocol]),
            ),
            e.xp6(3),
            e.Q6J("formControlName", l.FormControlNames.Protocol),
            e.xp6(2),
            e.Q6J("ngForOf", e.lcZ(11, 23, l.protocolObs)),
            e.xp6(2),
            e.Q6J("ngIf", i.protocolNumber),
            e.xp6(1),
            e.Q6J("ngIf", i.icmpType),
            e.xp6(1),
            e.Q6J("ngIf", i.icmpTypeNumber),
            e.xp6(1),
            e.Q6J("ngIf", i.icmpCode),
            e.xp6(1),
            e.Q6J("ngIf", i.sourceIp),
            e.xp6(1),
            e.Q6J("ngIf", i.sourcePort),
            e.xp6(1),
            e.Q6J("ngIf", i.userType),
            e.xp6(1),
            e.Q6J("ngIf", i.ldapServer && n.ldapServerSelectConfig),
            e.xp6(1),
            e.Q6J("ngIf", i.customLdapFilter),
            e.xp6(1),
            e.Q6J("ngIf", i.destination),
            e.xp6(1),
            e.Q6J("ngIf", i.destinationPort));
        }
      }
      function Ti(r, o) {
        1 & r &&
          (e.TgZ(0, "nu-dialog-section"),
          e.YNc(1, Pi, 23, 25, "ng-template", 5),
          e.qZA());
      }
      function Ci(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "tr")(1, "td"),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "td"),
            e._UZ(5, "nu-omni-source-entry-label", 29),
            e.qZA()()),
          2 & r)
        ) {
          const t = o.ngIf;
          (e.xp6(2), e.Oqu(e.lcZ(3, 2, "VDOM")), e.xp6(3), e.Q6J("entry", t));
        }
      }
      function xi(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "tr")(1, "td"),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "td"),
            e._uU(5),
            e.ALo(6, "translate"),
            e.qZA()()),
          2 & r)
        ) {
          const t = o.ngIf,
            i = e.oxw(6);
          (e.xp6(2),
            e.Oqu(
              e.lcZ(3, 2, i.FORM_CONTROL_LABELS[i.FormControlNames.IPVersion]),
            ),
            e.xp6(3),
            e.hij(" ", e.lcZ(6, 4, t), " "));
        }
      }
      function Mi(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "tr")(1, "td"),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "td"),
            e._uU(5),
            e.ALo(6, "translate"),
            e.qZA()()),
          2 & r)
        ) {
          const t = o.ngIf,
            i = e.oxw(6);
          (e.xp6(2),
            e.Oqu(
              e.lcZ(3, 2, i.FORM_CONTROL_LABELS[i.FormControlNames.Protocol]),
            ),
            e.xp6(3),
            e.hij(" ", e.lcZ(6, 4, t), " "));
        }
      }
      function Ii(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "tr")(1, "td"),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "td"),
            e._UZ(5, "nu-omni-source-entry-label", 29),
            e.qZA()()),
          2 & r)
        ) {
          const t = o.ngIf,
            i = e.oxw(6);
          (e.xp6(2),
            e.hij(
              " ",
              e.lcZ(
                3,
                2,
                i.FORM_CONTROL_LABELS[i.FormControlNames.IncomingInterface],
              ),
              " ",
            ),
            e.xp6(3),
            e.Q6J("entry", t));
        }
      }
      function Oi(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "tr")(1, "td"),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "td"),
            e._uU(5),
            e.qZA()()),
          2 & r)
        ) {
          const t = o.ngIf,
            i = e.oxw(6);
          (e.xp6(2),
            e.Oqu(
              e.lcZ(3, 2, i.FORM_CONTROL_LABELS[i.FormControlNames.SourceIP]),
            ),
            e.xp6(3),
            e.hij(" ", t, " "));
        }
      }
      function Ei(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "tr")(1, "td"),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "td"),
            e._uU(5),
            e.qZA()()),
          2 & r)
        ) {
          const t = o.ngIf,
            i = e.oxw(6);
          (e.xp6(2),
            e.Oqu(
              e.lcZ(3, 2, i.FORM_CONTROL_LABELS[i.FormControlNames.SourcePort]),
            ),
            e.xp6(3),
            e.hij(" ", t, " "));
        }
      }
      function Li(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "tr")(1, "td"),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "td"),
            e._UZ(5, "nu-omni-source-entry-label", 29),
            e.qZA()()),
          2 & r)
        ) {
          const t = o.ngIf,
            i = e.oxw(6);
          (e.xp6(2),
            e.Oqu(
              e.lcZ(3, 2, i.FORM_CONTROL_LABELS[i.FormControlNames.UserType]),
            ),
            e.xp6(3),
            e.Q6J("entry", t));
        }
      }
      function wi(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "tr")(1, "td"),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "td"),
            e._UZ(5, "nu-omni-source-entry-label", 29),
            e.qZA()()),
          2 & r)
        ) {
          const t = o.ngIf,
            i = e.oxw(6);
          (e.xp6(2),
            e.Oqu(
              e.lcZ(3, 2, i.FORM_CONTROL_LABELS[i.FormControlNames.LDAPServer]),
            ),
            e.xp6(3),
            e.Q6J("entry", t));
        }
      }
      function Ai(r, o) {
        if ((1 & r && (e.TgZ(0, "div"), e._uU(1), e.qZA()), 2 & r)) {
          const t = o.$implicit;
          (e.xp6(1), e.hij(" ", t, " "));
        }
      }
      function Fi(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "tr")(1, "td"),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "td"),
            e.YNc(5, Ai, 2, 1, "div", 30),
            e.qZA()()),
          2 & r)
        ) {
          const t = e.oxw(2).ngIf,
            i = e.oxw(4);
          (e.xp6(2),
            e.hij(
              " ",
              e.lcZ(
                3,
                2,
                i.FORM_CONTROL_LABELS[i.FormControlNames.CustomLDAPFilter],
              ),
              " ",
            ),
            e.xp6(3),
            e.Q6J("ngForOf", t.customLdapFilter));
        }
      }
      function Ni(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "tr")(1, "td"),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "td"),
            e._uU(5),
            e.qZA()()),
          2 & r)
        ) {
          const t = o.ngIf,
            i = e.oxw(6);
          (e.xp6(2),
            e.Oqu(
              e.lcZ(
                3,
                2,
                i.FORM_CONTROL_LABELS[i.FormControlNames.Destination],
              ),
            ),
            e.xp6(3),
            e.hij(" ", t, " "));
        }
      }
      function Zi(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "tr")(1, "td"),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "td"),
            e._uU(5),
            e.qZA()()),
          2 & r)
        ) {
          const t = o.ngIf,
            i = e.oxw(6);
          (e.xp6(2),
            e.hij(
              " ",
              e.lcZ(
                3,
                2,
                i.FORM_CONTROL_LABELS[i.FormControlNames.DestinationPort],
              ),
              " ",
            ),
            e.xp6(3),
            e.hij(" ", t, " "));
        }
      }
      function Di(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "table", 28)(1, "tbody"),
            e.YNc(2, Ci, 6, 4, "tr", 0),
            e.YNc(3, xi, 7, 6, "tr", 0),
            e.YNc(4, Mi, 7, 6, "tr", 0),
            e.YNc(5, Ii, 6, 4, "tr", 0),
            e.YNc(6, Oi, 6, 4, "tr", 0),
            e.YNc(7, Ei, 6, 4, "tr", 0),
            e.YNc(8, Li, 6, 4, "tr", 0),
            e.YNc(9, wi, 6, 4, "tr", 0),
            e.YNc(10, Fi, 6, 4, "tr", 0),
            e.YNc(11, Ni, 6, 4, "tr", 0),
            e.YNc(12, Zi, 6, 4, "tr", 0),
            e.qZA()()),
          2 & r)
        ) {
          const t = e.oxw().ngIf;
          (e.xp6(2),
            e.Q6J("ngIf", t.vdomEntryRef),
            e.xp6(1),
            e.Q6J("ngIf", t.ipVersion),
            e.xp6(1),
            e.Q6J("ngIf", t.protocol),
            e.xp6(1),
            e.Q6J("ngIf", t.incomingInterface),
            e.xp6(1),
            e.Q6J("ngIf", t.sourceIp),
            e.xp6(1),
            e.Q6J("ngIf", t.sourcePort),
            e.xp6(1),
            e.Q6J("ngIf", t.user),
            e.xp6(1),
            e.Q6J("ngIf", t.ldapServer),
            e.xp6(1),
            e.Q6J(
              "ngIf",
              null == t.customLdapFilter ? null : t.customLdapFilter.length,
            ),
            e.xp6(1),
            e.Q6J("ngIf", t.destination),
            e.xp6(1),
            e.Q6J("ngIf", t.destinationPort));
        }
      }
      function Gi(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "div", 34),
            e._UZ(1, "nu-icon", 35),
            e.TgZ(2, "span", 36),
            e._uU(3),
            e.qZA()()),
          2 & r)
        ) {
          const t = e.oxw(2).ngIf,
            i = e.oxw(5);
          (e.xp6(1),
            e.Q6J("icon", i.InfoIconAlias),
            e.xp6(2),
            e.hij(" ", t.errorMessage, " "));
        }
      }
      function Ui(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "td"),
            e._UZ(1, "nu-omni-source-entry-label", 29),
            e.qZA()),
          2 & r)
        ) {
          const t = e.oxw(4).ngIf;
          (e.xp6(1), e.Q6J("entry", t.proxyPolicy));
        }
      }
      function Ri(r, o) {
        (1 & r &&
          (e.TgZ(0, "td")(1, "span"),
          e._uU(2),
          e.ALo(3, "translate"),
          e.qZA()()),
          2 & r && (e.xp6(2), e.Oqu(e.lcZ(3, 1, "Not found"))));
      }
      function Vi(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "tr", 45)(1, "td"),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.YNc(4, Ui, 2, 1, "td", 0),
            e.YNc(5, Ri, 4, 3, "td", 0),
            e.qZA()),
          2 & r)
        ) {
          const t = e.oxw(3).ngIf,
            i = e.oxw(5);
          (e.xp6(2),
            e.Oqu(e.lcZ(3, 3, i.PolicyLookupResultLabels.RedirectedPolicy)),
            e.xp6(2),
            e.Q6J("ngIf", t.proxyPolicy),
            e.xp6(1),
            e.Q6J("ngIf", !t.proxyPolicy));
        }
      }
      function Bi(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "span"), e._uU(1), e.ALo(2, "translate"), e.qZA()),
          2 & r)
        ) {
          const t = e.oxw().ngIf;
          (e.xp6(1), e.hij(" ", e.lcZ(2, 1, t), " "));
        }
      }
      function Ji(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "span"),
            e._uU(1),
            e.ALo(2, "translate"),
            e.ALo(3, "translate"),
            e.qZA()),
          2 & r)
        ) {
          const t = e.oxw().ngIf,
            i = e.oxw(8);
          (e.xp6(1),
            e.hij(
              " ",
              e.xi3(
                2,
                1,
                "{0} by redirected policy",
                e.VKq(6, Pe, e.lcZ(3, 4, i.TP_POLICY_ACTION_LANG_MAP[t])),
              ),
              " ",
            ));
        }
      }
      function ki(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "tr")(1, "td"),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "td"),
            e._UZ(5, "nu-icon", 35),
            e.YNc(6, Bi, 3, 3, "span", 0),
            e.YNc(7, Ji, 4, 8, "span", 0),
            e.qZA()()),
          2 & r)
        ) {
          const t = o.ngIf,
            i = e.oxw(3).ngIf,
            n = e.oxw(5);
          (e.xp6(2),
            e.Oqu(e.lcZ(3, 4, n.PolicyLookupResultLabels.PolicyAction)),
            e.xp6(3),
            e.Q6J("icon", n.POLICY_ACTION_ICON_MAP[t]),
            e.xp6(1),
            e.Q6J("ngIf", !i.isTpLookup),
            e.xp6(1),
            e.Q6J("ngIf", i.isTpLookup && i.proxyPolicy));
        }
      }
      function Qi(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "tr", 46)(1, "td"),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "td"),
            e._UZ(5, "nu-icon", 35),
            e.TgZ(6, "span", 47),
            e._uU(7),
            e.ALo(8, "translate"),
            e.ALo(9, "translate"),
            e.qZA()()()),
          2 & r)
        ) {
          const t = o.ngIf;
          e.oxw();
          const i = e.MAs(13),
            n = e.oxw(7);
          (e.xp6(2),
            e.Oqu(e.lcZ(3, 4, n.PolicyLookupResultLabels.PolicyAction)),
            e.xp6(3),
            e.Q6J("icon", n.DEFAULT_POLICY_ACTION_ICON_MAP[t]),
            e.xp6(1),
            e.Q6J("nuTip", i),
            e.xp6(1),
            e.hij(
              " ",
              e.xi3(
                8,
                6,
                "{0} by implicit proxy policy",
                e.VKq(
                  11,
                  Pe,
                  e.lcZ(9, 9, n.EXPLICIT_PROXY_DEFAULT_ACTION_LANG_MAP[t]),
                ),
              ),
              " ",
            ));
        }
      }
      function Yi(r, o) {
        (1 & r && (e.TgZ(0, "span"), e._uU(1), e.ALo(2, "translate"), e.qZA()),
          2 & r &&
            (e.xp6(1),
            e.Oqu(
              e.lcZ(
                2,
                1,
                "Default firewall policy action configured in Network > Explicit Proxy.",
              ),
            )));
      }
      function Ki(r, o) {
        (1 & r && e._UZ(0, "nu-icon", 35), 2 & r && e.Q6J("icon", o.ngIf));
      }
      function Wi(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "tr", 50)(1, "td"),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "td"),
            e.YNc(5, Ki, 1, 1, "nu-icon", 51),
            e._uU(6),
            e.ALo(7, "translate"),
            e.qZA()()),
          2 & r)
        ) {
          const t = o.ngIf,
            i = e.oxw(9);
          (e.xp6(2),
            e.hij(
              " ",
              e.lcZ(3, 3, i.PolicyLookupResultLabels.WebFilterAction),
              " ",
            ),
            e.xp6(3),
            e.Q6J("ngIf", i.WEB_FILTER_ACTION_ICON_MAP[t]),
            e.xp6(1),
            e.hij(" ", e.lcZ(7, 5, i.WEB_FILTER_ACTION_LANG_MAP[t]), " "));
        }
      }
      function ji(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "tr", 50)(1, "td"),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "td"),
            e._uU(5),
            e.qZA()()),
          2 & r)
        ) {
          const t = o.ngIf,
            i = e.oxw(10);
          (e.xp6(2),
            e.hij(
              " ",
              e.lcZ(3, 2, i.PolicyLookupResultLabels.CategoryFilterUrl),
              " ",
            ),
            e.xp6(3),
            e.hij(" ", t, " "));
        }
      }
      function qi(r, o) {
        if (
          (1 & r &&
            (e.ynx(0),
            e.YNc(1, ji, 6, 4, "tr", 49),
            e.TgZ(2, "tr", 50)(3, "td"),
            e._uU(4),
            e.ALo(5, "translate"),
            e.qZA(),
            e.TgZ(6, "td"),
            e._UZ(7, "nu-omni-source-entry-label", 29),
            e.qZA()(),
            e.BQk()),
          2 & r)
        ) {
          const t = o.ngIf,
            i = e.oxw(5).ngIf,
            n = e.oxw(4);
          (e.xp6(1),
            e.Q6J("ngIf", i.destination),
            e.xp6(3),
            e.hij(
              " ",
              e.lcZ(5, 3, n.PolicyLookupResultLabels.CategoryFilter),
              " ",
            ),
            e.xp6(3),
            e.Q6J("entry", t));
        }
      }
      function Hi(r, o) {
        if (
          (1 & r &&
            (e.ynx(0),
            e.TgZ(1, "tr", 50)(2, "td"),
            e._uU(3),
            e.ALo(4, "translate"),
            e.qZA(),
            e.TgZ(5, "td"),
            e._uU(6),
            e.qZA()(),
            e.BQk()),
          2 & r)
        ) {
          const t = o.ngIf,
            i = e.oxw(9);
          (e.xp6(3),
            e.hij(" ", e.lcZ(4, 2, i.PolicyLookupResultLabels.UrlFilter), " "),
            e.xp6(3),
            e.Oqu(t));
        }
      }
      function $i(r, o) {
        if (
          (1 & r &&
            (e.ynx(0),
            e.TgZ(1, "tr", 48)(2, "td"),
            e._uU(3),
            e.ALo(4, "translate"),
            e.qZA(),
            e.TgZ(5, "td"),
            e._UZ(6, "nu-omni-source-entry-label", 29),
            e.qZA()(),
            e.YNc(7, Wi, 8, 7, "tr", 49),
            e.YNc(8, qi, 8, 5, "ng-container", 0),
            e.YNc(9, Hi, 7, 4, "ng-container", 0),
            e.BQk()),
          2 & r)
        ) {
          const t = o.ngIf,
            i = e.oxw(3).ngIf,
            n = e.oxw(5);
          (e.xp6(3),
            e.Oqu(e.lcZ(4, 5, n.PolicyLookupResultLabels.WebFilterProfile)),
            e.xp6(3),
            e.Q6J("entry", t),
            e.xp6(1),
            e.Q6J("ngIf", i.webFilterAction),
            e.xp6(1),
            e.Q6J("ngIf", i.webFilterCategory),
            e.xp6(1),
            e.Q6J("ngIf", i.webFilterStaticUrl));
        }
      }
      function zi(r, o) {
        if ((1 & r && (e.TgZ(0, "div"), e._uU(1), e.qZA()), 2 & r)) {
          const t = o.$implicit;
          (e.xp6(1), e.Oqu(t));
        }
      }
      function Xi(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "tr")(1, "td"),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "td"),
            e.YNc(5, zi, 2, 1, "div", 30),
            e.qZA()()),
          2 & r)
        ) {
          const t = o.ngIf,
            i = e.oxw(8);
          (e.xp6(2),
            e.Oqu(e.lcZ(3, 2, i.PolicyLookupResultLabels.FromRemoteGroup)),
            e.xp6(3),
            e.Q6J("ngForOf", t));
        }
      }
      function en(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "tfoot")(1, "tr")(2, "td", 52)(3, "div")(4, "button", 53),
            e.NdJ("click", function () {
              e.CHM(t);
              const n = e.oxw().ngIf,
                l = e.oxw(7);
              return e.KtG(l.showInList(n));
            }),
            e._UZ(5, "nu-icon", 35),
            e.TgZ(6, "span"),
            e._uU(7),
            e.ALo(8, "translate"),
            e.qZA()(),
            e.TgZ(9, "button", 53),
            e.NdJ("click", function () {
              e.CHM(t);
              const n = e.oxw().ngIf,
                l = e.oxw(7);
              return e.KtG(l.editPolicy(n));
            }),
            e._UZ(10, "nu-icon", 35),
            e.TgZ(11, "span"),
            e._uU(12),
            e.ALo(13, "translate"),
            e.qZA()()()()()());
        }
        if (2 & r) {
          const t = e.oxw(8);
          (e.xp6(5),
            e.Q6J("icon", t.externalLinkAltIcon),
            e.xp6(2),
            e.hij(" ", e.lcZ(8, 4, "Show in list"), " "),
            e.xp6(3),
            e.Q6J("icon", t.pencilAltIcon),
            e.xp6(2),
            e.hij(" ", e.lcZ(13, 6, "Edit"), " "));
        }
      }
      function tn(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "table", 37)(1, "thead")(2, "tr")(3, "th", 38)(
              4,
              "div",
              39,
            ),
            e._UZ(5, "nu-icon", 40),
            e.TgZ(6, "div", 41),
            e._UZ(7, "nu-omni-source-entry-label", 29),
            e.qZA()()()()(),
            e.TgZ(8, "tbody"),
            e.YNc(9, Vi, 6, 5, "tr", 42),
            e.YNc(10, ki, 8, 6, "tr", 0),
            e.YNc(11, Qi, 10, 13, "tr", 43),
            e.YNc(12, Yi, 3, 3, "ng-template", null, 44, e.W1O),
            e.YNc(14, $i, 10, 7, "ng-container", 0),
            e.YNc(15, Xi, 6, 4, "tr", 0),
            e.qZA(),
            e.YNc(16, en, 14, 8, "tfoot", 0),
            e.qZA()),
          2 & r)
        ) {
          const t = o.ngIf,
            i = e.oxw(2).ngIf,
            n = e.oxw(5);
          (e.xp6(5),
            e.Q6J("icon", n.policyObjectsIcon)("size", n.IconSize.XXLarge),
            e.xp6(2),
            e.Q6J("entry", t),
            e.xp6(2),
            e.Q6J("ngIf", i.isTpLookup),
            e.xp6(1),
            e.Q6J("ngIf", i.policyAction),
            e.xp6(1),
            e.Q6J("ngIf", i.isTpLookup && i.defaultFirewallPolicyAction),
            e.xp6(3),
            e.Q6J("ngIf", i.webFilterProfile),
            e.xp6(1),
            e.Q6J("ngIf", i.remoteGroups),
            e.xp6(1),
            e.Q6J("ngIf", !t.implicit));
        }
      }
      function nn(r, o) {
        if (
          (1 & r &&
            (e.YNc(0, Gi, 4, 2, "div", 32), e.YNc(1, tn, 17, 9, "table", 33)),
          2 & r)
        ) {
          const t = e.oxw().ngIf;
          (e.Q6J("ngIf", !(null != t && t.policy) && t.errorMessage),
            e.xp6(1),
            e.Q6J("ngIf", null == t ? null : t.policy));
        }
      }
      function on(r, o) {
        (1 & r &&
          (e.ynx(0),
          e.TgZ(1, "nu-dialog-section", 31),
          e.ALo(2, "translate"),
          e.YNc(3, nn, 2, 2, "ng-template", 5),
          e.qZA(),
          e.BQk()),
          2 & r && (e.xp6(1), e.Q6J("label", e.lcZ(2, 1, "Matched Policy"))));
      }
      function ln(r, o) {
        if (
          (1 & r &&
            (e.ynx(0)(1),
            e.TgZ(2, "nu-dialog-section", 27),
            e.ALo(3, "translate"),
            e.YNc(4, Di, 13, 11, "ng-template", 5),
            e.qZA(),
            e.BQk(),
            e.YNc(5, on, 4, 3, "ng-container", 0),
            e.ALo(6, "async"),
            e.BQk()),
          2 & r)
        ) {
          const t = e.oxw(4);
          (e.xp6(2),
            e.Q6J("type", t.DialogSectionType.EXPAND_COLLAPSE)(
              "label",
              e.lcZ(3, 3, "Traffic Parameters"),
            ),
            e.xp6(3),
            e.Q6J("ngIf", e.lcZ(6, 5, t.policyMatchDetailsObs)));
        }
      }
      function rn(r, o) {
        (1 & r &&
          (e.TgZ(0, "nu-dialog-submit-button"),
          e._uU(1),
          e.ALo(2, "translate"),
          e.qZA()),
          2 & r &&
            (e.xp6(1), e.hij(" ", e.lcZ(2, 1, "Find matching policy"), " ")));
      }
      function an(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "button", 54),
            e.NdJ("click", function () {
              e.CHM(t);
              const n = e.oxw(4);
              return e.KtG(n.goBack());
            }),
            e._uU(1),
            e.ALo(2, "translate"),
            e.qZA());
        }
        2 & r && (e.xp6(1), e.hij(" ", e.lcZ(2, 1, "Back"), " "));
      }
      function sn(r, o) {
        (1 & r && (e.TgZ(0, "div"), e._uU(1), e.ALo(2, "translate"), e.qZA()),
          2 & r &&
            (e.xp6(1),
            e.hij(" ", e.lcZ(2, 1, "Clear recent policy match history"), " ")));
      }
      function cn(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "span"),
            e._uU(1),
            e.ALo(2, "translate"),
            e.qZA(),
            e.TgZ(3, "nu-icon", 57),
            e.NdJ("click", function () {
              e.CHM(t);
              const n = e.oxw(6);
              return e.KtG(n.clearRecentLookupPolicies());
            }),
            e.qZA(),
            e.YNc(4, sn, 3, 3, "ng-template", null, 58, e.W1O));
        }
        if (2 & r) {
          const t = e.MAs(5),
            i = e.oxw(6);
          (e.xp6(1),
            e.Oqu(e.lcZ(2, 3, "Recent Matches")),
            e.xp6(2),
            e.Q6J("icon", i.trashIcon)("nuTip", t));
        }
      }
      function un(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "a", 63),
            e.NdJ("click", function (n) {
              e.CHM(t);
              const l = e.oxw().$implicit,
                a = e.oxw(6).ngIf,
                s = e.oxw(2);
              return e.KtG(s.populateRecentPolicy(n, a, l));
            }),
            e.TgZ(1, "span"),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e._UZ(4, "nu-omni-source-entry-label", 29),
            e.TgZ(5, "div")(6, "span"),
            e._uU(7),
            e.qZA()()());
        }
        if (2 & r) {
          const t = o.ngIf,
            i = e.oxw().$implicit,
            n = e.oxw(8);
          (e.xp6(2),
            e.hij("", e.lcZ(3, 3, i.protocol), " on "),
            e.xp6(2),
            e.Q6J("entry", t),
            e.xp6(3),
            e.hij("", n.getRecentPolicyAddressLabel(i), " "));
        }
      }
      function dn(r, o) {
        if (
          (1 & r && (e.TgZ(0, "div", 61), e.YNc(1, un, 8, 5, "a", 62), e.qZA()),
          2 & r)
        ) {
          const t = o.$implicit,
            i = e.oxw(7).ngIf,
            n = e.oxw();
          (e.xp6(1),
            e.Q6J(
              "ngIf",
              n.getRecentPolicyInterfaceEntry(t, i.sources.firewallInterface),
            ));
        }
      }
      function pn(r, o) {
        if (
          (1 & r &&
            (e.ynx(0),
            e.TgZ(1, "div", 59),
            e.YNc(2, dn, 2, 1, "div", 60),
            e.qZA(),
            e.BQk()),
          2 & r)
        ) {
          const t = e.oxw(3).ngIf;
          (e.xp6(2), e.Q6J("ngForOf", t));
        }
      }
      function _n(r, o) {
        if (
          (1 & r && (e.YNc(0, pn, 3, 1, "ng-container", 0), e.ALo(1, "async")),
          2 & r)
        ) {
          const t = e.oxw(6);
          e.Q6J(
            "ngIf",
            !0 === e.lcZ(1, 1, t.loadRecentLookupPolicyInterfacesObs),
          );
        }
      }
      function gn(r, o) {
        1 & r &&
          (e.TgZ(0, "nu-dialog-aside-section"),
          e.YNc(1, cn, 6, 5, "ng-template", 55),
          e.YNc(2, _n, 2, 3, "ng-template", 56),
          e.qZA());
      }
      function fn(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "aside"),
            e.YNc(1, gn, 3, 0, "nu-dialog-aside-section", 0),
            e.qZA()),
          2 & r)
        ) {
          const t = o.ngIf;
          (e.xp6(1), e.Q6J("ngIf", t.length));
        }
      }
      function yn(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "nu-dialog", 2),
            e.NdJ("dialogSubmitting", function (n) {
              const a = e.CHM(t).ngIf,
                s = e.oxw().ngIf,
                u = e.oxw(2);
              return e.KtG(u.lookupPolicy(n, s, a));
            }),
            e.ALo(1, "translate"),
            e.TgZ(2, "form", 3),
            e.YNc(3, Ti, 2, 0, "nu-dialog-section", 0),
            e.YNc(4, ln, 7, 7, "ng-container", 0),
            e.ALo(5, "async"),
            e.qZA(),
            e.TgZ(6, "footer"),
            e.YNc(7, rn, 3, 3, "nu-dialog-submit-button", 0),
            e.YNc(8, an, 3, 3, "button", 4),
            e.TgZ(9, "nu-dialog-close-button"),
            e._uU(10),
            e.ALo(11, "translate"),
            e.qZA()(),
            e.YNc(12, fn, 2, 1, "aside", 0),
            e.ALo(13, "async"),
            e.qZA());
        }
        if (2 & r) {
          const t = e.oxw().ngIf,
            i = e.oxw(2);
          (e.Q6J("dialogTitle", e.lcZ(1, 11, "Policy Match Tool"))("form", t)(
            "formTabLabelLangKey",
            "Details",
          )("gutterTabLabelLangKey", "Recently Matched Policies"),
            e.xp6(2),
            e.Q6J("formGroup", t),
            e.xp6(1),
            e.Q6J(
              "ngIf",
              i.policyLookupStateSubject.value === i.PolicyLookupState.Lookup,
            ),
            e.xp6(1),
            e.Q6J(
              "ngIf",
              i.policyLookupStateSubject.value === i.PolicyLookupState.Match &&
                e.lcZ(5, 13, i.trafficParamsObs),
            ),
            e.xp6(3),
            e.Q6J(
              "ngIf",
              i.policyLookupStateSubject.value === i.PolicyLookupState.Lookup,
            ),
            e.xp6(1),
            e.Q6J(
              "ngIf",
              i.policyLookupStateSubject.value === i.PolicyLookupState.Match,
            ),
            e.xp6(2),
            e.Oqu(e.lcZ(11, 15, "Close")),
            e.xp6(2),
            e.Q6J(
              "ngIf",
              i.policyLookupStateSubject.value === i.PolicyLookupState.Lookup &&
                e.lcZ(13, 17, i.recentLookupPoliciesSubject),
            ));
        }
      }
      function mn(r, o) {
        if (
          (1 & r &&
            (e.ynx(0),
            e.YNc(1, yn, 14, 19, "nu-dialog", 1),
            e.ALo(2, "async"),
            e.BQk()),
          2 & r)
        ) {
          const t = e.oxw(2);
          (e.xp6(1), e.Q6J("ngIf", e.lcZ(2, 1, t.visibilityObs)));
        }
      }
      function vn(r, o) {
        if (
          (1 & r &&
            (e.ynx(0),
            e.YNc(1, mn, 3, 3, "ng-container", 0),
            e.ALo(2, "async"),
            e.BQk()),
          2 & r)
        ) {
          const t = e.oxw();
          (e.xp6(1), e.Q6J("ngIf", e.lcZ(2, 1, t.formObs)));
        }
      }
      let vt = (() => {
        class r extends (0, _t.T)() {
          constructor(t, i, n, l, a, s, u, g, h, P, N, L, J, Q, j, K, H) {
            (super(),
              (this.fb = t),
              (this.router = i),
              (this.translation = n),
              (this.http = l),
              (this.prompt = a),
              (this.notify = s),
              (this.slideBridge = u),
              (this.interfaceFactory = g),
              (this.policyFactory = h),
              (this.proxyPolicyFactory = P),
              (this.localUserFactory = N),
              (this.ldapServerFactory = L),
              (this.webFilterProfileFactory = J),
              (this.webFilterFtgdCatFactory = Q),
              (this.webFilterFtgdLocalCatFactory = j),
              (this.webFilterUrlFilterFactory = K),
              (this.slideComponent = H),
              (this.FORM_CONTROL_LABELS = m.gg),
              (this.WEB_FILTER_ACTION_LANG_MAP = m.li),
              (this.WEB_FILTER_ACTION_ICON_MAP = m.Aq),
              (this.POLICY_ACTION_ICON_MAP = m.QK),
              (this.TP_POLICY_ACTION_LANG_MAP = m.dP),
              (this.EXPLICIT_PROXY_DEFAULT_ACTION_LANG_MAP = m.ES),
              (this.DEFAULT_POLICY_ACTION_ICON_MAP = m.Dq),
              (this.PolicyLookupResultLabels = m.LS),
              (this.IpVersion = m.IT),
              (this.UserOption = m.dC),
              (this.FormControlNames = m.Bd),
              (this.ICMPTypeOption = m.P4),
              (this.DialogSectionType = I.Xz),
              (this.PolicyLookupState = m.$o),
              (this.IconSize = f.Jh),
              (this.WarningIconAlias = z.$I),
              (this.trashIcon = Y.yiX),
              (this.externalLinkAltIcon = Y.sdl),
              (this.pencilAltIcon = Y.hRO),
              (this.InfoIconAlias = z.V0),
              (this.policyObjectsIcon = F.Nr3),
              (this.DEFAULT_IP_VERSION = m.IT.IPv4),
              (this.PORT_BASED_PROTOCOLS = [
                m.b$.HTTPS,
                m.b$.HTTP,
                m.b$.TCP,
                m.b$.UDP,
                m.b$.SCTP,
              ]),
              (this.BASE_PROTOCOLS = [...this.PORT_BASED_PROTOCOLS]),
              (this.DEFAULT_PROTOCOL = m.b$.HTTPS),
              (this.DEFAULT_USER = m.dC.Any),
              (this.DEFAULT_ICMP_TYPE = m.P4.PingReply),
              (this.PROTO_RANGE = { MIN: 0, MAX: 255 }),
              (this.PROTO_RANGE_HELP_TEXT = `${this.PROTO_RANGE.MIN}-${this.PROTO_RANGE.MAX}`),
              (this.ICMP_PRESET = {
                [m.P4.PingRequest]: { icmptype: 8, icmpcode: 0 },
                [m.P4.PingReply]: { icmptype: 0, icmpcode: 0 },
                protocol: m.b$.ICMP,
              }),
              (this.ICMP6_PRESET = {
                [m.P4.PingRequest]: { icmptype: 128, icmpcode: 0 },
                [m.P4.PingReply]: { icmptype: 129, icmpcode: 0 },
                protocol: m.b$.ICMP6,
              }),
              (this.neutrinoPatterns = le.tN),
              (this.fosPatterns = yt.W),
              (this.PORT_RANGE = { MIN: 1, MAX: 65535 }),
              (this.PORT_RANGE_HELP_TEXT = `${this.PORT_RANGE.MIN}-${this.PORT_RANGE.MAX}`),
              (this.SOURCE_PORT_RANGE_HELP_TEXT = `${this.translation.translate("Optional")} ${this.PORT_RANGE_HELP_TEXT}`),
              (this.destroyed = new de.t(1)),
              (this.sourcePool = new _.xR({
                destroyOn: (0, Oe.T)(this.destroyed, this.fortigateChanged),
              })),
              (this.policyLookupDataSubject = new he.X(null)),
              (this.policyLookupStateSubject = new he.X(m.$o.Lookup)),
              (this.recentLookupPoliciesSubject = new de.t(1)),
              (this.sourceConfigObs = this.fortigate.pipe(
                (0, ce.w)((B) =>
                  (0, d.mG)(this, void 0, void 0, function* () {
                    const k = {
                        pool: this.sourcePool,
                        variant: new gt.FirewallInterfacesOmniSourceVariant({
                          apiParams: { format: m.l_ },
                        }),
                      },
                      T = { pool: this.sourcePool, variant: B.getVariant() },
                      te = {
                        firewallInterface: this.interfaceFactory.create(k),
                        firewallPolicy: this.policyFactory.createSource(T),
                        proxyPolicy: this.proxyPolicyFactory.createSource(T),
                        localUser: this.localUserFactory.createSource(T),
                        ldapServer: this.ldapServerFactory.createSource(T),
                        webFilterProfile:
                          this.webFilterProfileFactory.createSource(T),
                        webFilterFtgdCat:
                          this.webFilterFtgdCatFactory.createSource(T),
                        webFilterFtgdLocalCat:
                          this.webFilterFtgdLocalCatFactory.createSource(T),
                        webFilterUrlFilter:
                          this.webFilterUrlFilterFactory.createSource(T),
                        vdomSource: B.createVdomSource(),
                      },
                      ee = yield this.getSelectSourcesConfigs(te);
                    return Object.assign({ sources: te }, ee);
                  }),
                ),
                (0, We.R)(this.destroyed),
                (0, ye.d)({ bufferSize: 1, refCount: !1 }),
              )),
              (this.guiFeatureVisibilityObs = this.fortigate.pipe(
                (0, ce.w)((B) =>
                  (0, d.mG)(this, void 0, void 0, function* () {
                    const [k, T] = yield Promise.all([
                      B.feature.featureVisible("ipv6"),
                      B.feature.featureVisible("implicit_policy"),
                    ]);
                    return { ipv6Enabled: k, guiImplicitVisible: T };
                  }),
                ),
                (0, ye.d)({ refCount: !0, bufferSize: 1 }),
              )),
              (this.isEnhancedLookupDisabled = this.fortigate.pipe(
                (0, ce.w)(() =>
                  (0, d.mG)(this, void 0, void 0, function* () {
                    return !!(yield ge.BUILD).CONFIG.CONFIG_RAM_2GB;
                  }),
                ),
                (0, ye.d)({ refCount: !0, bufferSize: 1 }),
              )),
              (this.ipVersionsObs = this.guiFeatureVisibilityObs.pipe(
                (0, Se.U)((B) =>
                  B.ipv6Enabled ? [m.IT.IPv4, m.IT.IPv6] : [m.IT.IPv4],
                ),
                (0, ye.d)({ refCount: !0, bufferSize: 1 }),
              )),
              (this.formObs = this.fortigate.pipe(
                (0, Se.U)(() => this.initializeForm()),
                (0, ye.d)({ refCount: !0, bufferSize: 1 }),
              )),
              (this.recentLookupPolicyKeyObs = this.fortigate.pipe(
                (0, ce.w)((B) =>
                  (0, d.mG)(this, void 0, void 0, function* () {
                    return `${yield B.admin.getAdminName()}:${B.vdom}:${m.R9}`;
                  }),
                ),
                (0, ye.d)({ refCount: !0, bufferSize: 1 }),
              )),
              (this.policyLookupIpVersionObs = this.formObs.pipe(
                (0, ce.w)((B) => this.getPolicyLookupIpVersionObs(B)),
                (0, ye.d)({ refCount: !0, bufferSize: 1 }),
              )),
              (this.visibilityObs = (0, Ee.a)([
                this.formObs,
                this.sourceConfigObs,
                this.isEnhancedLookupDisabled,
              ]).pipe(
                (0, ce.w)(([B, k, T]) =>
                  this.getVisibilityObservable(B, k.sources, T),
                ),
                (0, ye.d)({ refCount: !0, bufferSize: 1 }),
              )),
              (this.protocolObs = this.policyLookupIpVersionObs.pipe(
                (0, Se.U)((B) => this.getProtocols(B)),
                (0, ye.d)({ refCount: !0, bufferSize: 1 }),
              )),
              (this.trafficParamsObs = this.fortigate.pipe(
                (0, lt.V)(
                  this.sourceConfigObs,
                  this.formObs,
                  this.policyLookupDataSubject,
                ),
                (0, je.b)(0),
                (0, Se.U)(([B, k, T]) =>
                  this.getTrafficParams(T, {
                    [_.go]: B.vdom,
                    [_.Hx]: k.sources.vdomSource,
                  }),
                ),
                (0, ye.d)({ refCount: !0, bufferSize: 1 }),
              )),
              (this.loadRecentLookupPolicyInterfacesObs =
                this.recentLookupPoliciesSubject.pipe(
                  (0, lt.V)(this.sourceConfigObs),
                  (0, je.b)(0),
                  (0, ce.w)(([B, k]) =>
                    (0, d.mG)(this, void 0, void 0, function* () {
                      const T = [];
                      B.forEach((te) => {
                        var ee;
                        const ue =
                          null === (ee = te[m.Bd.IncomingInterface]) ||
                          void 0 === ee
                            ? void 0
                            : ee[_.go];
                        ue && T.push(ue);
                      });
                      try {
                        return (
                          yield k.sources.firewallInterface.load({ keys: T }),
                          !0
                        );
                      } catch (te) {
                        return !1;
                      }
                    }),
                  ),
                  (0, ye.d)({ refCount: !0, bufferSize: 1 }),
                  (0, We.R)(this.destroyed),
                )),
              (this.policyMatchDetailsObs = (0, Ee.a)([
                this.sourceConfigObs,
                this.policyLookupDataSubject,
                this.trafficParamsObs,
                this.guiFeatureVisibilityObs,
                this.isEnhancedLookupDisabled,
              ]).pipe(
                (0, je.b)(0),
                (0, ce.w)(([B, k, T, te, ee]) =>
                  (0, d.mG)(this, void 0, void 0, function* () {
                    return this.getPolicyMatchDetails(
                      te.guiImplicitVisible,
                      k,
                      T,
                      B.sources,
                      ee,
                    );
                  }),
                ),
                (0, ye.d)({ refCount: !0, bufferSize: 1 }),
              )),
              (this.ldapCustomFilter = []),
              (this.defaultKeyValueComparator = () => 0));
          }
          ngOnInit() {
            return (0, d.mG)(this, void 0, void 0, function* () {
              const t = yield this.getFormattedRecentLookupPolicies();
              this.recentLookupPoliciesSubject.next(t);
            });
          }
          ngOnDestroy() {
            (this.destroyed.next(), this.destroyed.complete());
          }
          getSelectSourcesConfigs(t) {
            return (0, d.mG)(this, void 0, void 0, function* () {
              const [i, n, l] = yield Promise.all([
                t.firewallInterface.adminHasWritePermission({
                  pathOverride: "system",
                  nameOverride: "interface",
                }),
                t.localUser.adminHasWritePermission(),
                t.ldapServer.adminHasWritePermission(),
              ]);
              return {
                interfaceSelectConfig: {
                  selectSettings: {
                    singleSelect: !0,
                    createNew: i,
                    inlineEdit: i,
                  },
                  selectSources: [
                    new Vt.NP({
                      source: t.firewallInterface,
                      filter: (g) => {
                        var h, P, N, L, J, Q;
                        return !(
                          "any" ===
                            (null === (h = g.data) || void 0 === h
                              ? void 0
                              : h.name) ||
                          null === (P = g.data) ||
                          void 0 === P ||
                          !P.valid_in_policy ||
                          (null !== (N = g.data) &&
                            void 0 !== N &&
                            N.is_zone) ||
                          (null !== (L = g.data) &&
                            void 0 !== L &&
                            L.is_sdwan_zone) ||
                          (null !== (J = g.data) &&
                            void 0 !== J &&
                            J.is_nat_tunnel) ||
                          (null !== (Q = g.data) &&
                            void 0 !== Q &&
                            Q.is_virtual_wire_pair_member)
                        );
                      },
                    }),
                  ],
                },
                userSelectConfig: {
                  selectSettings: {
                    singleSelect: !0,
                    createNew: n,
                    inlineEdit: n,
                  },
                  selectSources: [new ft.tU({ source: t.localUser })],
                },
                ldapServerSelectConfig: {
                  selectSettings: {
                    singleSelect: !0,
                    createNew: l,
                    inlineEdit: l,
                  },
                  selectSources: [new Bt.NJ({ source: t.ldapServer })],
                },
              };
            });
          }
          initializeForm() {
            return this.fb.group({
              [m.Bd.IPVersion]: this.fb.control(this.DEFAULT_IP_VERSION),
              [m.Bd.IncomingInterface]: this.fb.control(null, {
                validators: [S.kI.required],
              }),
              [m.Bd.Protocol]: this.fb.control(this.DEFAULT_PROTOCOL),
              [m.Bd.ProtocolNumber]: this.fb.control("", {
                validators: [
                  S.kI.required,
                  (0, qe.s)(this.PROTO_RANGE.MAX),
                  (0, He.R)(this.PROTO_RANGE.MIN),
                ],
              }),
              [m.Bd.ICMPType]: this.fb.control(m.P4.PingRequest, {
                validators: [S.kI.required],
              }),
              [m.Bd.ICMPTypeNumber]: this.fb.control(null, {
                validators: [
                  S.kI.required,
                  (0, qe.s)(this.PROTO_RANGE.MAX),
                  (0, He.R)(this.PROTO_RANGE.MIN),
                ],
              }),
              [m.Bd.ICMPCode]: this.fb.control(null, {
                validators: [
                  S.kI.required,
                  (0, qe.s)(this.PROTO_RANGE.MAX),
                  (0, He.R)(this.PROTO_RANGE.MIN),
                ],
              }),
              [m.Bd.SourceIP]: this.fb.control("", {
                validators: [
                  S.kI.required,
                  S.kI.pattern(this.neutrinoPatterns.IPV4_ADDRESS),
                ],
              }),
              [m.Bd.SourcePort]: this.fb.control("", {
                validators: [
                  (0, qe.s)(this.PORT_RANGE.MAX),
                  (0, He.R)(this.PORT_RANGE.MIN),
                ],
              }),
              [m.Bd.Destination]: this.fb.control("", {
                validators: [
                  S.kI.required,
                  (0, rt.b)([
                    this.fosPatterns.IPV4_ADDRESS,
                    this.fosPatterns.FQDN,
                  ]),
                ],
              }),
              [m.Bd.DestinationPort]: this.fb.control("", {
                validators: [
                  (0, qe.s)(this.PORT_RANGE.MAX),
                  (0, He.R)(this.PORT_RANGE.MIN),
                ],
              }),
              [m.Bd.UserType]: this.fb.control(m.dC.Any),
              [m.Bd.User]: this.fb.control(null),
              [m.Bd.LDAPServer]: this.fb.control(null),
              [m.Bd.CustomLDAPFilter]: this.fb.control({
                value: null,
                disabled: !0,
              }),
            });
          }
          getVisibilityObservable(t, i, n) {
            var l, a, s, u, g, h, P, N;
            const L =
                null === (l = t.get(m.Bd.Protocol)) || void 0 === l
                  ? void 0
                  : l.valueChanges.pipe(
                      (0, Ae.O)(
                        null === (a = t.get(m.Bd.Protocol)) || void 0 === a
                          ? void 0
                          : a.value,
                      ),
                      (0, Ge.x)(),
                      (0, Rt.b)((H) => {
                        var B, k;
                        H === m.b$.HTTP || H === m.b$.HTTPS
                          ? null === (B = t.get(m.Bd.DestinationPort)) ||
                            void 0 === B ||
                            B.setValue(m.W$[H])
                          : null === (k = t.get(m.Bd.DestinationPort)) ||
                            void 0 === k ||
                            k.reset();
                      }),
                    ),
              J =
                null === (s = t.get(m.Bd.UserType)) || void 0 === s
                  ? void 0
                  : s.valueChanges.pipe(
                      (0, Ae.O)(
                        null === (u = t.get(m.Bd.UserType)) || void 0 === u
                          ? void 0
                          : u.value,
                      ),
                      (0, Ge.x)(),
                    ),
              Q =
                null === (g = t.get(m.Bd.User)) || void 0 === g
                  ? void 0
                  : g.valueChanges.pipe(
                      (0, Ae.O)(
                        null === (h = t.get(m.Bd.User)) || void 0 === h
                          ? void 0
                          : h.value,
                      ),
                      (0, Ge.x)(),
                    ),
              j =
                null === (P = t.get(m.Bd.LDAPServer)) || void 0 === P
                  ? void 0
                  : P.valueChanges.pipe((0, Ae.O)([]), (0, Ge.x)()),
              K =
                null === (N = t.get(m.Bd.ICMPType)) || void 0 === N
                  ? void 0
                  : N.valueChanges.pipe(
                      (0, Ae.O)(t.get(m.Bd.ICMPType)),
                      (0, Ge.x)(),
                    );
            return L && J && Q && j && K
              ? (0, Ee.a)([L, J, Q, j, K]).pipe(
                  (0, je.b)(0),
                  (0, Se.U)(([H, B, k, T, te]) => {
                    var ee, ue, xe, se, we, Xe, et, pt;
                    const Ne = this.getDefaultVisibility();
                    if (
                      (this.setProtocolVisibilities(H, Ne),
                      (te === m.P4.PingRequest || te === m.P4.PingReply) &&
                        ((Ne.icmpTypeNumber = !1), (Ne.icmpCode = !1)),
                      !n)
                    )
                      switch (((Ne.userType = !0), B)) {
                        case m.dC.Any:
                          (null === (ee = t.get(m.Bd.User)) ||
                            void 0 === ee ||
                            ee.clearValidators(),
                            null === (ue = t.get(m.Bd.LDAPServer)) ||
                              void 0 === ue ||
                              ue.clearValidators());
                          break;
                        case m.dC.User:
                          if (
                            (null === (xe = t.get(m.Bd.User)) ||
                              void 0 === xe ||
                              xe.setValidators(S.kI.required),
                            null === (se = t.get(m.Bd.LDAPServer)) ||
                              void 0 === se ||
                              se.clearValidators(),
                            (Ne.user = !0),
                            k && k.length)
                          ) {
                            const Ze = k[0] || null;
                            if (
                              (null == Ze ? void 0 : Ze.isLdapUser()) &&
                              Ze.data
                            ) {
                              const ot = i.ldapServer.getEntry(
                                (0, X.xP)(Ze.data["ldap-server"]),
                              );
                              ot &&
                                (null === (we = t.get(m.Bd.LDAPServer)) ||
                                  void 0 === we ||
                                  we.patchValue([ot]));
                            }
                          }
                          break;
                        case m.dC.Group:
                          ((Ne.ldapServer = !0),
                            null === (Xe = t.get(m.Bd.LDAPServer)) ||
                              void 0 === Xe ||
                              Xe.setValidators(S.kI.required),
                            (Ne.customLdapFilter = !(
                              !Array.isArray(T) || !T.length
                            )));
                      }
                    for (const [Ze, ot] of Object.entries(Ne))
                      Ze !== m.Bd.CustomLDAPFilter && ot
                        ? null === (et = t.get(Ze)) ||
                          void 0 === et ||
                          et.enable()
                        : null === (pt = t.get(Ze)) ||
                          void 0 === pt ||
                          pt.disable();
                    return Ne;
                  }),
                  (0, We.R)(this.destroyed),
                )
              : (M.cM.error("Form observables not available"),
                (0, ke.of)(this.getDefaultVisibility()));
          }
          setProtocolVisibilities(t, i) {
            switch (t) {
              case m.b$.HTTP:
              case m.b$.HTTPS:
              case m.b$.TCP:
              case m.b$.UDP:
              case m.b$.SCTP:
                ((i.sourceIp = !0),
                  (i.sourcePort = !0),
                  (i.destination = !0),
                  (i.destinationPort = !0));
                break;
              case m.b$.ICMP:
              case m.b$.ICMP6:
                ((i.sourceIp = !0),
                  (i.destination = !0),
                  (i.icmpType = !0),
                  (i.icmpTypeNumber = !0),
                  (i.icmpCode = !0));
                break;
              case m.b$.OTHER:
                ((i.protocolNumber = !0),
                  (i.sourcePort = !0),
                  (i.sourceIp = !0),
                  (i.destination = !0),
                  (i.destinationPort = !0));
            }
          }
          getPolicyLookupIpVersionObs(t) {
            var i, n;
            const l =
              null === (i = t.get(m.Bd.IPVersion)) || void 0 === i
                ? void 0
                : i.valueChanges.pipe(
                    (0, Ae.O)(
                      (null === (n = t.get(m.Bd.IPVersion)) || void 0 === n
                        ? void 0
                        : n.value) || this.DEFAULT_IP_VERSION,
                    ),
                    (0, Ge.x)(),
                  );
            return l
              ? l.pipe(
                  (0, Se.U)((a) => {
                    var s, u;
                    const g =
                      a === m.IT.IPv6
                        ? this.neutrinoPatterns.IPV6_ADDRESS
                        : this.neutrinoPatterns.IPV4_ADDRESS;
                    (null === (s = t.get(m.Bd.SourceIP)) ||
                      void 0 === s ||
                      s.setValidators([S.kI.required, S.kI.pattern(g)]),
                      null === (u = t.get(m.Bd.Destination)) ||
                        void 0 === u ||
                        u.setValidators([
                          S.kI.required,
                          (0, rt.b)([
                            g,
                            this.fosPatterns.FQDN_WITH_COMPLEX_PATHS,
                          ]),
                        ]));
                    const h = t.get(m.Bd.Protocol),
                      P = null == h ? void 0 : h.value;
                    return (
                      a === m.IT.IPv6 && P === m.b$.ICMP
                        ? null == h || h.patchValue(m.b$.ICMP6)
                        : a === m.IT.IPv4 &&
                          P === m.b$.ICMP6 &&
                          (null == h || h.patchValue(m.b$.ICMP)),
                      null != a ? a : this.DEFAULT_IP_VERSION
                    );
                  }),
                )
              : (M.cM.error("Form observable not available"),
                (0, ke.of)(this.DEFAULT_IP_VERSION));
          }
          getProtocols(t) {
            return this.BASE_PROTOCOLS.concat(
              t === m.IT.IPv6
                ? [m.b$.ICMP6, m.b$.OTHER]
                : [m.b$.ICMP, m.b$.OTHER],
            );
          }
          getDefaultVisibility() {
            return {
              protocolNumber: !1,
              sourceIp: !1,
              sourcePort: !1,
              destination: !1,
              destinationPort: !1,
              icmpType: !1,
              icmpTypeNumber: !1,
              icmpCode: !1,
              userType: !1,
              user: !1,
              ldapServer: !1,
              customLdapFilter: !1,
            };
          }
          getPolicyLookupRequestParams(t, i) {
            var n, l, a, s;
            return (0, d.mG)(this, void 0, void 0, function* () {
              const u = t.value,
                g = u[m.Bd.IPVersion] === m.IT.IPv6,
                h = u[m.Bd.Protocol] === m.b$.OTHER,
                N = u[m.Bd.ICMPType],
                L = {
                  ipv6: g,
                  srcintf: u[m.Bd.IncomingInterface][0][_.go] || "",
                  protocol: h
                    ? u[m.Bd.ProtocolNumber]
                    : u[m.Bd.Protocol] === m.b$.HTTP ||
                        u[m.Bd.Protocol] === m.b$.HTTPS ||
                        u[m.Bd.Protocol] === m.b$.TCP
                      ? m.b$.TCP
                      : u[m.Bd.Protocol],
                  dest: u[m.Bd.Destination],
                };
              if (
                ((yield (0, be.z)(this.isEnhancedLookupDisabled)) ||
                  (L.policy_type = "policy"),
                u[m.Bd.SourcePort] &&
                  (L.sourceport = Number(u[m.Bd.SourcePort])),
                u[m.Bd.SourceIP] && (L.sourceip = u[m.Bd.SourceIP]),
                h
                  ? (L.destport = 0)
                  : u[m.Bd.DestinationPort] &&
                    (L.destport = Number(u[m.Bd.DestinationPort])),
                N === m.P4.Other
                  ? ((L.icmptype = Number(u[m.Bd.ICMPTypeNumber])),
                    (L.icmpcode = Number(u[m.Bd.ICMPCode])))
                  : (N === m.P4.PingReply || N === m.P4.PingRequest) &&
                    Object.assign(
                      L,
                      Object.assign(
                        {},
                        g ? this.ICMP6_PRESET[N] : this.ICMP_PRESET[N],
                      ),
                    ),
                i.userType)
              ) {
                if (u[m.Bd.UserType] === m.dC.Any) return L;
                if (u[m.Bd.UserType] === m.dC.User) {
                  const Q =
                    null === (n = u[m.Bd.User]) || void 0 === n ? void 0 : n[0];
                  Q instanceof ft.eH &&
                    ((L.auth_type = m.Gr.User),
                    (L.user_group = (0, X.xP)(Q.data)),
                    Q.isLdapUser() &&
                      Q.data &&
                      (L.server_name = (0, X.xP)(Q.data["ldap-server"])));
                } else {
                  ((L.auth_type = m.Gr.Group),
                    (L.user_group = this.ldapCustomFilter));
                  const Q =
                    null ===
                      (a =
                        null === (l = t.get(m.Bd.LDAPServer)) || void 0 === l
                          ? void 0
                          : l.value) || void 0 === a
                      ? void 0
                      : a[0];
                  Q && (L.server_name = (0, X.xP)(Q.data));
                }
                if (
                  (null == L ? void 0 : L.auth_type) === m.Gr.Group &&
                  (null === (s = L.user_group) || void 0 === s || !s.length)
                )
                  try {
                    (yield this.prompt.confirm(m.R7, p.P7.Warning, {
                      okButtonLabel: this.translation.translate("Confirm"),
                    }),
                      delete L.auth_type,
                      delete L.user_group,
                      delete L.server_name);
                  } catch (Q) {
                    return null;
                  }
              }
              return L;
            });
          }
          saveRecentLookupPolicy(t) {
            return (0, d.mG)(this, void 0, void 0, function* () {
              const [i, n] = yield Promise.all([
                  (0, be.z)(this.recentLookupPolicyKeyObs),
                  this.getRecentLookupPolicies(),
                ]),
                l = {};
              for (const s of Object.keys(m.Bd)) {
                const u = t.value[m.Bd[s]],
                  g = m.Bd[s];
                Object.assign(l, {
                  [g]:
                    Array.isArray(u) &&
                    u.length &&
                    (g === m.Bd.IncomingInterface ||
                      g === m.Bd.User ||
                      g === m.Bd.LDAPServer)
                      ? u[0][_.go]
                      : u,
                });
              }
              (this.ldapCustomFilter.length &&
                Object.assign(l, {
                  [m.Bd.CustomLDAPFilter]: this.ldapCustomFilter,
                }),
                n.length === m.em && n.pop(),
                n.unshift(l),
                localStorage.setItem(i, JSON.stringify(n)));
              const a = yield this.getFormattedRecentLookupPolicies();
              this.recentLookupPoliciesSubject.next(a);
            });
          }
          getRecentLookupPolicies() {
            return (0, d.mG)(this, void 0, void 0, function* () {
              const t = yield (0, be.z)(this.recentLookupPolicyKeyObs),
                i = localStorage.getItem(t);
              return i ? JSON.parse(i) : [];
            });
          }
          getFormattedRecentLookupPolicies() {
            return (0, d.mG)(this, void 0, void 0, function* () {
              const [t, i] = yield Promise.all([
                this.getRecentLookupPolicies(),
                (0, be.z)(this.sourceConfigObs),
              ]);
              return t.map(
                (n) => (
                  n[m.Bd.IncomingInterface] &&
                    (n[m.Bd.IncomingInterface] = {
                      [_.go]: n[m.Bd.IncomingInterface],
                      [_.Hx]: i.sources.firewallInterface,
                    }),
                  n[m.Bd.User] &&
                    (n[m.Bd.User] = {
                      [_.go]: n[m.Bd.User],
                      [_.Hx]: i.sources.localUser,
                    }),
                  n[m.Bd.LDAPServer] &&
                    (n[m.Bd.LDAPServer] = {
                      [_.go]: n[m.Bd.LDAPServer],
                      [_.Hx]: i.sources.ldapServer,
                    }),
                  n
                ),
              );
            });
          }
          populateMatchDetailsResult(t, i, n, l, a) {
            var s, u, g, h;
            return (0, d.mG)(this, void 0, void 0, function* () {
              const P = { isTpLookup: !a && null != i.proxy_policy_id },
                N = String(i.policy_id);
              yield l.firewallPolicy.load({ keys: [N] });
              const L = l.firewallPolicy.getEntry(N),
                J = i.webfilter_profile,
                Q = i.urlf_entry_id,
                j = i.webfilter_category;
              if (L) {
                let K;
                if (
                  ((P.policy = L),
                  i.policy_action && (P.policyAction = i.policy_action),
                  !a && i.proxy_policy_id)
                ) {
                  const H = String(i.proxy_policy_id);
                  (yield l.proxyPolicy.load({ keys: [H] }),
                    (K = l.proxyPolicy.getEntry(H)),
                    K && (P.proxyPolicy = K));
                }
                if (!a && J) {
                  yield l.webFilterProfile.load({ keys: [J] });
                  const H = l.webFilterProfile.getEntry(J);
                  if (H) {
                    if (
                      ((P.webFilterProfile = H),
                      i.webfilter_action &&
                        (P.webFilterAction = i.webfilter_action),
                      Q)
                    ) {
                      const B =
                          null === (s = H.data) || void 0 === s
                            ? void 0
                            : s.web["urlfilter-table"],
                        k = (0, X.xP)(B);
                      yield l.webFilterUrlFilter.load({ keys: [k] });
                      const T =
                        null ===
                          (h =
                            null ===
                              (g =
                                null === (u = l.webFilterUrlFilter) ||
                                void 0 === u
                                  ? void 0
                                  : u.getEntry(k)) || void 0 === g
                              ? void 0
                              : g.data) || void 0 === h
                          ? void 0
                          : h.entries.find((te) => te.id === Q);
                      P.webFilterStaticUrl = null == T ? void 0 : T.url;
                    }
                    if (j) {
                      const B = String(j);
                      yield Promise.all([
                        l.webFilterFtgdCat.load({ keys: [B] }),
                        l.webFilterFtgdLocalCat.load({ keys: [B] }),
                      ]);
                      const k =
                        l.webFilterFtgdCat.getEntry(B) ||
                        l.webFilterFtgdLocalCat.getEntry(B);
                      k && (P.webFilterCategory = k);
                    }
                  }
                }
                !a &&
                  i.remote_groups &&
                  (P.remoteGroups = i.remote_groups.filter(
                    (H) => H.split(",").length > 1,
                  ));
              } else
                !t && n.sourceIp && n.destination
                  ? (P.errorMessage = this.translation.translate(
                      "No explicit policy exists from source {0} to destination {1}. Traffic is implicitly denied.",
                      [n.sourceIp, n.destination],
                    ))
                  : (P.policy = me.j.generateImplicitPolicy(l.firewallPolicy));
              return (
                i.sec_default_action &&
                  (P.defaultFirewallPolicyAction = i.sec_default_action),
                P
              );
            });
          }
          getPolicyMatchDetails(t, i, n, l, a) {
            return (0, d.mG)(this, void 0, void 0, function* () {
              const s = { isTpLookup: !1 };
              if (!i)
                return (
                  (s.errorMessage = this.translation.translate(
                    "Missing policy lookup response",
                  )),
                  s
                );
              if (i.success)
                return this.populateMatchDetailsResult(t, i, n, l, a);
              if (i.error_code)
                switch (i.error_code) {
                  case "error_unresolved_dns":
                    s.errorMessage = this.translation.translate(
                      "Failed to resolve FQDN",
                    );
                    break;
                  case "error_unknown_source_route":
                    s.errorMessage = this.translation.translate(
                      "No route exists from source address {0}",
                      [n.sourceIp || ""],
                    );
                    break;
                  case "error_unknown_route":
                    s.errorMessage = this.translation.translate(
                      "No route exists to the destination {0}",
                      [n.destination || ""],
                    );
                    break;
                  default:
                    s.errorMessage = this.translation.translate(
                      "Policy match failed due to internal error",
                    );
                }
              return s;
            });
          }
          getTrafficParams(t, i) {
            const n = {},
              l = t.value;
            for (const [a, s] of Object.entries(l))
              if (s) {
                const u = Array.isArray(s) && s.length ? s[0] : s;
                Object.assign(n, { [a]: u });
              }
            return (
              n.ldapServer && (n.customLdapFilter = this.ldapCustomFilter),
              i && (n.vdomEntryRef = i),
              n
            );
          }
          lookupPolicy(t, i, n) {
            (t.preventParentSlideSubmission(),
              t.resolve(
                (() =>
                  (0, d.mG)(this, void 0, void 0, function* () {
                    const l = yield this.getPolicyLookupRequestParams(i, n);
                    if (!l) return;
                    const a = {};
                    let s = "GET";
                    l.auth_type === m.Gr.Group &&
                      Array.isArray(l.user_group) &&
                      ((s = "POST"),
                      (a.body = { user_group: l.user_group }),
                      (a.headers = new C.WM({
                        "X-HTTP-Method-Override": "GET",
                      })),
                      delete l.user_group);
                    try {
                      const u = yield (0, De.n)(
                        this.http.request(
                          s,
                          m.pj,
                          Object.assign(Object.assign({}, a), {
                            params: new C.LE({
                              fromObject: Object.assign({}, l),
                            }),
                          }),
                        ),
                      );
                      (yield this.saveRecentLookupPolicy(i),
                        this.policyLookupStateSubject.next(m.$o.Match),
                        this.policyLookupDataSubject.next(u.results));
                    } catch (u) {
                      return (
                        M.cM.error(u),
                        this.notify.error(
                          this.translation.translate(
                            "Unable to find the matching policy given the provided information.",
                          ),
                        ),
                        Promise.reject(u)
                      );
                    }
                  }))(),
              ));
          }
          slideSubmitting() {}
          goBack() {
            this.policyLookupStateSubject.next(m.$o.Lookup);
          }
          editPolicy(t) {
            return null == t ? void 0 : t.edit();
          }
          showInList(t) {
            this.router.navigate([m.ZC], {
              queryParams: {
                showInList: JSON.stringify({
                  q_origin_key: (0, X.xP)(null == t ? void 0 : t.data),
                }),
              },
            });
          }
          browseLdapFilters(t) {
            var i;
            try {
              this.slideBridge
                .ngOpen({
                  params: {
                    template:
                      '<f-ldap-browser-dialog\n                          server-params="serverParams"\n                          ldap-server="ldapServer"\n                          tabs="tabs">\n                      </f-ldap-browser-dialog>',
                    parentScope: {
                      serverParams: { fortigate: this.selectedFortigate },
                      ldapServer:
                        null === (i = t.get(m.Bd.LDAPServer)) || void 0 === i
                          ? void 0
                          : i.value[0],
                      tabs: ["GROUPS"],
                    },
                    options: {
                      title: this.translation
                        .translate("User Group Match")
                        .toString(),
                      fullHeight: !0,
                      buttons: !1,
                    },
                  },
                  css: ["ng/components/ldap/f-ldap-browser.css"],
                  initModules: [
                    "ng/components/ldap/f-ldap-browser",
                    "ng/components/ldap/f-ldap-browser-dialog",
                  ],
                })
                .then((n) => {
                  Array.isArray(n) && this.formatCustomLdapFilter(t, n);
                });
            } catch (n) {}
          }
          clearRecentLookupPolicies() {
            return (0, d.mG)(this, void 0, void 0, function* () {
              const t = yield (0, be.z)(this.recentLookupPolicyKeyObs);
              (this.recentLookupPoliciesSubject.next([]),
                localStorage.removeItem(t));
            });
          }
          getRecentPolicyInterfaceEntry(t, i) {
            var n, l;
            return i.getEntry(
              null !==
                (l =
                  null === (n = t[m.Bd.IncomingInterface]) || void 0 === n
                    ? void 0
                    : n[_.go]) && void 0 !== l
                ? l
                : "",
            );
          }
          getRecentPolicyAddressLabel(t) {
            var i, n, l, a, s, u;
            return (
              (t.sourcePort
                ? `From ${null !== (i = t.sourceIp) && void 0 !== i ? i : ""}:${null !== (n = t.sourcePort) && void 0 !== n ? n : ""} `
                : `From ${null !== (l = t.sourceIp) && void 0 !== l ? l : ""} `) +
              (t.destinationPort
                ? `to ${null !== (a = t.destination) && void 0 !== a ? a : ""}:${null !== (s = t.destinationPort) && void 0 !== s ? s : ""}`
                : `to ${null !== (u = t.destination) && void 0 !== u ? u : ""}`)
            );
          }
          populateRecentPolicy(t, i, n) {
            return (0, d.mG)(this, void 0, void 0, function* () {
              t.preventDefault();
              const { sources: l } = yield (0, be.z)(this.sourceConfigObs);
              for (const a of Object.keys(n)) {
                const s = n[a],
                  u = i.get(a);
                switch (a) {
                  case m.Bd.IncomingInterface:
                    if ("object" == typeof s && !Array.isArray(s) && s[_.go]) {
                      const g = l.firewallInterface.getEntry(s[_.go]);
                      null == u || u.patchValue([g]);
                    }
                    break;
                  case m.Bd.User:
                    if ("object" == typeof s && !Array.isArray(s) && s[_.go]) {
                      l.localUser.sourceFullyLoaded ||
                        (yield l.localUser.load({ keys: [s[_.go]] }));
                      const g = l.localUser.getEntry(s[_.go]);
                      null == u || u.patchValue([g]);
                    }
                    break;
                  case m.Bd.LDAPServer:
                    if ("object" == typeof s && !Array.isArray(s) && s[_.go]) {
                      l.ldapServer.sourceFullyLoaded ||
                        (yield l.ldapServer.load({ keys: [s[_.go]] }));
                      const g = l.ldapServer.getEntry(s[_.go]);
                      null == u || u.patchValue([g]);
                    }
                    break;
                  case m.Bd.CustomLDAPFilter:
                    Array.isArray(s) && this.formatCustomLdapFilter(i, s);
                    break;
                  default:
                    null == u || u.patchValue(s);
                }
              }
            });
          }
          formatCustomLdapFilter(t, i) {
            var n;
            if (((this.ldapCustomFilter = i), i.length)) {
              let l = "";
              (i.forEach((a) => {
                l += `"${a}",`;
              }),
                null === (n = t.get(m.Bd.CustomLDAPFilter)) ||
                  void 0 === n ||
                  n.patchValue(l.substring(0, l.length - 1)));
            }
          }
        }
        return (
          (r.ɵfac = function (t) {
            return new (t || r)(
              e.Y36(S.qu),
              e.Y36(w.Router),
              e.Y36(G.D7),
              e.Y36(C.eN),
              e.Y36(at.lK),
              e.Y36(Qe.Cq),
              e.Y36(Jt.SlideBridgeHostService),
              e.Y36(kt.FirewallInterfacesOmniSourceFactoryService),
              e.Y36(Qt.PolicySourceFactoryService),
              e.Y36(Yt.ProxyPolicyOmniSourceFactoryService),
              e.Y36(Kt.UserLocalOmniSourceFactoryService),
              e.Y36(Wt.UserLdapOmniSourceFactoryService),
              e.Y36(jt.WebFilterProfileOmniSourceFactoryService),
              e.Y36(qt.WebfilterFtgdCatSourceFactoryService),
              e.Y36(Ht.WebfilterFtgdLocalCatSourceFactoryService),
              e.Y36(ti),
              e.Y36($.o6, 8),
            );
          }),
          (r.ɵcmp = e.Xpm({
            type: r,
            selectors: [["fos-policy-lookup-slidein-dialog"]],
            features: [e.qOj],
            decls: 2,
            vars: 3,
            consts: [
              [4, "ngIf"],
              [
                3,
                "dialogTitle",
                "form",
                "formTabLabelLangKey",
                "gutterTabLabelLangKey",
                "dialogSubmitting",
                4,
                "ngIf",
              ],
              [
                3,
                "dialogTitle",
                "form",
                "formTabLabelLangKey",
                "gutterTabLabelLangKey",
                "dialogSubmitting",
              ],
              [3, "formGroup"],
              ["class", "back-btn", 3, "click", 4, "ngIf"],
              ["nuDialogSectionContent", ""],
              [3, "nuFor"],
              [3, "formControlName"],
              ["protocol", ""],
              [3, "value", 4, "ngFor", "ngForOf"],
              [3, "formControlName", "sources", "settings"],
              ["incomingInterface", ""],
              [3, "value"],
              [3, "errorMessages"],
              ["type", "number", 3, "formControlName", "placeholder"],
              ["protocolNumber", ""],
              [1, "nu-child-label", 3, "nuFor"],
              ["icmpType", ""],
              ["icmpCode", ""],
              ["type", "text", 3, "formControlName", "placeholder"],
              ["sourceIp", ""],
              ["sourcePort", ""],
              [3, "formControlName", "sources", "settings", 4, "ngIf"],
              [1, "ldap-filter"],
              [1, "browse-button", 3, "click"],
              ["destination", ""],
              ["destinationPort", ""],
              [3, "type", "label"],
              [
                1,
                "nu-table",
                "nu-table-key-value",
                "nu-table-slightly-condensed",
                "traffic-params-table",
              ],
              [3, "entry"],
              [4, "ngFor", "ngForOf"],
              [3, "label"],
              ["class", "nu-warning-message", 4, "ngIf"],
              [
                "class",
                "nu-table nu-table-bordered nu-table-key-value-with-header policy-details-table",
                4,
                "ngIf",
              ],
              [1, "nu-warning-message"],
              [3, "icon"],
              [1, "message-content"],
              [
                1,
                "nu-table",
                "nu-table-bordered",
                "nu-table-key-value-with-header",
                "policy-details-table",
              ],
              ["colspan", "2", 1, "policy-details-table-header-container"],
              [1, "policy-details-table-header-content"],
              [1, "policy-details-table-header-icon", 3, "icon", "size"],
              [1, "policy-details-table-header-text"],
              ["class", "policy-details-table-policy-redirect", 4, "ngIf"],
              [
                "class",
                "policy-details-table-default-policy-action",
                4,
                "ngIf",
              ],
              ["fgtDefaultPolicyActionTooltip", ""],
              [1, "policy-details-table-policy-redirect"],
              [1, "policy-details-table-default-policy-action"],
              [1, "nu-tooltip-hint", 3, "nuTip"],
              [1, "policy-details-table-webfilter-profile"],
              ["class", "policy-details-table-webfilter-info", 4, "ngIf"],
              [1, "policy-details-table-webfilter-info"],
              [3, "icon", 4, "ngIf"],
              ["colspan", "2"],
              ["type", "button", 3, "click"],
              [1, "back-btn", 3, "click"],
              ["nuDialogAsideSectionLabel", ""],
              ["nuDialogAsideSectionContent", ""],
              [1, "clear-history-icon", 3, "icon", "nuTip", "click"],
              ["clearHistoryTip", ""],
              [1, "gutter-recent-policies"],
              ["class", "gutter-recent-policies-item", 4, "ngFor", "ngForOf"],
              [1, "gutter-recent-policies-item"],
              ["href", "#", 3, "click", 4, "ngIf"],
              ["href", "#", 3, "click"],
            ],
            template: function (t, i) {
              (1 & t &&
                (e.YNc(0, vn, 3, 3, "ng-container", 0), e.ALo(1, "async")),
                2 & t && e.Q6J("ngIf", e.lcZ(1, 1, i.sourceConfigObs)));
            },
            dependencies: [
              D._g,
              O.sg,
              O.O5,
              I.au,
              I.Jw,
              I.gr,
              I.JQ,
              I.CK,
              I.TC,
              I.mN,
              I.CF,
              I.VX,
              I.SM,
              I.DX,
              x.wT,
              x.CO,
              x.yc,
              S._Y,
              S.YN,
              S.Kr,
              S.Fj,
              S.wV,
              S.EJ,
              S.JJ,
              S.JL,
              S.sg,
              S.u,
              _.ad,
              _.YI,
              A.lD,
              f.oJ,
              O.Ov,
              O.Nd,
              Re.X,
            ],
            styles: [
              ".ldap-filter[_ngcontent-%COMP%]{width:50%}.traffic-params-table[_ngcontent-%COMP%]{width:45%}.policy-details-table[_ngcontent-%COMP%]{width:90%}.policy-details-table-header-container[_ngcontent-%COMP%]{padding-left:0}.policy-details-table-header-content[_ngcontent-%COMP%]{display:flex;align-items:center}.policy-details-table-header-icon[_ngcontent-%COMP%]{padding:0 .5em;display:inline-flex}.policy-details-table-header-text[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:flex-start}.policy-details-table-header-text[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%]{margin:.2em 0}.policy-details-table-policy-redirect[_ngcontent-%COMP%] > td[_ngcontent-%COMP%], .policy-details-table-webfilter-profile[_ngcontent-%COMP%] > td[_ngcontent-%COMP%], .policy-details-table-webfilter-info[_ngcontent-%COMP%] > td[_ngcontent-%COMP%]{background-color:rgb(var(--nu-theme-override-table-striped-background, var(--nu-theme-color-background-level2)))}.policy-details-table-webfilter-info[_ngcontent-%COMP%] > td[_ngcontent-%COMP%]:first-child{padding-left:2em}.gutter-recent-policies[_ngcontent-%COMP%]{display:flex;flex-direction:column}.gutter-recent-policies-item[_ngcontent-%COMP%]{margin-bottom:.75em}[_nghost-%COMP%]     nu-dialog nu-dialog-submit-button button{min-width:13em!important}",
            ],
          })),
          r
        );
      })();
      var Ve = c(70355),
        hn = c(77579),
        bn = c(32966),
        V = c(78089),
        ie = c(13801),
        Sn = c(24934),
        st = c(89179),
        pe = c(74042),
        re = c(81207),
        fe = c(89075),
        Pn = c(70092),
        Tn = c(30230),
        Cn = c(57407),
        ct = c(90117),
        ht = c(55377),
        oe = c(19331),
        Te = c(23021),
        xn = c(94761);
      const bt = {
        key: "NOT_APPLICABLE_FILTER_KEY",
        pattern: "NOT_APPLICABLE_FILTER_PATTERN",
      };
      class St extends xn.o {
        getAndProcessStats(o) {
          return (0, d.mG)(this, void 0, void 0, function* () {
            const { filters: t } = this.getFilterProcessResult(o.filters);
            return this.sources[0].getStats(
              Object.assign(Object.assign({}, o), { filters: t }),
            );
          });
        }
        getSourceLoadParams(o) {
          const t = this.getFilterProcessResult(o.filters);
          return {
            skipEntryFetch: t.skipEntryFetch,
            params: Object.assign(Object.assign({}, o), t),
          };
        }
        getFilterProcessResult(o = []) {
          const t = structuredClone(o),
            i = [];
          let n = !1;
          for (const l of t) {
            const a = this.processColumnFilterGroup(l);
            if (a.notApplicable) {
              n = !0;
              break;
            }
            a.processedColumnFilters.length &&
              i.push(
                Object.assign(Object.assign({}, l), {
                  filters: a.processedColumnFilters,
                }),
              );
          }
          return n
            ? { filters: i, skipEntryFetch: n }
            : this.processFiltersForSource({ filters: i });
        }
        processColumnFilterGroup(o) {
          let t = [],
            i = !1,
            n = !1;
          for (const l of o.filters) {
            const a = this.processFilterPerColumn(l);
            if (a.notApplicable) {
              if (o.logic === p.tk.And) {
                n = !0;
                break;
              }
              if (i) continue;
              ((i = !0), t.push(Object.assign(Object.assign({}, l), bt)));
            } else t = t.concat(a.filter);
          }
          return (
            !n &&
              1 === t.length &&
              t[0].key === bt.key &&
              !t[0].negate &&
              (n = !0),
            { notApplicable: n, processedColumnFilters: t }
          );
        }
        processFilterPerColumn(o) {
          return { filter: o };
        }
        processFiltersForSource(o) {
          return o;
        }
      }
      var Pt = c(52579),
        Tt = c(27110),
        Mn = c(18125),
        In = c(79056),
        tt = c(51620),
        ve = c(40300),
        Ye = (() => {
          return (
            ((r = Ye || (Ye = {})).Before = "Before"),
            (r.After = "After"),
            Ye
          );
          var r;
        })();
      function ut(r, o, t) {
        return (0, d.mG)(this, void 0, void 0, function* () {
          !r.data ||
            ((r.data["global-label"] = o),
            yield r.save({ skipChangeSummary: t }));
        });
      }
      function ze(r, o) {
        var t;
        return (0, d.mG)(this, void 0, void 0, function* () {
          if (!o.data)
            return { success: !1, errorMsg: "Missing data in policy entry." };
          const i =
            null !== (t = o.data["global-label"]) && void 0 !== t ? t : "";
          let l = o.new;
          return (
            (o.new = !1),
            yield ut(o, "", !0),
            (o.new = l),
            (l = r.new),
            r.data && ((r.new = !1), yield ut(r, i, !0), (r.new = l)),
            { success: !0 }
          );
        });
      }
      function Ct(r, o, t, i, n) {
        return (0, d.mG)(this, void 0, void 0, function* () {
          if (
            !(
              (r[_.Hx] instanceof pe.m || r[_.Hx] instanceof ve.u) &&
              (o[_.Hx] instanceof pe.m || o[_.Hx] instanceof ve.u) &&
              r.data &&
              o
            )
          )
            return {
              success: !1,
              errorMsg: "Valid policy or security policy entry is expected.",
            };
          if (i && !n)
            return {
              success: !1,
              errorMsg:
                "Leading policies should be provided if sequence grouping needs to be handled.",
            };
          const l = i && n && n.has(parseInt(o[_.go], 10)),
            a = i && n && n.has(parseInt(r[_.go], 10));
          if (t === Ye.Before) {
            if ((yield r.moveBefore(o[_.go]), l)) return ze(r, o);
          } else {
            const s = r[_.go];
            if (a && r.data["global-label"]) {
              const u = yield r[_.Hx].getPolicyGroupLabelInfo(s);
              if (!u)
                return {
                  success: !1,
                  errorMsg: `Unable parse sequence group info of policy ${s}.`,
                };
              const g = u.startIndexOfGroup,
                P = (yield r[_.Hx].getTargetGroupPolicyInfo(
                  [u.groupLabel],
                  g,
                )).at(1);
              if (P) {
                const N = yield r[_.Hx].load({ keys: [String(P.policyid)] });
                if (Array.isArray(N)) {
                  const L = N[0];
                  yield ze(L, r);
                }
              }
            }
            yield r.moveAfter(o[_.go]);
          }
          return { success: !0 };
        });
      }
      const On = new Set([
        "av-profile",
        "emailfilter-profile",
        "webfilter-profile",
        "videofilter-profile",
        "dlp-profile",
        "file-filter-profile",
        "dnsfilter-profile",
        "waf-profile",
        "application-list",
        "ips-sensor",
        "icap-profile",
        "voip-profile",
        "profile-group",
        "profile",
        "virtual-patch-profile",
        "casb-profile",
      ]);
      class xt {
        hasInternetService(o) {
          return o.some(oe.uE);
        }
        hasInternetService6(o) {
          return o.some(oe.hm);
        }
        hasIpPool(o) {
          return o.some((t) => t instanceof Mn.B || t instanceof In.X);
        }
        copyEntry(o) {
          o.disableDynamicUpdate();
          const t = o.clone();
          return (t.initializeForEditing(), t);
        }
        updateDependencyData(o, t, i) {
          if (
            (On.has(t) && o.updateUtmStatus(t, i),
            "ztna-status" === t && "disable" === i && o.resetZtnaTags(),
            "ztna-ems-tag" === t && !o.hasZtnaTags() && o.resetZtnaTags(),
            "consolidated-source" === t || "consolidated-destination" === t)
          ) {
            const n = Array.from(i.entryMap.values()),
              l = Pt.g.hasInternetService(n),
              a = Pt.g.hasInternetService6(n),
              s = n.some((g) => Tt.ZX.has(g[_.Hx].datasource)),
              u = n.some((g) => Tt.hn.has(g[_.Hx].datasource));
            if (
              (o.toggleInternetServiceStatus(
                "consolidated-source" === t ? tt.a7.Source : tt.a7.Destination,
                l,
                a,
              ),
              "consolidated-destination" === t && o.data)
            ) {
              const h = (s || u) && (l || a) && !o.data.service.length;
              (!l && !a && !o.data.service.length) || h
                ? o.setDefaultService()
                : !s && !u && (o.data.service = []);
            }
          }
          if (
            (("consolidated-source" === t ||
              "consolidated-srcaddr" === t ||
              "consolidated-destination" === t ||
              "consolidated-dstaddr" === t) &&
              (o.isNat46Enabled()
                ? o.setDefaultAddressForNat46Policy()
                : o.isNat64Enabled() && o.setDefaultAddressForNat64Policy()),
            this instanceof Me && "consolidated-poolname" === t)
          ) {
            const n = Array.from(i.entryMap.values());
            this.hasIpPool(n) && o.enableIpPool();
          }
          ("service" === t && "disable" === i && o.setDefaultService(),
            "nat" === t && o.prepareCmdbDataForMutableNatInlineEdit(i),
            "consolidated-poolname" === t &&
              i.entryMap instanceof Map &&
              o.prepareCmdbDataForMutablePoolnameInlineEdit(
                i.entryMap.size > 0,
              ),
            o instanceof me.j &&
              o.data &&
              "action" === t &&
              ("accept" === i || "deny" === i) &&
              (o.data.vpntunnel = ""));
        }
        getBasicFilter(o) {
          return { filter: o };
        }
        processIntfPairFilters(o) {
          const t = this.getBasicFilter(o);
          return (o.pattern === oe.oT && (t.notApplicable = !0), t);
        }
        processSequenceGroupingFilters(o) {
          const t = this.getBasicFilter(o);
          return (o.pattern === oe.oT && (t.notApplicable = !0), t);
        }
        processFiltersForSequenceGroup(o) {
          let t,
            i,
            n = "contains",
            l = "exact";
          const a = [];
          let s = 0,
            u = "";
          for (const g of o.filters) {
            for (const h of g.filters)
              if ("global-label" === h.key) {
                const P = String(h.pattern);
                if (
                  (h.operator === p.pg.Contains && !t && ((t = g), (n = P)),
                  h.operator === p.pg.Exact && !i)
                ) {
                  l = P;
                  const { parsedGroupLabel: N, skipTo: L } = (0, oe.dh)(P);
                  ((h.pattern = N), (u = P), (s = L), (i = g));
                }
              }
            g !== t && g !== i && a.push(g);
          }
          if (1 === o.filters.length)
            return (
              s && (o.skipTo = s),
              void (u && (o.serializationToken = u))
            );
          (t && i
            ? l.toLowerCase().includes(n.toLowerCase())
              ? a.push(i)
              : (a.push(i),
                a.push(
                  Object.assign(Object.assign({}, t), {
                    filters: t.filters.filter((g) => "global-label" !== g.key),
                  }),
                ))
            : t
              ? a.push(t)
              : i && a.push(i),
            (o.filters = a),
            s && (o.skipTo = s),
            u && (o.serializationToken = u));
        }
        setNewEntryValueHelper(o, t, i, n) {
          ((n = o.processValueAfterEdit(i.id, n)),
            i.type === y.QD.Omni && n instanceof _.xZ
              ? this.updateOmniselectValues(o, i, n)
              : o.updateCmdbValue(i.id, n),
            this.updateDependencyData(o, i.id, n));
        }
        externallyReorderEntryHelper(o, t, i) {
          var n, l, a;
          return (0, d.mG)(this, void 0, void 0, function* () {
            let s = { success: !0 };
            (null !== (n = o.beforeEntry) && void 0 !== n && n[_.go]
              ? (s = yield Ct(o.entry, o.beforeEntry, Ye.Before, t, i))
              : !(null === (l = o.afterEntry) || void 0 === l) &&
                l[_.go] &&
                (s = yield Ct(o.entry, o.afterEntry, Ye.After, t, i)),
              s.success ||
                M.cM.error(
                  null !== (a = s.errorMsg) && void 0 !== a
                    ? a
                    : "Failed to reorder policy.",
                ));
          });
        }
        updateOmniselectValues(o, t, i) {
          var n;
          const l = [];
          for (const s of i.values())
            l.push(
              Object.assign(
                { q_origin_key: s[_.go], datasource: s[_.Hx].datasource },
                s.data,
              ),
            );
          const a = o.getCmdbData();
          o.needValueSplit(t.id)
            ? o.updateConsolidatedProperty(t.id, l, !0)
            : Array.isArray(a[t.id])
              ? o.updateCmdbValue(t.id, l)
              : o.updateCmdbValue(
                  t.id,
                  null !== (n = l[0]) && void 0 !== n ? n : null,
                );
        }
        endOfTableReached(o, t) {
          return (
            o.length <
            ((null == t ? void 0 : t.endIndex) || 0) -
              ((null == t ? void 0 : t.startIndex) || 0)
          );
        }
        collectGroupLabelStats(o) {
          const t = new Set(),
            i = new Set();
          for (const n of o)
            (t.add(n.value ? n.value : oe.BE),
              n.start_mkey && i.add(Number(n.start_mkey)));
          return { currentGroupLabels: t, leadingPolicyOfGroups: i };
        }
        isTableInSectionView(o) {
          return [re.H.InterfacePairView, re.H.SequenceGroupingView].includes(
            o,
          );
        }
        updateGroupLabelsWithSkipToAndOccurrence(o) {
          const t = {},
            i = [];
          let n;
          for (const l of o)
            if (l.value) {
              const a = l.value;
              (n &&
                i.push(
                  Object.assign(Object.assign({}, n), {
                    value: (0, oe.R8)(
                      (0, oe.S4)(n.value, String(n.group)),
                      t[n.value],
                    ),
                  }),
                ),
                (n = {
                  group: l.group,
                  value: l.value,
                  count: l.count,
                  start_mkey: l.start_mkey,
                }),
                t[a] ? t[a]++ : (t[a] = 1));
            } else i.push(l);
          return (
            n &&
              i.push(
                "implicit" !== n.value || n.group
                  ? Object.assign(Object.assign({}, n), {
                      value: (0, oe.R8)(
                        (0, oe.S4)(n.value, String(n.group)),
                        t[n.value],
                      ),
                    })
                  : n,
              ),
            Object.assign(i, { totalCount: o.totalCount })
          );
        }
      }
      class Ln extends St {
        constructor(o, t, i, n, l) {
          (super(o, t),
            (this.logSettingSource = i),
            (this.isIpv6Enabled = n),
            (this.tableView = l),
            (this.currentGroupLabels = new Set()),
            (this.leadingPolicyOfGroups = new Set()));
        }
      }
      class Me extends Ln {
        constructor() {
          (super(...arguments),
            (this.FETCH_SIZE = 100),
            (this._getImplicitLogStatus = (o) =>
              "disable" === o ? "disable" : "enable"));
        }
        processFetchedEntries(o) {
          return (0, d.mG)(this, void 0, void 0, function* () {
            let t = o.fetchedEntries;
            const i = this.isTableInSectionView(this.tableView);
            if (yield this.implicitPolicyEnabled()) {
              let n;
              if (i) {
                for (const l of o.requestParams.filters || []) {
                  for (const a of l.filters)
                    if (
                      ((this.tableView === re.H.InterfacePairView &&
                        "intf-pair" === a.key) ||
                        (this.tableView === re.H.SequenceGroupingView &&
                          "global-label" === a.key)) &&
                      "implicit" === a.pattern
                    ) {
                      n = a;
                      break;
                    }
                  if (n) break;
                }
                n && (t = [this.createImplicitPolicy(this.sources[0])]);
              } else
                (this.endOfTableReached(t, o.requestParams) || o.endOfTable) &&
                  (t = t.concat(this.createImplicitPolicy(this.sources[0])));
            }
            return t;
          });
        }
        getProcessedStatsCount(o) {
          return (0, d.mG)(this, void 0, void 0, function* () {
            return !this.isTableInSectionView(this.tableView) &&
              (yield this.implicitPolicyEnabled())
              ? o + 1
              : o;
          });
        }
        processFetchedStats(o) {
          return (0, d.mG)(this, void 0, void 0, function* () {
            if (this.isTableInSectionView(this.tableView)) {
              if (this.tableView === re.H.InterfacePairView && o.columnStats) {
                const n = "intf-pair";
                const l = o.columnStats.get(n);
                if (l && Array.isArray(l)) {
                  let removedCount = 0;
                  const filtered = l.filter((item) => {
                    if (item.value && item.value.indexOf("T-") !== -1) {
                      removedCount += item.count || 0;
                      return false;
                    }
                    return true;
                  });
                  if (removedCount > 0) {
                    o.columnStats.set(
                      n,
                      Object.assign(filtered, {
                        totalCount: (l.totalCount || 0) - removedCount,
                      }),
                    );
                  }
                }
              }
              const t = "implicit",
                i = yield this.implicitPolicyEnabled();
              if (this.sources[0] instanceof pe.m) {
                if (i) {
                  o.matchedCount++;
                  const n =
                      this.tableView === re.H.InterfacePairView
                        ? "intf-pair"
                        : "global-label",
                    l = o.columnStats.get(n);
                  l
                    ? (l.push({ value: t, count: 1 }), l.totalCount++)
                    : o.columnStats.set(
                        n,
                        Object.assign([{ value: t, count: 1 }], {
                          totalCount: 1,
                        }),
                      );
                }
                if (this.tableView === re.H.SequenceGroupingView) {
                  let n = o.columnStats.get("global-label");
                  if (n) {
                    n = this.updateGroupLabelsWithSkipToAndOccurrence(n);
                    const { currentGroupLabels: l, leadingPolicyOfGroups: a } =
                      this.collectGroupLabelStats(n);
                    ((this.currentGroupLabels = l),
                      (this.leadingPolicyOfGroups = a),
                      o.columnStats.set("global-label", n));
                  } else {
                    const { currentGroupLabels: l, leadingPolicyOfGroups: a } =
                      this.collectGroupLabelStats(
                        Object.assign([{ value: t, count: 1 }], {
                          totalCount: 1,
                        }),
                      );
                    ((this.currentGroupLabels = l),
                      (this.leadingPolicyOfGroups = a));
                  }
                }
              }
            }
          });
        }
        implicitPolicyEnabled() {
          return (0, d.mG)(this, void 0, void 0, function* () {
            let o = !1;
            return (
              (yield this.fortigate.then((i) =>
                i.feature.featureVisible("implicit_policy"),
              )) && (o = this.sources[0] instanceof pe.m),
              o
            );
          });
        }
        createImplicitPolicy(o) {
          if (o instanceof pe.m)
            return me.j.generateImplicitPolicy(o, this.logSettingSource.data);
          throw new Error("Unsupported policy type for implicit policy");
        }
        processExpirationDateFilters(o) {
          const t = this.getBasicFilter(o);
          return (
            (o.key = "policy-expiry-date-utc"),
            "number" == typeof o.pattern && (o.pattern /= 1e3),
            (t.filter = o),
            t
          );
        }
        processFilterPerColumn(o) {
          let t = { filter: o };
          return (
            "intf-pair" === o.key
              ? (t = this.processIntfPairFilters(o))
              : "global-label" === o.key
                ? (t = this.processSequenceGroupingFilters(o))
                : "policy-expiry-date" === o.key &&
                  (t = this.processExpirationDateFilters(o)),
            t
          );
        }
        processFiltersForSource(o) {
          return (
            this.sources[0] instanceof pe.m &&
              this.processFiltersForSequenceGroup(o),
            o
          );
        }
        setNewEntryValue(o, t, i, n) {
          this.setNewEntryValueHelper(o, t, i, n);
        }
        externallyReorderEntry(o) {
          const t = Object.create(null, {
            externallyReorderEntry: { get: () => super.externallyReorderEntry },
          });
          return (0, d.mG)(this, void 0, void 0, function* () {
            return (
              yield t.externallyReorderEntry.call(this, o),
              this.externallyReorderEntryHelper(
                o,
                this.tableView === re.H.SequenceGroupingView,
                this.leadingPolicyOfGroups,
              )
            );
          });
        }
        externallyUpdateEntry(o) {
          const t = Object.create(null, {
            externallyUpdateEntry: { get: () => super.externallyUpdateEntry },
          });
          var i, n, l;
          return (0, d.mG)(this, void 0, void 0, function* () {
            if ((yield t.externallyUpdateEntry.call(this, o), o.implicit)) {
              if (null !== (i = o.data) && void 0 !== i && i.logtraffic)
                this.logSettingSource.data = Object.assign(
                  Object.assign({}, this.logSettingSource.data),
                  {
                    "fwpolicy-implicit-log": this._getImplicitLogStatus(
                      o.data.logtraffic,
                    ),
                    "fwpolicy6-implicit-log": this.isIpv6Enabled
                      ? this._getImplicitLogStatus(o.data.logtraffic)
                      : this.logSettingSource.data["fwpolicy6-implicit-log"],
                  },
                );
              else {
                const a = o.logSetting;
                this.logSettingSource.data = Object.assign(
                  Object.assign({}, this.logSettingSource.data),
                  {
                    "fwpolicy-implicit-log":
                      null !==
                        (n = null == a ? void 0 : a["fwpolicy-implicit-log"]) &&
                      void 0 !== n
                        ? n
                        : this.logSettingSource.data["fwpolicy-implicit-log"],
                    "fwpolicy6-implicit-log":
                      null !==
                        (l =
                          null == a ? void 0 : a["fwpolicy6-implicit-log"]) &&
                      void 0 !== l
                        ? l
                        : this.logSettingSource.data["fwpolicy6-implicit-log"],
                  },
                );
              }
              return this.logSettingSource.save();
            }
            return o.save();
          });
        }
      }
      (0, X.ef)(Me, [xt]);
      var Be = c(39556);
      class wn extends St {
        constructor(o, t, i, n, l) {
          (super(o, t),
            (this.logSettingSource = i),
            (this.isIpv6Enabled = n),
            (this.tableView = l),
            (this.currentGroupLabels = new Set()),
            (this.leadingPolicyOfGroups = new Set()));
        }
      }
      class Le extends wn {
        constructor() {
          (super(...arguments), (this.FETCH_SIZE = 100));
        }
        processFetchedEntries(o) {
          return (0, d.mG)(this, void 0, void 0, function* () {
            let t = o.fetchedEntries;
            const i = this.isTableInSectionView(this.tableView);
            if (yield this.implicitPolicyEnabled()) {
              let n;
              if (i) {
                for (const l of o.requestParams.filters || []) {
                  for (const a of l.filters)
                    if (
                      ((this.tableView === re.H.InterfacePairView &&
                        "intf-pair" === a.key) ||
                        (this.tableView === re.H.SequenceGroupingView &&
                          "global-label" === a.key)) &&
                      "implicit" === a.pattern
                    ) {
                      n = a;
                      break;
                    }
                  if (n) break;
                }
                n && (t = [this.createImplicitPolicy(this.sources[0])]);
              } else
                (this.endOfTableReached(t, o.requestParams) || o.endOfTable) &&
                  (t = t.concat(this.createImplicitPolicy(this.sources[0])));
            }
            return t;
          });
        }
        getProcessedStatsCount(o) {
          return (0, d.mG)(this, void 0, void 0, function* () {
            return !this.isTableInSectionView(this.tableView) &&
              (yield this.implicitPolicyEnabled())
              ? o + 1
              : o;
          });
        }
        processFetchedStats(o) {
          return (0, d.mG)(this, void 0, void 0, function* () {
            if (this.isTableInSectionView(this.tableView)) {
              const t = "implicit",
                i = yield this.implicitPolicyEnabled();
              if (this.sources[0] instanceof ve.u) {
                if (i) {
                  o.matchedCount++;
                  const n =
                      this.tableView === re.H.InterfacePairView
                        ? "intf-pair"
                        : "global-label",
                    l = o.columnStats.get(n);
                  l
                    ? (l.push({ value: t, count: 1 }), l.totalCount++)
                    : o.columnStats.set(
                        n,
                        Object.assign([{ value: t, count: 1 }], {
                          totalCount: 1,
                        }),
                      );
                }
                if (this.tableView === re.H.SequenceGroupingView) {
                  let n = o.columnStats.get("global-label");
                  if (n) {
                    n = this.updateGroupLabelsWithSkipToAndOccurrence(n);
                    const { currentGroupLabels: l, leadingPolicyOfGroups: a } =
                      this.collectGroupLabelStats(n);
                    ((this.currentGroupLabels = l),
                      (this.leadingPolicyOfGroups = a),
                      o.columnStats.set("global-label", n));
                  } else {
                    const { currentGroupLabels: l, leadingPolicyOfGroups: a } =
                      this.collectGroupLabelStats(
                        Object.assign([{ value: t, count: 1 }], {
                          totalCount: 1,
                        }),
                      );
                    ((this.currentGroupLabels = l),
                      (this.leadingPolicyOfGroups = a));
                  }
                }
              }
            }
          });
        }
        implicitPolicyEnabled() {
          return (0, d.mG)(this, void 0, void 0, function* () {
            let o = !1;
            return (
              (yield this.fortigate.then((i) =>
                i.feature.featureVisible("implicit_policy"),
              )) && (o = this.sources[0] instanceof ve.u),
              o
            );
          });
        }
        createImplicitPolicy(o) {
          if (o instanceof ve.u)
            return Be.P.generateImplicitPolicy(o, this.logSettingSource.data);
          throw new Error("Unsupported policy type for implicit policy");
        }
        processFilterPerColumn(o) {
          let t = { filter: o };
          return (
            "intf-pair" === o.key
              ? (t = this.processIntfPairFilters(o))
              : "global-label" === o.key &&
                (t = this.processSequenceGroupingFilters(o)),
            t
          );
        }
        processFiltersForSource(o) {
          return (
            this.sources[0] instanceof ve.u &&
              this.processFiltersForSequenceGroup(o),
            o
          );
        }
        setNewEntryValue(o, t, i, n) {
          this.setNewEntryValueHelper(o, t, i, n);
        }
        externallyReorderEntry(o) {
          const t = Object.create(null, {
            externallyReorderEntry: { get: () => super.externallyReorderEntry },
          });
          return (0, d.mG)(this, void 0, void 0, function* () {
            return (
              yield t.externallyReorderEntry.call(this, o),
              this.externallyReorderEntryHelper(
                o,
                this.tableView === re.H.SequenceGroupingView,
                this.leadingPolicyOfGroups,
              )
            );
          });
        }
        externallyUpdateEntry(o) {
          const t = Object.create(null, {
            externallyUpdateEntry: { get: () => super.externallyUpdateEntry },
          });
          var i, n, l, a, s;
          return (0, d.mG)(this, void 0, void 0, function* () {
            if ((yield t.externallyUpdateEntry.call(this, o), o.implicit)) {
              if (null !== (i = o.data) && void 0 !== i && i.logtraffic)
                this.logSettingSource.data = Object.assign(
                  Object.assign({}, this.logSettingSource.data),
                  {
                    "fwpolicy-implicit-log":
                      null === (n = o.data) || void 0 === n
                        ? void 0
                        : n.logtraffic,
                    "fwpolicy6-implicit-log": this.isIpv6Enabled
                      ? null === (l = o.data) || void 0 === l
                        ? void 0
                        : l.logtraffic
                      : this.logSettingSource.data["fwpolicy6-implicit-log"],
                  },
                );
              else {
                const u = o.logSetting;
                this.logSettingSource.data = Object.assign(
                  Object.assign({}, this.logSettingSource.data),
                  {
                    "fwpolicy-implicit-log":
                      null !==
                        (a = null == u ? void 0 : u["fwpolicy-implicit-log"]) &&
                      void 0 !== a
                        ? a
                        : this.logSettingSource.data["fwpolicy-implicit-log"],
                    "fwpolicy6-implicit-log":
                      null !==
                        (s =
                          null == u ? void 0 : u["fwpolicy6-implicit-log"]) &&
                      void 0 !== s
                        ? s
                        : this.logSettingSource.data["fwpolicy6-implicit-log"],
                  },
                );
              }
              return this.logSettingSource.save();
            }
            return o.save();
          });
        }
      }
      function An(r, o, t) {
        return r.getVariant(
          Object.assign(Object.assign({}, t), {
            filters:
              ((n = o),
              [
                {
                  filters: n.reduce(
                    (l, a) =>
                      l.concat([
                        {
                          key: "srcintf",
                          type: p.NM.String,
                          pattern: a,
                          negate: !0,
                          operator: p.pg.Contains,
                        },
                        {
                          key: "dstintf",
                          type: p.NM.String,
                          pattern: a,
                          negate: !0,
                          operator: p.pg.Contains,
                        },
                      ]),
                    [],
                  ),
                  logic: p.tk.And,
                },
              ]),
          }),
        );
        var n;
      }
      (0, X.ef)(Le, [xt]);
      const Fn = [...m.l_];
      class Nn {
        constructor(o, t, i, n, l, a, s, u, g, h, P) {
          ((this.fortigate = o),
            (this.destroyOn = t),
            (this.params = i),
            (this.cmdbService = l),
            (this.cmdbSourceMap = a),
            (this.csfSourceFactory = s),
            (this.logSettingService = u),
            (this.systemSettingsService = g),
            (this.settingsFactory = h),
            (this.globalSettingSourceFactoryService = P),
            (this.viewTypeManager = n),
            (this.logSettingSource = u.create()),
            (this.systemSettingsSource = g.create()),
            (this.globalSettingSource = P.create()));
        }
        initForRender(o, t, i, n) {
          return (0, d.mG)(this, void 0, void 0, function* () {
            const { cmdbSources: l, defaultSyncMode: a } =
              yield this.generateCandidateSources();
            ((this.cmdbSources = l),
              this.setPolicySource(l),
              this.setPolicyLookupSources({
                localUser: l.localUser,
                userGroup: l.userGroup,
                webFilterProfile: l.wfProfile,
                webFilterFtgdCat: l.wfCategory,
                webFilterFtgdLocalCat: l.ftgdLocalCategory,
              }),
              this.viewTypeManager.init({
                type: this.params.type,
                subType: this.params.subType,
                optInForInlineMenu: i,
                tableView: n,
                defaultSyncMode: a,
                insideSlide: o,
                readOnly: t,
              }));
          });
        }
        setupTable(o) {
          return (0, d.mG)(this, void 0, void 0, function* () {
            if (!this.cmdbSources)
              throw new Error("CMDB sources are not properly setup.");
            this.params.type === ie.a.Policy && this.logSettingSource
              ? yield this.setupTableForFirewallPolicy(
                  this.cmdbSources,
                  this.logSettingSource,
                  this.systemSettingsSource,
                  this.globalSettingSource,
                  o,
                )
              : this.params.type === ie.a.SecurityPolicy &&
                  this.logSettingSource
                ? yield this.setupTableForSecurityPolicy(
                    this.cmdbSources,
                    this.logSettingSource,
                    this.systemSettingsSource,
                    this.globalSettingSource,
                    o,
                  )
                : M.cM.error(
                    `Policy type ${this.params.type} is not supported.`,
                  );
          });
        }
        getDialogUrl() {
          return `/firewall/policy/${this.params.type}/${this.params.subType}/edit`;
        }
        getInterfacePairSectionValue(o, t) {
          return `${o}->${t}`;
        }
        getLocateParams(o, t) {
          var i, n;
          return (0, d.mG)(this, void 0, void 0, function* () {
            let l;
            try {
              if ((null == o ? void 0 : o.q_origin_key) && this.policySource) {
                const a = parseInt(o.q_origin_key, 10);
                if (Number.isNaN(a))
                  throw new Error(`Invalid policy ID: ${o.q_origin_key}.`);
                if (t === re.H.SequenceGroupingView) {
                  const s = o["global-label"];
                  let u = 0;
                  const g = [];
                  if (s) {
                    const P = (0, oe.dh)(s);
                    (g.push(P.parsedGroupLabel), (u = P.skipTo));
                  }
                  const h = yield this.policySource.getPolicyGroupLabelInfo(
                    a,
                    g,
                    u,
                  );
                  if (!h) throw new Error(`Cannot locate policy ${a}.`);
                  l = {
                    matches: {
                      sectionValue: h.formattedGlobalLabel,
                      sectionIndex: h.entryOffsetInGroup,
                    },
                    highlight: !0,
                  };
                } else if (t === re.H.InterfacePairView) {
                  let s = o.srcintf,
                    u = o.dstintf;
                  if (!s || !u) {
                    const P = (yield this.policySource.load({
                      keys: [String(a)],
                    }))[0];
                    if (
                      !(
                        P &&
                        (null === (i = P.data) || void 0 === i
                          ? void 0
                          : i.srcintf) &&
                        (null === (n = P.data) || void 0 === n
                          ? void 0
                          : n.dstintf)
                      )
                    )
                      throw new Error(`Cannot locate policy ${a}.`);
                    ((s = (0, X.xP)(P.data.srcintf[0])),
                      (u = (0, X.xP)(P.data.dstintf[0])));
                  }
                  l = {
                    matches: {
                      sectionValue: this.getInterfacePairSectionValue(s, u),
                      sectionIndex:
                        yield this.policySource.findIndexOfPrimaryKey(
                          String(a),
                          [
                            {
                              filters: [
                                {
                                  key: "srcintf",
                                  type: p.NM.String,
                                  pattern: s,
                                  operator: p.pg.Contains,
                                },
                                {
                                  key: "dstintf",
                                  type: p.NM.String,
                                  pattern: u,
                                  operator: p.pg.Contains,
                                },
                              ],
                              logic: p.tk.And,
                            },
                          ],
                        ),
                    },
                    highlight: !0,
                  };
                } else {
                  if (t !== re.H.BySequenceView)
                    throw new Error("Unsupported table view.");
                  l = {
                    matches: yield this.policySource.findIndexOfPrimaryKey(
                      String(a),
                    ),
                    highlight: !0,
                  };
                }
              }
            } catch (a) {
              (M.cM.error("Failed to parse initial table locate:"),
                M.cM.error(a));
            }
            return l;
          });
        }
        processGroupLabel(o, t, i, n = !1) {
          var l, a;
          return (0, d.mG)(this, void 0, void 0, function* () {
            if (
              this.viewTypeManager.sequenceGroupingView &&
              o &&
              t.data &&
              null !== (l = t.data) &&
              void 0 !== l &&
              l["global-label"] &&
              i.data
            ) {
              const s =
                null === (a = t.data) || void 0 === a
                  ? void 0
                  : a["global-label"];
              let u = t.new;
              ((t.new = !1),
                (t.data["global-label"] = ""),
                yield t.save({ skipChangeSummary: !n }),
                (t.new = u),
                (u = i.new),
                (i.new = !1),
                (i.data["global-label"] = s),
                yield i.save({ skipChangeSummary: !n }),
                (i.new = u));
            }
          });
        }
        getTableExportFilename() {
          const o = (0, O.p6)(Date.now(), "yyyy-MM-dd", "en");
          return `${this.settingsFactory.tableId(this.fortigate.vdom)}_${o}`;
        }
        setupTableForFirewallPolicy(o, t, i, n, l) {
          return (0, d.mG)(this, void 0, void 0, function* () {
            if (this.logSettingSource) {
              const a = yield this.fortigate.feature.featureVisible("ipv6");
              this.tableSource =
                this.cmdbService.instantiateStreamableMutableSource(
                  o.firewallPolicy,
                  this.destroyOn,
                  Me,
                  this.logSettingSource,
                  a,
                  l,
                );
            } else
              M.cM.error(
                "logSettingSource needs to be created before mutable source is instantiated",
              );
            this.settings =
              yield this.settingsFactory.createFirewallPolicySettings(
                o,
                this.fortigate,
                t,
                i,
                n,
              );
          });
        }
        setupTableForSecurityPolicy(o, t, i, n, l) {
          return (0, d.mG)(this, void 0, void 0, function* () {
            if (this.logSettingSource) {
              const a = yield this.fortigate.feature.featureVisible("ipv6");
              this.tableSource =
                this.cmdbService.instantiateStreamableMutableSource(
                  o.securityPolicy,
                  this.destroyOn,
                  Le,
                  this.logSettingSource,
                  a,
                  l,
                );
            } else
              M.cM.error(
                "logSettingSource needs to be created before mutable source is instantiated",
              );
            this.settings =
              yield this.settingsFactory.createSecurityPolicySettings(
                o,
                this.fortigate,
                t,
                i,
                n,
              );
          });
        }
        setPolicySource(o) {
          this.isFirewallPolicy()
            ? ((this.policySource = o.firewallPolicy),
              this.policySource.enablethrottleStatsRequest())
            : this.isSecurityFirewallPolicy() &&
              (this.policySource = o.securityPolicy);
        }
        setPolicyLookupSources(o) {
          this.isFirewallPolicy() &&
            ((this.localUser = o.localUser),
            (this.userGroup = o.userGroup),
            (this.webFilterProfile = o.webFilterProfile),
            (this.webFilterFtgdCat = o.webFilterFtgdCat),
            (this.webFilterFtgdLocalCat = o.webFilterFtgdLocalCat));
        }
        generateCandidateSources() {
          var o;
          return (0, d.mG)(this, void 0, void 0, function* () {
            const t =
                this.params.type === ie.a.SecurityPolicy
                  ? {
                      "system.external-resource": "type",
                      "firewall.address": "sub-type",
                      "firewall.addrgrp": "category",
                    }
                  : { "system.external-resource": "type" },
              i = Object.assign(
                {},
                null === (o = this.fortigate) || void 0 === o
                  ? void 0
                  : o.getVariant().params,
              ),
              n = new ht.i(i),
              l = new ht.i(
                Object.assign(Object.assign({}, i), {
                  datasourceFormat: t,
                  datasourceChecks: {
                    srcaddr: ["ResolvedFirewallAddress"],
                    dstaddr: ["ResolvedFirewallAddress"],
                  },
                }),
              ),
              a = new _.xR({ destroyOn: this.destroyOn }),
              s = { variant: n, pool: a },
              u = { variant: l, pool: a },
              g = [];
            this.params.type === ie.a.SecurityPolicy &&
              g.push("device_id_enabled");
            const h = {
                pool: a,
                variant: new gt.FirewallInterfacesOmniSourceVariant({
                  apiParams: { format: [...Fn, ...g] },
                }),
              },
              P = { destroyOn: this.destroyOn },
              N = yield this.cmdbSourceMap.createSourceForCmdbPath(
                "system.interface",
                h,
              ),
              L = yield this.cmdbSourceMap.createSourceForCmdbPath(
                "system.virtual-wire-pair",
                s,
              ),
              J = yield this.cmdbSourceMap.createSourceForCmdbPath(
                "firewall.gtp",
                s,
              );
            if (!N || !L)
              throw new Error(
                "Unable to create source for interface or virtual-wire-pair.",
              );
            const Q = N,
              K = this.csfSourceFactory.create({
                variant: s.variant,
                destroyOn: this.destroyOn,
              }),
              { defaultSyncMode: H } = yield this.preloadData({
                firewallInterface: Q,
                csf: K,
                virtualWirePair: L,
              }),
              B = Array.from(this.getVwpInterfaces(L)),
              k =
                B.length > 0
                  ? {
                      variant: An(this.fortigate, B, { datasourceFormat: t }),
                      pool: a,
                    }
                  : u,
              T = Object.assign(
                Object.assign(
                  Object.assign(
                    Object.assign(
                      Object.assign(
                        Object.assign(
                          Object.assign(
                            Object.assign(
                              Object.assign(
                                Object.assign(
                                  Object.assign(
                                    Object.assign(
                                      Object.assign(
                                        {
                                          firewallPolicy:
                                            yield this.cmdbSourceMap.createSourceForCmdbPath(
                                              "firewall.policy",
                                              this.isFirewallPolicy() ? k : P,
                                            ),
                                          securityPolicy:
                                            yield this.cmdbSourceMap.createSourceForCmdbPath(
                                              "firewall.security-policy",
                                              this.isSecurityFirewallPolicy()
                                                ? k
                                                : P,
                                            ),
                                          firewallInterface: Q,
                                        },
                                        yield (0, Te.W7)(this.cmdbSourceMap, s),
                                      ),
                                      yield (0, Te.B7)(this.cmdbSourceMap, s),
                                    ),
                                    yield (0, Te.Re)(this.cmdbSourceMap, s),
                                  ),
                                  yield (0, Te.Q9)(this.cmdbSourceMap, s),
                                ),
                                yield (0, Te.vA)(this.cmdbSourceMap, s),
                              ),
                              yield (0, Te.Hy)(this.cmdbSourceMap, s),
                            ),
                            yield (0, Te.bE)(this.cmdbSourceMap, s),
                          ),
                          yield (0, Te.FK)(this.cmdbSourceMap, s),
                        ),
                        yield (0, Te.f$)(this.cmdbSourceMap, s),
                      ),
                      yield (0, Te.tX)(this.cmdbSourceMap, s),
                    ),
                    yield (0, Te.R7)(this.cmdbSourceMap, s),
                  ),
                  yield (0, Te.xW)(this.cmdbSourceMap, s),
                ),
                { virtualWirePair: L, firewallGtpProfile: J },
              );
            let te = !0;
            const ee = [];
            for (const [xe, se] of Object.entries(T))
              se || (ee.push(xe), (te = !1));
            if (!te)
              throw new Error(`Unable to create source for: ${ee.join(", ")}.`);
            return {
              cmdbSources: {
                firewallPolicy: T.firewallPolicy,
                securityPolicy: T.securityPolicy,
                firewallInterface: Q,
                oneTimeSchedule: T.oneTimeSchedule,
                recurringSchedule: T.recurringSchedule,
                scheduleGroup: T.scheduleGroup,
                customService: T.customService,
                serviceGroup: T.serviceGroup,
                avProfile: T.avProfile,
                wfProfile: T.wfProfile,
                dfProfile: T.dfProfile,
                appControl: T.appControl,
                ipsSensor: T.ipsSensor,
                efProfile: T.efProfile,
                voipProfile: T.voipProfile,
                icapProfile: T.icapProfile,
                wafProfile: T.wafProfile,
                sslSshProfile: T.sslSshProfile,
                fileFilterProfile: T.fileFilterProfile,
                videoFilterProfile: T.videoFilterProfile,
                dlpProfile: T.dlpProfile,
                virtualPatchProfile: T.virtualPatchProfile,
                protocolOptions: T.protocolOptions,
                profileGroup: T.profileGroup,
                localUser: T.localUser,
                certificateUser: T.certificateUser,
                userGroup: T.userGroup,
                userAdgrp: T.userAdgrp,
                phase1: T.phase1,
                manualKey: T.manualKey,
                firewallAddress: T.firewallAddress,
                addressGroup: T.addressGroup,
                externalResourceAddress: T.externalResourceAddress,
                externalResourceAddress6: T.externalResourceAddress6,
                firewallAddress6: T.firewallAddress6,
                addressGroup6: T.addressGroup6,
                internetServiceName: T.internetServiceName,
                internetService6Name: T.internetService6Name,
                internetServiceGroup: T.internetServiceGroup,
                internetService6Group: T.internetService6Group,
                internetServiceCustom: T.internetServiceCustom,
                internetService6Custom: T.internetService6Custom,
                internetServiceCustomGroup: T.internetServiceCustomGroup,
                internetService6CustomGroup: T.internetService6CustomGroup,
                networkServiceDynamic: T.networkServiceDynamic,
                ippool: T.ippool,
                ippool6: T.ippool6,
                vip: T.vip,
                vipgrp: T.vipgrp,
                vip6: T.vip6,
                vipgrp6: T.vipgrp6,
                ztnaTag: T.ztnaTag,
                ztnaTagGroup: T.ztnaTagGroup,
                ztnaVip: T.ztnaVip,
                ztnaVip6: T.ztnaVip6,
                firewallPolicyZtnaTagGroup: T.firewallPolicyZtnaTagGroup,
                applicationName: T.applicationName,
                applicationCustom: T.applicationCustom,
                applicationCategory: T.applicationCategory,
                applicationGroup: T.applicationGroup,
                wfCategory: T.wfCategory,
                wfCategoryGroup: T.wfCategoryGroup,
                ftgdLocalCategory: T.ftgdLocalCategory,
                externalResourceCategory: T.externalResourceCategory,
                casbProfile: T.casbProfile,
                virtualWirePair: L,
                replacementMessageGroup: T.replacementMessageGroup,
                decryptedTraffic: T.decryptedTraffic,
                firewallGtpProfile: T.firewallGtpProfile,
              },
              defaultSyncMode: H,
            };
          });
        }
        isFirewallPolicy() {
          return this.params.type === ie.a.Policy;
        }
        isSecurityFirewallPolicy() {
          return this.params.type === ie.a.SecurityPolicy;
        }
        getVwpInterfaces(o) {
          const t = new Set();
          for (const i of o.entries)
            if (i.data)
              for (const n of i.data.member) {
                const l = (0, X.xP)(n);
                l && t.add(l);
              }
          return t;
        }
        preloadData(o) {
          return (0, d.mG)(this, void 0, void 0, function* () {
            let t;
            return (
              (this.firewallInterface = o.firewallInterface),
              ([
                t,
                this.workflowManagementVisible,
                this.logDeviceEnabled,
                this.isNgfwPolicyMode,
              ] = yield Promise.all([
                o.csf.getByFormat(["configuration-sync", "status"]),
                this.fortigate.feature.featureVisible("workflow_management"),
                this.isLogDeviceEnabled(),
                this.fortigate.config.isNgfwPolicyMode(),
                o.firewallInterface.getSslVpnInterfaceName(),
                this.logSettingSource.load(),
                this.systemSettingsSource.load(),
                this.globalSettingSource.load(),
                o.virtualWirePair.load(),
              ])),
              {
                defaultSyncMode:
                  "default" === t["configuration-sync"] &&
                  "enable" === t.status,
              }
            );
          });
        }
        isLogDeviceEnabled() {
          return Promise.all([
            this.fortigate.logDevice.isLogDeviceEnabled(
              this.fortigate.logDevice.LOG_DEVICES.DISK,
            ),
            this.fortigate.logDevice.isLogDeviceEnabled(
              this.fortigate.logDevice.LOG_DEVICES.FORTIANALYZER,
            ),
            this.fortigate.logDevice.isLogDeviceEnabled(
              this.fortigate.logDevice.LOG_DEVICES.FORTIANALYZER_CLOUD,
            ),
          ]).then((o) => o.some((t) => !!t));
        }
      }
      var Zn = c(60421),
        Dn = c(41440),
        Gn = c(77324),
        Un = c(49824),
        Rn = c(80161),
        Ce = c(16938),
        Mt = c(90240),
        Vn = c(23338),
        Bn = c(45477),
        Jn = c(22559),
        kn = c(3868),
        Qn = c(60737),
        Yn = c(38010),
        It = c(80497),
        it = c(58248),
        Ot = c(92815),
        Fe = c(50998),
        Kn = c(70886),
        Wn = c(63033),
        Et = c(21971),
        jn = c(72300),
        Lt = c(27169);
      const wt = {
          [ie.a.Policy]: [
            "policy",
            "policyid",
            "name",
            "srcintf",
            "dstintf",
            "consolidated-srcaddr",
            "consolidated-source",
            "consolidated-dstaddr",
            "consolidated-destination",
            "schedule",
            "service",
            "action",
            "consolidated-poolname",
            "nat",
            "profile",
            "logtraffic",
            "bytes",
            "av-profile",
            "emailfilter-profile",
            "webfilter-profile",
            "videofilter-profile",
            "dlp-profile",
            "dnsfilter-profile",
            "waf-profile",
            "application-list",
            "ips-sensor",
            "icap-profile",
            "voip-profile",
            "file-filter-profile",
            "profile-protocol-options",
            "ssl-ssh-profile",
            "profile-group",
            "packets",
            "software_bytes",
            "software_packets",
            "asic_bytes",
            "asic_packets",
            "nturbo_bytes",
            "nturbo_packets",
            "last_used",
            "first_used",
            "active_sessions",
            "hit_count",
            "status",
            "groups",
            "users",
            "vpntunnel",
            "comments",
            "inspection-mode",
            "gtp-profile",
            "ztna-ems-tag",
            "ztna-ems-tag-secondary",
            "ztna-status",
            "global-label",
            "intf-pair",
            "policy-behaviour-type",
            "policy-expiry-date",
            "virtual-patch-profile",
            "casb-profile",
          ],
          [ie.a.NgfwFirewallPolicy]: [
            "policy",
            "policyid",
            "name",
            "srcintf",
            "dstintf",
            "consolidated-srcaddr",
            "consolidated-source",
            "consolidated-dstaddr",
            "consolidated-destination",
            "nat",
            "service",
            "comments",
            "status",
            "groups",
            "users",
            "ssl-ssh-profile",
            "bytes",
            "packets",
            "software_bytes",
            "software_packets",
            "asic_bytes",
            "asic_packets",
            "nturbo_bytes",
            "nturbo_packets",
            "last_used",
            "first_used",
            "active_sessions",
            "hit_count",
            "ztna-ems-tag",
            "ztna-ems-tag-secondary",
            "ztna-status",
            "global-label",
            "intf-pair",
          ],
          [ie.a.SecurityPolicy]: [
            "policy",
            "policyid",
            "name",
            "srcintf",
            "dstintf",
            "consolidated-srcaddr",
            "consolidated-source",
            "consolidated-dstaddr",
            "consolidated-destination",
            "schedule",
            "service",
            "applications",
            "url-category",
            "action",
            "logtraffic",
            "profile",
            "av-profile",
            "webfilter-profile",
            "videofilter-profile",
            "file-filter-profile",
            "dnsfilter-profile",
            "ips-sensor",
            "emailfilter-profile",
            "profile-protocol-options",
            "profile-group",
            "status",
            "groups",
            "users",
            "comments",
            "hit_count",
            "global-label",
            "intf-pair",
            "virtual-patch-profile",
          ],
        },
        qn = {
          [ie.a.Policy]: [
            "policy",
            "srcintf",
            "dstintf",
            "consolidated-source",
            "consolidated-destination",
            "schedule",
            "service",
            "action",
            "consolidated-poolname",
            "nat",
            "policy-behaviour-type",
            "profile",
            "logtraffic",
            "bytes",
            "global-label",
            "intf-pair",
          ],
          [ie.a.NgfwFirewallPolicy]: [
            "policy",
            "srcintf",
            "dstintf",
            "consolidated-source",
            "consolidated-destination",
            "service",
            "ssl-ssh-profile",
            "nat",
            "bytes",
            "global-label",
            "intf-pair",
          ],
          [ie.a.SecurityPolicy]: [
            "policy",
            "srcintf",
            "dstintf",
            "consolidated-source",
            "consolidated-destination",
            "schedule",
            "service",
            "applications",
            "url-category",
            "action",
            "profile",
            "logtraffic",
            "hit_count",
            "global-label",
            "intf-pair",
          ],
        },
        Ie = "nu-tooltip-hint",
        Ue = 100,
        ae = (r) => r instanceof me.j && r.policyExpired();
      function Je(r, o, t, i, n, l, a, s) {
        (0, V.cj)(r, o, t, i, n.firewallPolicy, l, a, s);
      }
      class $n {
        constructor(o, t, i, n, l, a, s, u, g, h = !1) {
          ((this.fortigate = o),
            (this.translation = t),
            (this.datetime = i),
            (this.theme = n),
            (this.selectConfig = l),
            (this.viewTypeManager = a),
            (this.http = s),
            (this.sourceManagerFactory = u),
            (this.mutableDefaultSettingsService = g),
            (this.forceTraditionalGui = h),
            (this.ipv6Enabled = !1),
            (this.STATUS_LANG_KEY_MAPPING = new Map([
              ["enable", this.translation.translate("Enabled")],
              ["disable", this.translation.translate("Disabled")],
              ["Enable", this.translation.translate("Enable")],
              ["Disable", this.translation.translate("Disable")],
            ])),
            (this.TYPE_LANG_KEY_MAPPING = new Map([
              ["Standard", this.translation.translate("Standard")],
              ["ZTNA", this.translation.translate("ZTNA")],
            ])),
            (this.INSPECTION_MODE_LANG_KEY = new Map([
              ["flow", this.translation.translate("Flow-based")],
              ["proxy", this.translation.translate("Proxy-based")],
            ])),
            (this.ENABLE_DISABLE_OPTION = [
              new y.j4({
                label: this.translate(this.STATUS_LANG_KEY_MAPPING, "enable"),
                labelAsVerb: this.translate(
                  this.STATUS_LANG_KEY_MAPPING,
                  "Enable",
                ),
                entryValue: "enable",
                icon: z.nI,
              }),
              new y.j4({
                label: this.translate(this.STATUS_LANG_KEY_MAPPING, "disable"),
                labelAsVerb: this.translate(
                  this.STATUS_LANG_KEY_MAPPING,
                  "Disable",
                ),
                entryValue: "disable",
                icon: z.oc,
              }),
            ]),
            (this.FORTI_FIREWALL_LOG_ENABLE_DISABLE_OPTION = [
              new y.j4({
                label: this.translate(this.STATUS_LANG_KEY_MAPPING, "enable"),
                labelAsVerb: this.translate(
                  this.STATUS_LANG_KEY_MAPPING,
                  "Enable",
                ),
                entryValue: "all",
                icon: z.nI,
              }),
              new y.j4({
                label: this.translate(this.STATUS_LANG_KEY_MAPPING, "disable"),
                labelAsVerb: this.translate(
                  this.STATUS_LANG_KEY_MAPPING,
                  "Disable",
                ),
                entryValue: "disable",
                icon: z.oc,
              }),
            ]),
            (this.INSPECTION_MODE_COL_OPTION = [
              new y.j4({
                label: this.translate(this.INSPECTION_MODE_LANG_KEY, "flow"),
                entryValue: "flow",
              }),
              new y.j4({
                label: this.translate(this.INSPECTION_MODE_LANG_KEY, "proxy"),
                entryValue: "proxy",
              }),
            ]),
            (this.sourceManager =
              this.sourceManagerFactory.createTableSourceManager()));
        }
        translate(o, t) {
          var i;
          return null !== (i = o.get(t)) && void 0 !== i ? i : t;
        }
        getFirewallPolicyColumns(o, t, i) {
          return this.getColumns(o, t, i);
        }
        getSecurityPolicyColumns(o, t, i) {
          return (0, d.mG)(this, void 0, void 0, function* () {
            return this.getColumns(o, t, i);
          });
        }
        getColumns(o, t, i) {
          return (0, d.mG)(this, void 0, void 0, function* () {
            this.sourceManager.collectOmniSources(o);
            const n = yield (0, Kn.e)(
                this.fortigate,
                this.viewTypeManager.type,
              ),
              l = yield (0, Wn.zt)(this.fortigate, this.viewTypeManager.type);
            let a;
            const s = (L) => {
              a = L;
            };
            (yield this.sourceManager.prepareSources(
              this.fortigate,
              n,
              l,
              !1,
              this.viewTypeManager.type === ie.a.SecurityPolicy
                ? o.securityPolicy
                : o.firewallPolicy,
              () => a,
            ),
              (this.ipv6Enabled = this.sourceManager.ipv6Enabled));
            const u = yield this.fortigate.buildState.isFortiFirewall(),
              g = (L, J) =>
                !L.implicit &&
                !L.isLearnModePolicy() &&
                n.editable(J.id, L) &&
                !ae(L),
              h = {
                policy: {
                  columnFn: this.forceTraditionalGui
                    ? this.policyStandardColumn.bind(this)
                    : this.policyOmniColumn.bind(this),
                },
                policyid: { columnFn: this.policyIdColumn.bind(this) },
                name: { columnFn: this.nameColumn.bind(this) },
                srcintf: { columnFn: this.srcintfColumn.bind(this) },
                dstintf: { columnFn: this.dstintfColumn.bind(this) },
                "consolidated-srcaddr": {
                  columnFn: () => this.consolidatedSrcaddrColumn(s),
                },
                "consolidated-source": {
                  columnFn: () => this.consolidatedSourceColumn(s),
                },
                "consolidated-dstaddr": {
                  columnFn: () => this.consolidatedDstaddrColumn(s),
                },
                "consolidated-destination": {
                  columnFn: () => this.consolidatedDestinationColumn(s),
                },
                "security-source": {
                  columnFn: () => this.consolidatedSourceColumn(s),
                },
                "security-dstaddr": {
                  columnFn: () => this.consolidatedDstaddrColumn(s),
                },
                "security-destination": {
                  columnFn: () => this.consolidatedDestinationColumn(s),
                },
                "consolidated-poolname": {
                  columnFn: this.consolidatedPoolnameColumn.bind(this),
                },
                nat: { columnFn: this.natColumn.bind(this) },
                schedule: { columnFn: this.scheduleColumn.bind(this) },
                service: { columnFn: this.serviceColumn.bind(this) },
                applications: { columnFn: () => this.applicationsColumn(n, l) },
                "url-category": { columnFn: this.urlCategoryColumn.bind(this) },
                users: { columnFn: this.usersColumn.bind(this) },
                groups: { columnFn: this.groupsColumn.bind(this) },
                vpntunnel: { columnFn: () => this.vpntunnelColumn(s) },
                action: { columnFn: this.actionColumn.bind(this) },
                logtraffic: { columnFn: this.logtrafficColumn(t, u) },
                profile: { columnFn: this.profileColumnFactory(n) },
                "av-profile": { columnFn: this.avProfileColumnFactory(g, n) },
                "webfilter-profile": {
                  columnFn: this.webfilterProfileColumnFactory(g),
                },
                "dnsfilter-profile": {
                  columnFn: this.dnsfilterProfileColumnFactory(g),
                },
                "application-list": {
                  columnFn: this.applicationListColumnFactory(g),
                },
                "ips-sensor": { columnFn: this.ipsSensorColumnFactory(g) },
                "emailfilter-profile": {
                  columnFn: this.emailFilterProfileColumnFactory(g),
                },
                "voip-profile": { columnFn: this.voipProfileColumnFactory(g) },
                "icap-profile": { columnFn: this.icapProfileColumnFactory(g) },
                "waf-profile": { columnFn: this.wafProfileColumnFactory(g) },
                "ssl-ssh-profile": {
                  columnFn: this.sslSshProfileColumnFactory(g),
                },
                "file-filter-profile": {
                  columnFn: this.fileFilterProfileColumnFactory(g),
                },
                "videofilter-profile": {
                  columnFn: this.videoFilterProfileColumnFactory(g),
                },
                "casb-profile": { columnFn: this.inlineCasbColumnFactory(g) },
                "dlp-profile": { columnFn: this.dlpProfileColumnFactory(g) },
                "profile-protocol-options": {
                  columnFn: this.profileProtocolOptionsColumnFactory(g),
                },
                "profile-group": {
                  columnFn: this.profileGroupColumnFactory(g),
                },
                "virtual-patch-profile": {
                  columnFn: this.virtualPatchProfileColumnFactory(g),
                },
                "gtp-profile": { columnFn: this.gtpProfileColumn.bind(this) },
                status: { columnFn: this.statusColumn.bind(this) },
                bytes: { columnFn: this.bytesColumn.bind(this) },
                packets: { columnFn: this.packetsColumn.bind(this) },
                software_bytes: {
                  columnFn: this.softwareBytesColumn.bind(this),
                },
                software_packets: {
                  columnFn: this.softwarePacketsColumn.bind(this),
                },
                asic_bytes: { columnFn: this.asicBytesColumn.bind(this) },
                asic_packets: { columnFn: this.asicPacketsColumn.bind(this) },
                nturbo_bytes: { columnFn: this.nturboBytesColumn.bind(this) },
                nturbo_packets: {
                  columnFn: this.nturboPacketsColumn.bind(this),
                },
                last_used: { columnFn: this.lastUsedColumn.bind(this) },
                first_used: { columnFn: this.firstUsedColumn.bind(this) },
                active_sessions: {
                  columnFn: this.activeSessionsColumn.bind(this),
                },
                hit_count: { columnFn: this.hitCountColumn.bind(this) },
                packets_dropped: {
                  columnFn: this.packetsDroppedColumn.bind(this),
                },
                "inspection-mode": {
                  columnFn: this.inspectionModeColumnFactory(n, i),
                },
                comments: { columnFn: this.commentsColumn.bind(this) },
                "intf-pair": { columnFn: this.hiddenIntfPairColumn.bind(this) },
                "global-label": {
                  columnFn: this.hiddenSequenceGroupingLabelColumn.bind(this),
                },
                "policy-expiry-date": {
                  columnFn: this.policyExpiryDateColumn.bind(this),
                },
                "policy-behaviour-type": {
                  columnFn: this.policyBehaviourType.bind(this),
                },
                "ztna-status": { columnFn: this.ztnaStatusColumn.bind(this) },
                "ztna-ems-tag": {
                  columnFn: this.ztnaEmsTagColumnFactory(
                    void 0,
                    void 0,
                    void 0,
                    s,
                  ),
                },
                "ztna-ems-tag-secondary": {
                  columnFn: this.ztnaEmsTagColumnFactory(
                    "ztna-ems-tag-secondary",
                    "Secondary Security Posture Tag",
                    "ztna-ems-tag-secondary",
                    s,
                  ),
                },
              },
              P = yield this.getCandidateColumns();
            if (!Array.isArray(P))
              throw new Error(
                `Policy type "${this.viewTypeManager.type}" isn't supported`,
              );
            const N = [];
            for (const L of P) {
              const J = h[L],
                Q = null == J ? void 0 : J.columnFn;
              "function" == typeof Q &&
                this.visible(L, n, l) &&
                N.push(yield Q.call(this, o, l));
            }
            return N;
          });
        }
        policyIdColumn() {
          return V.Um.getPolicyIdColumn();
        }
        policyOmniColumn(o) {
          const t =
            this.viewTypeManager.type === ie.a.SecurityPolicy
              ? o.securityPolicy
              : o.firewallPolicy;
          return new y.b7({
            id: "policy",
            fixed: !0,
            langKey: "Policy",
            omniSources: new Set([t]),
            cellValueFunction: (i) => [
              { [_.go]: String(i.policyId), [_.Hx]: t },
            ],
            externalFilterCreationFunction: (i) => {
              const n = { logic: i.negated ? p.tk.And : p.tk.Or, filters: [] };
              return (
                i.matchedOmniReferences.length &&
                  (n.filters = i.matchedOmniReferences.map((l) => ({
                    key: "policyid",
                    type: p.NM.String,
                    negate: i.negated,
                    operator: p.pg.Exact,
                    pattern: l[_.go],
                  }))),
                n
              );
            },
          });
        }
        policyStandardColumn() {
          return new y.EH({
            id: "policy",
            fixed: !0,
            langKey: "Policy",
            cellValueFunction: (o) => (0, _.mC)(o[p.O3], "name"),
            cellFormatter: (o, t, i) => {
              const n = [];
              return (
                o.disabled && n.push(new f.le(z.oc)),
                o.warnings.length > 0 && n.push(new f.le(z.$I)),
                n.push((0, Ce.elem)("span", { textContent: i })),
                (0, Ce.elem)("span", { className: Ie }, { children: n })
              );
            },
            onCellRendered: function (o, t, i) {
              const l = o.querySelector(`.${Ie}`);
              l && this.addComponentTooltipToElement(l, i, v.I);
            },
            externalFilterCreationFunction: (o) => {
              const t = { logic: o.negated ? p.tk.And : p.tk.Or, filters: [] };
              for (const i of o.filterValues) {
                const n = /( \((\d*)\))?(?!.*\1)/.exec(i),
                  l = null == n ? void 0 : n.at(2);
                n && l
                  ? t.filters.push({
                      key: "policyid",
                      type: p.NM.String,
                      negate: o.negated,
                      operator: p.pg.Exact,
                      pattern: l,
                    })
                  : (t.filters.push({
                      key: "policyid",
                      type: p.NM.String,
                      negate: o.negated,
                      operator: p.pg.Exact,
                      pattern: i,
                    }),
                    t.filters.push({
                      key: "name",
                      type: p.NM.String,
                      negate: o.negated,
                      operator:
                        o.filterType === y.vA.Exact
                          ? p.pg.Exact
                          : p.pg.Contains,
                      pattern: i,
                    }));
              }
              return t;
            },
          });
        }
        nameColumn() {
          return V.Um.nameColumn(this.translation, this.fortigate, this.http);
        }
        srcintfColumn(o) {
          var t;
          return (0, d.mG)(this, void 0, void 0, function* () {
            return yield V.Um.srcintfColumn(
              this.fortigate,
              o.firewallInterface,
              this.viewTypeManager.type,
              {
                hidden:
                  null === (t = this.viewTypeManager) || void 0 === t
                    ? void 0
                    : t.interfacePairView,
                cellValueFunction: (i) => {
                  var n, l;
                  return this.sourceManager.getVisibleInterfaceOmniSourceEntryReferences(
                    null !==
                      (l =
                        null === (n = i.data) || void 0 === n
                          ? void 0
                          : n.srcintf) && void 0 !== l
                      ? l
                      : [],
                  );
                },
                externalFilterCreationFunction: (i) => {
                  const n = {
                    logic: i.negated ? p.tk.And : p.tk.Or,
                    filters: [],
                  };
                  if (i.matchedOmniReferences.length)
                    n.filters = i.matchedOmniReferences.map((l) => ({
                      key: "srcintf",
                      type: p.NM.String,
                      negate: i.negated,
                      operator: p.pg.Contains,
                      pattern: l[_.go],
                    }));
                  else
                    for (const l of i.filterValues)
                      n.filters.push({
                        key: "srcintf",
                        type: p.NM.String,
                        pattern: l,
                        negate: i.negated,
                        operator:
                          i.filterType === y.vA.Exact
                            ? p.pg.Exact
                            : p.pg.Contains,
                      });
                  return n;
                },
                editable: (i) =>
                  !i.implicit && !i.isZTNAFirewallPolicy() && !ae(i),
                editableRequired: !0,
                editableStartCallback: (i) => {
                  var n;
                  null ===
                    (n = this.sourceManager.sourceInterfaceSelectSource) ||
                    void 0 === n ||
                    n.setContext({ policyEntry: i });
                },
                editableOmniSelectSources: [
                  this.sourceManager.sourceInterfaceSelectSource,
                ],
              },
            );
          });
        }
        dstintfColumn(o) {
          var t;
          return (0, d.mG)(this, void 0, void 0, function* () {
            return V.Um.dstintfColumn(
              this.fortigate,
              o.firewallInterface,
              this.viewTypeManager.type,
              {
                hidden:
                  null === (t = this.viewTypeManager) || void 0 === t
                    ? void 0
                    : t.interfacePairView,
                cellValueFunction: (i) => {
                  var n, l;
                  return this.sourceManager.getVisibleInterfaceOmniSourceEntryReferences(
                    null !==
                      (l =
                        null === (n = i.data) || void 0 === n
                          ? void 0
                          : n.dstintf) && void 0 !== l
                      ? l
                      : [],
                  );
                },
                externalFilterCreationFunction: (i) => {
                  const n = {
                    logic: i.negated ? p.tk.And : p.tk.Or,
                    filters: [],
                  };
                  if (i.matchedOmniReferences.length)
                    n.filters = i.matchedOmniReferences.map((l) => ({
                      key: "dstintf",
                      type: p.NM.String,
                      negate: i.negated,
                      operator: p.pg.Contains,
                      pattern: l[_.go],
                    }));
                  else
                    for (const l of i.filterValues)
                      n.filters.push({
                        key: "dstintf",
                        type: p.NM.String,
                        pattern: l,
                        negate: i.negated,
                        operator:
                          i.filterType === y.vA.Exact
                            ? p.pg.Exact
                            : p.pg.Contains,
                      });
                  return n;
                },
                editable: (i) =>
                  !i.implicit && !i.isZTNAFirewallPolicy() && !ae(i),
                editableRequired: !0,
                editableStartCallback: (i) => {
                  var n;
                  null ===
                    (n = this.sourceManager.destinationInterfaceSelectSource) ||
                    void 0 === n ||
                    n.setContext({ policyEntry: i });
                },
                editableOmniSelectSources: [
                  this.sourceManager.destinationInterfaceSelectSource,
                ],
              },
            );
          });
        }
        consolidatedSrcaddrColumn(o) {
          return (0, d.mG)(this, void 0, void 0, function* () {
            const t = this;
            return new y.b7({
              id: "consolidated-srcaddr",
              langKey: "src_addr",
              filtering: !0,
              collectionLimit: V.so,
              omniSources: new Set(
                this.sourceManager.getConsolidatedSrcaddrOmniSources(),
              ),
              cellValueFunction: (i) =>
                this.sourceManager.getVisibleConsolidatedSourceOmniSourceEntryReferences(
                  i.consolidatedSrcaddr,
                  i,
                ),
              externalFilterCreationFunction: (i) => {
                const n = {
                  logic: i.negated ? p.tk.And : p.tk.Or,
                  filters: [],
                };
                if (i.matchedOmniReferences.length) {
                  const l = new Set();
                  n.filters = i.matchedOmniReferences.reduce((a, s) => {
                    const u =
                        this.sourceManager.getConsolidatedSourcePolicyPropertyFromSource(
                          s[_.Hx],
                        ),
                      g = `${null != u ? u : ""}#${s[_.go]}`;
                    return (
                      u &&
                        !l.has(g) &&
                        (l.add(g),
                        a.push({
                          key: u,
                          type: p.NM.String,
                          pattern: s[_.go],
                          negate: i.negated,
                          operator: p.pg.Contains,
                        })),
                      a
                    );
                  }, []);
                } else
                  for (const l of i.filterValues)
                    (n.filters.push({
                      key: "srcaddr",
                      type: p.NM.String,
                      pattern: l,
                      negate: i.negated,
                      operator:
                        i.filterType === y.vA.Exact
                          ? p.pg.Exact
                          : p.pg.Contains,
                    }),
                      n.filters.push({
                        key: "srcaddr6",
                        type: p.NM.String,
                        pattern: l,
                        negate: i.negated,
                        operator:
                          i.filterType === y.vA.Exact
                            ? p.pg.Exact
                            : p.pg.Contains,
                      }));
                return n;
              },
              collectionEntryOnRender: function (i, n, l) {
                var a, s;
                const u = this.entry;
                (("enable" ===
                  (null === (a = u.data) || void 0 === a
                    ? void 0
                    : a["srcaddr-negate"]) &&
                  (0, oe.xi)(n)) ||
                  ("enable" ===
                    (null === (s = u.data) || void 0 === s
                      ? void 0
                      : s["srcaddr6-negate"]) &&
                    (0, oe.Qm)(n))) &&
                  V.Um.prependNegateIcon(t.translation, i, this, l.langKey);
              },
              editable: (i) =>
                !i.implicit &&
                !i.isLearnModePolicy() &&
                !ae(i) &&
                (this.ipv6Enabled ||
                  (!this.ipv6Enabled && !i.hasIpv6Address())),
              editableStartCallback: (i) => {
                o(i);
              },
              editableOmniSelectSources:
                this.sourceManager.getConsolidatedSrcaddrSelectSources(),
              editableOmniSelectSettings: Fe.P.getSettings(
                this.viewTypeManager.type,
                "consolidated-srcaddr",
                {
                  createNew:
                    (yield this.fortigate.admin.adminHasWritePermission(
                      Ve.Z0.FIREWALL,
                    )) &&
                    (yield this.fortigate.admin.adminHasWritePermission(
                      Ve.Z0.SYSTEM,
                    )),
                },
              ),
              editableValidateFunction: (i, n) =>
                (0, d.mG)(this, void 0, void 0, function* () {
                  const a = {
                    trafficDirection: Ot.zU.TrafficDirection.Source,
                    addrCounterparts: n.consolidatedSrcaddr,
                    isNafEnabled: n.isNafEnabled(),
                  };
                  return (
                    this.sourceManager.validateIpVersionMatch(i, a) ||
                    (0, it.T2)(
                      i,
                      this.sourceManager.getConsolidatedSrcaddrSelectSources(),
                    )
                  );
                }),
            });
          });
        }
        consolidatedSourceColumn(o) {
          return (0, d.mG)(this, void 0, void 0, function* () {
            return V.Um.consolidatedSourceColumn(
              this.fortigate,
              this.translation,
              this.viewTypeManager.type,
              {
                id: "consolidated-source",
                omniSources: new Set(
                  this.sourceManager.getConsolidatedSourceOmniSources(),
                ),
                cellValueFunction: (t) =>
                  this.sourceManager.getVisibleConsolidatedSourceOmniSourceEntryReferences(
                    t.getConsolidatedSource(),
                    t,
                  ),
                externalFilterCreationFunction: (t) => {
                  const i = {
                    logic: t.negated ? p.tk.And : p.tk.Or,
                    filters: [],
                  };
                  if (t.matchedOmniReferences.length) {
                    const n = new Set();
                    i.filters = t.matchedOmniReferences.reduce((l, a) => {
                      const s =
                          this.sourceManager.getConsolidatedSourcePolicyPropertyFromSource(
                            a[_.Hx],
                          ),
                        u = `${null != s ? s : ""}#${a[_.go]}`;
                      return (
                        s &&
                          !n.has(u) &&
                          (n.add(u),
                          l.push({
                            key: s,
                            type: p.NM.String,
                            pattern: a[_.go],
                            negate: t.negated,
                            operator: p.pg.Contains,
                          })),
                        l
                      );
                    }, []);
                  } else
                    for (const n of t.filterValues)
                      (i.filters.push({
                        key: "srcaddr",
                        type: p.NM.String,
                        pattern: n,
                        negate: t.negated,
                        operator:
                          t.filterType === y.vA.Exact
                            ? p.pg.Exact
                            : p.pg.Contains,
                      }),
                        i.filters.push({
                          key: "srcaddr6",
                          type: p.NM.String,
                          pattern: n,
                          negate: t.negated,
                          operator:
                            t.filterType === y.vA.Exact
                              ? p.pg.Exact
                              : p.pg.Contains,
                        }));
                  return i;
                },
                bulkEditable: !0,
                editable: (t) =>
                  !t.implicit &&
                  !t.isLearnModePolicy() &&
                  (!t.policyExpired || !t.policyExpired()) &&
                  (this.ipv6Enabled ||
                    (!this.ipv6Enabled && !t.hasIpv6Address())),
                editableStartCallback: (t) => {
                  (o(t),
                    this.sourceManager.updateConsolidatedSourceSelectSourcesPolicyContext(
                      { policyEntry: t },
                    ));
                },
                editableOmniSelectSources:
                  this.sourceManager.getConsolidatedSourceSelectSources(),
                editableRequired: !0,
                editableValidateFunction: (t, i) =>
                  (0, d.mG)(this, void 0, void 0, function* () {
                    return (
                      (yield (0, Et.wh)({
                        sourceManager: this.sourceManager,
                        entrySet: t,
                        policy: i,
                        trafficDirection: tt.a7.Source,
                      })) ||
                      (0, it.T2)(
                        t,
                        this.sourceManager.getConsolidatedSourceSelectSources(),
                      )
                    );
                  }),
              },
            );
          });
        }
        consolidatedDstaddrColumn(o) {
          return (0, d.mG)(this, void 0, void 0, function* () {
            const t = this;
            return new y.b7({
              id: "consolidated-dstaddr",
              langKey: "field_dstaddr",
              filtering: !0,
              collectionLimit: V.so,
              omniSources: new Set(
                this.sourceManager.getConsolidatedDstaddrOmniSources(),
              ),
              cellValueFunction: (i) =>
                this.sourceManager.getVisibleConsolidatedDestinationOmniSourceEntryReferences(
                  i.consolidatedDstaddr,
                  i,
                ),
              externalFilterCreationFunction: (i) => {
                const n = {
                  logic: i.negated ? p.tk.And : p.tk.Or,
                  filters: [],
                };
                if (i.matchedOmniReferences.length) {
                  const l = new Set();
                  n.filters = i.matchedOmniReferences.reduce((a, s) => {
                    const u =
                        this.sourceManager.getConsolidatedDestinationPolicyPropertyFromSource(
                          s[_.Hx],
                        ),
                      g = `${null != u ? u : ""}#${s[_.go]}`;
                    return (
                      u &&
                        !l.has(g) &&
                        (l.add(g),
                        a.push({
                          key: u,
                          type: p.NM.String,
                          pattern: s[_.go],
                          negate: i.negated,
                          operator: p.pg.Contains,
                        })),
                      a
                    );
                  }, []);
                } else
                  for (const l of i.filterValues)
                    (n.filters.push({
                      key: "dstaddr",
                      type: p.NM.String,
                      pattern: l,
                      negate: i.negated,
                      operator:
                        i.filterType === y.vA.Exact
                          ? p.pg.Exact
                          : p.pg.Contains,
                    }),
                      n.filters.push({
                        key: "dstaddr6",
                        type: p.NM.String,
                        pattern: l,
                        negate: i.negated,
                        operator:
                          i.filterType === y.vA.Exact
                            ? p.pg.Exact
                            : p.pg.Contains,
                      }));
                return n;
              },
              collectionEntryOnRender: function (i, n, l) {
                var a, s;
                const u = this.entry;
                (("enable" ===
                  (null === (a = u.data) || void 0 === a
                    ? void 0
                    : a["srcaddr-negate"]) &&
                  (0, oe.xi)(n)) ||
                  ("enable" ===
                    (null === (s = u.data) || void 0 === s
                      ? void 0
                      : s["srcaddr6-negate"]) &&
                    (0, oe.Qm)(n))) &&
                  V.Um.prependNegateIcon(t.translation, i, this, l.langKey);
              },
              editable: (i) =>
                !i.implicit &&
                !i.isLearnModePolicy() &&
                !i.isZTNAFirewallPolicy() &&
                !ae(i) &&
                (this.ipv6Enabled ||
                  (!this.ipv6Enabled && !i.hasIpv6Address())),
              editableStartCallback: (i) => {
                o(i);
              },
              editableOmniSelectSources:
                this.sourceManager.getConsolidatedDstaddrSelectSources(),
              editableOmniSelectSettings: Fe.P.getSettings(
                this.viewTypeManager.type,
                "consolidated-dstaddr",
                {
                  createNew:
                    (yield this.fortigate.admin.adminHasWritePermission(
                      Ve.Z0.FIREWALL,
                    )) &&
                    (yield this.fortigate.admin.adminHasWritePermission(
                      Ve.Z0.SYSTEM,
                    )),
                },
              ),
              editableValidateFunction: (i, n) =>
                (0, d.mG)(this, void 0, void 0, function* () {
                  const a = {
                    trafficDirection: Ot.zU.TrafficDirection.Destination,
                    addrCounterparts: n.consolidatedDstaddr,
                    isNafEnabled: n.isNafEnabled(),
                  };
                  let s = this.sourceManager.validateIpVersionMatch(i, a);
                  return (
                    s ||
                      (s = yield (0, it.T2)(
                        i,
                        this.sourceManager.getConsolidatedDstaddrSelectSources(),
                      )),
                    s ||
                      (s = (0, Lt.YW)({
                        entries: Array.from(i.values()),
                        getPolicy: () => n,
                      })),
                    s
                  );
                }),
            });
          });
        }
        consolidatedDestinationColumn(o) {
          return (0, d.mG)(this, void 0, void 0, function* () {
            return V.Um.consolidatedDestinationColumn(
              this.fortigate,
              this.translation,
              this.viewTypeManager.type,
              {
                id: "consolidated-destination",
                omniSources: new Set(
                  this.sourceManager.getConsolidatedDestinationOmniSources(),
                ),
                cellValueFunction: (t) =>
                  this.sourceManager.getVisibleConsolidatedDestinationOmniSourceEntryReferences(
                    t.getConsolidatedDestination(),
                    t,
                  ),
                externalFilterCreationFunction: (t) => {
                  const i = {
                    logic: t.negated ? p.tk.And : p.tk.Or,
                    filters: [],
                  };
                  if (t.matchedOmniReferences.length) {
                    const n = new Set();
                    i.filters = t.matchedOmniReferences.reduce((l, a) => {
                      const s =
                          this.sourceManager.getConsolidatedDestinationPolicyPropertyFromSource(
                            a[_.Hx],
                          ),
                        u = `${null != s ? s : ""}#${a[_.go]}`;
                      return (
                        s &&
                          !n.has(u) &&
                          (n.add(u),
                          l.push({
                            key: s,
                            type: p.NM.String,
                            pattern: a[_.go],
                            negate: t.negated,
                            operator: p.pg.Contains,
                          })),
                        l
                      );
                    }, []);
                  } else
                    for (const n of t.filterValues)
                      (i.filters.push({
                        key: "dstaddr",
                        type: p.NM.String,
                        pattern: n,
                        negate: t.negated,
                        operator:
                          t.filterType === y.vA.Exact
                            ? p.pg.Exact
                            : p.pg.Contains,
                      }),
                        i.filters.push({
                          key: "dstaddr6",
                          type: p.NM.String,
                          pattern: n,
                          negate: t.negated,
                          operator:
                            t.filterType === y.vA.Exact
                              ? p.pg.Exact
                              : p.pg.Contains,
                        }));
                  return i;
                },
                bulkEditable: !0,
                editable: (t) =>
                  !t.implicit &&
                  !t.isLearnModePolicy() &&
                  !t.isZTNAFirewallPolicy() &&
                  (!t.policyExpired || !t.policyExpired()) &&
                  (this.ipv6Enabled ||
                    (!this.ipv6Enabled && !t.hasIpv6Address())),
                editableStartCallback: (t) => {
                  (o(t),
                    this.sourceManager.updateConsolidatedDestinationSelectSourcesPolicyContext(
                      { policyEntry: t },
                    ));
                },
                editableOmniSelectSources:
                  this.sourceManager.getConsolidatedDestinationSelectSources(),
                editableValidateFunction: (t, i) =>
                  (0, d.mG)(this, void 0, void 0, function* () {
                    let n = yield (0, Et.wh)({
                      sourceManager: this.sourceManager,
                      entrySet: t,
                      policy: i,
                      trafficDirection: tt.a7.Destination,
                    });
                    return (
                      n ||
                        (n = yield (0, it.T2)(
                          t,
                          this.sourceManager.getConsolidatedDestinationSelectSources(),
                        )),
                      n ||
                        (n = (0, Lt.YW)({
                          entries: Array.from(t.values()),
                          getPolicy: () => i,
                        })),
                      n
                    );
                  }),
              },
            );
          });
        }
        natColumn() {
          const o = this.sourceManager.centralNatEnabled.includeNgfwCheck,
            t = this.translation.translate("Custom"),
            i = this.translation.translate(
              "Central NAT is enabled so NAT settings from matching Central SNAT policies will be applied.",
            ),
            n = {
              disabled: this.translation.translate("Disabled"),
              nat: this.translation.translate("field_nat"),
              nat46: this.translation.translate("NAT46"),
              nat64: this.translation.translate("NAT64"),
            };
          return new y.EH({
            id: "nat",
            langKey: "field_nat",
            filtering: !o,
            cellValueFunction: (l) => {
              var a, s, u, g;
              return "deny" ===
                (null === (a = l.data) || void 0 === a ? void 0 : a.action)
                ? ""
                : o
                  ? t
                  : "enable" ===
                      (null === (s = l.data) || void 0 === s ? void 0 : s.nat)
                    ? n.nat
                    : "enable" ===
                        (null === (u = l.data) || void 0 === u
                          ? void 0
                          : u.nat64)
                      ? n.nat64
                      : "enable" ===
                          (null === (g = l.data) || void 0 === g
                            ? void 0
                            : g.nat46)
                        ? n.nat46
                        : n.disabled;
            },
            cellFormatter: (l, a, s) => {
              var u, g, h, P;
              if (
                "deny" ===
                (null === (u = l.data) || void 0 === u ? void 0 : u.action)
              )
                return s;
              if (
                "enable" ===
                (null === (g = l.data) || void 0 === g ? void 0 : g.nat46)
              )
                return (0, Ce.elem)("span", void 0, {
                  children: [
                    new f.le(z.nI),
                    (0, Ce.elem)("span", { textContent: "NAT46" }),
                  ],
                });
              if (
                "enable" ===
                (null === (h = l.data) || void 0 === h ? void 0 : h.nat64)
              )
                return (0, Ce.elem)("span", void 0, {
                  children: [
                    new f.le(z.nI),
                    (0, Ce.elem)("span", { textContent: "NAT64" }),
                  ],
                });
              if (o) {
                const N = [new f.le(z.V0)];
                return (
                  N.push((0, Ce.elem)("span", { textContent: s })),
                  (0, Ce.elem)("span", { className: Ie }, { children: N })
                );
              }
              {
                const N =
                  "enable" ===
                  (null === (P = l.data) || void 0 === P ? void 0 : P.nat)
                    ? z.nI
                    : z.oc;
                return (0, Ce.elem)("span", void 0, {
                  children: [
                    new f.le(N),
                    (0, Ce.elem)("span", { textContent: s }),
                  ],
                });
              }
            },
            onCellRendered: function (l, a) {
              var s;
              if (
                a.implicit ||
                !o ||
                "deny" ===
                  (null === (s = a.data) || void 0 === s ? void 0 : s.action)
              )
                return;
              const g = l.querySelector(`.${Ie}`);
              g && this.addSimpleTooltipToElement(g, { message: i });
            },
            editable: (l) => {
              var a;
              return !(
                l.implicit ||
                o ||
                "accept" !==
                  (null === (a = l.data) || void 0 === a ? void 0 : a.action) ||
                [l.data.nat46, l.data.nat64].includes("enable") ||
                ae(l)
              );
            },
            editableType: y.zT.Selection,
            editableOptions: [
              new y.j4({ label: n.nat, entryValue: "enable" }),
              new y.j4({ label: n.disabled, entryValue: "disable" }),
            ],
            externalFilterCreationFunction: (l) => {
              const s = Object.values(n).filter((h) => (0, Yn.yz)(h, l));
              return {
                filters: ["nat", "nat46", "nat64"].reduce(
                  (h, P) => (
                    !s.includes(n.disabled) &&
                      s.includes(n[P]) &&
                      h.push({
                        key: P,
                        type: p.NM.String,
                        operator: p.pg.Exact,
                        pattern: "enable",
                      }),
                    s.includes(n.disabled) &&
                      !s.includes(n[P]) &&
                      h.push({
                        key: P,
                        type: p.NM.String,
                        operator: p.pg.Exact,
                        pattern: "disable",
                      }),
                    h
                  ),
                  [],
                ),
                logic: s.includes(n.disabled) ? p.tk.And : p.tk.Or,
              };
            },
          });
        }
        consolidatedPoolnameColumn() {
          const o = this.sourceManager.centralNatEnabled.includeNgfwCheck;
          return new y.b7({
            id: "consolidated-poolname",
            langKey: "IP Pool",
            filtering: !0,
            omniSources: new Set(this.sourceManager.getIppoolOmniSources()),
            cellValueFunction: (t) => {
              let i = [];
              return (
                t.consolidatedPoolname.length > 0 &&
                  (i = t.consolidatedPoolname.map((n) => ({
                    [_.go]: n.q_origin_key,
                    [_.Hx]: this.sourceManager.getIppoolOmniSource(
                      n.datasource,
                    ),
                  }))),
                i
              );
            },
            editable: (t) => {
              var i, n, l, a;
              return (
                !t.implicit &&
                !o &&
                "accept" ===
                  (null === (i = t.data) || void 0 === i ? void 0 : i.action) &&
                ("enable" ===
                  (null === (n = t.data) || void 0 === n ? void 0 : n.nat) ||
                  "enable" ===
                    (null === (l = t.data) || void 0 === l
                      ? void 0
                      : l.nat64) ||
                  "enable" ===
                    (null === (a = t.data) || void 0 === a
                      ? void 0
                      : a.nat46)) &&
                !ae(t) &&
                (this.ipv6Enabled || (!this.ipv6Enabled && !t.hasIpv6Address()))
              );
            },
            editableOmniSelectSources:
              this.sourceManager.getIppoolSelectSources(),
            editableOmniSelectSettings: Fe.P.getSettings(
              this.viewTypeManager.type,
              "consolidated-poolname",
            ),
            editableStartCallback: (t) => {
              var i, n;
              (null === (i = this.sourceManager.ippoolSelectSource) ||
                void 0 === i ||
                i.setContext({ policyEntry: t }),
                null === (n = this.sourceManager.ippool6SelectSource) ||
                  void 0 === n ||
                  n.setContext({ policyEntry: t }));
            },
            editableValidateFunction: (t, i) =>
              Promise.resolve((0, jn.It)(this.translation, i, t)),
            externalFilterCreationFunction(t) {
              const i = {
                logic:
                  t.negated || t.filterType === y.vA.Exact ? p.tk.And : p.tk.Or,
                filters: [],
              };
              if (!t.forSection)
                if (t.matchedOmniReferences.length)
                  i.filters = t.matchedOmniReferences.map((n) => ({
                    key: n[_.Hx] instanceof kn.tE ? "poolname" : "poolname6",
                    type: p.NM.String,
                    negate: t.negated,
                    operator: p.pg.Contains,
                    pattern: n[_.go],
                  }));
                else
                  for (const n of t.filterValues)
                    (i.filters.push({
                      key: "poolname",
                      type: p.NM.String,
                      pattern: n,
                      negate: t.negated,
                      operator:
                        t.filterType === y.vA.Exact
                          ? p.pg.Exact
                          : p.pg.Contains,
                    }),
                      i.filters.push({
                        key: "poolname6",
                        type: p.NM.String,
                        pattern: n,
                        negate: t.negated,
                        operator:
                          t.filterType === y.vA.Exact
                            ? p.pg.Exact
                            : p.pg.Contains,
                      }));
              return i;
            },
          });
        }
        scheduleColumn() {
          return (0, d.mG)(this, void 0, void 0, function* () {
            return yield V.Um.scheduleColumn(
              this.fortigate,
              this.viewTypeManager.type,
              new Set(this.sourceManager.getScheduleOmniSources()),
              this.sourceManager.getScheduleOmniSource.bind(this.sourceManager),
              {
                editable: (o) =>
                  !o.implicit && !o.isLearnModePolicy() && !ae(o),
                editableOmniSelectSources:
                  this.sourceManager.getScheduleSelectSources(),
              },
            );
          });
        }
        gtpProfileColumn(o) {
          return new y.b7({
            id: "gtp-profile",
            langKey: "GTP",
            filtering: !0,
            omniSources: new Set([o.firewallGtpProfile]),
            cellValueFunction: (t) => {
              var i;
              let n = [];
              return (
                !(null === (i = t.data) || void 0 === i) &&
                  i["gtp-profile"] &&
                  (n = [
                    {
                      [_.go]: (0, X.xP)(t.data["gtp-profile"]),
                      [_.Hx]: o.firewallGtpProfile,
                    },
                  ]),
                n
              );
            },
            editable: (t) => !t.implicit,
            editableOmniSelectSources:
              this.sourceManager.getGtpProfileSelectSources(),
            editableOmniSelectSettings: this.selectConfig.getSettings({
              property: "gtp-profile",
              policyType: this.viewTypeManager.type,
            }),
          });
        }
        serviceColumn() {
          const o = this.translation;
          return V.Um.serviceColumn(
            this.translation,
            this.viewTypeManager.type,
            new Set(this.sourceManager.getServiceOmniSources()),
            this.sourceManager.getServiceOmniSource.bind(this.sourceManager),
            {
              externalFilterCreationFunction: (t) => {
                const i = {
                  logic: t.negated ? p.tk.And : p.tk.Or,
                  filters: [],
                };
                return (
                  t.filterValues.some((l) => {
                    const a = o.translate("App default");
                    return t.filterType === y.vA.Exact
                      ? a === l
                      : a.includes(l);
                  }) &&
                    i.filters.push({
                      key: "enforce-default-app-port",
                      type: p.NM.String,
                      negate: t.negated,
                      operator: p.pg.Exact,
                      pattern: "enable",
                    }),
                  t.matchedOmniReferences.length &&
                    i.filters.push(
                      ...t.matchedOmniReferences.map((l) => ({
                        key: "service",
                        type: p.NM.String,
                        negate: t.negated,
                        operator: p.pg.Contains,
                        pattern: l[_.go],
                      })),
                    ),
                  i
                );
              },
              editable: (t) =>
                !(
                  t.internetServiceEnabled ||
                  t.implicit ||
                  t.isLearnModePolicy() ||
                  t.isZTNAFirewallPolicy() ||
                  ae(t)
                ),
              editableStartCallback: (t) => {
                var i, n;
                (null === (i = this.sourceManager.customServiceSelectSource) ||
                  void 0 === i ||
                  i.setContext({
                    policyEntry: t,
                    policyType: this.viewTypeManager.type,
                  }),
                  null === (n = this.sourceManager.serviceGroupSelectSource) ||
                    void 0 === n ||
                    n.setContext({
                      policyEntry: t,
                      policyType: this.viewTypeManager.type,
                    }));
              },
              editableOmniSelectSources:
                this.sourceManager.getServiceSelectSources(),
              collectionEntryOnRender: function (t, i, n) {
                (this.entry instanceof me.j || this.entry instanceof Be.P) &&
                  this.entry.isServiceNegated &&
                  V.Um.prependNegateIcon(o, t, this, n.langKey);
              },
            },
          );
        }
        applicationsColumn(o, t) {
          return new y.Ni({
            id: "applications",
            langKey: "field_application",
            filtering: !0,
            omniSources: new Set(
              this.sourceManager.getApplicationOmnisources(),
            ),
            cellWidth: 200,
            collectionCount: (i) => i.applications.length || 0,
            cellValueFunction: (i) =>
              (0, d.mG)(this, void 0, void 0, function* () {
                let n = [];
                return (
                  i.applications.length > 0 &&
                    ((!this.sourceManager.omniSources.applicationName
                      .sourceFullyLoaded ||
                      !this.sourceManager.omniSources.applicationCategory
                        .sourceFullyLoaded) &&
                      (yield (0, It.D)(
                        this.sourceManager.getPreloadDataApplicationsRequests(
                          o,
                          t,
                        ),
                      )),
                    (n = i.applications.map((l) => {
                      const a = this.sourceManager.getApplicationDatasource(l);
                      return {
                        [_.go]: this.sourceManager.getApplicationPrimaryKey(l),
                        [_.Hx]: this.sourceManager.getApplicationsOmniSource(a),
                      };
                    }))),
                  n
                );
              }),
            externalFilterCreationFunction: (i) => {
              const n = { logic: i.negated ? p.tk.And : p.tk.Or, filters: [] };
              return (
                i.matchedOmniReferences.length &&
                  (n.filters = i.matchedOmniReferences.reduce((l, a) => {
                    const s = parseInt(a[_.go], 10);
                    return (
                      (a[_.Hx] instanceof Jn.uM ||
                        a[_.Hx] instanceof Vn.L ||
                        a[_.Hx] instanceof Mt.eI) &&
                      Number.isSafeInteger(s)
                        ? l.push({
                            key:
                              a[_.Hx] instanceof Mt.eI
                                ? "app-category"
                                : "application",
                            type: p.NM.Number,
                            pattern: s,
                            negate: i.negated,
                            operator: p.pg.Contains,
                          })
                        : a[_.Hx] instanceof Bn.vV &&
                          l.push({
                            key: "app-group",
                            type: p.NM.String,
                            pattern: a[_.go],
                            negate: i.negated,
                            operator: p.pg.Contains,
                          }),
                      l
                    );
                  }, [])),
                n
              );
            },
            editable: (i) => !i.implicit && !i.isLearnModePolicy(),
            editableStartCallback: (i) => {
              var n, l, a;
              (null === (n = this.sourceManager.applicationNameSelectSource) ||
                void 0 === n ||
                n.setContext({ policyEntry: i }),
                null ===
                  (l = this.sourceManager.applicationCustomSelectSource) ||
                  void 0 === l ||
                  l.setContext({ policyEntry: i }),
                null ===
                  (a = this.sourceManager.applicationGroupSelectSource) ||
                  void 0 === a ||
                  a.setContext({ policyEntry: i }));
            },
            editableOmniSelectSources:
              this.sourceManager.getApplicationsSelectSources(),
            editableOmniSelectSettings: Fe.P.getSettings(
              this.viewTypeManager.type,
              "applications",
            ),
          });
        }
        urlCategoryColumn() {
          return new y.Ni({
            id: "url-category",
            langKey: "URL Category",
            filtering: !0,
            collectionCount: (o) => o.urlCategory.length,
            cellWidth: 150,
            omniSources: new Set(
              this.sourceManager.getUrlCategoryOmnisources(),
            ),
            cellValueFunction: (o) =>
              (0, d.mG)(this, void 0, void 0, function* () {
                this.sourceManager.preloadDataObservables.urlCategoryRequests &&
                  (yield (0, be.z)(
                    this.sourceManager.preloadDataObservables
                      .urlCategoryRequests,
                  ));
                let t = [];
                return (
                  o.urlCategory.length > 0 &&
                    (t = o.urlCategory.map((i) => ({
                      [_.go]: i.q_origin_key,
                      [_.Hx]: this.sourceManager.getUrlCategoryOmnisource(i),
                    }))),
                  t
                );
              }),
            editable: (o) => !o.implicit && !o.isLearnModePolicy(),
            editableOmniSelectSources:
              this.sourceManager.getUrlCategorySelectSources(),
            editableOmniSelectSettings: Fe.P.getSettings(
              this.viewTypeManager.type,
              "url-category",
            ),
          });
        }
        usersColumn(o) {
          return V.Um.usersColumn(
            o.localUser,
            o.certificateUser,
            this.viewTypeManager.type,
            {
              externalFilterCreationFunction: (t) => {
                const i = {
                  logic: t.negated ? p.tk.And : p.tk.Or,
                  filters: [],
                };
                if (t.matchedOmniReferences.length)
                  i.filters = t.matchedOmniReferences.map((n) => ({
                    key: "users",
                    type: p.NM.String,
                    negate: t.negated,
                    operator: p.pg.Contains,
                    pattern: n[_.go],
                  }));
                else
                  for (const n of t.filterValues)
                    i.filters.push({
                      key: "users",
                      type: p.NM.String,
                      pattern: n,
                      negate: t.negated,
                      operator:
                        t.filterType === y.vA.Exact
                          ? p.pg.Exact
                          : p.pg.Contains,
                    });
                return i;
              },
              editable: (t) => {
                var i;
                return (
                  "ipsec" !==
                    (null === (i = t.data) || void 0 === i
                      ? void 0
                      : i.action) &&
                  !t.implicit &&
                  !t.isLearnModePolicy() &&
                  !ae(t)
                );
              },
              editableStartCallback: (t) => {
                var i, n;
                (null === (i = this.sourceManager.localUserSelectSource) ||
                  void 0 === i ||
                  i.setContext({ policyEntry: t }),
                  null ===
                    (n = this.sourceManager.certificateUserSelectSource) ||
                    void 0 === n ||
                    n.setContext({ policyEntry: t }));
              },
              editableOmniSelectSources: [
                this.sourceManager.localUserSelectSource,
                this.sourceManager.certificateUserSelectSource,
              ],
            },
          );
        }
        groupsColumn(o) {
          return V.Um.groupsColumn(o.userGroup, this.viewTypeManager.type, {
            externalFilterCreationFunction: (t) => {
              const i = { logic: t.negated ? p.tk.And : p.tk.Or, filters: [] };
              if (t.matchedOmniReferences.length)
                i.filters = t.matchedOmniReferences.map((n) => ({
                  key: "groups",
                  type: p.NM.String,
                  negate: t.negated,
                  operator: p.pg.Contains,
                  pattern: n[_.go],
                }));
              else
                for (const n of t.filterValues)
                  i.filters.push({
                    key: "groups",
                    type: p.NM.String,
                    pattern: n,
                    negate: t.negated,
                    operator:
                      t.filterType === y.vA.Exact ? p.pg.Exact : p.pg.Contains,
                  });
              return i;
            },
            editable: (t) => {
              var i;
              return (
                "ipsec" !==
                  (null === (i = t.data) || void 0 === i ? void 0 : i.action) &&
                !t.implicit &&
                !t.isLearnModePolicy() &&
                !ae(t)
              );
            },
            editableStartCallback: (t) => {
              var i;
              null === (i = this.sourceManager.userGroupSelectSource) ||
                void 0 === i ||
                i.setContext({ policyEntry: t });
            },
            editableOmniSelectSources: [
              this.sourceManager.userGroupSelectSource,
            ],
            editableOmniSelectSettings: Fe.P.getSettings(
              this.viewTypeManager.type,
              "groups",
            ),
          });
        }
        vpntunnelColumn(o) {
          return new y.b7({
            id: "vpntunnel",
            langKey: "field_vpntunnel",
            filtering: !0,
            omniSources: new Set([
              this.sourceManager.omniSources.phase1,
              this.sourceManager.omniSources.manualKey,
            ]),
            cellValueFunction: (t) => {
              var i, n, l;
              let a = [];
              if (null !== (i = t.data) && void 0 !== i && i.vpntunnel) {
                const s = (0, X.qO)(
                  null === (n = t.data) || void 0 === n ? void 0 : n.vpntunnel,
                );
                s &&
                  (a = [
                    {
                      [_.go]: (0, X.xP)(
                        null === (l = t.data) || void 0 === l
                          ? void 0
                          : l.vpntunnel,
                      ),
                      [_.Hx]: this.sourceManager.getVpnTunnelOmniSource(s),
                    },
                  ]);
              }
              return a;
            },
            editable: (t) => {
              var i;
              return (
                "ipsec" ===
                  (null === (i = t.data) || void 0 === i ? void 0 : i.action) &&
                !t.implicit &&
                !ae(t)
              );
            },
            editableRequired: !0,
            editableStartCallback: (t) => {
              o(t);
            },
            editableOmniSelectSources:
              this.sourceManager.getVpnTunnelSelectSources(),
            editableOmniSelectSettings: Fe.P.getSettings(
              this.viewTypeManager.type,
              "vpntunnel",
            ),
          });
        }
        actionColumn() {
          return V.Um.actionColumn(this.translation, void 0, {
            editable: (o) => !o.implicit && !o.isLearnModePolicy() && !ae(o),
            externalFilterCreationFunction: (o) => {
              const t = V.Um.getActionColumnLangKeyMapping(this.translation),
                i = V.Um.generateReverseMap(t);
              return {
                logic: o.negated ? p.tk.And : p.tk.Or,
                filters: (() => {
                  const a = this.translation
                      .translate("Firewall::policyAction.learn")
                      .toLowerCase(),
                    s = o.filterType === y.vA.Exact,
                    u = o.filterValues.some((L) =>
                      s ? a === L.toLowerCase() : a.includes(L.toLowerCase()),
                    ),
                    g = [...i.entries()],
                    N = o.filterValues
                      .map((L) => {
                        var J;
                        return null ===
                          (J = g.find(([Q]) => {
                            const j = Q.toLowerCase(),
                              K = L.toLowerCase();
                            return (
                              j === K ||
                              !!(
                                o.filterType === y.vA.Contains &&
                                K.length >= 3 &&
                                j.includes(K)
                              )
                            );
                          })) || void 0 === J
                          ? void 0
                          : J.at(1);
                      })
                      .filter((L) => Boolean(L))
                      .map((L) => ({
                        key: "action",
                        type: p.NM.String,
                        pattern: L,
                        negate: o.negated,
                        operator:
                          o.filterType === y.vA.Exact
                            ? p.pg.Exact
                            : p.pg.Contains,
                      }));
                  return u
                    ? N.concat({
                        key: "learning-mode",
                        type: p.NM.String,
                        pattern: "enable",
                        negate: o.negated,
                        operator: p.pg.Exact,
                      })
                    : N;
                })(),
              };
            },
          });
        }
        logtrafficColumn(o, t) {
          return () =>
            V.Um.logtrafficColumn(
              o,
              this.translation,
              this.viewTypeManager.defaultSyncMode,
              this.ipv6Enabled,
              t,
              {
                editable: (i) =>
                  !this.viewTypeManager.defaultSyncMode &&
                  !i.isLearnModePolicy() &&
                  !ae(i),
              },
            );
        }
        profileColumnFactory(o) {
          return () =>
            V.Um.profileColumn(
              new Set(this.sourceManager.getProfileOmniSources()),
              this.sourceManager.getProfileOmniSource.bind(this.sourceManager),
              (t, i) => this.sourceManager.getVisibleProfiles(t, i, o),
              this.viewTypeManager.type,
              {
                externalFilterCreationFunction: (t) => ({
                  logic: t.negated ? p.tk.And : p.tk.Or,
                  filters: t.matchedOmniReferences.reduce((n, l) => {
                    const a =
                      this.sourceManager.getProfilePolicyPropertyFromSource(
                        l[_.Hx],
                      );
                    return (
                      a &&
                        n.push({
                          key: a,
                          type: p.NM.String,
                          pattern: l[_.go],
                          negate: t.negated,
                          operator: p.pg.Exact,
                        }),
                      n
                    );
                  }, []),
                }),
                bulkEditable: !0,
                editable: (t) => {
                  var i;
                  return (
                    !t.implicit &&
                    "deny" !==
                      (null === (i = t.data) || void 0 === i
                        ? void 0
                        : i.action) &&
                    !t.isLearnModePolicy() &&
                    !ae(t)
                  );
                },
                editableStartCallback: (t) => {
                  var i, n, l, a, s, u, g, h, P, N, L, J, Q, j, K, H;
                  (null === (i = this.sourceManager.avProfileSelectSource) ||
                    void 0 === i ||
                    i.setContext({ policyEntry: t }),
                    null === (n = this.sourceManager.wfProfileSelectSource) ||
                      void 0 === n ||
                      n.setContext({ policyEntry: t }),
                    null === (l = this.sourceManager.dfProfileSelectSource) ||
                      void 0 === l ||
                      l.setContext({ policyEntry: t }),
                    null === (a = this.sourceManager.appControlSelectSource) ||
                      void 0 === a ||
                      a.setContext({ policyEntry: t }),
                    null === (s = this.sourceManager.ipsSensorSelectSource) ||
                      void 0 === s ||
                      s.setContext({ policyEntry: t }),
                    null === (u = this.sourceManager.efProfileSelectSource) ||
                      void 0 === u ||
                      u.setContext({ policyEntry: t }),
                    null === (g = this.sourceManager.voipProfileSelectSource) ||
                      void 0 === g ||
                      g.setContext({ policyEntry: t }),
                    null === (h = this.sourceManager.icapProfileSelectSource) ||
                      void 0 === h ||
                      h.setContext({ policyEntry: t }),
                    null === (P = this.sourceManager.wafProfileSelectSource) ||
                      void 0 === P ||
                      P.setContext({ policyEntry: t }),
                    null ===
                      (N = this.sourceManager.sslSshProfileSelectSource) ||
                      void 0 === N ||
                      N.setContext({ policyEntry: t }),
                    null ===
                      (L = this.sourceManager.fileFilterProfileSelectSource) ||
                      void 0 === L ||
                      L.setContext({ policyEntry: t }),
                    null ===
                      (J = this.sourceManager.videoFilterProfileSelectSource) ||
                      void 0 === J ||
                      J.setContext({ policyEntry: t }),
                    null === (Q = this.sourceManager.dlpProfileSelectSource) ||
                      void 0 === Q ||
                      Q.setContext({ policyEntry: t }),
                    null === (j = this.sourceManager.casbProfileSelectSource) ||
                      void 0 === j ||
                      j.setContext({ policyEntry: t }),
                    null ===
                      (K = this.sourceManager.profileGroupSelectSource) ||
                      void 0 === K ||
                      K.setContext({ policyEntry: t }),
                    null ===
                      (H =
                        this.sourceManager.virtualPatchProfileSelectSource) ||
                      void 0 === H ||
                      H.setContext({ policyEntry: t }));
                },
                editableOmniSelectSources: (t) =>
                  this.sourceManager.getProfileSelectSources(t, o),
              },
            );
        }
        avProfileColumnFactory(o, t) {
          return (i) =>
            V.Um.avProfileColumn(i.avProfile, this.viewTypeManager.type, {
              cellValueFunction: (n) => {
                var l, a;
                let s = [];
                return (
                  !(null === (l = n.data) || void 0 === l) &&
                    l["av-profile"] &&
                    (s = this.sourceManager.getVisibleProfiles(
                      [
                        {
                          [_.go]: (0, X.xP)(
                            null === (a = n.data) || void 0 === a
                              ? void 0
                              : a["av-profile"],
                          ),
                          [_.Hx]: i.avProfile,
                        },
                      ],
                      n,
                      t,
                    )),
                  s
                );
              },
              editable: o,
              editableStartCallback: (n) => {
                var l;
                null === (l = this.sourceManager.avProfileSelectSource) ||
                  void 0 === l ||
                  l.setContext({ policyEntry: n });
              },
              editableOmniSelectSources: [
                this.sourceManager.avProfileSelectSource,
              ],
            });
        }
        webfilterProfileColumnFactory(o) {
          return (t) =>
            V.Um.webfilterProfileColumn(
              t.wfProfile,
              this.viewTypeManager.type,
              {
                editable: o,
                editableStartCallback: (i) => {
                  var n;
                  null === (n = this.sourceManager.wfProfileSelectSource) ||
                    void 0 === n ||
                    n.setContext({ policyEntry: i });
                },
                editableOmniSelectSources: [
                  this.sourceManager.wfProfileSelectSource,
                ],
              },
            );
        }
        dnsfilterProfileColumnFactory(o) {
          return (t) =>
            new y.b7({
              id: "dnsfilter-profile",
              langKey: "field_dnsfilter-profile",
              filtering: !0,
              omniSources: new Set([t.dfProfile]),
              cellValueFunction: (i) => {
                var n, l;
                let a = [];
                return (
                  !(null === (n = i.data) || void 0 === n) &&
                    n["dnsfilter-profile"] &&
                    (a = [
                      {
                        [_.go]: (0, X.xP)(
                          null === (l = i.data) || void 0 === l
                            ? void 0
                            : l["dnsfilter-profile"],
                        ),
                        [_.Hx]: t.dfProfile,
                      },
                    ]),
                  a
                );
              },
              editable: o,
              editableStartCallback: (i) => {
                var n;
                null === (n = this.sourceManager.dfProfileSelectSource) ||
                  void 0 === n ||
                  n.setContext({ policyEntry: i });
              },
              editableOmniSelectSources: [
                this.sourceManager.dfProfileSelectSource,
              ],
              editableOmniSelectSettings: Fe.P.getSettings(
                this.viewTypeManager.type,
                "dnsfilter-profile",
              ),
            });
        }
        applicationListColumnFactory(o) {
          return (t) =>
            V.Um.applicationListColumn(
              t.appControl,
              this.viewTypeManager.type,
              {
                cellValueFunction: (i) => {
                  var n, l;
                  let a = [];
                  return (
                    !(null === (n = i.data) || void 0 === n) &&
                      n["application-list"] &&
                      (a = [
                        {
                          [_.go]: (0, X.xP)(
                            null === (l = i.data) || void 0 === l
                              ? void 0
                              : l["application-list"],
                          ),
                          [_.Hx]: t.appControl,
                        },
                      ]),
                    a
                  );
                },
                editable: o,
                editableStartCallback: (i) => {
                  var n;
                  null === (n = this.sourceManager.appControlSelectSource) ||
                    void 0 === n ||
                    n.setContext({ policyEntry: i });
                },
                editableOmniSelectSources: [
                  this.sourceManager.appControlSelectSource,
                ],
              },
            );
        }
        ipsSensorColumnFactory(o) {
          return (t) =>
            V.Um.ipsSensorColumn(t.ipsSensor, this.viewTypeManager.type, {
              editable: o,
              editableStartCallback: (i) => {
                var n;
                null === (n = this.sourceManager.ipsSensorSelectSource) ||
                  void 0 === n ||
                  n.setContext({ policyEntry: i });
              },
              editableOmniSelectSources: [
                this.sourceManager.ipsSensorSelectSource,
              ],
            });
        }
        emailFilterProfileColumnFactory(o) {
          return (t) =>
            V.Um.emailFilterProfileColumn(
              t.efProfile,
              this.viewTypeManager.type,
              {
                editable: o,
                editableStartCallback: (i) => {
                  var n;
                  null === (n = this.sourceManager.efProfileSelectSource) ||
                    void 0 === n ||
                    n.setContext({ policyEntry: i });
                },
                editableOmniSelectSources: [
                  this.sourceManager.efProfileSelectSource,
                ],
              },
            );
        }
        voipProfileColumnFactory(o) {
          return (t) =>
            new y.b7({
              id: "voip-profile",
              langKey: "field_voip-profile",
              filtering: !0,
              omniSources: new Set([t.voipProfile]),
              cellValueFunction: (i) => {
                var n, l;
                let a = [];
                return (
                  !(null === (n = i.data) || void 0 === n) &&
                    n["voip-profile"] &&
                    (a = [
                      {
                        [_.go]: (0, X.xP)(
                          null === (l = i.data) || void 0 === l
                            ? void 0
                            : l["voip-profile"],
                        ),
                        [_.Hx]: t.voipProfile,
                      },
                    ]),
                  a
                );
              },
              editable: o,
              editableStartCallback: (i) => {
                var n;
                null === (n = this.sourceManager.voipProfileSelectSource) ||
                  void 0 === n ||
                  n.setContext({ policyEntry: i });
              },
              editableOmniSelectSources: [
                this.sourceManager.voipProfileSelectSource,
              ],
              editableOmniSelectSettings: Fe.P.getSettings(
                this.viewTypeManager.type,
                "voip-profile",
              ),
            });
        }
        icapProfileColumnFactory(o) {
          return (t) =>
            V.Um.icapProfileColumn(t.icapProfile, this.viewTypeManager.type, {
              editable: o,
              editableStartCallback: (i) => {
                var n;
                null === (n = this.sourceManager.icapProfileSelectSource) ||
                  void 0 === n ||
                  n.setContext({ policyEntry: i });
              },
              editableOmniSelectSources: [
                this.sourceManager.icapProfileSelectSource,
              ],
            });
        }
        wafProfileColumnFactory(o) {
          return (t) =>
            V.Um.wafProfileColumn(t.wafProfile, this.viewTypeManager.type, {
              editable: o,
              editableStartCallback: (i) => {
                var n;
                null === (n = this.sourceManager.wafProfileSelectSource) ||
                  void 0 === n ||
                  n.setContext({ policyEntry: i });
              },
              editableOmniSelectSources: [
                this.sourceManager.wafProfileSelectSource,
              ],
            });
        }
        sslSshProfileColumnFactory(o) {
          return (t) =>
            V.Um.sslSshProfileColumn(
              t.sslSshProfile,
              this.viewTypeManager.type,
              {
                editable: o,
                editableStartCallback: (i) => {
                  var n;
                  null === (n = this.sourceManager.sslSshProfileSelectSource) ||
                    void 0 === n ||
                    n.setContext({ policyEntry: i });
                },
                editableOmniSelectSources: [
                  this.sourceManager.sslSshProfileSelectSource,
                ],
              },
            );
        }
        fileFilterProfileColumnFactory(o) {
          return (t) =>
            V.Um.fileFilterProfileColumn(
              t.fileFilterProfile,
              this.viewTypeManager.type,
              {
                editable: o,
                editableStartCallback: (i) => {
                  var n;
                  null ===
                    (n = this.sourceManager.fileFilterProfileSelectSource) ||
                    void 0 === n ||
                    n.setContext({ policyEntry: i });
                },
                editableOmniSelectSources: [
                  this.sourceManager.fileFilterProfileSelectSource,
                ],
              },
            );
        }
        virtualPatchProfileColumnFactory(o) {
          return (t) =>
            V.Um.virtualPatchProfileColumn(
              t.virtualPatchProfile,
              this.viewTypeManager.type,
              {
                editable: o,
                editableStartCallback: (i) => {
                  var n;
                  null ===
                    (n = this.sourceManager.virtualPatchProfileSelectSource) ||
                    void 0 === n ||
                    n.setContext({ policyEntry: i });
                },
                editableOmniSelectSources: [
                  this.sourceManager.virtualPatchProfileSelectSource,
                ],
              },
            );
        }
        dlpProfileColumnFactory(o) {
          return (t) =>
            V.Um.dlpProfileColumn(t.dlpProfile, this.viewTypeManager.type, {
              editable: o,
              editableStartCallback: (i) => {
                var n;
                null === (n = this.sourceManager.dlpProfileSelectSource) ||
                  void 0 === n ||
                  n.setContext({ policyEntry: i });
              },
              editableOmniSelectSources: [
                this.sourceManager.dlpProfileSelectSource,
              ],
            });
        }
        videoFilterProfileColumnFactory(o) {
          return (t) =>
            V.Um.videoFilterProfileColumn(
              t.videoFilterProfile,
              this.viewTypeManager.type,
              {
                editable: o,
                editableStartCallback: (i) => {
                  var n;
                  null ===
                    (n = this.sourceManager.videoFilterProfileSelectSource) ||
                    void 0 === n ||
                    n.setContext({ policyEntry: i });
                },
                editableOmniSelectSources: [
                  this.sourceManager.videoFilterProfileSelectSource,
                ],
              },
            );
        }
        inlineCasbColumnFactory(o) {
          return (t) =>
            V.Um.inlineCasbColumn(t.casbProfile, this.viewTypeManager.type, {
              editable: o,
              editableStartCallback: (i) => {
                var n;
                null === (n = this.sourceManager.casbProfileSelectSource) ||
                  void 0 === n ||
                  n.setContext({ policyEntry: i });
              },
              editableOmniSelectSources: [
                this.sourceManager.casbProfileSelectSource,
              ],
            });
        }
        profileProtocolOptionsColumnFactory(o) {
          return (t) =>
            V.Um.protocolOptionsColumn(
              t.protocolOptions,
              this.viewTypeManager.type,
              {
                editable: o,
                editableOmniSelectSources: [
                  new Qn.t({ source: t.protocolOptions }),
                ],
              },
            );
        }
        profileGroupColumnFactory(o) {
          return (t) =>
            V.Um.profileGroupColumn(t.profileGroup, this.viewTypeManager.type, {
              editable: o,
              editableStartCallback: (i) => {
                var n;
                null === (n = this.sourceManager.profileGroupSelectSource) ||
                  void 0 === n ||
                  n.setContext({ policyEntry: i });
              },
              editableOmniSelectSources: [
                this.sourceManager.profileGroupSelectSource,
              ],
            });
        }
        statusColumn() {
          return V.Um.statusColumn(this.translation, {
            externalFilterValueMapping: this.generateReverseMap(
              this.STATUS_LANG_KEY_MAPPING,
            ),
            editable: (o) => !o.implicit && !ae(o),
          });
        }
        bytesColumn(o, t) {
          return V.Um.bytesColumn(this.fortigate, o.firewallPolicy, t);
        }
        packetsColumn(o, t) {
          const i = this.fortigate,
            n = "packets";
          return new y.iY({
            id: n,
            cellWidth: Ue,
            filtering: !0,
            filteringCapabilities: {
              negation: !1,
              types: [y.vA.GreaterThanEqualTo, y.vA.LessThanEqualTo],
              emptyValue: !1,
            },
            searching: !1,
            cellValueFunction: (l) =>
              (0, d.mG)(this, void 0, void 0, function* () {
                var a;
                const s = yield o.firewallPolicy.getPolicyStats(
                  l.policyId,
                  l.disabled,
                );
                return null !== (a = null == s ? void 0 : s[n]) && void 0 !== a
                  ? a
                  : 0;
              }),
            onCellRendered: function (l, a, s) {
              Je(this, l, a, s, o, t, Ie, i);
            },
            externalFilterEnforceSpecialKeys: !0,
            externalFilterCreationFunction: (0, V.jZ)(n, o.firewallPolicy),
          });
        }
        softwareBytesColumn(o, t) {
          const i = this.fortigate,
            n = "software_bytes";
          return new y.iY({
            id: n,
            langKey: "CPU Bytes",
            filtering: !0,
            filteringCapabilities: {
              negation: !1,
              types: [y.vA.GreaterThanEqualTo, y.vA.LessThanEqualTo],
              emptyValue: !1,
            },
            searching: !1,
            cellWidth: Ue,
            getCompareBarMax: (l) => {
              var a;
              const s = o.firewallPolicy.getPolicyStatsSync(
                l.policyId,
                l.disabled,
              );
              return null !== (a = null == s ? void 0 : s.bytes) && void 0 !== a
                ? a
                : 0;
            },
            cellValueFunction: (l) =>
              (0, d.mG)(this, void 0, void 0, function* () {
                var a;
                const s = yield o.firewallPolicy.getPolicyStats(
                  l.policyId,
                  l.disabled,
                );
                return null !== (a = null == s ? void 0 : s[n]) && void 0 !== a
                  ? a
                  : 0;
              }),
            onCellRendered: function (l, a, s) {
              Je(this, l, a, s, o, t, Ie, i);
            },
            numberType: y.sw.MetricBytes,
            externalFilterEnforceSpecialKeys: !0,
            externalFilterCreationFunction: (0, V.jZ)(n, o.firewallPolicy),
          });
        }
        softwarePacketsColumn(o, t) {
          const i = this.fortigate,
            n = "software_packets";
          return new y.iY({
            id: n,
            langKey: "CPU Packets",
            filtering: !0,
            filteringCapabilities: {
              negation: !1,
              types: [y.vA.GreaterThanEqualTo, y.vA.LessThanEqualTo],
              emptyValue: !1,
            },
            searching: !1,
            cellWidth: Ue,
            getCompareBarMax: (l) => {
              var a;
              const s = o.firewallPolicy.getPolicyStatsSync(
                l.policyId,
                l.disabled,
              );
              return null !== (a = null == s ? void 0 : s.packets) &&
                void 0 !== a
                ? a
                : 0;
            },
            cellValueFunction: (l) =>
              (0, d.mG)(this, void 0, void 0, function* () {
                var a;
                const s = yield o.firewallPolicy.getPolicyStats(
                  l.policyId,
                  l.disabled,
                );
                return null !== (a = null == s ? void 0 : s[n]) && void 0 !== a
                  ? a
                  : 0;
              }),
            onCellRendered: function (l, a, s) {
              Je(this, l, a, s, o, t, Ie, i);
            },
            externalFilterEnforceSpecialKeys: !0,
            externalFilterCreationFunction: (0, V.jZ)(n, o.firewallPolicy),
          });
        }
        asicBytesColumn(o, t) {
          const i = this.fortigate,
            n = "asic_bytes";
          return new y.iY({
            id: n,
            langKey: "SPU Bytes",
            filtering: !0,
            filteringCapabilities: {
              negation: !1,
              types: [y.vA.GreaterThanEqualTo, y.vA.LessThanEqualTo],
              emptyValue: !1,
            },
            searching: !1,
            cellWidth: Ue,
            cellValueFunction: (l) =>
              (0, d.mG)(this, void 0, void 0, function* () {
                var a;
                const s = yield o.firewallPolicy.getPolicyStats(
                  l.policyId,
                  l.disabled,
                );
                return null !== (a = null == s ? void 0 : s[n]) && void 0 !== a
                  ? a
                  : 0;
              }),
            onCellRendered: function (l, a, s) {
              Je(this, l, a, s, o, t, Ie, i);
            },
            numberType: y.sw.MetricBytes,
            externalFilterEnforceSpecialKeys: !0,
            externalFilterCreationFunction: (0, V.jZ)(n, o.firewallPolicy),
          });
        }
        asicPacketsColumn(o, t) {
          const i = this.fortigate,
            n = "asic_packets";
          return new y.iY({
            id: n,
            langKey: "SPU Packets",
            filtering: !0,
            filteringCapabilities: {
              negation: !1,
              types: [y.vA.GreaterThanEqualTo, y.vA.LessThanEqualTo],
              emptyValue: !1,
            },
            searching: !1,
            cellWidth: Ue,
            cellValueFunction: (l) =>
              (0, d.mG)(this, void 0, void 0, function* () {
                var a;
                const s = yield o.firewallPolicy.getPolicyStats(
                  l.policyId,
                  l.disabled,
                );
                return null !== (a = null == s ? void 0 : s[n]) && void 0 !== a
                  ? a
                  : 0;
              }),
            onCellRendered: function (l, a, s) {
              Je(this, l, a, s, o, t, Ie, i);
            },
            externalFilterEnforceSpecialKeys: !0,
            externalFilterCreationFunction: (0, V.jZ)(n, o.firewallPolicy),
          });
        }
        nturboBytesColumn(o, t) {
          const i = this.fortigate,
            n = "nturbo_bytes";
          return new y.iY({
            id: n,
            langKey: "nTurbo Bytes",
            filtering: !0,
            filteringCapabilities: {
              negation: !1,
              types: [y.vA.GreaterThanEqualTo, y.vA.LessThanEqualTo],
              emptyValue: !1,
            },
            cellWidth: Ue,
            cellValueFunction: (l) =>
              (0, d.mG)(this, void 0, void 0, function* () {
                var a;
                const s = yield o.firewallPolicy.getPolicyStats(
                  l.policyId,
                  l.disabled,
                );
                return null !== (a = null == s ? void 0 : s[n]) && void 0 !== a
                  ? a
                  : 0;
              }),
            onCellRendered: function (l, a, s) {
              Je(this, l, a, s, o, t, Ie, i);
            },
            numberType: y.sw.MetricBytes,
            externalFilterEnforceSpecialKeys: !0,
            externalFilterCreationFunction: (0, V.jZ)(n, o.firewallPolicy),
          });
        }
        nturboPacketsColumn(o, t) {
          const i = this.fortigate,
            n = "nturbo_packets";
          return new y.iY({
            id: n,
            langKey: "nTurbo Packets",
            filtering: !0,
            filteringCapabilities: {
              negation: !1,
              types: [y.vA.GreaterThanEqualTo, y.vA.LessThanEqualTo],
              emptyValue: !1,
            },
            cellWidth: Ue,
            cellValueFunction: (l) =>
              (0, d.mG)(this, void 0, void 0, function* () {
                var a;
                const s = yield o.firewallPolicy.getPolicyStats(
                  l.policyId,
                  l.disabled,
                );
                return null !== (a = null == s ? void 0 : s[n]) && void 0 !== a
                  ? a
                  : 0;
              }),
            onCellRendered: function (l, a, s) {
              Je(this, l, a, s, o, t, Ie, i);
            },
            externalFilterEnforceSpecialKeys: !0,
            externalFilterCreationFunction: (0, V.jZ)(n, o.firewallPolicy),
          });
        }
        lastUsedColumn(o) {
          return V.Um.lastUsedColumn(o.firewallPolicy);
        }
        firstUsedColumn(o) {
          return V.Um.firstUsedColumn(o.firewallPolicy);
        }
        activeSessionsColumn(o) {
          return V.Um.activeSessionsColumn(o.firewallPolicy);
        }
        hitCountColumn(o, t) {
          return V.Um.hitCountColumn(
            this.fortigate,
            this.viewTypeManager.type === ie.a.SecurityPolicy
              ? o.securityPolicy
              : o.firewallPolicy,
            t,
          );
        }
        packetsDroppedColumn(o) {
          const t = "packets_dropped";
          return new y.iY({
            id: t,
            langKey: "Packets Dropped",
            filtering: !0,
            filteringCapabilities: {
              negation: !1,
              types: [y.vA.GreaterThanEqualTo, y.vA.LessThanEqualTo],
              emptyValue: !1,
            },
            searching: !1,
            cellWidth: Ue,
            cellValueFunction: (i) =>
              (0, d.mG)(this, void 0, void 0, function* () {
                var n;
                const l = yield o.firewallPolicy.getPolicyStats(
                  i.policyId,
                  i.disabled,
                );
                return null !== (n = null == l ? void 0 : l[t]) && void 0 !== n
                  ? n
                  : 0;
              }),
            externalFilterEnforceSpecialKeys: !0,
            externalFilterCreationFunction: (0, V.jZ)(t, o.firewallPolicy),
          });
        }
        inspectionModeColumnFactory(o, t) {
          const i = t.supportExplicitProxy;
          return () =>
            new y.EH({
              id: "inspection-mode",
              langKey: "inspect_mode",
              externalFilterCreationFunction: (n) => {
                const l = {
                  logic: n.negated ? p.tk.And : p.tk.Or,
                  filters: [],
                };
                return (
                  1 === n.filterValues.length &&
                    (n.filterValues[0].includes("proxy")
                      ? l.filters.push({
                          key: "inspection-mode",
                          type: p.NM.String,
                          negate: n.negated,
                          operator: p.pg.Exact,
                          pattern: "proxy",
                        })
                      : n.filterValues[0].includes("flow") &&
                        l.filters.push({
                          key: "inspection-mode",
                          type: p.NM.String,
                          negate: n.negated,
                          operator: p.pg.Exact,
                          pattern: "flow",
                        })),
                  l
                );
              },
              editable: (n) =>
                !n.implicit &&
                o.guiProxyInspectionEnabled() &&
                !n.hasVirtualServer() &&
                !n.isZTNAFirewallPolicy() &&
                !ae(n) &&
                i &&
                !n.isDenyPolicy(),
              editableType: y.zT.Selection,
              editableOptions: this.INSPECTION_MODE_COL_OPTION,
              cellValueFunction: (n) => {
                var l, a;
                if (
                  (null === (l = n.data) || void 0 === l
                    ? void 0
                    : l["inspection-mode"]) &&
                  !n.isZTNAFirewallPolicy() &&
                  !n.isDenyPolicy()
                )
                  return this.translate(
                    this.INSPECTION_MODE_LANG_KEY,
                    null === (a = n.data) || void 0 === a
                      ? void 0
                      : a["inspection-mode"],
                  );
              },
            });
        }
        commentsColumn() {
          return this.mutableDefaultSettingsService.createCommentColumn({
            id: "comments",
            editable: (o) => !o.implicit && !ae(o),
            editableValidateFunction: (o, t) => {
              var i;
              return o ===
                (null === (i = t.data) || void 0 === i ? void 0 : i.comments)
                ? Promise.resolve(null)
                : Promise.resolve(void 0);
            },
          });
        }
        hiddenIntfPairColumn(o) {
          return V.Um.hiddenIntfPairColumn(o.firewallInterface, {
            externalFilterCreationFunction: (t) => {
              const i = { logic: t.negated ? p.tk.And : p.tk.Or, filters: [] };
              if (t.forSection) {
                if ("implicit" === t.filterValues[0])
                  i.filters.push({
                    key: "intf-pair",
                    type: p.NM.String,
                    negate: t.negated,
                    operator: p.pg.Exact,
                    pattern: t.filterValues[0],
                  });
                else if (
                  t.filterValues[0] &&
                  "string" == typeof t.filterValues[0] &&
                  t.filterValues[0].includes("->")
                ) {
                  const [n, l] = t.filterValues[0].split("->");
                  ((i.filters = [
                    {
                      key: "srcintf",
                      type: p.NM.String,
                      pattern: n,
                      negate: t.negated,
                      operator: p.pg.Contains,
                    },
                    {
                      key: "dstintf",
                      type: p.NM.String,
                      pattern: l,
                      negate: t.negated,
                      operator: p.pg.Contains,
                    },
                  ]),
                    (i.logic = p.tk.And));
                }
              } else
                for (const n of t.matchedOmniReferences)
                  (i.filters.push({
                    key: "srcintf",
                    type: p.NM.String,
                    negate: t.negated,
                    operator: p.pg.Contains,
                    pattern: n[_.go],
                  }),
                    i.filters.push({
                      key: "dstintf",
                      type: p.NM.String,
                      negate: t.negated,
                      operator: p.pg.Contains,
                      pattern: n[_.go],
                    }));
              return i;
            },
            statisticOmniJoiner: "\u2192",
            statisticValueFunction: (t) =>
              "implicit" === t
                ? this.translation.translate("Implicit")
                : t
                    .split("->")
                    .map((i) => ({ [_.go]: i, [_.Hx]: o.firewallInterface })),
            statisticSortComparator: (t, i) => {
              const n = this.translation.translate("implicit");
              if (t.value === n) return 1;
              if (i.value === n) return -1;
              if (
                2 === t.omniSourceEntries.length &&
                2 === i.omniSourceEntries.length
              ) {
                const l = (a) =>
                  a
                    .map((s) => (0, _.mC)(s[p.O3], "name").toLocaleLowerCase())
                    .join("\u2192");
                return l(t.omniSourceEntries) > l(i.omniSourceEntries) ? 1 : -1;
              }
              return 1;
            },
          });
        }
        hiddenSequenceGroupingLabelColumn() {
          return V.Um.hiddenSequenceGroupingLabelColumn(this.translation, {
            externalFilterCreationFunction: (o) => {
              const t = { logic: o.negated ? p.tk.And : p.tk.Or, filters: [] };
              return (
                o.forSection &&
                  t.filters.push({
                    key: "global-label",
                    type: p.NM.String,
                    negate: o.negated,
                    operator:
                      o.filterType === y.vA.Exact ? p.pg.Exact : p.pg.Contains,
                    pattern: o.filterValues[0],
                    forSection: !0,
                  }),
                t
              );
            },
          });
        }
        policyExpiryDateColumn() {
          return new y.sx({
            id: "policy-expiry-date",
            langKey: "Expiration Date",
            filtering: !0,
            cellWidth: 160,
            cellValueFunction: (o) =>
              (0, d.mG)(this, void 0, void 0, function* () {
                var t, i;
                const n =
                  null === (t = o.data) || void 0 === t
                    ? void 0
                    : t["policy-expiry-date"];
                if (
                  n &&
                  "enable" ===
                    (null === (i = o.data) || void 0 === i
                      ? void 0
                      : i["policy-expiry"])
                ) {
                  let l = new Date(n);
                  isNaN(l.getTime()) && (l = new Date());
                  const a = yield this.datetime.getDisplayTzOffset(
                      l,
                      this.fortigate,
                    ),
                    u =
                      "system" ===
                      (yield this.fortigate.config.getDateFormatDevice())
                        ? -1 * a
                        : a;
                  return l.getTime() + u;
                }
                return null;
              }),
          });
        }
        ztnaStatusColumn() {
          const { STATUS_LANG_KEY_MAPPING: o, ENABLE_DISABLE_OPTION: t } = this;
          return new y.EH({
            id: "ztna-status",
            langKey: "Enforce ZTNA",
            filtering: !0,
            cellValueFunction: (i) => {
              var n;
              if (!i.isZTNAFirewallPolicy())
                return this.STATUS_LANG_KEY_MAPPING.get(
                  (null === (n = i.data) || void 0 === n
                    ? void 0
                    : n["ztna-status"]) || "disable",
                );
            },
            cellFormatter: (i, n, l) => {
              var a;
              if (i.isZTNAFirewallPolicy()) return;
              const s =
                "enable" ===
                (null === (a = i.data) || void 0 === a
                  ? void 0
                  : a["ztna-status"])
                  ? z.nI
                  : z.oc;
              return i.implicit
                ? void 0
                : (0, Ce.elem)("span", void 0, {
                    children: [
                      new f.le(s),
                      (0, Ce.elem)("span", { textContent: l }),
                    ],
                  });
            },
            editable: (i) => {
              var n;
              return (
                !i.implicit &&
                "ipv4" ===
                  (null === (n = i.data) || void 0 === n
                    ? void 0
                    : n["ip-version-type"]) &&
                !i.isZTNAFirewallPolicy() &&
                !ae(i)
              );
            },
            editableType: y.zT.Selection,
            editableOptions: t,
            externalFilterValueMapping: this.generateReverseMap(o),
          });
        }
        policyBehaviourType() {
          const { TYPE_LANG_KEY_MAPPING: o } = this;
          return new y.EH({
            id: "policy-behaviour-type",
            langKey: "Type",
            filtering: !0,
            cellValueFunction: (t) => {
              var i;
              const n =
                "ztna" ===
                (null === (i = t.data) || void 0 === i
                  ? void 0
                  : i["policy-behaviour-type"])
                  ? "ZTNA"
                  : "Standard";
              return t.implicit ? "" : o.get(n);
            },
          });
        }
        ztnaEmsTagColumnFactory(
          o = "ztna-ems-tag",
          t = "Security Posture Tag",
          i = "ztna-ems-tag",
          n,
        ) {
          return () =>
            new y.b7({
              id: o,
              langKey: t,
              filtering: !0,
              omniSources: new Set(this.sourceManager.getZtnaOmniSources()),
              cellValueFunction: (l) => {
                var a, s;
                return null !== (a = l.data) && void 0 !== a && a[i]
                  ? this.sourceManager.getVisibleZtnaTagOmniSourceEntryReferences(
                      null === (s = l.data) || void 0 === s ? void 0 : s[i],
                      l.isZTNAFirewallPolicy(),
                    )
                  : [];
              },
              editable: (l) => {
                var a;
                return (
                  !l.implicit &&
                  !ae(l) &&
                  ("ztna-ems-tag-secondary" === i
                    ? l.hasZtnaTags() && !l.isZTNAFirewallPolicy()
                    : "enable" ===
                        (null === (a = l.data) || void 0 === a
                          ? void 0
                          : a["ztna-status"]) || l.isZTNAFirewallPolicy())
                );
              },
              editableOmniSelectSources: (l) =>
                "ztna-ems-tag-secondary" === i
                  ? this.sourceManager.getZtnaSecondaryOmniSelectSources(
                      l.isZTNAFirewallPolicy(),
                    )
                  : this.sourceManager.getZtnaOmniSelectSources(
                      l.isZTNAFirewallPolicy(),
                    ),
              editableStartCallback: (l) => {
                n(l);
              },
              editableOmniSelectSettings: this.selectConfig.getSettings({
                property: i,
                policyType: this.viewTypeManager.type,
              }),
              externalFilterCreationFunction: (l) => {
                const a = {
                  logic: l.negated ? p.tk.And : p.tk.Or,
                  filters: [],
                };
                if (l.matchedOmniReferences.length)
                  a.filters = l.matchedOmniReferences.map((s) => ({
                    key: i,
                    type: p.NM.String,
                    negate: l.negated,
                    operator: p.pg.Contains,
                    pattern: s[_.go],
                  }));
                else
                  for (const s of l.filterValues)
                    a.filters.push({
                      key: i,
                      type: p.NM.String,
                      pattern: s,
                      negate: l.negated,
                      operator:
                        l.filterType === y.vA.Exact
                          ? p.pg.Exact
                          : p.pg.Contains,
                    });
                return a;
              },
            });
        }
        visible(o, t, i) {
          var n;
          let l = !0;
          const a =
            null === (n = i[o]) || void 0 === n ? void 0 : n.visibilityCheck;
          return (
            a
              ? (l = a.visible())
              : t.isSecurityProfile(o)
                ? (l = t.visible(o))
                : (("global-label" === o &&
                    !this.viewTypeManager.sequenceGroupingView) ||
                    ("intf-pair" === o &&
                      !this.viewTypeManager.interfacePairView)) &&
                  (l = !1),
            l
          );
        }
        getDefaultColumns(o) {
          return (0, d.mG)(this, void 0, void 0, function* () {
            let t = this.viewTypeManager.type;
            t === ie.a.Policy &&
              (yield this.fortigate.config.isNgfwPolicyMode()) &&
              (t = ie.a.NgfwFirewallPolicy);
            const i = o.data["gui-default-policy-columns"]
              .map(({ name: n }) => n)
              .filter((n) => wt[t].includes(n));
            return i.length ? i : qn[t];
          });
        }
        getCandidateColumns() {
          return (0, d.mG)(this, void 0, void 0, function* () {
            let o = this.viewTypeManager.type;
            return (
              o === ie.a.Policy &&
                (yield this.fortigate.config.isNgfwPolicyMode()) &&
                (o = ie.a.NgfwFirewallPolicy),
              wt[o]
            );
          });
        }
        generateReverseMap(o) {
          return new Map(Array.from(o.entries()).map(([t, i]) => [i, t]));
        }
      }
      var zn = c(12826),
        Xn = c(25672),
        eo = c(94881),
        to = c(12325);
      let io = (() => {
          class r {
            constructor(t, i, n, l, a, s, u, g, h) {
              ((this.translation = t),
                (this.datetime = i),
                (this.theme = n),
                (this.selectConfig = l),
                (this.viewTypeManager = a),
                (this.http = s),
                (this.sourceManagerFactory = u),
                (this.mutableDefaultSettingsService = g),
                (this.forceTraditionalGui = h));
            }
            create(t) {
              return new $n(
                t,
                this.translation,
                this.datetime,
                this.theme,
                this.selectConfig,
                this.viewTypeManager,
                this.http,
                this.sourceManagerFactory,
                this.mutableDefaultSettingsService,
                this.forceTraditionalGui,
              );
            }
          }
          return (
            (r.ɵfac = function (t) {
              return new (t || r)(
                e.LFG(G.D7),
                e.LFG(zn.DatetimeService),
                e.LFG(Xn.ThemeService),
                e.LFG(eo.s),
                e.LFG(fe.UW),
                e.LFG(C.eN),
                e.LFG(ct.n),
                e.LFG(to.y),
                e.LFG(y.Hm),
              );
            }),
            (r.ɵprov = e.Yz7({
              token: r,
              factory: r.ɵfac,
              providedIn: "root",
            })),
            r
          );
        })(),
        no = (() => {
          class r {
            constructor(t, i) {
              ((this.viewTypeManager = t),
                (this.columnsStoreFactory = i),
                (this.DEFAULT_COLLECTION_LIMIT = 3),
                (this.DEFAULT_ALLOW_SORTING = !1),
                (this.DEFAULT_ALLOW_FILTERING = !0));
            }
            createFirewallPolicySettings(t, i, n, l, a) {
              return (0, d.mG)(this, void 0, void 0, function* () {
                const s = this.columnsStoreFactory.create(i),
                  u = {};
                return (
                  (this.viewTypeManager.interfacePairView ||
                    this.viewTypeManager.sequenceGroupingView) &&
                    ((u.sections = !0),
                    this.viewTypeManager.interfacePairView
                      ? ((u.defaultSectionColumn = "intf-pair"),
                        (u.statisticCollectionColumns = ["intf-pair"]))
                      : ((u.defaultSectionColumn = "global-label"),
                        (u.statisticCollectionColumns = ["global-label"]))),
                  Object.assign(
                    {
                      id: this.tableId(i.vdom),
                      sections: !1,
                      reordering: !this.viewTypeManager.readOnly,
                      canReorderFunction: (h) => !h.implicit,
                      editable: this.editable(),
                      editingNeedsExternalUpdate: !0,
                      collectionLimit: this.DEFAULT_COLLECTION_LIMIT,
                      sorting: this.DEFAULT_ALLOW_SORTING,
                      filtering: this.DEFAULT_ALLOW_FILTERING,
                      rowSelectionStyle: this.rowSelectionStyle(),
                      maintainRowSelection: this.maintainRowSelection(),
                      onRowRendered: (h, P) => {
                        var N;
                        ("disable" ===
                          (null === (N = P.data) || void 0 === N
                            ? void 0
                            : N.status) && h.classList.add("disabled"),
                          P.implicit && h.classList.add("implicit"));
                      },
                      defaultColumns: yield s.getDefaultColumns(l),
                      columns: yield s.getFirewallPolicyColumns(t, n, a),
                    },
                    u,
                  )
                );
              });
            }
            createSecurityPolicySettings(t, i, n, l, a) {
              return (0, d.mG)(this, void 0, void 0, function* () {
                const s = this.columnsStoreFactory.create(i),
                  u = {};
                return (
                  (this.viewTypeManager.interfacePairView ||
                    this.viewTypeManager.sequenceGroupingView) &&
                    ((u.sections = !0),
                    this.viewTypeManager.interfacePairView
                      ? ((u.defaultSectionColumn = "intf-pair"),
                        (u.statisticCollectionColumns = ["intf-pair"]))
                      : ((u.defaultSectionColumn = "global-label"),
                        (u.statisticCollectionColumns = ["global-label"]))),
                  Object.assign(
                    {
                      id: this.tableId(i.vdom),
                      sections: !1,
                      reordering: !this.viewTypeManager.readOnly,
                      canReorderFunction: (h) => !h.implicit,
                      editable: this.editable(),
                      editingNeedsExternalUpdate: !0,
                      collectionLimit: this.DEFAULT_COLLECTION_LIMIT,
                      sorting: this.DEFAULT_ALLOW_SORTING,
                      filtering: this.DEFAULT_ALLOW_FILTERING,
                      rowSelectionStyle: this.rowSelectionStyle(),
                      maintainRowSelection: this.maintainRowSelection(),
                      onRowRendered: (h, P) => {
                        var N;
                        ("disable" ===
                          (null === (N = P.data) || void 0 === N
                            ? void 0
                            : N.status) && h.classList.add("disabled"),
                          P.implicit && h.classList.add("implicit"));
                      },
                      defaultColumns: yield s.getDefaultColumns(l),
                      columns: yield s.getSecurityPolicyColumns(t, n, a),
                    },
                    u,
                  )
                );
              });
            }
            tableId(t) {
              let i = "sequence";
              return (
                this.viewTypeManager.interfacePairView
                  ? (i = "interface-pair")
                  : this.viewTypeManager.sequenceGroupingView ||
                    (i = "sequence-non-section"),
                `policyList-${t}-${this.viewTypeManager.type}-${this.viewTypeManager.subType}-${i}`
              );
            }
            rowSelectionStyle() {
              return this.viewTypeManager.optInForInlineMenu
                ? y.mb.Checkbox
                : y.mb.Plain;
            }
            maintainRowSelection() {
              return this.viewTypeManager.optInForInlineMenu;
            }
            editable() {
              return (
                !this.viewTypeManager.readOnly &&
                !this.viewTypeManager.insideSlide
              );
            }
          }
          return (
            (r.ɵfac = function (t) {
              return new (t || r)(e.LFG(fe.UW), e.LFG(io));
            }),
            (r.ɵprov = e.Yz7({
              token: r,
              factory: r.ɵfac,
              providedIn: "root",
            })),
            r
          );
        })();
      var oo = c(75522);
      let lo = (() => {
        class r {
          constructor(t, i, n, l, a, s, u, g) {
            ((this.cmdbService = t),
              (this.viewTypeManager = i),
              (this.cmdbSourceMap = n),
              (this.csfSourceFactory = l),
              (this.logSettingService = a),
              (this.systemSettingsService = s),
              (this.settingsFactory = u),
              (this.globalSettingSourceFactoryService = g));
          }
          create(t, i, n) {
            return new Nn(
              t,
              i,
              n,
              this.viewTypeManager,
              this.cmdbService,
              this.cmdbSourceMap,
              this.csfSourceFactory,
              this.logSettingService,
              this.systemSettingsService,
              this.settingsFactory,
              this.globalSettingSourceFactoryService,
            );
          }
        }
        return (
          (r.ɵfac = function (t) {
            return new (t || r)(
              e.LFG(Zn._),
              e.LFG(fe.UW),
              e.LFG(Dn.q),
              e.LFG(Gn.p),
              e.LFG(Un.v),
              e.LFG(Rn.T),
              e.LFG(no),
              e.LFG(oo.Z),
            );
          }),
          (r.ɵprov = e.Yz7({ token: r, factory: r.ɵfac, providedIn: "root" })),
          r
        );
      })();
      var At = c(9922),
        Ft = c(95589),
        ro = c(97114),
        ao = c(36202),
        so = c(12278),
        dt = c(18846),
        Nt = c(41565),
        co = c(80188),
        uo = c(39300);
      function po(r, o) {
        if (
          (1 & r &&
            (e.ynx(0),
            e.TgZ(1, "label", 7),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "nu-field"),
            e._UZ(5, "input", 10, 11),
            e.qZA(),
            e.BQk()),
          2 & r)
        ) {
          const t = e.MAs(6);
          (e.xp6(1),
            e.Q6J("nuFor", t),
            e.xp6(1),
            e.Oqu(e.lcZ(3, 2, "Destination policy ID")));
        }
      }
      const _o = function (r) {
        return [r];
      };
      function go(r, o) {
        if (
          (1 & r &&
            (e.ynx(0),
            e.TgZ(1, "label"),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "nu-field"),
            e._UZ(5, "nu-omni-suggestion-input", 12),
            e.qZA(),
            e.BQk()),
          2 & r)
        ) {
          const t = e.oxw(2);
          (e.xp6(2),
            e.Oqu(e.lcZ(3, 2, "Destination policy ID")),
            e.xp6(3),
            e.Q6J("sources", e.VKq(4, _o, t.policySource)));
        }
      }
      function fo(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "label"),
            e._uU(1),
            e.ALo(2, "translate"),
            e.qZA(),
            e.TgZ(3, "nu-field")(4, "span"),
            e._UZ(5, "nu-omni-source-entry-label", 3),
            e.qZA()(),
            e.TgZ(6, "label"),
            e._uU(7),
            e.ALo(8, "translate"),
            e.qZA(),
            e.TgZ(9, "nu-field")(10, "nu-radio-group", 4)(
              11,
              "nu-radio-input",
              5,
            ),
            e._uU(12),
            e.ALo(13, "translate"),
            e.qZA(),
            e.TgZ(14, "nu-radio-input", 5),
            e._uU(15),
            e.ALo(16, "translate"),
            e.qZA()()(),
            e.YNc(17, po, 7, 4, "ng-container", 6),
            e.YNc(18, go, 6, 6, "ng-container", 6),
            e.TgZ(19, "label", 7),
            e._uU(20),
            e.ALo(21, "translate"),
            e.qZA(),
            e.TgZ(22, "nu-field"),
            e._UZ(23, "nu-toggle", 8, 9),
            e.qZA()),
          2 & r)
        ) {
          const t = e.MAs(24),
            i = e.oxw();
          (e.xp6(1),
            e.Oqu(e.lcZ(2, 11, "Selected policy")),
            e.xp6(4),
            e.Q6J("entry", i.policyEntry),
            e.xp6(2),
            e.Oqu(e.lcZ(8, 13, "Move")),
            e.xp6(4),
            e.Q6J("value", i.MovePosition.Above),
            e.xp6(1),
            e.hij(" ", e.lcZ(13, 15, i.MovePosition.Above), " "),
            e.xp6(2),
            e.Q6J("value", i.MovePosition.Below),
            e.xp6(1),
            e.hij(" ", e.lcZ(16, 17, i.MovePosition.Below), " "),
            e.xp6(2),
            e.Q6J("ngIf", !i.policySource),
            e.xp6(1),
            e.Q6J("ngIf", i.policySource),
            e.xp6(1),
            e.Q6J("nuFor", t),
            e.xp6(1),
            e.Oqu(e.lcZ(21, 19, "Jump to policy after move")));
        }
      }
      var Ke = (() => {
        return (
          ((r = Ke || (Ke = {})).Above = "Above"),
          (r.Below = "Below"),
          Ke
        );
        var r;
      })();
      const Zt = new e.OlP("PolicyMoveByIdDialogData");
      let yo = (() => {
        class r {
          constructor(t, i, n) {
            var l;
            ((this.notify = t),
              (this.translation = i),
              (this.MAX_INTEGER = 4294967294),
              (this.DESTINATION_POLICYID_ERROR_MSG =
                "Destination policy ID must be a valid policy."),
              (this.MovePosition = Ke),
              (this.policyEntry = n.policyEntry),
              (this.policyEntry[_.Hx] instanceof pe.m ||
                this.policyEntry[_.Hx] instanceof ve.u) &&
                (this.policySource = this.policyEntry[_.Hx]),
              (this.selectedView = n.tableView),
              (this.leadingPolicyOfGroups = n.leadingPolicyOfGroups),
              (this.policyIdInputControl = new S.NI(null, {
                validators: [
                  S.kI.required,
                  S.kI.min(1),
                  S.kI.max(
                    (null === (l = this.policyEntry.schema) || void 0 === l
                      ? void 0
                      : l.children.policyid["max-value"]) || this.MAX_INTEGER,
                  ),
                ],
              })),
              (this.movePositionRadioControl = new S.NI(Ke.Above, {
                nonNullable: !0,
              })),
              (this.locateAfterMoveToggleControl = new S.NI(!0, {
                nonNullable: !0,
              })),
              (this.form = new S.cw({
                destinationPolicyId: this.policyIdInputControl,
                movePosition: this.movePositionRadioControl,
                locateAfterMove: this.locateAfterMoveToggleControl,
              })));
          }
          updateOldGroupWithNewLeader(t, i) {
            return (0, d.mG)(this, void 0, void 0, function* () {
              const n = i.at(1),
                l = t[_.Hx];
              if (n) {
                const a = yield l.load({ keys: [String(n.policyid)] });
                if (!a.length)
                  throw Error(`Unable to fetch policy with ID ${n.policyid}`);
                const s = a[0];
                s && (yield ze(s, t));
              }
            });
          }
          resetCurrentPolicyGroupLabel(t) {
            var i;
            return (0, d.mG)(this, void 0, void 0, function* () {
              t.data &&
                (null === (i = t.data) || void 0 === i
                  ? void 0
                  : i["global-label"]) &&
                ((t.data["global-label"] = ""),
                yield t.save({ skipChangeSummary: !0 }));
            });
          }
          movePolicyAbove(t) {
            var i, n;
            return (0, d.mG)(this, void 0, void 0, function* () {
              (t.indexOfNextPolicyInCurrentGroup &&
                t.policiesInCurrentGroup.length >
                  t.indexOfNextPolicyInCurrentGroup &&
                this.policyIdInputControl.value ===
                  (null ===
                    (i =
                      t.policiesInCurrentGroup[
                        t.indexOfNextPolicyInCurrentGroup
                      ]) || void 0 === i
                    ? void 0
                    : i.policyid)) ||
                ((null === (n = t.currentPolicy.data) || void 0 === n
                  ? void 0
                  : n["global-label"]) &&
                  t.currentPolicyLeadsGroup &&
                  (yield this.updateOldGroupWithNewLeader(
                    t.currentPolicy,
                    t.policiesInCurrentGroup,
                  )),
                t.targetPolicyLeadsGroup
                  ? yield ze(t.currentPolicy, t.destinationEntry)
                  : yield this.resetCurrentPolicyGroupLabel(t.currentPolicy),
                yield t.currentPolicy.moveBefore(
                  String(t.destinationEntry.policyId),
                  !1,
                ));
            });
          }
          movePolicyBelow(t) {
            var i, n;
            return (0, d.mG)(this, void 0, void 0, function* () {
              if (
                (null === (i = t.currentPolicy.data) || void 0 === i
                  ? void 0
                  : i["global-label"]) &&
                t.currentPolicyLeadsGroup
              )
                yield this.updateOldGroupWithNewLeader(
                  t.currentPolicy,
                  t.policiesInCurrentGroup,
                );
              else {
                if (
                  t.indexOfPreviousPolicyInCurrentGroup &&
                  t.indexOfPreviousPolicyInCurrentGroup >= 0 &&
                  this.policyIdInputControl.value ===
                    (null ===
                      (n =
                        t.policiesInCurrentGroup[
                          t.indexOfPreviousPolicyInCurrentGroup
                        ]) || void 0 === n
                      ? void 0
                      : n.policyid)
                )
                  return;
                yield this.resetCurrentPolicyGroupLabel(t.currentPolicy);
              }
              yield t.currentPolicy.moveAfter(
                String(t.destinationEntry.policyId),
                !1,
              );
            });
          }
          moveByIdAndUpdateSequenceGrouping(t) {
            var i, n;
            return (0, d.mG)(this, void 0, void 0, function* () {
              const l = this.policyEntry;
              if (
                this.policyEntry.policyId !== this.policyIdInputControl.value &&
                (this.policySource instanceof pe.m ||
                  this.policySource instanceof ve.u)
              ) {
                const a =
                    null === (i = this.leadingPolicyOfGroups) || void 0 === i
                      ? void 0
                      : i.has(parseInt(l[_.go], 10)),
                  s =
                    null === (n = this.leadingPolicyOfGroups) || void 0 === n
                      ? void 0
                      : n.has(parseInt(t[_.go], 10)),
                  u = yield this.policySource.getPolicyGroupLabelInfo(
                    l.policyId,
                  );
                if (u) {
                  const g = yield this.policySource.getTargetGroupPolicyInfo(
                      [u.groupLabel],
                      u.startIndexOfGroup,
                    ),
                    h = g.findIndex((P) => P.policyid === l.policyId);
                  if (h >= 0)
                    try {
                      if (this.movePositionRadioControl.value === Ke.Above) {
                        const P = h + 1;
                        yield this.movePolicyAbove({
                          currentPolicy: l,
                          currentPolicyLeadsGroup: a,
                          policiesInCurrentGroup: g,
                          indexOfNextPolicyInCurrentGroup: P,
                          destinationEntry: t,
                          targetPolicyLeadsGroup: s,
                        });
                      } else {
                        const P = h - 1;
                        yield this.movePolicyBelow({
                          currentPolicy: l,
                          currentPolicyLeadsGroup: a,
                          policiesInCurrentGroup: g,
                          indexOfPreviousPolicyInCurrentGroup: P,
                          destinationEntry: t,
                        });
                      }
                    } catch (P) {
                      M.cM.error(P);
                    }
                } else
                  M.cM.error(
                    "Policy global label and Policy or Security Policy source is expected.",
                  );
              }
            });
          }
          slideSubmitting() {
            return (0, d.mG)(this, void 0, void 0, function* () {
              const t = yield this.policyEntry[_.Hx].load({
                keys: [String(this.policyIdInputControl.value)],
              });
              if (!t.length)
                throw (
                  this.notify.error(
                    this.translation.translate(
                      this.DESTINATION_POLICYID_ERROR_MSG,
                    ),
                  ),
                  Error()
                );
              return (
                yield this.moveByIdAndUpdateSequenceGrouping(t[0]),
                {
                  locateMovedEntry: this.locateAfterMoveToggleControl.value,
                  policyEntry: this.policyEntry,
                }
              );
            });
          }
        }
        return (
          (r.ɵfac = function (t) {
            return new (t || r)(e.Y36(Qe.Cq), e.Y36(G.D7), e.Y36(Zt));
          }),
          (r.ɵcmp = e.Xpm({
            type: r,
            selectors: [["fos-policy-move-by-id-slidein-dialog"]],
            decls: 5,
            vars: 5,
            consts: [
              [3, "dialogTitle", "form"],
              [3, "formGroup"],
              ["nuDialogSectionContent", ""],
              [3, "entry"],
              ["name", "move-position", "formControlName", "movePosition"],
              [3, "value"],
              [4, "ngIf"],
              [3, "nuFor"],
              [
                "formControlName",
                "locateAfterMove",
                "name",
                "locate-after-move",
              ],
              ["locateAfterMove", ""],
              [
                "type",
                "number",
                "formControlName",
                "destinationPolicyId",
                "name",
                "policy-id",
              ],
              ["destinationPolicyId", ""],
              [
                "type",
                "number",
                "formControlName",
                "destinationPolicyId",
                "name",
                "suggested-policy-id",
                3,
                "sources",
              ],
            ],
            template: function (t, i) {
              (1 & t &&
                (e.TgZ(0, "nu-dialog", 0),
                e.ALo(1, "translate"),
                e.TgZ(2, "form", 1)(3, "nu-dialog-section"),
                e.YNc(4, fo, 25, 21, "ng-template", 2),
                e.qZA()()()),
                2 & t &&
                  (e.Q6J("dialogTitle", e.lcZ(1, 3, "Move by ID"))(
                    "form",
                    i.form,
                  ),
                  e.xp6(2),
                  e.Q6J("formGroup", i.form)));
            },
            dependencies: [
              D._g,
              O.O5,
              I.au,
              I.Jw,
              I.JQ,
              I.CF,
              I.VX,
              I.SM,
              x.n$,
              x.wT,
              x.CO,
              x.yc,
              S._Y,
              S.Fj,
              S.wV,
              S.JJ,
              S.JL,
              S.sg,
              S.u,
              _.ad,
              _.e_,
              Re.X,
            ],
            encapsulation: 2,
          })),
          r
        );
      })();
      function mo(r, o) {
        if (
          (1 & r &&
            (e.ynx(0), e._uU(1, " \xa0 "), e._UZ(2, "nu-icon", 11), e.BQk()),
          2 & r)
        ) {
          const t = e.oxw(3);
          (e.xp6(2), e.Q6J("icon", t.loadingIcon));
        }
      }
      function vo(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "nu-menu-item-button", 1),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw(2);
              return e.KtG(n.copyEntry(!0));
            }),
            e.ALo(1, "async"),
            e._UZ(2, "nu-icon", 2),
            e.TgZ(3, "span"),
            e._uU(4),
            e.ALo(5, "translate"),
            e.qZA(),
            e.YNc(6, mo, 3, 1, "ng-container", 0),
            e.qZA());
        }
        if (2 & r) {
          const t = e.oxw(2);
          (e.Q6J("menu", t.menu)(
            "disabled",
            t.multiplePoliciesSelected ||
              !1 !== e.lcZ(1, 5, t.disableCloneReverseObs),
          ),
            e.xp6(2),
            e.Q6J("icon", t.copyIcon),
            e.xp6(2),
            e.Oqu(e.lcZ(5, 7, "Copy reverse")),
            e.xp6(2),
            e.Q6J(
              "ngIf",
              !t.multiplePoliciesSelected && void 0 === t.enableCloneReverse,
            ));
        }
      }
      function ho(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "nu-menu-item-button", 14),
            e._UZ(1, "nu-icon", 2),
            e.TgZ(2, "span"),
            e._uU(3),
            e.ALo(4, "translate"),
            e.qZA()()),
          2 & r)
        ) {
          e.oxw();
          const t = e.MAs(3),
            i = e.oxw(2);
          (e.Q6J("menu", i.menu)("nuPopUpMenuToggle", t),
            e.xp6(1),
            e.Q6J("icon", i.pasteIcon),
            e.xp6(2),
            e.Oqu(e.lcZ(4, 4, "Paste")));
        }
      }
      function bo(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "nu-mutable-insert-row", 15),
            e.NdJ("insert", function (n) {
              e.CHM(t);
              const l = e.oxw(3);
              return e.KtG(l.pastePolicyInline(n));
            }),
            e.qZA());
        }
        if (2 & r) {
          const t = e.oxw(3);
          e.Q6J("menu", t.menu)("translationKey", "Paste");
        }
      }
      function So(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.ynx(0),
            e.YNc(1, ho, 5, 6, "nu-menu-item-button", 7),
            e.TgZ(2, "nu-pop-up-menu", null, 12)(4, "nu-menu-item-button", 9),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw(2);
              return e.KtG(n.pasteAbove());
            }),
            e._UZ(5, "nu-icon", 2),
            e.TgZ(6, "span"),
            e._uU(7),
            e.ALo(8, "translate"),
            e.qZA()(),
            e.TgZ(9, "nu-menu-item-button", 9),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw(2);
              return e.KtG(n.pasteBelow());
            }),
            e._UZ(10, "nu-icon", 2),
            e.TgZ(11, "span"),
            e._uU(12),
            e.ALo(13, "translate"),
            e.qZA()()(),
            e.YNc(14, bo, 1, 2, "nu-mutable-insert-row", 13),
            e.BQk());
        }
        if (2 & r) {
          const t = e.oxw().ngIf,
            i = e.oxw();
          (e.xp6(1),
            e.Q6J("ngIf", !t.optInForInlineMenu),
            e.xp6(4),
            e.Q6J("icon", i.pasteAboveIcon),
            e.xp6(2),
            e.Oqu(e.lcZ(8, 6, "Above")),
            e.xp6(3),
            e.Q6J("icon", i.pasteBelowIcon),
            e.xp6(2),
            e.Oqu(e.lcZ(13, 8, "Below")),
            e.xp6(2),
            e.Q6J("ngIf", t.optInForInlineMenu));
        }
      }
      function Po(r, o) {
        (1 & r && (e.TgZ(0, "div"), e._uU(1), e.ALo(2, "translate"), e.qZA()),
          2 & r &&
            (e.xp6(1),
            e.hij(
              " ",
              e.lcZ(
                2,
                1,
                "Copied policy cannot be pasted into this Interface Pair",
              ),
              " ",
            )));
      }
      const To = function (r) {
        return { "nu-tooltip-hint": r };
      };
      function Co(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "nu-menu-item-button", 16),
            e.ALo(1, "async"),
            e.ALo(2, "async"),
            e._UZ(3, "nu-icon", 2),
            e.TgZ(4, "span", 17),
            e.ALo(5, "async"),
            e.ALo(6, "async"),
            e._uU(7),
            e.ALo(8, "translate"),
            e.qZA()(),
            e.YNc(9, Po, 3, 3, "ng-template", null, 18, e.W1O)),
          2 & r)
        ) {
          const t = e.MAs(10),
            i = e.oxw(2);
          (e.Q6J("menu", i.menu)("disabled", !0)("nuTip", t)(
            "nuTipDisabled",
            !1 === e.lcZ(1, 7, i.singleNonImplicitPolicySelected) ||
              void 0 === e.lcZ(2, 9, i.copiedPolicy),
          ),
            e.xp6(3),
            e.Q6J("icon", i.pasteIcon),
            e.xp6(1),
            e.Q6J(
              "ngClass",
              e.VKq(
                17,
                To,
                e.lcZ(5, 11, i.singleNonImplicitPolicySelected) &&
                  e.lcZ(6, 13, i.copiedPolicy),
              ),
            ),
            e.xp6(3),
            e.hij(" ", e.lcZ(8, 15, "Paste"), " "));
        }
      }
      function xo(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "nu-menu-item-button", 19),
            e._UZ(1, "nu-icon", 2),
            e.TgZ(2, "span"),
            e._uU(3),
            e.ALo(4, "translate"),
            e.qZA()()),
          2 & r)
        ) {
          const t = e.oxw(2);
          (e.Q6J("menu", t.menu)("disabled", !0),
            e.xp6(1),
            e.Q6J("icon", t.plusIcon),
            e.xp6(2),
            e.Oqu(e.lcZ(4, 4, "Insert empty policy")));
        }
      }
      function Mo(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "nu-menu-item-button", 14),
            e._UZ(1, "nu-icon", 2),
            e.TgZ(2, "span"),
            e._uU(3),
            e.ALo(4, "translate"),
            e.qZA()()),
          2 & r)
        ) {
          e.oxw();
          const t = e.MAs(14),
            i = e.oxw();
          (e.Q6J("menu", i.menu)("nuPopUpMenuToggle", t),
            e.xp6(1),
            e.Q6J("icon", i.plusIcon),
            e.xp6(2),
            e.Oqu(e.lcZ(4, 4, "Insert empty policy")));
        }
      }
      function Io(r, o) {
        if (
          (1 & r &&
            (e.ynx(0), e._uU(1, " \xa0 "), e._UZ(2, "nu-icon", 11), e.BQk()),
          2 & r)
        ) {
          const t = e.oxw(3);
          (e.xp6(2), e.Q6J("icon", t.loadingIcon));
        }
      }
      function Oo(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "nu-menu-item-button", 1),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw(2);
              return e.KtG(n.cloneReverse());
            }),
            e.ALo(1, "async"),
            e._UZ(2, "nu-icon", 2),
            e.TgZ(3, "span"),
            e._uU(4),
            e.ALo(5, "translate"),
            e.qZA(),
            e.YNc(6, Io, 3, 1, "ng-container", 0),
            e.qZA());
        }
        if (2 & r) {
          const t = e.oxw(2);
          (e.Q6J("menu", t.menu)(
            "disabled",
            t.multiplePoliciesSelected ||
              !1 !== e.lcZ(1, 5, t.disableCloneReverseObs),
          ),
            e.xp6(2),
            e.Q6J("icon", t.cloneIcon),
            e.xp6(2),
            e.Oqu(e.lcZ(5, 7, "Create reverse policy")),
            e.xp6(2),
            e.Q6J(
              "ngIf",
              !t.multiplePoliciesSelected && void 0 === t.enableCloneReverse,
            ));
        }
      }
      function Eo(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "nu-menu-item-button", 20),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw(2);
              return e.KtG(n.movePolicyById());
            }),
            e._UZ(1, "nu-icon", 2),
            e.TgZ(2, "span"),
            e._uU(3),
            e.ALo(4, "translate"),
            e.qZA()());
        }
        if (2 & r) {
          const t = e.oxw(2);
          (e.Q6J("menu", t.menu),
            e.xp6(1),
            e.Q6J("icon", t.moveIcon),
            e.xp6(2),
            e.Oqu(e.lcZ(4, 3, "Move by ID")));
        }
      }
      function Lo(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.ynx(0),
            e.TgZ(1, "nu-menu-item-button", 1),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw();
              return e.KtG(n.copyEntry());
            }),
            e._UZ(2, "nu-icon", 2),
            e.TgZ(3, "span"),
            e._uU(4),
            e.ALo(5, "translate"),
            e.qZA()(),
            e.YNc(6, vo, 7, 9, "nu-menu-item-button", 3),
            e.YNc(7, So, 15, 10, "ng-container", 4),
            e.ALo(8, "async"),
            e.YNc(9, Co, 11, 19, "ng-template", null, 5, e.W1O),
            e.YNc(11, xo, 5, 6, "nu-menu-item-button", 6),
            e.YNc(12, Mo, 5, 6, "nu-menu-item-button", 7),
            e.TgZ(13, "nu-pop-up-menu", null, 8)(15, "nu-menu-item-button", 9),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw();
              return e.KtG(n.insertAbove());
            }),
            e._UZ(16, "nu-icon", 2),
            e.TgZ(17, "span"),
            e._uU(18),
            e.ALo(19, "translate"),
            e.qZA()(),
            e.TgZ(20, "nu-menu-item-button", 9),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw();
              return e.KtG(n.insertBelow());
            }),
            e._UZ(21, "nu-icon", 2),
            e.TgZ(22, "span"),
            e._uU(23),
            e.ALo(24, "translate"),
            e.qZA()()(),
            e.YNc(25, Oo, 7, 9, "nu-menu-item-button", 3),
            e.YNc(26, Eo, 5, 5, "nu-menu-item-button", 10),
            e.ALo(27, "async"),
            e.BQk());
        }
        if (2 & r) {
          const t = o.ngIf,
            i = e.MAs(10),
            n = e.oxw();
          (e.xp6(1),
            e.Q6J("menu", n.menu)("disabled", n.isCopyDisabled()),
            e.xp6(1),
            e.Q6J("icon", n.copyIcon),
            e.xp6(2),
            e.Oqu(e.lcZ(5, 15, "Copy")),
            e.xp6(2),
            e.Q6J("ngIf", t.optInForInlineMenu && !t.interfacePairView),
            e.xp6(1),
            e.Q6J("ngIf", e.lcZ(8, 17, n.policyValidToPasteInSection))(
              "ngIfElse",
              i,
            ),
            e.xp6(4),
            e.Q6J(
              "ngIf",
              !t.optInForInlineMenu &&
                (n.multiplePoliciesSelected || n.implicitPolicySelected),
            ),
            e.xp6(1),
            e.Q6J(
              "ngIf",
              !t.optInForInlineMenu &&
                !n.multiplePoliciesSelected &&
                !n.implicitPolicySelected,
            ),
            e.xp6(4),
            e.Q6J("icon", n.insertAboveIcon),
            e.xp6(2),
            e.Oqu(e.lcZ(19, 19, "Above")),
            e.xp6(3),
            e.Q6J("icon", n.insertBelowIcon),
            e.xp6(2),
            e.Oqu(e.lcZ(24, 21, "Below")),
            e.xp6(2),
            e.Q6J("ngIf", !t.optInForInlineMenu || t.interfacePairView),
            e.xp6(1),
            e.Q6J(
              "ngIf",
              !t.interfacePairView &&
                e.lcZ(27, 23, n.singleNonImplicitPolicySelected),
            ));
        }
      }
      let wo = (() => {
        class r {
          constructor(t, i, n, l, a, s) {
            if (
              ((this.slide = t),
              (this.sourceManagerFactory = i),
              (this.notify = n),
              (this.translation = l),
              (this.router = a),
              (this.multiplePoliciesSelected = !1),
              (this.implicitPolicySelected = !1),
              (this.selectionSnapshot = y.rA),
              (this.selectionSubject = new he.X(this.selectionSnapshot)),
              (this.selectedPolicyLeadsGroup = !1),
              (this.selection = this.selectionSubject.asObservable()),
              (this.copiedPolicySubject = new he.X(this.copiedPolicySnapshot)),
              (this.copiedPolicy = this.copiedPolicySubject.asObservable()),
              (this.copiedPolicyChange = new e.vpe()),
              (this.disableCloneReverseObs = (0, co.D)(
                this.loadDataForCloneReverseVisibility(),
              ).pipe((0, Se.U)((u) => !this.shouldEnableCloneReverse(u)))),
              (this.SLIDE_WIDTH = 600),
              (this.copyIcon = dt.UI),
              (this.pasteIcon = Y.bGW),
              (this.plusIcon = Y.R7U),
              (this.insertAboveIcon = Nt.O7),
              (this.insertBelowIcon = Nt.Zk),
              (this.pasteAboveIcon = Y.WZs),
              (this.pasteBelowIcon = Y.JBv),
              (this.cloneIcon = dt.W6),
              (this.loadingIcon = Y.Qtd),
              (this.moveIcon = Y.guY),
              !s)
            )
              throw new Error("Could not inject mutable component");
            ((this.mutable = s),
              (this.singleNonImplicitPolicySelected =
                this.createSingleNonImplicitPolicySelected()),
              (this.policyValidToPasteInSection =
                this.createPolicyValidToPasteInSection()));
          }
          set _selectionInput(t) {
            var i;
            if (
              this.mutable.source instanceof Me ||
              this.mutable.source instanceof Le
            ) {
              const n =
                null === (i = t.lastSelectedRow) || void 0 === i
                  ? void 0
                  : i.entry;
              null != n &&
                n.data &&
                (this.selectedPolicyLeadsGroup =
                  this.mutable.source.leadingPolicyOfGroups.has(
                    parseInt(n[_.go], 10),
                  ));
            }
            ((this.selectionSnapshot = t), this.selectionSubject.next(t));
          }
          set _copiedPolicyInput(t) {
            ((this.copiedPolicySnapshot = t), this.copiedPolicySubject.next(t));
          }
          getEmptyPolicy() {
            var t;
            const i =
              null === (t = this.selectionSnapshot.lastSelectedRow) ||
              void 0 === t
                ? void 0
                : t.entry;
            return i ? i.createNewPolicy() : null;
          }
          notifySuccessMessage() {
            this.notify.success(
              this.translation.translate("Your changes have been saved"),
            );
          }
          notifyFailureMessage() {
            this.notify.error(
              this.translation.translate("Failed to save changes"),
            );
          }
          addEntry(t, i) {
            var n, l;
            return (0, d.mG)(this, void 0, void 0, function* () {
              if (this.policyTableManager && t) {
                let a = { insertedIndex: null != i ? i : 0 };
                if ("number" != typeof i) {
                  const s = yield this.policyTableManager.getLocateParams(
                    {
                      q_origin_key: t[_.go],
                      srcintf: (0, X.xP)(
                        null === (n = t.data) || void 0 === n
                          ? void 0
                          : n.srcintf[0],
                      ),
                      dstintf: (0, X.xP)(
                        null === (l = t.data) || void 0 === l
                          ? void 0
                          : l.dstintf[0],
                      ),
                    },
                    this.policyTableManager.viewTypeManager.currentTableView,
                  );
                  s &&
                    (a =
                      "number" != typeof s.matches
                        ? {
                            insertedIndex: s.matches.sectionIndex,
                            insertedSection: s.matches.sectionValue,
                          }
                        : { insertedIndex: s.matches });
                }
                try {
                  yield this.mutable.addEntry(t, a);
                } catch (s) {
                  (M.cM.error("Failed to add policy entry to mutable:"),
                    M.cM.error(s));
                }
              }
            });
          }
          insertAbove() {
            var t, i, n;
            return (0, d.mG)(this, void 0, void 0, function* () {
              const l =
                  null === (t = this.selectionSnapshot.lastSelectedRow) ||
                  void 0 === t
                    ? void 0
                    : t.entry,
                a =
                  null === (i = this.selectionSnapshot.lastSelectedRow) ||
                  void 0 === i
                    ? void 0
                    : i.sourceIndex;
              if (l && null != a)
                try {
                  const s = this.getEmptyPolicy();
                  if (s) {
                    const u = yield this.copyEntryToCmdb(s);
                    if (u) {
                      const g = l[_.go];
                      (yield null === (n = this.policyTableManager) ||
                      void 0 === n
                        ? void 0
                        : n.processGroupLabel(!0, l, u),
                        yield u.moveBefore(g, !0),
                        yield this.addEntry(u),
                        this.notifySuccessMessage());
                    }
                  }
                } catch (s) {
                  (M.cM.error("Failed to insert above:"),
                    M.cM.error(s),
                    this.notifyFailureMessage());
                }
            });
          }
          insertBelow() {
            var t, i;
            return (0, d.mG)(this, void 0, void 0, function* () {
              if (
                null ==
                (null === (t = this.selectionSnapshot.lastSelectedRow) ||
                void 0 === t
                  ? void 0
                  : t.sourceIndex)
              )
                return;
              const l =
                null === (i = this.selectionSnapshot.lastSelectedRow) ||
                void 0 === i
                  ? void 0
                  : i.entry;
              if (l)
                try {
                  const a = this.getEmptyPolicy();
                  if (a) {
                    const s = yield this.copyEntryToCmdb(a);
                    if (s) {
                      const u = l[_.go];
                      (yield s.moveAfter(u, !0),
                        yield this.addEntry(s),
                        this.notifySuccessMessage());
                    }
                  }
                } catch (a) {
                  (M.cM.error("Failed to insert below:"),
                    M.cM.error(a),
                    this.notifyFailureMessage());
                }
            });
          }
          copyEntry(t) {
            const i = this.selectionSnapshot.entries[0];
            let n;
            ((n = t ? i.getPolicyReverseClone() : i.getPolicyCopy()),
              (this.copiedPolicySnapshot = n),
              this.copiedPolicySubject.next(n),
              this.copiedPolicyChange.emit(n));
          }
          isCopyDisabled() {
            return !!this.multiplePoliciesSelected;
          }
          copyEntryToCmdb(t) {
            return (0, d.mG)(this, void 0, void 0, function* () {
              if (
                (!t &&
                  this.copiedPolicySnapshot &&
                  (t = this.copiedPolicySnapshot),
                (t = null == t ? void 0 : t.getPolicyCopy()))
              ) {
                ((t[_.go] = ""),
                  t.data && (t.data.policyid = 0),
                  t instanceof me.j &&
                    t.policyExpired() &&
                    t.data &&
                    ((t.data["policy-expiry"] = "disable"),
                    (t.data["policy-expiry-date"] = "")));
                const i = yield t.saveWithResponse();
                if ("mkey" in i)
                  return (
                    (t[_.go] = String(i.mkey)),
                    t.data && (t.data.policyid = i.mkey),
                    t
                  );
              }
              return null;
            });
          }
          pasteAbove() {
            var t, i, n;
            return (0, d.mG)(this, void 0, void 0, function* () {
              const l =
                  null === (t = this.selectionSnapshot.lastSelectedRow) ||
                  void 0 === t
                    ? void 0
                    : t.entry,
                a =
                  null === (i = this.selectionSnapshot.lastSelectedRow) ||
                  void 0 === i
                    ? void 0
                    : i.sourceIndex;
              if (l && null != a)
                try {
                  const s = yield this.copyEntryToCmdb();
                  if (s) {
                    const u = l[_.go];
                    (yield null === (n = this.policyTableManager) ||
                    void 0 === n
                      ? void 0
                      : n.processGroupLabel(!0, l, s),
                      yield s.moveBefore(u, !0),
                      yield this.addEntry(s),
                      this.notifySuccessMessage());
                  }
                } catch (s) {
                  (M.cM.error("Failed to paste:"),
                    M.cM.error(s),
                    this.notifyFailureMessage());
                }
            });
          }
          pasteBelow() {
            var t, i;
            return (0, d.mG)(this, void 0, void 0, function* () {
              if (
                null ==
                (null === (t = this.selectionSnapshot.lastSelectedRow) ||
                void 0 === t
                  ? void 0
                  : t.sourceIndex)
              )
                return;
              const l =
                null === (i = this.selectionSnapshot.lastSelectedRow) ||
                void 0 === i
                  ? void 0
                  : i.entry;
              if (l)
                try {
                  const a = yield this.copyEntryToCmdb();
                  if (a) {
                    const s = l[_.go];
                    (yield a.moveAfter(s, !0),
                      yield this.addEntry(a),
                      this.notifySuccessMessage());
                  }
                } catch (a) {
                  (M.cM.error("Failed to paste:"),
                    M.cM.error(a),
                    this.notifyFailureMessage());
                }
            });
          }
          shouldEnableCloneReverse(t) {
            var i, n, l, a;
            if (null != this.enableCloneReverse)
              return !!this.enableCloneReverse;
            const s =
              null === (i = this.selectionSnapshot.lastSelectedRow) ||
              void 0 === i
                ? void 0
                : i.entry;
            return (
              !!s &&
              ((this.enableCloneReverse = !(
                "ipsec" ===
                  (null === (n = s.data) || void 0 === n ? void 0 : n.action) ||
                s.isNatEnabled() ||
                s.hasInterfaceAny() ||
                s.hasVIP() ||
                s.hasInternetService() ||
                s.hasMacAddress(
                  null === (l = t.firewallAddress) || void 0 === l
                    ? void 0
                    : l.map,
                  null === (a = t.firewallAddress6) || void 0 === a
                    ? void 0
                    : a.map,
                ) ||
                s.hasDynamicDeviceAddress() ||
                s.hasExternalResources() ||
                (() =>
                  !!s.data &&
                  "learning-mode" in s.data &&
                  "enable" === s.data["learning-mode"] &&
                  s.data.dstintf.some((h) => {
                    var P, N;
                    return (
                      !0 !==
                      (null ===
                        (N =
                          null ===
                            (P = this.sourceManagerFactory
                              .getTableSourceManager()
                              .omniSources.firewallInterface.getEntry(
                                (0, X.xP)(h),
                              )) || void 0 === P
                            ? void 0
                            : P.data) || void 0 === N
                        ? void 0
                        : N.device_id_enabled)
                    );
                  }))() ||
                (() => {
                  var h, P;
                  return (
                    (null === (h = s.data) || void 0 === h
                      ? void 0
                      : h.dstaddr.some((N) => {
                          var L, J;
                          return (
                            "route-tag" ===
                            (null ===
                              (J =
                                null ===
                                  (L = this.sourceManagerFactory
                                    .getTableSourceManager()
                                    .omniSources.firewallAddress.getEntry(
                                      (0, X.xP)(N),
                                    )) || void 0 === L
                                  ? void 0
                                  : L.data) || void 0 === J
                              ? void 0
                              : J.type)
                          );
                        })) ||
                    (null === (P = s.data) || void 0 === P
                      ? void 0
                      : P.dstaddr6.some((N) => {
                          var L, J;
                          return (
                            "route-tag" ===
                            (null ===
                              (J =
                                null ===
                                  (L = this.sourceManagerFactory
                                    .getTableSourceManager()
                                    .omniSources.firewallAddress6.getEntry(
                                      (0, X.xP)(N),
                                    )) || void 0 === L
                                  ? void 0
                                  : L.data) || void 0 === J
                              ? void 0
                              : J.type)
                          );
                        })) ||
                    !1
                  );
                })()
              )),
              !!this.enableCloneReverse)
            );
          }
          loadDataForCloneReverseVisibility() {
            return (0, d.mG)(this, void 0, void 0, function* () {
              const t = this.sourceManagerFactory.getTableSourceManager();
              return (
                yield (0, It.D)({
                  addresses: t.loadAndCacheAddresses(),
                  firewallInterfaces: t.loadAndCacheInterfaces(),
                }),
                t.cached
              );
            });
          }
          reverseCloneEntryToCmdb(t) {
            return (0, d.mG)(this, void 0, void 0, function* () {
              const i = t.getPolicyReverseClone(),
                n = yield i.saveWithResponse();
              return "mkey" in n ? ((i[_.go] = String(n.mkey)), i) : null;
            });
          }
          cloneReverse() {
            var t, i;
            return (0, d.mG)(this, void 0, void 0, function* () {
              if (
                null ==
                (null === (t = this.selectionSnapshot.lastSelectedRow) ||
                void 0 === t
                  ? void 0
                  : t.sourceIndex)
              )
                return;
              const l =
                null === (i = this.selectionSnapshot.lastSelectedRow) ||
                void 0 === i
                  ? void 0
                  : i.entry;
              if (l)
                try {
                  const a = yield this.reverseCloneEntryToCmdb(l);
                  if (a) {
                    const s = l[_.go];
                    (yield a.moveAfter(s, !0),
                      yield this.addEntry(a),
                      this.notifySuccessMessage());
                  }
                } catch (a) {
                  (M.cM.error("Failed to reverse-clone:"),
                    M.cM.error(a),
                    this.notifyFailureMessage());
                }
            });
          }
          pastePolicyInline(t) {
            var i;
            const n = t.orientation === y.wQ.Above,
              l =
                null === (i = this.selectionSnapshot.lastSelectedRow) ||
                void 0 === i
                  ? void 0
                  : i.entry;
            l &&
              t.resolve(
                (() =>
                  (0, d.mG)(this, void 0, void 0, function* () {
                    var a, s, u;
                    try {
                      const g = yield this.copyEntryToCmdb();
                      if (g) {
                        null ===
                          (s =
                            null === (a = this.policyTableManager) ||
                            void 0 === a
                              ? void 0
                              : a.policySource) ||
                          void 0 === s ||
                          s.notifyAngularJsSourceChange();
                        const h = l[_.go];
                        return (
                          n
                            ? (yield null === (u = this.policyTableManager) ||
                              void 0 === u
                                ? void 0
                                : u.processGroupLabel(n, l, g),
                              yield g.moveBefore(h, !0))
                            : yield g.moveAfter(h, !0),
                          this.notifySuccessMessage(),
                          g
                        );
                      }
                    } catch (g) {
                      return (
                        M.cM.error("Failed to paste:"),
                        M.cM.error(g),
                        this.notifyFailureMessage(),
                        Promise.reject(g)
                      );
                    }
                  }))(),
              );
          }
          createSingleNonImplicitPolicySelected() {
            return this.selection.pipe(
              (0, Se.U)(
                (t) => 1 === t.entries.length && !t.entries[0].implicit,
              ),
            );
          }
          createPolicyValidToPasteInSection() {
            return this.copiedPolicy.pipe(
              (0, uo.h)(X.D),
              (0, ce.w)((t) => (0, Ee.a)([(0, ke.of)(t), this.selection])),
              (0, Se.U)(([t, i]) => {
                var n, l, a, s, u;
                let g = 1 === i.entries.length && !i.entries[0].implicit;
                if (
                  null !== (n = this.policyTableManager) &&
                  void 0 !== n &&
                  n.viewTypeManager.interfacePairView
                ) {
                  const h = i.entries[0];
                  (Dt(
                    (null === (l = h.data) || void 0 === l
                      ? void 0
                      : l.srcintf) || [],
                    (null === (a = t.data) || void 0 === a
                      ? void 0
                      : a.srcintf) || [],
                  ) &&
                    Dt(
                      (null === (s = h.data) || void 0 === s
                        ? void 0
                        : s.dstintf) || [],
                      (null === (u = t.data) || void 0 === u
                        ? void 0
                        : u.dstintf) || [],
                    )) ||
                    (g = !1);
                }
                return g;
              }),
              (0, Ae.O)(!1),
            );
          }
          movePolicyById() {
            var t, i, n, l, a;
            return (0, d.mG)(this, void 0, void 0, function* () {
              const s =
                null === (t = this.selectionSnapshot.lastSelectedRow) ||
                void 0 === t
                  ? void 0
                  : t.entry;
              if (
                s &&
                (this.mutable.source instanceof Me ||
                  this.mutable.source instanceof Le)
              ) {
                const u = {
                  provide: Zt,
                  useValue: {
                    policyEntry: s,
                    tableView:
                      null === (i = this.policyTableManager) || void 0 === i
                        ? void 0
                        : i.viewTypeManager.currentTableView,
                    leadingPolicyOfGroups:
                      this.mutable.source.leadingPolicyOfGroups,
                  },
                };
                try {
                  const { locateMovedEntry: g, policyEntry: h } =
                    yield this.slide
                      .open({
                        component: yo,
                        providers: [u],
                        settings: { width: this.SLIDE_WIDTH },
                      })
                      .toPromise();
                  if ((this.mutable.clearSelection(), g))
                    if (
                      (null === (n = this.policyTableManager) || void 0 === n
                        ? void 0
                        : n.viewTypeManager.currentTableView) ===
                      re.H.BySequenceView
                    ) {
                      const P = this.router.parseUrl(this.router.url);
                      ((P.queryParams = Object.assign(
                        Object.assign({}, P.queryParams),
                        {
                          showInList: JSON.stringify({ q_origin_key: h[_.go] }),
                        },
                      )),
                        yield this.router.navigateByUrl(P));
                    } else {
                      const P = g
                        ? yield null === (l = this.policyTableManager) ||
                          void 0 === l
                            ? void 0
                            : l.getLocateParams(
                                { q_origin_key: h[_.go] },
                                this.policyTableManager.viewTypeManager
                                  .currentTableView,
                              )
                        : void 0;
                      yield this.mutable.addEntry(h, {
                        insertedIndex:
                          null == P ? void 0 : P.matches.sectionIndex,
                        insertedSection:
                          null == P ? void 0 : P.matches.sectionValue,
                      });
                    }
                  else
                    null === (a = this.policyTableManager) ||
                      void 0 === a ||
                      a.viewTypeManager.reloadWithCurrentView();
                } catch (g) {
                  M.cM.error(g);
                }
              } else
                M.cM.error(
                  "Selected entry and Policy or Security Policy source is expected.",
                );
            });
          }
        }
        return (
          (r.ɵfac = function (t) {
            return new (t || r)(
              e.Y36($.Bc),
              e.Y36(ct.n),
              e.Y36(Qe.Cq),
              e.Y36(G.D7),
              e.Y36(w.Router),
              e.Y36(y.MW, 8),
            );
          }),
          (r.ɵcmp = e.Xpm({
            type: r,
            selectors: [["fos-policy-table-copy-paste-menu"]],
            inputs: {
              menu: "menu",
              multiplePoliciesSelected: "multiplePoliciesSelected",
              implicitPolicySelected: "implicitPolicySelected",
              policyTableManager: "policyTableManager",
              _selectionInput: ["selection", "_selectionInput"],
              _copiedPolicyInput: ["copiedPolicy", "_copiedPolicyInput"],
            },
            outputs: { copiedPolicyChange: "copiedPolicyChange" },
            decls: 1,
            vars: 1,
            consts: [
              [4, "ngIf"],
              [3, "menu", "disabled", "action"],
              [3, "icon"],
              [3, "menu", "disabled", "action", 4, "ngIf"],
              [4, "ngIf", "ngIfElse"],
              ["cantPastePolicy", ""],
              [3, "menu", "disabled", 4, "ngIf"],
              [3, "menu", "nuPopUpMenuToggle", 4, "ngIf"],
              ["insertMenu", ""],
              [3, "action"],
              [3, "menu", "action", 4, "ngIf"],
              [1, "nu-loading-icon", 3, "icon"],
              ["pasteMenu", ""],
              [3, "menu", "translationKey", "insert", 4, "ngIf"],
              [3, "menu", "nuPopUpMenuToggle"],
              [3, "menu", "translationKey", "insert"],
              [3, "menu", "disabled", "nuTip", "nuTipDisabled"],
              [3, "ngClass"],
              ["disabledPasteTip", ""],
              [3, "menu", "disabled"],
              [3, "menu", "action"],
            ],
            template: function (t, i) {
              (1 & t && e.YNc(0, Lo, 28, 25, "ng-container", 0),
                2 & t &&
                  e.Q6J(
                    "ngIf",
                    null == i.policyTableManager
                      ? null
                      : i.policyTableManager.viewTypeManager,
                  ));
            },
            dependencies: [
              D._g,
              O.mk,
              O.O5,
              y.LL,
              A.lD,
              E.C6,
              E.Zo,
              E.wk,
              f.oJ,
              O.Ov,
              Re.X,
            ],
            encapsulation: 2,
          })),
          r
        );
      })();
      function Dt(r, o) {
        const t = (i) => ("string" == typeof i ? i : i.name);
        return 1 === r.length && 1 === o.length && t(r[0]) === t(o[0]);
      }
      var Ao = c(64065);
      const Fo = function () {
        return { fosPatterns: "Invalid sequence grouping name." };
      };
      function No(r, o) {
        if (
          (1 & r &&
            (e.ynx(0),
            e.TgZ(1, "label", 5),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "nu-field", 6),
            e._UZ(5, "input", 7, 8),
            e.qZA(),
            e.BQk()),
          2 & r)
        ) {
          const t = e.MAs(6);
          (e.xp6(1),
            e.Q6J("nuFor", t),
            e.xp6(1),
            e.Oqu(e.lcZ(3, 3, "Sequence grouping name")),
            e.xp6(2),
            e.Q6J("errorMessages", e.DdM(5, Fo)));
        }
      }
      function Zo(r, o) {
        if (
          (1 & r && (e.TgZ(0, "span"), e._uU(1), e.ALo(2, "fn"), e.qZA()),
          2 & r)
        ) {
          const t = e.oxw().$implicit,
            i = e.oxw(4);
          (e.xp6(1), e.Oqu(e.xi3(2, 1, i.formatGroupLabel, t)));
        }
      }
      function Do(r, o) {
        (1 & r && (e.TgZ(0, "span"), e._uU(1), e.ALo(2, "translate"), e.qZA()),
          2 & r && (e.xp6(1), e.Oqu(e.lcZ(2, 1, "Uncategorized"))));
      }
      function Go(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "option", 12),
            e.YNc(1, Zo, 3, 4, "span", 4),
            e.YNc(2, Do, 3, 3, "span", 4),
            e.qZA()),
          2 & r)
        ) {
          const t = o.$implicit;
          (e.Q6J("ngValue", t),
            e.xp6(1),
            e.Q6J("ngIf", "uncategorized" !== t),
            e.xp6(1),
            e.Q6J("ngIf", "uncategorized" === t));
        }
      }
      function Uo(r, o) {
        if (
          (1 & r &&
            (e.ynx(0),
            e.TgZ(1, "label", 5),
            e._uU(2),
            e.ALo(3, "translate"),
            e.qZA(),
            e.TgZ(4, "nu-field")(5, "select", 9, 10),
            e.YNc(7, Go, 3, 3, "option", 11),
            e.qZA()(),
            e.BQk()),
          2 & r)
        ) {
          const t = e.MAs(6),
            i = e.oxw(3);
          (e.xp6(1),
            e.Q6J("nuFor", t),
            e.xp6(1),
            e.hij(" ", e.lcZ(3, 3, "Move to another sequence grouping"), " "),
            e.xp6(5),
            e.Q6J("ngForOf", i.candidateMoveToGroupLabels));
        }
      }
      function Ro(r, o) {
        if (
          (1 & r &&
            (e.YNc(0, No, 7, 6, "ng-container", 4),
            e.YNc(1, Uo, 8, 5, "ng-container", 4)),
          2 & r)
        ) {
          const t = e.oxw(2);
          (e.Q6J(
            "ngIf",
            t.operation !== t.PolicySequenceGroupingOperation.Move,
          ),
            e.xp6(1),
            e.Q6J(
              "ngIf",
              t.operation === t.PolicySequenceGroupingOperation.Move,
            ));
        }
      }
      function Vo(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "form", 2)(1, "nu-dialog-section"),
            e.YNc(2, Ro, 2, 2, "ng-template", 3),
            e.qZA()()),
          2 & r)
        ) {
          const t = e.oxw();
          e.Q6J("formGroup", t.form);
        }
      }
      var _e = (() => {
        return (
          ((r = _e || (_e = {})).Insert = "Insert"),
          (r.Rename = "Rename"),
          (r.Move = "Move"),
          _e
        );
        var r;
      })();
      const Gt = new e.OlP("PolicySequenceGroupingDialogData");
      let Bo = (() => {
        class r {
          constructor(t, i) {
            ((this.translation = t),
              (this.loading = !0),
              (this.currentGroupLabels = new Set([oe.BE])),
              (this.currentFormattedGroupLabel = ""),
              (this.currentGroupLabel = ""),
              (this.policyEntryGroupLabel = ""),
              (this.moveToGroupLabel = ""),
              (this.candidateMoveToGroupLabels = []),
              (this.fosPatterns = yt.W),
              (this.PolicySequenceGroupingOperation = _e),
              (this.form = new S.cw({})),
              (this.formatGroupLabel = oe.Ur),
              (this.policyEntry = i.policyEntry),
              (this.rawCurrentGroupLabels = i.currentGroupLabels),
              (this.leadingPolicyOfGroups = i.leadingPolicyOfGroups),
              (this.operation = i.operation));
            let n = "";
            (this.operation === _e.Insert
              ? (n = "Insert Sequence Grouping")
              : this.operation === _e.Rename
                ? (n = "Rename Sequence Grouping")
                : this.operation === _e.Move &&
                  (n = "Move to Another Sequence Grouping"),
              (this.title = n && this.translation.translate(n)));
          }
          ngOnInit() {
            return (0, d.mG)(this, void 0, void 0, function* () {
              this.loading = !0;
              try {
                if (
                  this.policyEntry[_.Hx] instanceof pe.m ||
                  this.policyEntry[_.Hx] instanceof ve.u
                ) {
                  const t = yield this.policyEntry[
                    _.Hx
                  ].getPolicyGroupLabelInfo(this.policyEntry[_.go]);
                  if (!t)
                    throw new Error("Unabel to find group label information.");
                  switch (
                    ((this.currentFormattedGroupLabel = t.formattedGlobalLabel),
                    (this.currentGroupLabel = t.groupLabel),
                    this.operation)
                  ) {
                    case _e.Move:
                      this.setupForOperationMove();
                      break;
                    case _e.Insert:
                    case _e.Rename:
                      this.setupForOperationInsertOrRename();
                      break;
                    default:
                      throw new Error(
                        "Unsupported sequence grouping operation.",
                      );
                  }
                  this.loading = !1;
                } else
                  M.cM.error("Policy or Security Policy source is expected.");
              } catch (t) {
                (M.cM.error("Unable to update sequence grouping:"),
                  M.cM.error(t));
              }
            });
          }
          setupForOperationMove() {
            ((this.candidateMoveToGroupLabels = Array.from(
              this.rawCurrentGroupLabels,
            ).filter((t) => {
              const i = t.toLowerCase();
              return (
                i !== this.currentFormattedGroupLabel.toLowerCase() &&
                "implicit" !== i &&
                ("" !== this.currentFormattedGroupLabel || i !== oe.BE)
              );
            })),
              (this.moveToSequenceGroupSelect = new S.NI(
                this.moveToGroupLabel,
                { validators: [S.kI.required], nonNullable: !0 },
              )),
              this.form.addControl(
                "moveToSequenceGroupSelect",
                this.moveToSequenceGroupSelect,
              ));
          }
          setupForOperationInsertOrRename() {
            var t, i;
            const n = this.leadingPolicyOfGroups.has(
              parseInt(this.policyEntry[_.go], 10),
            );
            this.policyEntryGroupLabel =
              n &&
              null !==
                (i =
                  null === (t = this.policyEntry.data) || void 0 === t
                    ? void 0
                    : t["global-label"]) &&
              void 0 !== i
                ? i
                : "";
            for (const l of Array.from(this.rawCurrentGroupLabels)) {
              const s = (0, oe.dh)(l).parsedGroupLabel.toLowerCase();
              s !== this.policyEntryGroupLabel.toLowerCase() &&
                this.currentGroupLabels.add(s);
            }
            ((this.sequenceGroupNameInput = new S.NI(
              this.policyEntryGroupLabel,
              {
                validators: [
                  S.kI.required,
                  S.kI.maxLength(63),
                  (0, rt.b)([this.fosPatterns.XSS]),
                  (0, Ao.t)(
                    this.currentGroupLabels,
                    (l, a) =>
                      "string" == typeof a && l.has(a.toLowerCase().trim()),
                  ),
                ],
                nonNullable: !0,
              },
            )),
              this.form.addControl(
                "sequenceGroupName",
                this.sequenceGroupNameInput,
              ));
          }
          policyMoveToSequenceGroupHelper(t, i, n, l) {
            return (0, d.mG)(this, void 0, void 0, function* () {
              if (
                !(t[_.Hx] instanceof pe.m || t[_.Hx] instanceof ve.u) ||
                !t.data
              )
                return {
                  success: !1,
                  errorMsg:
                    "Valid policy or security policy entry is expected.",
                };
              let a = n === oe.BE ? "" : n,
                s = 0;
              if (a) {
                const h = (0, oe.dh)(a);
                ((a = h.parsedGroupLabel), (s = h.skipTo));
              }
              const g = (yield t[_.Hx].getTargetGroupPolicyInfo([a], s)).at(-1);
              if (g) {
                const h = t.data["global-label"],
                  P = l.has(parseInt(t[_.go], 10));
                if (h && P) {
                  const L = (0, oe.dh)(i).skipTo,
                    Q = (yield t[_.Hx].getTargetGroupPolicyInfo([h], L)).at(1);
                  if (Q) {
                    const j = yield t[_.Hx].load({
                      keys: [String(Q.policyid)],
                    });
                    if (Array.isArray(j)) {
                      const K = j[0];
                      yield ze(K, t);
                    }
                  } else yield ut(t, "", !0);
                } else
                  h &&
                    ((t.data["global-label"] = ""),
                    yield t.save({ skipChangeSummary: !0 }));
                return (yield t.moveAfter(String(g.policyid)), { success: !0 });
              }
              return {
                success: !1,
                errorMsg: "Unable to find the target move-to group.",
              };
            });
          }
          slideSubmitting() {
            return (0, d.mG)(this, void 0, void 0, function* () {
              if (
                !(
                  this.policyEntry[_.Hx] instanceof pe.m ||
                  this.policyEntry[_.Hx] instanceof ve.u
                )
              )
                return (
                  M.cM.error("Policy or Security Policy source is expected."),
                  { requireReload: !1 }
                );
              if (
                this.operation !== _e.Move &&
                this.sequenceGroupNameInput.value &&
                this.policyEntry.data &&
                this.policyEntryGroupLabel !== this.sequenceGroupNameInput.value
              )
                return (
                  yield this.policyEntry.insertOrRenameGroupLabel(
                    this.currentGroupLabel,
                    this.sequenceGroupNameInput.value,
                  ),
                  {
                    requireReload: !0,
                    policyId: this.policyEntry.data.policyid,
                  }
                );
              if (
                this.operation === _e.Move &&
                this.moveToSequenceGroupSelect.value &&
                this.policyEntry.data
              ) {
                const t = yield this.policyMoveToSequenceGroupHelper(
                  this.policyEntry,
                  this.currentFormattedGroupLabel,
                  this.moveToSequenceGroupSelect.value,
                  this.leadingPolicyOfGroups,
                );
                return t.success
                  ? {
                      requireReload: !0,
                      policyId: this.policyEntry.data.policyid,
                      policyEntry: this.policyEntry,
                    }
                  : (M.cM.error(t.errorMsg), { requireReload: !1 });
              }
              return { requireReload: !1 };
            });
          }
        }
        return (
          (r.ɵfac = function (t) {
            return new (t || r)(e.Y36(G.D7), e.Y36(Gt));
          }),
          (r.ɵcmp = e.Xpm({
            type: r,
            selectors: [["fos-policy-sequence-grouping-slidein-dialog"]],
            decls: 3,
            vars: 6,
            consts: [
              [3, "dialogTitle", "form", "loading"],
              [3, "formGroup", 4, "ngIf"],
              [3, "formGroup"],
              ["nuDialogSectionContent", ""],
              [4, "ngIf"],
              [3, "nuFor"],
              [3, "errorMessages"],
              [
                "type",
                "text",
                "formControlName",
                "sequenceGroupName",
                "name",
                "sequence-group-name",
              ],
              ["sequenceGroupName", ""],
              ["formControlName", "moveToSequenceGroupSelect"],
              ["currentGroupLabels", ""],
              [3, "ngValue", 4, "ngFor", "ngForOf"],
              [3, "ngValue"],
            ],
            template: function (t, i) {
              (1 & t &&
                (e.TgZ(0, "nu-dialog", 0),
                e.ALo(1, "translate"),
                e.YNc(2, Vo, 3, 1, "form", 1),
                e.qZA()),
                2 & t &&
                  (e.Q6J("dialogTitle", e.lcZ(1, 4, i.title))("form", i.form)(
                    "loading",
                    i.loading,
                  ),
                  e.xp6(2),
                  e.Q6J("ngIf", !i.loading)));
            },
            dependencies: [
              D._g,
              O.sg,
              O.O5,
              I.au,
              I.Jw,
              I.JQ,
              I.CF,
              I.VX,
              I.SM,
              x.yc,
              S._Y,
              S.YN,
              S.Kr,
              S.Fj,
              S.EJ,
              S.JJ,
              S.JL,
              S.sg,
              S.u,
              p.U5,
              Re.X,
            ],
            encapsulation: 2,
          })),
          r
        );
      })();
      function Jo(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "nu-menu-item-button", 2),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw(2);
              return e.KtG(n.insertGroupLabel());
            }),
            e._UZ(1, "nu-icon", 3),
            e.TgZ(2, "span"),
            e._uU(3),
            e.ALo(4, "translate"),
            e.qZA()());
        }
        if (2 & r) {
          const t = e.oxw(2);
          (e.Q6J("menu", t.menu),
            e.xp6(1),
            e.Q6J("icon", t.insertIcon),
            e.xp6(2),
            e.Oqu(e.lcZ(4, 3, "Insert sequence grouping")));
        }
      }
      function ko(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "nu-menu-item-button", 2),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw(2);
              return e.KtG(n.renameGroupLabel());
            }),
            e._UZ(1, "nu-icon", 3),
            e.TgZ(2, "span"),
            e._uU(3),
            e.ALo(4, "translate"),
            e.qZA()());
        }
        if (2 & r) {
          const t = e.oxw(2);
          (e.Q6J("menu", t.menu),
            e.xp6(1),
            e.Q6J("icon", t.editIcon),
            e.xp6(2),
            e.Oqu(e.lcZ(4, 3, "Rename sequence grouping")));
        }
      }
      function Qo(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "nu-menu-item-button", 2),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw(2);
              return e.KtG(n.deleteGroupLabel());
            }),
            e._UZ(1, "nu-icon", 3),
            e.TgZ(2, "span"),
            e._uU(3),
            e.ALo(4, "translate"),
            e.qZA()());
        }
        if (2 & r) {
          const t = e.oxw(2);
          (e.Q6J("menu", t.menu),
            e.xp6(1),
            e.Q6J("icon", t.deleteIcon),
            e.xp6(2),
            e.Oqu(e.lcZ(4, 3, "Delete sequence grouping")));
        }
      }
      function Yo(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "nu-menu-item-button", 2),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw(2);
              return e.KtG(n.moveSequenceGrouping());
            }),
            e._UZ(1, "nu-icon", 3),
            e.TgZ(2, "span"),
            e._uU(3),
            e.ALo(4, "translate"),
            e.qZA()());
        }
        if (2 & r) {
          const t = e.oxw(2);
          (e.Q6J("menu", t.menu),
            e.xp6(1),
            e.Q6J("icon", t.moveIcon),
            e.xp6(2),
            e.Oqu(e.lcZ(4, 3, "Move to another sequence grouping")));
        }
      }
      function Ko(r, o) {
        if (
          (1 & r &&
            (e.ynx(0),
            e.YNc(1, Jo, 5, 5, "nu-menu-item-button", 1),
            e.YNc(2, ko, 5, 5, "nu-menu-item-button", 1),
            e.YNc(3, Qo, 5, 5, "nu-menu-item-button", 1),
            e.YNc(4, Yo, 5, 5, "nu-menu-item-button", 1),
            e.BQk()),
          2 & r)
        ) {
          const t = e.oxw();
          (e.xp6(1),
            e.Q6J("ngIf", !t.currentPolicyLeadsASequenceGroup),
            e.xp6(1),
            e.Q6J("ngIf", t.currentPolicyLeadsASequenceGroup),
            e.xp6(1),
            e.Q6J("ngIf", t.currentPolicyLeadsASequenceGroup),
            e.xp6(1),
            e.Q6J("ngIf", t.allowMoveToAnotherGroup));
        }
      }
      let Wo = (() => {
          class r {
            constructor(t, i, n, l, a) {
              if (
                ((this.slide = t),
                (this.notify = i),
                (this.translation = n),
                (this.prompt = l),
                (this._selection = y.rA),
                (this.currentPolicyLeadsASequenceGroup = !1),
                (this.allowMoveToAnotherGroup = !1),
                (this.readyForSequenceGroupMenu = !0),
                (this.insertIcon = Y.R7U),
                (this.editIcon = Y.hRO),
                (this.deleteIcon = dt.GC),
                (this.moveIcon = Y.guY),
                !a)
              )
                throw new Error("Could not inject mutable component");
              ((this.mutable = a),
                (this.mutable.source instanceof Me ||
                  this.mutable.source instanceof Le) &&
                  (this.allowMoveToAnotherGroup =
                    (this.mutable.source.currentGroupLabels.has(oe.oT)
                      ? this.mutable.source.currentGroupLabels.size > 2
                      : this.mutable.source.currentGroupLabels.size > 1) &&
                    Array.from(this.mutable.source.currentGroupLabels).some(
                      (s) => s !== oe.BE && s !== oe.oT,
                    )));
            }
            get selection() {
              return this._selection;
            }
            set selection(t) {
              var i;
              this._selection = t;
              const n =
                null === (i = t.lastSelectedRow) || void 0 === i
                  ? void 0
                  : i.entry;
              (this.mutable.source instanceof Me ||
                this.mutable.source instanceof Le) &&
              n
                ? (this.currentPolicyLeadsASequenceGroup =
                    this.mutable.source.leadingPolicyOfGroups.has(
                      parseInt(n[_.go], 10),
                    ))
                : (this.readyForSequenceGroupMenu = !1);
            }
            notifySuccessMessage() {
              this.notify.success(
                this.translation.translate("Your changes have been saved"),
              );
            }
            openSequenceGroupingSlideInDialog(t) {
              return (0, d.mG)(this, void 0, void 0, function* () {
                return yield this.slide
                  .open({
                    component: Bo,
                    providers: [{ provide: Gt, useValue: t }],
                    settings: { width: 600 },
                  })
                  .toPromise();
              });
            }
            insertGroupLabel() {
              var t, i, n;
              return (0, d.mG)(this, void 0, void 0, function* () {
                const l =
                  null === (t = this.selection.lastSelectedRow) || void 0 === t
                    ? void 0
                    : t.entry;
                if (
                  (this.mutable.source instanceof Me ||
                    this.mutable.source instanceof Le) &&
                  l
                )
                  try {
                    const { requireReload: a, policyId: s } =
                      yield this.openSequenceGroupingSlideInDialog({
                        policyEntry: l,
                        currentGroupLabels:
                          null !==
                            (n =
                              null === (i = this.mutable.source) || void 0 === i
                                ? void 0
                                : i.currentGroupLabels) && void 0 !== n
                            ? n
                            : new Set(),
                        operation: _e.Insert,
                        leadingPolicyOfGroups:
                          this.mutable.source.leadingPolicyOfGroups,
                      });
                    a && (yield this.reloadTableOnSuccess(s));
                  } catch (a) {}
              });
            }
            deleteGroupLabel() {
              var t, i, n, l, a;
              return (0, d.mG)(this, void 0, void 0, function* () {
                const s =
                  null === (t = this.selection.lastSelectedRow) || void 0 === t
                    ? void 0
                    : t.entry;
                if (
                  (this.mutable.source instanceof Me ||
                    this.mutable.source instanceof Le) &&
                  s &&
                  (null === (i = s.data) || void 0 === i
                    ? void 0
                    : i["global-label"])
                )
                  try {
                    const u = `Are you sure you want to delete sequence grouping name ${null === (n = s.data) || void 0 === n ? void 0 : n["global-label"]}?`;
                    (yield this.prompt.confirm(u),
                      yield s.deleteGroupLabel(s.data["global-label"]),
                      null ===
                        (a =
                          null === (l = this.policyTableManager) || void 0 === l
                            ? void 0
                            : l.viewTypeManager) ||
                        void 0 === a ||
                        a.reloadWithCurrentView(),
                      this.notifySuccessMessage());
                  } catch (u) {}
              });
            }
            renameGroupLabel() {
              var t, i, n;
              return (0, d.mG)(this, void 0, void 0, function* () {
                const l =
                  null === (t = this.selection.lastSelectedRow) || void 0 === t
                    ? void 0
                    : t.entry;
                if (
                  (this.mutable.source instanceof Me ||
                    this.mutable.source instanceof Le) &&
                  l
                )
                  try {
                    const { requireReload: a, policyId: s } =
                      yield this.openSequenceGroupingSlideInDialog({
                        policyEntry: l,
                        currentGroupLabels:
                          null !==
                            (n =
                              null === (i = this.mutable.source) || void 0 === i
                                ? void 0
                                : i.currentGroupLabels) && void 0 !== n
                            ? n
                            : new Set(),
                        operation: _e.Rename,
                        leadingPolicyOfGroups:
                          this.mutable.source.leadingPolicyOfGroups,
                      });
                    a && (yield this.reloadTableOnSuccess(s));
                  } catch (a) {}
              });
            }
            moveSequenceGrouping() {
              var t, i, n;
              return (0, d.mG)(this, void 0, void 0, function* () {
                const l = this.selection.lastSelectedRow,
                  a = null == l ? void 0 : l.entry;
                if (
                  (this.mutable.source instanceof Me ||
                    this.mutable.source instanceof Le) &&
                  a
                )
                  try {
                    const { policyId: s, policyEntry: u } =
                      yield this.openSequenceGroupingSlideInDialog({
                        policyEntry: a,
                        currentGroupLabels:
                          null !==
                            (i =
                              null === (t = this.mutable.source) || void 0 === t
                                ? void 0
                                : t.currentGroupLabels) && void 0 !== i
                            ? i
                            : new Set(),
                        operation: _e.Move,
                        leadingPolicyOfGroups:
                          this.mutable.source.leadingPolicyOfGroups,
                      });
                    this.mutable.clearSelection();
                    const g = yield null === (n = this.policyTableManager) ||
                    void 0 === n
                      ? void 0
                      : n.getLocateParams(
                          { q_origin_key: String(s) },
                          this.policyTableManager.viewTypeManager
                            .currentTableView,
                        );
                    u &&
                      g &&
                      (yield this.mutable.addEntry(u, {
                        insertedIndex:
                          null == g ? void 0 : g.matches.sectionIndex,
                        insertedSection:
                          null == g ? void 0 : g.matches.sectionValue,
                      }));
                  } catch (s) {}
              });
            }
            reloadTableOnSuccess(t) {
              var i;
              return (0, d.mG)(this, void 0, void 0, function* () {
                if (this.policyTableManager) {
                  if (null != t) {
                    const n = yield null === (i = this.policyTableManager) ||
                    void 0 === i
                      ? void 0
                      : i.getLocateParams(
                          { q_origin_key: String(t) },
                          this.policyTableManager.viewTypeManager
                            .currentTableView,
                        );
                    this.policyTableManager.viewTypeManager.reloadWithCurrentView(
                      n,
                    );
                  } else
                    this.policyTableManager.viewTypeManager.reloadWithCurrentView();
                  this.notifySuccessMessage();
                }
              });
            }
          }
          return (
            (r.ɵfac = function (t) {
              return new (t || r)(
                e.Y36($.Bc),
                e.Y36(Qe.Cq),
                e.Y36(G.D7),
                e.Y36(at.lK),
                e.Y36(y.MW, 8),
              );
            }),
            (r.ɵcmp = e.Xpm({
              type: r,
              selectors: [["fos-policy-table-sequence-grouping-menu"]],
              inputs: {
                menu: "menu",
                policyTableManager: "policyTableManager",
                selection: "selection",
              },
              decls: 1,
              vars: 1,
              consts: [
                [4, "ngIf"],
                [3, "menu", "action", 4, "ngIf"],
                [3, "menu", "action"],
                [3, "icon"],
              ],
              template: function (t, i) {
                (1 & t && e.YNc(0, Ko, 5, 4, "ng-container", 0),
                  2 & t && e.Q6J("ngIf", i.readyForSequenceGroupMenu));
              },
              dependencies: [D._g, O.O5, E.wk, f.oJ, Re.X],
              encapsulation: 2,
            })),
            r
          );
        })(),
        jo = (() => {
          class r {
            constructor(t, i) {
              if (((this.slide = t), (this.searchIcon = Y.RL9), !i))
                throw new Error("Could not inject mutable component");
              this.mutable = i;
            }
            policyLookup() {
              return (0, d.mG)(this, void 0, void 0, function* () {
                return this.firewallInterface
                  ? this.firewallPolicy instanceof pe.m
                    ? this.localUser
                      ? this.webFilterProfile
                        ? this.webFilterFtgdCat
                          ? this.webFilterFtgdLocalCat
                            ? this.policyTableManager
                              ? void this.slide.open({
                                  component: vt,
                                  settings: { width: m.Tw },
                                })
                              : (M.cM.error(
                                  "Missing policy table manager for policy lookup setup.",
                                ),
                                Promise.resolve())
                            : (M.cM.error(
                                "Missing webfilter local category source for policy lookup setup.",
                              ),
                              Promise.resolve())
                          : (M.cM.error(
                              "Missing webfilter category source for policy lookup setup.",
                            ),
                            Promise.resolve())
                        : (M.cM.error(
                            "Missing webfilter profile source for policy lookup setup.",
                          ),
                          Promise.resolve())
                      : (M.cM.error(
                          "Missing local user source for policy lookup setup.",
                        ),
                        Promise.resolve())
                    : (M.cM.error(
                        "Policy lookup is only supported for firewall policy.",
                      ),
                      Promise.resolve())
                  : (M.cM.error(
                      "Missing firewall interface source for policy lookup setup.",
                    ),
                    Promise.resolve());
              });
            }
          }
          return (
            (r.ɵfac = function (t) {
              return new (t || r)(e.Y36($.Bc), e.Y36(y.MW, 8));
            }),
            (r.ɵcmp = e.Xpm({
              type: r,
              selectors: [["fos-policy-table-menu-lookup"]],
              inputs: {
                menu: "menu",
                localUser: "localUser",
                webFilterProfile: "webFilterProfile",
                webFilterFtgdCat: "webFilterFtgdCat",
                webFilterFtgdLocalCat: "webFilterFtgdLocalCat",
                firewallPolicy: "firewallPolicy",
                firewallInterface: "firewallInterface",
                policyTableManager: "policyTableManager",
              },
              decls: 5,
              vars: 5,
              consts: [
                [3, "menu", "action"],
                [3, "icon"],
              ],
              template: function (t, i) {
                (1 & t &&
                  (e.TgZ(0, "nu-menu-item-button", 0),
                  e.NdJ("action", function () {
                    return i.policyLookup();
                  }),
                  e._UZ(1, "nu-icon", 1),
                  e.TgZ(2, "span"),
                  e._uU(3),
                  e.ALo(4, "translate"),
                  e.qZA()()),
                  2 & t &&
                    (e.Q6J("menu", i.menu),
                    e.xp6(1),
                    e.Q6J("icon", i.searchIcon),
                    e.xp6(2),
                    e.Oqu(e.lcZ(4, 3, "Policy match"))));
              },
              dependencies: [D._g, E.wk, f.oJ, Re.X],
              encapsulation: 2,
            })),
            r
          );
        })();
      var qo = c(35482);
      function Ho(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "fos-table-menu-create", 1),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw();
              return e.KtG(n.createPolicyInline());
            }),
            e.qZA());
        }
        if (2 & r) {
          const t = e.oxw();
          e.Q6J("menu", t.menu);
        }
      }
      function $o(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "fos-table-menu-edit", 1),
            e.NdJ("action", function (n) {
              e.CHM(t);
              const l = e.oxw();
              return e.KtG(l.editPolicyInline(n));
            }),
            e.qZA());
        }
        if (2 & r) {
          const t = e.oxw();
          e.Q6J("menu", t.menu);
        }
      }
      let zo = (() => {
        class r extends qo.k {
          constructor(t, i, n) {
            if (
              (super(),
              (this.notify = t),
              (this.translation = i),
              (this.dialogUrl = ""),
              (this.topMenu = !1),
              (this.implicitPolicySelected = !1),
              (this.selection = y.rA),
              (this.destroyed = new de.t(1)),
              !n)
            )
              throw new Error("Could not inject mutable component");
            this.mutableSubject.next(n);
          }
          ngOnInit() {
            var t;
            (null === (t = this.menu) || void 0 === t ? void 0 : t.isMenuBar) &&
              this.topMenu &&
              this.mkeyQueryParam
                .pipe((0, We.R)(this.destroyed))
                .subscribe((i) => {
                  i.mkey
                    ? this.editPolicyInlineByMkey(i.mkey)
                    : this.createPolicyInline();
                });
          }
          ngOnDestroy() {
            this.destroyed.next();
          }
          createPolicyInline() {
            var t;
            null !== (t = this.policyTableManager) &&
              void 0 !== t &&
              t.policySource &&
              this.policyTableManager.policySource.create().then(
                (i) =>
                  (0, d.mG)(this, void 0, void 0, function* () {
                    var n, l, a, s;
                    if (
                      (i instanceof me.j || i instanceof Be.P) &&
                      this.policyTableManager &&
                      (null === (n = this.policyTableManager) || void 0 === n
                        ? void 0
                        : n.policySource)
                    ) {
                      this.policyTableManager.policySource.notifyAngularJsSourceChange();
                      const u = i,
                        g = yield this.policyTableManager.getLocateParams(
                          {
                            q_origin_key: u[_.go],
                            srcintf: (0, X.xP)(
                              null === (l = u.data) || void 0 === l
                                ? void 0
                                : l.srcintf[0],
                            ),
                            dstintf: (0, X.xP)(
                              null === (a = u.data) || void 0 === a
                                ? void 0
                                : a.dstintf[0],
                            ),
                          },
                          this.policyTableManager.viewTypeManager
                            .currentTableView,
                        );
                      if (!g)
                        throw new Error("Failed to locate appended policy");
                      {
                        const h = {
                          insertedIndex:
                            "number" == typeof g.matches
                              ? g.matches
                              : g.matches.sectionIndex,
                        };
                        (g.matches.sectionValue &&
                          (h.insertedSection = g.matches.sectionValue),
                          null === (s = this.mutable) ||
                            void 0 === s ||
                            s.addEntry(u, h).catch(() => {
                              M.cM.error(
                                "Failed to append policy entry to mutable.",
                              );
                            }),
                          this.notify.success(
                            this.translation.translate(
                              "Your changes have been saved",
                            ),
                          ));
                      }
                    }
                  }),
                (i) => {
                  (M.cM.error("Failed to create policy:"), M.cM.error(i));
                },
              );
          }
          editHelper(t, i, n) {
            var l, a, s;
            if (t) {
              this.addMkeyQueryParams(this.getEntryMkey(t));
              let u = Promise.resolve();
              return (
                t instanceof me.j &&
                (null === (l = this.policyTableManager) || void 0 === l
                  ? void 0
                  : l.policySource) instanceof pe.m
                  ? (u = this.policyTableManager.policySource.edit(
                      i
                        ? me.j.generateImplicitPolicy(
                            this.policyTableManager.policySource,
                          )
                        : t,
                    ))
                  : t instanceof Be.P &&
                      (null === (a = this.policyTableManager) || void 0 === a
                        ? void 0
                        : a.policySource) instanceof ve.u
                    ? (u = this.policyTableManager.policySource.edit(
                        i
                          ? Be.P.generateImplicitPolicy(
                              this.policyTableManager.policySource,
                            )
                          : t,
                      ))
                    : !(
                        null === (s = this.policyTableManager) || void 0 === s
                      ) &&
                      s.policySource &&
                      (u = this.policyTableManager.policySource.create()),
                u
                  .then(
                    (g) =>
                      (0, d.mG)(this, void 0, void 0, function* () {
                        var h, P, N, L, J, Q, j, K, H, B;
                        const k =
                          null === (h = this.policyTableManager) || void 0 === h
                            ? void 0
                            : h.policySource;
                        if (t.implicit || i) {
                          yield null === (P = this.policyTableManager) ||
                          void 0 === P
                            ? void 0
                            : P.logSettingSource.load();
                          const te = (() => {
                            var ee, ue;
                            return k instanceof pe.m
                              ? me.j.generateImplicitPolicy(
                                  k,
                                  null === (ee = this.policyTableManager) ||
                                    void 0 === ee
                                    ? void 0
                                    : ee.logSettingSource.data,
                                )
                              : k instanceof ve.u
                                ? Be.P.generateImplicitPolicy(
                                    k,
                                    null === (ue = this.policyTableManager) ||
                                      void 0 === ue
                                      ? void 0
                                      : ue.logSettingSource.data,
                                  )
                                : void 0;
                          })();
                          te &&
                            n &&
                            (null === (N = this.mutable) ||
                              void 0 === N ||
                              N.updateRowEntry(n, te));
                        } else if (g instanceof me.j || g instanceof Be.P) {
                          const T = g;
                          if (
                            this.policyTableManager &&
                            this.policyTableManager.viewTypeManager
                              .interfacePairView &&
                            !["srcintf", "dstintf"].every((ee) => {
                              var ue, xe;
                              const se =
                                  null === (ue = t.data) || void 0 === ue
                                    ? void 0
                                    : ue[ee],
                                we =
                                  null === (xe = T.data) || void 0 === xe
                                    ? void 0
                                    : xe[ee];
                              return (
                                (null == se ? void 0 : se.length) ===
                                  (null == we ? void 0 : we.length) &&
                                (null == se
                                  ? void 0
                                  : se.every(
                                      (Xe, et) =>
                                        (0, X.xP)(Xe) ===
                                        (0, X.xP)(null == we ? void 0 : we[et]),
                                    ))
                              );
                            })
                          ) {
                            const ee =
                              yield this.policyTableManager.getLocateParams(
                                {
                                  q_origin_key: T[_.go],
                                  srcintf: (0, X.xP)(
                                    null === (L = T.data) || void 0 === L
                                      ? void 0
                                      : L.srcintf[0],
                                  ),
                                  dstintf: (0, X.xP)(
                                    null === (J = T.data) || void 0 === J
                                      ? void 0
                                      : J.dstintf[0],
                                  ),
                                },
                                this.policyTableManager.viewTypeManager
                                  .currentTableView,
                              );
                            return (
                              ee &&
                              "object" == typeof ee.matches &&
                              "sectionValue" in ee.matches &&
                              ee.matches.sectionValue &&
                              "sectionIndex" in ee.matches &&
                              "number" == typeof ee.matches.sectionIndex
                                ? (null === (Q = this.mutable) ||
                                    void 0 === Q ||
                                    Q.retrieveNewRowsNextRender({
                                      andStats: !0,
                                    }),
                                  yield null === (j = this.mutable) ||
                                  void 0 === j
                                    ? void 0
                                    : j.locate({
                                        matches:
                                          null == ee ? void 0 : ee.matches,
                                        highlight: !0,
                                      }))
                                : yield this.router.navigate(
                                    [this.router.url],
                                    {
                                      queryParams: {
                                        showInList: JSON.stringify({
                                          q_origin_key: T[_.go],
                                          srcintf: (0, X.xP)(
                                            null === (K = T.data) ||
                                              void 0 === K
                                              ? void 0
                                              : K.srcintf[0],
                                          ),
                                          dstintf: (0, X.xP)(
                                            null === (H = T.data) ||
                                              void 0 === H
                                              ? void 0
                                              : H.dstintf[0],
                                          ),
                                        }),
                                      },
                                    },
                                  ),
                              void this.notify.success(
                                this.translation.translate(
                                  "Your changes have been saved",
                                ),
                              )
                            );
                          }
                          (n &&
                            (null === (B = this.mutable) ||
                              void 0 === B ||
                              B.updateRowEntry(n, T)),
                            this.notify.success(
                              this.translation.translate(
                                "Your changes have been saved",
                              ),
                            ));
                        }
                      }),
                    (g) => {
                      (M.cM.error("Failed to edit policy:"), M.cM.error(g));
                    },
                  )
                  .finally(() => {
                    this.removeMkeyQueryParams();
                  })
              );
            }
            return Promise.resolve();
          }
          getEntryMkey(t) {
            return t.implicit ? "implicit" : t[_.go];
          }
          editPolicyInlineByMkey(t) {
            var i;
            return (0, d.mG)(this, void 0, void 0, function* () {
              if (
                null !== (i = this.policyTableManager) &&
                void 0 !== i &&
                i.policySource
              ) {
                const n = yield this.policyTableManager.policySource.load({
                  keys: [t],
                });
                return this.editHelper(n[0], "implicit" === t);
              }
            });
          }
          editPolicyInline(t) {
            let i = !1;
            return t
              ? ((i = t.implicit),
                this.editHelper(t, i, this.selection.rows[0]))
              : Promise.resolve();
          }
        }
        return (
          (r.ɵfac = function (t) {
            return new (t || r)(e.Y36(Qe.Cq), e.Y36(G.D7), e.Y36(y.MW, 8));
          }),
          (r.ɵcmp = e.Xpm({
            type: r,
            selectors: [["fos-policy-table-inline-menu"]],
            inputs: {
              menu: "menu",
              policyTableManager: "policyTableManager",
              dialogUrl: "dialogUrl",
              insideSlide: "insideSlide",
              topMenu: "topMenu",
              implicitPolicySelected: "implicitPolicySelected",
              selection: "selection",
            },
            features: [e.qOj],
            decls: 2,
            vars: 2,
            consts: [
              [3, "menu", "action", 4, "ngIf"],
              [3, "menu", "action"],
            ],
            template: function (t, i) {
              (1 & t &&
                (e.YNc(0, Ho, 1, 1, "fos-table-menu-create", 0),
                e.YNc(1, $o, 1, 1, "fos-table-menu-edit", 0)),
                2 & t &&
                  (e.Q6J("ngIf", i.topMenu),
                  e.xp6(1),
                  e.Q6J("ngIf", !i.insideSlide && !i.topMenu)));
            },
            dependencies: [O.O5, At.V, Ft.Z],
            encapsulation: 2,
          })),
          r
        );
      })();
      function Xo(r, o) {
        if ((1 & r && e._UZ(0, "fos-policy-table-inline-menu", 10), 2 & r)) {
          const t = o.$implicit,
            i = e.oxw(2);
          e.Q6J("policyTableManager", i.policyTableManager)(
            "dialogUrl",
            i.dialogUrl,
          )("insideSlide", i.insideSlide)("topMenu", !0)(
            "implicitPolicySelected",
            i.implicitPolicySelected(),
          )("selection", i.selection)("menu", t);
        }
      }
      function el(r, o) {
        if ((1 & r && e._UZ(0, "fos-policy-table-menu-lookup", 12), 2 & r)) {
          const t = e.oxw().$implicit,
            i = e.oxw(2);
          e.Q6J("menu", t)(
            "firewallPolicy",
            null == i.policyTableManager
              ? null
              : i.policyTableManager.policySource,
          )(
            "firewallInterface",
            null == i.policyTableManager
              ? null
              : i.policyTableManager.firewallInterface,
          )(
            "localUser",
            null == i.policyTableManager
              ? null
              : i.policyTableManager.localUser,
          )(
            "webFilterProfile",
            null == i.policyTableManager
              ? null
              : i.policyTableManager.webFilterProfile,
          )(
            "webFilterFtgdCat",
            null == i.policyTableManager
              ? null
              : i.policyTableManager.webFilterFtgdCat,
          )(
            "webFilterFtgdLocalCat",
            null == i.policyTableManager
              ? null
              : i.policyTableManager.webFilterFtgdLocalCat,
          )("policyTableManager", i.policyTableManager);
        }
      }
      function tl(r, o) {
        if (
          (1 & r &&
            (e.YNc(0, el, 1, 8, "fos-policy-table-menu-lookup", 11),
            e.ALo(1, "async")),
          2 & r)
        ) {
          const t = e.oxw(2);
          e.Q6J("ngIf", e.lcZ(1, 1, t.showLookup));
        }
      }
      function il(r, o) {
        if ((1 & r && e._UZ(0, "nu-icon", 22), 2 & r)) {
          const t = e.oxw(3);
          e.Q6J("icon", t.infoIcon);
        }
      }
      function nl(r, o) {
        if ((1 & r && e._UZ(0, "nu-icon", 22), 2 & r)) {
          const t = e.oxw(3);
          e.Q6J("icon", t.recommendIcon);
        }
      }
      function ol(r, o) {
        if ((1 & r && e._UZ(0, "nu-icon", 22), 2 & r)) {
          const t = e.oxw(4);
          e.Q6J("icon", t.infoIcon);
        }
      }
      function ll(r, o) {
        if ((1 & r && e._UZ(0, "nu-icon", 22), 2 & r)) {
          const t = e.oxw(4);
          e.Q6J("icon", t.recommendIcon);
        }
      }
      const Ut = function (r) {
          return { selected: r };
        },
        nt = function (r) {
          return { "nu-tooltip-hint": r };
        };
      function rl(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "nu-menu-item-button", 23),
            e.NdJ("action", function () {
              const l = e.CHM(t).$implicit,
                a = e.oxw(3);
              return e.KtG(a.onTableViewChange(l));
            }),
            e.YNc(1, ol, 1, 1, "nu-icon", 15),
            e.YNc(2, ll, 1, 1, "nu-icon", 15),
            e.TgZ(3, "span", 16),
            e._uU(4),
            e.ALo(5, "translate"),
            e.qZA()());
        }
        if (2 & r) {
          const t = o.$implicit,
            i = e.oxw(3);
          (e.Q6J("nuTip", i.EXCEEDS_PERFORMANCE_THRESHOLD_MESSAGE)(
            "nuTipDisabled",
            !i.exceedsPerformanceThreshold,
          )("ngClass", e.VKq(9, Ut, t === i.selectedView)),
            e.xp6(1),
            e.Q6J(
              "ngIf",
              i.exceedsPerformanceThreshold && t !== i.TableView.BySequenceView,
            ),
            e.xp6(1),
            e.Q6J(
              "ngIf",
              i.exceedsPerformanceThreshold && t === i.TableView.BySequenceView,
            ),
            e.xp6(1),
            e.Q6J("ngClass", e.VKq(11, nt, i.exceedsPerformanceThreshold)),
            e.xp6(1),
            e.hij(" ", e.lcZ(5, 7, t), " "));
        }
      }
      function al(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e._UZ(0, "nu-mutable-export-to-file", 13),
            e.TgZ(1, "nu-menu-item-button", 14),
            e.YNc(2, il, 1, 1, "nu-icon", 15),
            e.YNc(3, nl, 1, 1, "nu-icon", 15),
            e.TgZ(4, "span", 16),
            e._uU(5),
            e.ALo(6, "translate"),
            e.qZA()(),
            e.TgZ(7, "nu-pop-up-menu", null, 17),
            e.YNc(9, rl, 6, 13, "nu-menu-item-button", 18),
            e.qZA(),
            e.TgZ(10, "nu-menu-item-button", 19)(11, "span"),
            e._uU(12),
            e.ALo(13, "translate"),
            e.qZA()(),
            e.TgZ(
              14,
              "nu-pop-up-menu",
              null,
              20,
            )(16, "nu-menu-item-button", 21),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw(2);
              return e.KtG(
                n.toggleInlineMenuLayout(
                  !(
                    null == n.policyTableManager ||
                    null == n.policyTableManager.viewTypeManager ||
                    !n.policyTableManager.viewTypeManager.optInForInlineMenu
                  ),
                ),
              );
            }),
            e.TgZ(17, "span"),
            e._uU(18),
            e.ALo(19, "translate"),
            e.qZA()()());
        }
        if (2 & r) {
          const t = o.$implicit,
            i = e.MAs(8),
            n = e.MAs(15),
            l = e.oxw(2);
          (e.Q6J("menu", t)("name", l.exportFilename),
            e.xp6(1),
            e.Q6J("menu", t)("nuPopUpMenuToggle", i)(
              "nuTip",
              l.EXCEEDS_PERFORMANCE_THRESHOLD_MESSAGE,
            )("nuTipDisabled", !l.exceedsPerformanceThreshold),
            e.xp6(1),
            e.Q6J(
              "ngIf",
              l.exceedsPerformanceThreshold &&
                l.selectedView !== l.TableView.BySequenceView,
            ),
            e.xp6(1),
            e.Q6J(
              "ngIf",
              l.exceedsPerformanceThreshold &&
                l.selectedView === l.TableView.BySequenceView,
            ),
            e.xp6(1),
            e.Q6J("ngClass", e.VKq(21, nt, l.exceedsPerformanceThreshold)),
            e.xp6(1),
            e.Oqu(e.lcZ(6, 15, l.selectedView)),
            e.xp6(4),
            e.Q6J("ngForOf", l.tableViews),
            e.xp6(1),
            e.Q6J("menu", t)("nuPopUpMenuToggle", n),
            e.xp6(2),
            e.Oqu(
              e.lcZ(
                13,
                17,
                null != l.policyTableManager &&
                  null != l.policyTableManager.viewTypeManager &&
                  l.policyTableManager.viewTypeManager.optInForInlineMenu
                  ? "New layout"
                  : "Classic layout",
              ),
            ),
            e.xp6(6),
            e.Oqu(
              e.lcZ(
                19,
                19,
                null != l.policyTableManager &&
                  null != l.policyTableManager.viewTypeManager &&
                  l.policyTableManager.viewTypeManager.optInForInlineMenu
                  ? "Use classic layout"
                  : "Use new layout",
              ),
            ));
        }
      }
      function sl(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "nu-mutable-insert-row", 27),
            e.NdJ("insert", function (n) {
              e.CHM(t);
              const l = e.oxw(3);
              return e.KtG(l.insertPolicy(n));
            }),
            e.qZA());
        }
        if (2 & r) {
          const t = e.oxw().$implicit;
          e.Q6J("menu", t);
        }
      }
      function cl(r, o) {
        if ((1 & r && e._UZ(0, "nu-mutable-edit-column", 28), 2 & r)) {
          const t = e.oxw().$implicit;
          e.Q6J("menu", t)("columnId", "status")("binaryMode", !0);
        }
      }
      function ul(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e._UZ(0, "fos-policy-table-inline-menu", 10),
            e.YNc(1, sl, 1, 1, "nu-mutable-insert-row", 24),
            e.YNc(2, cl, 1, 3, "nu-mutable-edit-column", 25),
            e.TgZ(3, "fos-table-menu-delete", 26),
            e.NdJ("canDeleteEntry", function (n) {
              e.CHM(t);
              const l = e.oxw(2);
              return e.KtG(l.canDeleteEntry(n));
            }),
            e.ALo(4, "async"),
            e.qZA());
        }
        if (2 & r) {
          const t = o.$implicit,
            i = e.oxw(2);
          (e.Q6J("policyTableManager", i.policyTableManager)(
            "dialogUrl",
            i.dialogUrl,
          )("insideSlide", i.insideSlide)("topMenu", !1)(
            "implicitPolicySelected",
            i.implicitPolicySelected(),
          )("selection", i.selection)("menu", t),
            e.xp6(1),
            e.Q6J("ngIf", !i.readOnly && !i.implicitPolicySelected()),
            e.xp6(1),
            e.Q6J("ngIf", !i.readOnly),
            e.xp6(1),
            e.Q6J("menu", t)("fortigate", e.lcZ(4, 12, i.fortigate))(
              "deleteEntryAction",
              i.deleteEntryAction,
            ));
        }
      }
      function dl(r, o) {
        if ((1 & r && e._UZ(0, "nu-mutable-edit-column", 30), 2 & r)) {
          const t = e.oxw().$implicit;
          e.Q6J("menu", t)("columnId", "status");
        }
      }
      function pl(r, o) {
        if ((1 & r && e._UZ(0, "nu-mutable-edit-column", 30), 2 & r)) {
          const t = e.oxw().$implicit;
          e.Q6J("menu", t)("columnId", "consolidated-source");
        }
      }
      function _l(r, o) {
        if ((1 & r && e._UZ(0, "nu-mutable-edit-column", 30), 2 & r)) {
          const t = e.oxw().$implicit;
          e.Q6J("menu", t)("columnId", "consolidated-destination");
        }
      }
      function gl(r, o) {
        if ((1 & r && e._UZ(0, "nu-mutable-edit-column", 30), 2 & r)) {
          const t = e.oxw().$implicit;
          e.Q6J("menu", t)("columnId", "profile");
        }
      }
      function fl(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.YNc(0, dl, 1, 2, "nu-mutable-edit-column", 29),
            e.YNc(1, pl, 1, 2, "nu-mutable-edit-column", 29),
            e.YNc(2, _l, 1, 2, "nu-mutable-edit-column", 29),
            e.YNc(3, gl, 1, 2, "nu-mutable-edit-column", 29),
            e.TgZ(4, "fos-table-menu-delete", 26),
            e.NdJ("canDeleteEntry", function (n) {
              e.CHM(t);
              const l = e.oxw(2);
              return e.KtG(l.canDeleteEntry(n));
            }),
            e.ALo(5, "async"),
            e.qZA());
        }
        if (2 & r) {
          const t = o.$implicit,
            i = e.oxw(2);
          (e.Q6J("ngIf", !i.readOnly),
            e.xp6(1),
            e.Q6J("ngIf", !i.readOnly),
            e.xp6(1),
            e.Q6J("ngIf", !i.readOnly),
            e.xp6(1),
            e.Q6J("ngIf", !i.readOnly),
            e.xp6(1),
            e.Q6J("menu", t)("fortigate", e.lcZ(5, 7, i.fortigate))(
              "deleteEntryAction",
              i.deleteEntryAction,
            ));
        }
      }
      function yl(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "div")(1, "nu-menu-item-button", 37),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw(3);
              return e.KtG(n.updatePolicyStats());
            }),
            e.TgZ(2, "span"),
            e._uU(3),
            e.ALo(4, "translate"),
            e.qZA()(),
            e.TgZ(5, "nu-menu-item-button", 37),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw(3);
              return e.KtG(n.clearPolicyStats());
            }),
            e.TgZ(6, "span"),
            e._uU(7),
            e.ALo(8, "translate"),
            e.qZA()()());
        }
        if (2 & r) {
          const t = e.oxw().$implicit,
            i = e.oxw(2);
          (e.xp6(1),
            e.Q6J("menu", t),
            e.xp6(2),
            e.Oqu(e.lcZ(4, 4, i.updateStatisticsLabel)),
            e.xp6(2),
            e.Q6J("menu", t),
            e.xp6(2),
            e.Oqu(e.lcZ(8, 6, "Clear counters")));
        }
      }
      function ml(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "fos-policy-table-copy-paste-menu", 38),
            e.NdJ("copiedPolicyChange", function (n) {
              e.CHM(t);
              const l = e.oxw(3);
              return e.KtG((l.copiedPolicy = n));
            }),
            e.qZA());
        }
        if (2 & r) {
          const t = e.oxw().$implicit,
            i = e.oxw(2);
          e.Q6J("menu", t)(
            "multiplePoliciesSelected",
            i.multiplePoliciesSelected(),
          )("implicitPolicySelected", i.implicitPolicySelected())(
            "policyTableManager",
            i.policyTableManager,
          )("selection", i.selection)("copiedPolicy", i.copiedPolicy);
        }
      }
      function vl(r, o) {
        if (
          (1 & r && e._UZ(0, "fos-policy-table-sequence-grouping-menu", 39),
          2 & r)
        ) {
          const t = e.oxw().$implicit,
            i = e.oxw(2);
          e.Q6J("menu", t)("policyTableManager", i.policyTableManager)(
            "selection",
            i.selection,
          );
        }
      }
      function hl(r, o) {
        1 & r && e._UZ(0, "div", 40);
      }
      function bl(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "nu-menu-item-button", 37),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw(3);
              return e.KtG(n.openAuditTrail());
            }),
            e._UZ(1, "nu-icon", 22),
            e.TgZ(2, "span"),
            e._uU(3),
            e.ALo(4, "translate"),
            e.qZA()());
        }
        if (2 & r) {
          const t = e.oxw().$implicit,
            i = e.oxw(2);
          (e.Q6J("menu", t),
            e.xp6(1),
            e.Q6J("icon", i.auditIcon),
            e.xp6(2),
            e.Oqu(e.lcZ(4, 3, "Audit trail")));
        }
      }
      function Sl(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "nu-menu-item-button", 37),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw(3);
              return e.KtG(n.navigateToMatchingLogs());
            }),
            e._UZ(1, "nu-icon", 22),
            e.TgZ(2, "span"),
            e._uU(3),
            e.ALo(4, "translate"),
            e.qZA()());
        }
        if (2 & r) {
          const t = e.oxw().$implicit,
            i = e.oxw(2);
          (e.Q6J("menu", t),
            e.xp6(1),
            e.Q6J("icon", i.logIcon),
            e.xp6(2),
            e.Oqu(e.lcZ(4, 3, "Show matching logs")));
        }
      }
      function Pl(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "nu-menu-item-button", 37),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw(3);
              return e.KtG(n.navigateFortiView());
            }),
            e._UZ(1, "nu-icon", 22),
            e.TgZ(2, "span"),
            e._uU(3),
            e.ALo(4, "translate"),
            e.qZA()());
        }
        if (2 & r) {
          const t = e.oxw().$implicit,
            i = e.oxw(2);
          (e.Q6J("menu", t),
            e.xp6(1),
            e.Q6J("icon", i.fortiViewIcon),
            e.xp6(2),
            e.Oqu(e.lcZ(4, 3, "Show in FortiView")));
        }
      }
      function Tl(r, o) {
        if (
          (1 & r &&
            (e._UZ(0, "fos-table-menu-edit-cli", 41),
            e.ALo(1, "async"),
            e.ALo(2, "async")),
          2 & r)
        ) {
          const t = e.oxw().$implicit,
            i = e.oxw(2);
          e.Q6J("menu", t)("fortigate", e.lcZ(1, 4, i.fortigate))(
            "disabled",
            !i.editCliEnabled,
          )("editParams", e.lcZ(2, 6, i.editCliParams));
        }
      }
      function Cl(r, o) {
        if (
          (1 & r &&
            (e.YNc(0, yl, 9, 8, "div", 31),
            e.YNc(1, ml, 1, 6, "fos-policy-table-copy-paste-menu", 32),
            e.YNc(2, vl, 1, 3, "fos-policy-table-sequence-grouping-menu", 33),
            e.YNc(3, hl, 1, 0, "div", 34),
            e.YNc(4, bl, 5, 5, "nu-menu-item-button", 35),
            e.YNc(5, Sl, 5, 5, "nu-menu-item-button", 35),
            e.ALo(6, "async"),
            e.YNc(7, Pl, 5, 5, "nu-menu-item-button", 35),
            e.ALo(8, "async"),
            e.YNc(9, Tl, 3, 8, "fos-table-menu-edit-cli", 36)),
          2 & r)
        ) {
          const t = o.$implicit,
            i = e.oxw(2);
          (e.Q6J("ngIf", !i.readOnly && i.policyStatsSupported()),
            e.xp6(1),
            e.Q6J("ngIf", !i.readOnly && !i.implicitPolicySelected()),
            e.xp6(1),
            e.Q6J(
              "ngIf",
              !i.readOnly &&
                (null == i.policyTableManager ||
                null == i.policyTableManager.viewTypeManager
                  ? null
                  : i.policyTableManager.viewTypeManager
                      .sequenceGroupingView) &&
                !i.implicitPolicySelected() &&
                !i.multiplePoliciesSelected(),
            ),
            e.xp6(1),
            e.Q6J("ngIf", !i.implicitPolicySelected()),
            e.xp6(1),
            e.Q6J("ngIf", i.showAuditTrail()),
            e.xp6(1),
            e.Q6J("ngIf", e.lcZ(6, 8, i.showViewInLog)),
            e.xp6(2),
            e.Q6J("ngIf", e.lcZ(8, 10, i.showFortiView)),
            e.xp6(2),
            e.Q6J("ngIf", !(null != t && t.isMenuBar)));
        }
      }
      function xl(r, o) {
        if (
          (1 & r &&
            (e._UZ(0, "fos-table-footer-notification", 42), e.ALo(1, "async")),
          2 & r)
        ) {
          const t = e.oxw(2);
          (e.ekj("is-hidden", !t.showSecurityRatingNotification),
            e.Q6J("filter", t.filterIssue)("useTableSource", !0)(
              "getLazySectionLocateParamsFn",
              e.lcZ(1, 5, t.getLazySectionLocateParamsFnObs),
            ));
        }
      }
      function Ml(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "div", 1)(1, "nu-mutable", 2),
            e.NdJ("selection", function (n) {
              e.CHM(t);
              const l = e.oxw();
              return e.KtG(l.onSelectionChange(n));
            }),
            e.YNc(2, Xo, 1, 7, "ng-template", 3),
            e.YNc(3, tl, 2, 3, "ng-template", 4),
            e.YNc(4, al, 20, 23, "ng-template", 5),
            e.YNc(5, ul, 5, 14, "ng-template", 6),
            e.YNc(6, fl, 6, 9, "ng-template", 7),
            e.YNc(7, Cl, 10, 12, "ng-template", 8),
            e.YNc(8, xl, 2, 7, "ng-template", 9),
            e.qZA()());
        }
        if (2 & r) {
          const t = e.oxw();
          (e.xp6(1),
            e.Q6J(
              "source",
              null == t.policyTableManager
                ? null
                : t.policyTableManager.tableSource,
            )(
              "settings",
              null == t.policyTableManager
                ? null
                : t.policyTableManager.settings,
            )("initialLocate", t.initialLocate)("forceTraditionalMenu", !1));
        }
      }
      function Il(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "div")(1, "nu-menu-item-button", 37),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw(4);
              return e.KtG(n.updatePolicyStats());
            }),
            e._UZ(2, "nu-icon", 22),
            e.TgZ(3, "span"),
            e._uU(4),
            e.ALo(5, "translate"),
            e.qZA()(),
            e.TgZ(6, "nu-menu-item-button", 37),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw(4);
              return e.KtG(n.clearPolicyStats());
            }),
            e._UZ(7, "nu-icon", 22),
            e.TgZ(8, "span"),
            e._uU(9),
            e.ALo(10, "translate"),
            e.qZA()()());
        }
        if (2 & r) {
          const t = e.oxw(2).$implicit,
            i = e.oxw(2);
          (e.xp6(1),
            e.Q6J("menu", t),
            e.xp6(1),
            e.Q6J("icon", i.refreshIcon),
            e.xp6(2),
            e.Oqu(e.lcZ(5, 6, "Update statistics")),
            e.xp6(2),
            e.Q6J("menu", t),
            e.xp6(1),
            e.Q6J("icon", i.purgeIcon),
            e.xp6(2),
            e.Oqu(e.lcZ(10, 8, "Clear counters")));
        }
      }
      function Ol(r, o) {
        if ((1 & r && e._UZ(0, "nu-mutable-filter", 52), 2 & r)) {
          const t = e.oxw(3).$implicit;
          e.Q6J("menu", t)("separatorBelow", !0);
        }
      }
      function El(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "div"),
            e.YNc(1, Ol, 1, 2, "nu-mutable-filter", 51),
            e.qZA()),
          2 & r)
        ) {
          const t = e.oxw(4);
          (e.xp6(1), e.Q6J("ngIf", !t.implicitPolicySelected()));
        }
      }
      function Ll(r, o) {
        if ((1 & r && e._UZ(0, "nu-mutable-edit-column", 30), 2 & r)) {
          const t = e.oxw(2).$implicit;
          e.Q6J("menu", t)("columnId", "status");
        }
      }
      function wl(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "fos-policy-table-copy-paste-menu", 38),
            e.NdJ("copiedPolicyChange", function (n) {
              e.CHM(t);
              const l = e.oxw(4);
              return e.KtG((l.copiedPolicy = n));
            }),
            e.qZA());
        }
        if (2 & r) {
          const t = e.oxw(2).$implicit,
            i = e.oxw(2);
          e.Q6J("menu", t)(
            "multiplePoliciesSelected",
            i.multiplePoliciesSelected(),
          )("implicitPolicySelected", i.implicitPolicySelected())(
            "policyTableManager",
            i.policyTableManager,
          )("selection", i.selection)("copiedPolicy", i.copiedPolicy);
        }
      }
      function Al(r, o) {
        if (
          (1 & r && e._UZ(0, "fos-policy-table-sequence-grouping-menu", 39),
          2 & r)
        ) {
          const t = e.oxw(2).$implicit,
            i = e.oxw(2);
          e.Q6J("menu", t)("policyTableManager", i.policyTableManager)(
            "selection",
            i.selection,
          );
        }
      }
      function Fl(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "nu-menu-item-button", 37),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw(4);
              return e.KtG(n.openAuditTrail());
            }),
            e._UZ(1, "nu-icon", 22),
            e.TgZ(2, "span"),
            e._uU(3),
            e.ALo(4, "translate"),
            e.qZA()());
        }
        if (2 & r) {
          const t = e.oxw(2).$implicit,
            i = e.oxw(2);
          (e.Q6J("menu", t),
            e.xp6(1),
            e.Q6J("icon", i.auditIcon),
            e.xp6(2),
            e.Oqu(e.lcZ(4, 3, "Audit trail")));
        }
      }
      function Nl(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "nu-menu-item-button", 37),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw(4);
              return e.KtG(n.navigateToMatchingLogs());
            }),
            e._UZ(1, "nu-icon", 22),
            e.TgZ(2, "span"),
            e._uU(3),
            e.ALo(4, "translate"),
            e.qZA()());
        }
        if (2 & r) {
          const t = e.oxw(2).$implicit,
            i = e.oxw(2);
          (e.Q6J("menu", t),
            e.xp6(1),
            e.Q6J("icon", i.logIcon),
            e.xp6(2),
            e.Oqu(e.lcZ(4, 3, "Show matching logs")));
        }
      }
      function Zl(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "nu-menu-item-button", 37),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw(4);
              return e.KtG(n.navigateFortiView());
            }),
            e._UZ(1, "nu-icon", 22),
            e.TgZ(2, "span"),
            e._uU(3),
            e.ALo(4, "translate"),
            e.qZA()());
        }
        if (2 & r) {
          const t = e.oxw(2).$implicit,
            i = e.oxw(2);
          (e.Q6J("menu", t),
            e.xp6(1),
            e.Q6J("icon", i.fortiViewIcon),
            e.xp6(2),
            e.Oqu(e.lcZ(4, 3, "Show in FortiView")));
        }
      }
      function Dl(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "div"),
            e.YNc(1, Il, 11, 10, "div", 31),
            e.TgZ(2, "div", 50),
            e._uU(3),
            e.ALo(4, "translate"),
            e.qZA(),
            e.YNc(5, El, 2, 1, "div", 31),
            e.YNc(6, Ll, 1, 2, "nu-mutable-edit-column", 29),
            e.YNc(7, wl, 1, 6, "fos-policy-table-copy-paste-menu", 32),
            e.YNc(8, Al, 1, 3, "fos-policy-table-sequence-grouping-menu", 33),
            e._UZ(9, "div", 40),
            e.YNc(10, Fl, 5, 5, "nu-menu-item-button", 35),
            e.YNc(11, Nl, 5, 5, "nu-menu-item-button", 35),
            e.ALo(12, "async"),
            e.YNc(13, Zl, 5, 5, "nu-menu-item-button", 35),
            e.ALo(14, "async"),
            e.qZA()),
          2 & r)
        ) {
          const t = e.oxw(3);
          (e.xp6(1),
            e.Q6J("ngIf", !t.readOnly && t.policyStatsSupported(!0)),
            e.xp6(2),
            e.Oqu(e.lcZ(4, 9, "Policy")),
            e.xp6(2),
            e.Q6J("ngIf", !t.insideSlide),
            e.xp6(1),
            e.Q6J("ngIf", !t.readOnly),
            e.xp6(1),
            e.Q6J("ngIf", !t.readOnly && !t.implicitPolicySelected()),
            e.xp6(1),
            e.Q6J(
              "ngIf",
              !t.readOnly &&
                (null == t.policyTableManager ||
                null == t.policyTableManager.viewTypeManager
                  ? null
                  : t.policyTableManager.viewTypeManager
                      .sequenceGroupingView) &&
                !t.implicitPolicySelected() &&
                !t.multiplePoliciesSelected(),
            ),
            e.xp6(2),
            e.Q6J("ngIf", t.showAuditTrail()),
            e.xp6(1),
            e.Q6J("ngIf", e.lcZ(12, 11, t.showViewInLog)),
            e.xp6(2),
            e.Q6J("ngIf", e.lcZ(14, 13, t.showFortiView)));
        }
      }
      function Gl(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "fos-table-menu-edit", 37),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw(3);
              return e.KtG(n.editPolicy());
            }),
            e.qZA());
        }
        if (2 & r) {
          const t = e.oxw().$implicit;
          e.Q6J("menu", t);
        }
      }
      function Ul(r, o) {
        if (
          (1 & r &&
            (e._UZ(0, "fos-table-menu-edit-cli", 53),
            e.ALo(1, "async"),
            e.ALo(2, "async")),
          2 & r)
        ) {
          const t = e.oxw().$implicit,
            i = e.oxw(2);
          e.Q6J("menu", t)("disabled", !i.editCliEnabled)(
            "fortigate",
            e.lcZ(1, 4, i.fortigate),
          )("editParams", e.lcZ(2, 6, i.editCliParams));
        }
      }
      function Rl(r, o) {
        if ((1 & r && e._UZ(0, "fos-policy-table-menu-lookup", 12), 2 & r)) {
          const t = e.oxw(2).$implicit,
            i = e.oxw(2);
          e.Q6J("menu", t)(
            "firewallPolicy",
            null == i.policyTableManager
              ? null
              : i.policyTableManager.policySource,
          )(
            "firewallInterface",
            null == i.policyTableManager
              ? null
              : i.policyTableManager.firewallInterface,
          )(
            "localUser",
            null == i.policyTableManager
              ? null
              : i.policyTableManager.localUser,
          )(
            "webFilterProfile",
            null == i.policyTableManager
              ? null
              : i.policyTableManager.webFilterProfile,
          )(
            "webFilterFtgdCat",
            null == i.policyTableManager
              ? null
              : i.policyTableManager.webFilterFtgdCat,
          )(
            "webFilterFtgdLocalCat",
            null == i.policyTableManager
              ? null
              : i.policyTableManager.webFilterFtgdLocalCat,
          )("policyTableManager", i.policyTableManager);
        }
      }
      function Vl(r, o) {
        if (
          (1 & r &&
            (e.TgZ(0, "div", 54),
            e._UZ(1, "div", 40),
            e.YNc(2, Rl, 1, 8, "fos-policy-table-menu-lookup", 11),
            e.ALo(3, "async"),
            e._UZ(4, "nu-mutable-search"),
            e.qZA()),
          2 & r)
        ) {
          const t = e.oxw(3);
          (e.xp6(2), e.Q6J("ngIf", e.lcZ(3, 1, t.showLookup)));
        }
      }
      function Bl(r, o) {
        if ((1 & r && e._UZ(0, "nu-icon", 22), 2 & r)) {
          const t = e.oxw(4);
          e.Q6J("icon", t.infoIcon);
        }
      }
      function Jl(r, o) {
        if ((1 & r && e._UZ(0, "nu-icon", 22), 2 & r)) {
          const t = e.oxw(4);
          e.Q6J("icon", t.recommendIcon);
        }
      }
      function kl(r, o) {
        if ((1 & r && e._UZ(0, "nu-icon", 22), 2 & r)) {
          const t = e.oxw(5);
          e.Q6J("icon", t.infoIcon);
        }
      }
      function Ql(r, o) {
        if ((1 & r && e._UZ(0, "nu-icon", 22), 2 & r)) {
          const t = e.oxw(5);
          e.Q6J("icon", t.recommendIcon);
        }
      }
      function Yl(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "nu-menu-item-button", 23),
            e.NdJ("action", function () {
              const l = e.CHM(t).$implicit,
                a = e.oxw(4);
              return e.KtG(a.onTableViewChange(l));
            }),
            e.YNc(1, kl, 1, 1, "nu-icon", 15),
            e.YNc(2, Ql, 1, 1, "nu-icon", 15),
            e.TgZ(3, "span", 16),
            e._uU(4),
            e.ALo(5, "translate"),
            e.qZA()());
        }
        if (2 & r) {
          const t = o.$implicit,
            i = e.oxw(4);
          (e.Q6J("nuTip", i.EXCEEDS_PERFORMANCE_THRESHOLD_MESSAGE)(
            "nuTipDisabled",
            !i.exceedsPerformanceThreshold,
          )("ngClass", e.VKq(9, Ut, t === i.selectedView)),
            e.xp6(1),
            e.Q6J(
              "ngIf",
              i.exceedsPerformanceThreshold && t !== i.TableView.BySequenceView,
            ),
            e.xp6(1),
            e.Q6J(
              "ngIf",
              i.exceedsPerformanceThreshold && t === i.TableView.BySequenceView,
            ),
            e.xp6(1),
            e.Q6J("ngClass", e.VKq(11, nt, i.exceedsPerformanceThreshold)),
            e.xp6(1),
            e.hij(" ", e.lcZ(5, 7, t), " "));
        }
      }
      function Kl(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "div", 55),
            e._UZ(1, "nu-mutable-export-to-file", 13),
            e.TgZ(2, "nu-menu-item-button", 14),
            e.YNc(3, Bl, 1, 1, "nu-icon", 15),
            e.YNc(4, Jl, 1, 1, "nu-icon", 15),
            e.TgZ(5, "span", 16),
            e._uU(6),
            e.ALo(7, "translate"),
            e.qZA()(),
            e.TgZ(8, "nu-pop-up-menu", null, 17),
            e.YNc(10, Yl, 6, 13, "nu-menu-item-button", 18),
            e.qZA(),
            e.TgZ(11, "nu-menu-item-button", 19)(12, "span"),
            e._uU(13),
            e.ALo(14, "translate"),
            e.qZA()(),
            e.TgZ(
              15,
              "nu-pop-up-menu",
              null,
              20,
            )(17, "nu-menu-item-button", 21),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw(3);
              return e.KtG(
                n.toggleInlineMenuLayout(
                  !(
                    null == n.policyTableManager ||
                    null == n.policyTableManager.viewTypeManager ||
                    !n.policyTableManager.viewTypeManager.optInForInlineMenu
                  ),
                ),
              );
            }),
            e.TgZ(18, "span"),
            e._uU(19),
            e.ALo(20, "translate"),
            e.qZA()()()());
        }
        if (2 & r) {
          const t = e.MAs(9),
            i = e.MAs(16),
            n = e.oxw().$implicit,
            l = e.oxw(2);
          (e.xp6(1),
            e.Q6J("menu", n)("name", l.exportFilename),
            e.xp6(1),
            e.Q6J("menu", n)("nuPopUpMenuToggle", t)(
              "nuTip",
              l.EXCEEDS_PERFORMANCE_THRESHOLD_MESSAGE,
            )("nuTipDisabled", !l.exceedsPerformanceThreshold),
            e.xp6(1),
            e.Q6J(
              "ngIf",
              l.exceedsPerformanceThreshold &&
                l.selectedView !== l.TableView.BySequenceView,
            ),
            e.xp6(1),
            e.Q6J(
              "ngIf",
              l.exceedsPerformanceThreshold &&
                l.selectedView === l.TableView.BySequenceView,
            ),
            e.xp6(1),
            e.Q6J("ngClass", e.VKq(21, nt, l.exceedsPerformanceThreshold)),
            e.xp6(1),
            e.Oqu(e.lcZ(7, 15, l.selectedView)),
            e.xp6(4),
            e.Q6J("ngForOf", l.tableViews),
            e.xp6(1),
            e.Q6J("menu", n)("nuPopUpMenuToggle", i),
            e.xp6(2),
            e.Oqu(
              e.lcZ(
                14,
                17,
                null != l.policyTableManager &&
                  null != l.policyTableManager.viewTypeManager &&
                  l.policyTableManager.viewTypeManager.optInForInlineMenu
                  ? "New layout"
                  : "Classic layout",
              ),
            ),
            e.xp6(6),
            e.Oqu(
              e.lcZ(
                20,
                19,
                null != l.policyTableManager &&
                  null != l.policyTableManager.viewTypeManager &&
                  l.policyTableManager.viewTypeManager.optInForInlineMenu
                  ? "Use classic layout"
                  : "Use new layout",
              ),
            ));
        }
      }
      function Wl(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.YNc(0, Dl, 15, 15, "div", 31),
            e.TgZ(1, "div", 45)(2, "fos-table-menu-create", 37),
            e.NdJ("action", function () {
              e.CHM(t);
              const n = e.oxw(2);
              return e.KtG(n.createPolicy());
            }),
            e.qZA(),
            e.YNc(3, Gl, 1, 1, "fos-table-menu-edit", 35),
            e.YNc(4, Ul, 3, 8, "fos-table-menu-edit-cli", 46),
            e.TgZ(5, "fos-table-menu-delete", 47),
            e.NdJ("canDeleteEntry", function (n) {
              e.CHM(t);
              const l = e.oxw(2);
              return e.KtG(l.canDeleteEntry(n));
            }),
            e.ALo(6, "async"),
            e.qZA()(),
            e.YNc(7, Vl, 5, 3, "div", 48),
            e.YNc(8, Kl, 21, 23, "div", 49));
        }
        if (2 & r) {
          const t = o.$implicit,
            i = e.oxw(2);
          (e.Q6J("ngIf", !(null != t && t.isMenuBar)),
            e.xp6(2),
            e.Q6J("menu", t),
            e.xp6(1),
            e.Q6J("ngIf", !i.insideSlide),
            e.xp6(1),
            e.Q6J("ngIf", !(null != t && t.isMenuBar)),
            e.xp6(1),
            e.Q6J("menu", t)("fortigate", e.lcZ(6, 10, i.fortigate))(
              "label",
              null != t && t.isMenuBar ? "Delete" : "Delete policy",
            )("deleteEntryAction", i.deleteEntryAction),
            e.xp6(2),
            e.Q6J("ngIf", null == t ? null : t.isMenuBar),
            e.xp6(1),
            e.Q6J("ngIf", null == t ? null : t.isMenuBar));
        }
      }
      function jl(r, o) {
        if (
          (1 & r &&
            (e._UZ(0, "fos-table-footer-notification", 42), e.ALo(1, "async")),
          2 & r)
        ) {
          const t = e.oxw(2);
          (e.ekj("is-hidden", !t.showSecurityRatingNotification),
            e.Q6J("filter", t.filterIssue)("useTableSource", !0)(
              "getLazySectionLocateParamsFn",
              e.lcZ(1, 5, t.getLazySectionLocateParamsFnObs),
            ));
        }
      }
      function ql(r, o) {
        if (1 & r) {
          const t = e.EpF();
          (e.TgZ(0, "div", 1)(1, "nu-mutable", 43),
            e.NdJ("selection", function (n) {
              e.CHM(t);
              const l = e.oxw();
              return e.KtG(l.onSelectionChange(n));
            }),
            e.YNc(2, Wl, 9, 12, "ng-template", 44),
            e.YNc(3, jl, 2, 7, "ng-template", 9),
            e.qZA()());
        }
        if (2 & r) {
          const t = e.oxw();
          (e.xp6(1),
            e.Q6J(
              "source",
              null == t.policyTableManager
                ? null
                : t.policyTableManager.tableSource,
            )(
              "settings",
              null == t.policyTableManager
                ? null
                : t.policyTableManager.settings,
            )("popUpMenu", !0)("initialLocate", t.initialLocate));
        }
      }
      const Hl = [
        {
          path: ":type/:subType",
          component: (() => {
            class r extends (0, _t.T)((0, bn.v)()) {
              constructor(t, i, n, l, a, s, u, g, h, P, N, L, J, Q) {
                (super(),
                  (this.element = t),
                  (this.auditTrailService = i),
                  (this.changeDetectorRef = n),
                  (this.router = l),
                  (this.notify = a),
                  (this.translation = s),
                  (this.prompt = u),
                  (this.fortiviewService = g),
                  (this.http = h),
                  (this.logViewer = P),
                  (this.sourceManagerFactory = N),
                  (this.policyTableManagerFactory = L),
                  (this.zone = J),
                  (this.destroyed = new de.t(1)),
                  (this.searchIcon = Y.RL9),
                  (this.refreshIcon = Y.b6u),
                  (this.purgeIcon = Y.NKw),
                  (this.auditIcon = Y.s_Y),
                  (this.logIcon = F.wsg),
                  (this.fortiViewIcon = Y.pyg),
                  (this.infoIcon = z.V0),
                  (this.recommendIcon = z.nI),
                  (this.TABLE_VIEW_OPTION_KEY = "policyList-viewOptionKey"),
                  (this.DEFAULT_TABLE_VIEW = re.H.InterfacePairView),
                  (this.TableView = re.H),
                  (this.EXCEEDS_PERFORMANCE_THRESHOLD_MESSAGE =
                    this.translation.translate(
                      "For a large policy table, By Sequence will load the fastest.",
                    )),
                  (this.dialogUrl = ""),
                  (this.readOnly = !1),
                  (this.insideSlide = !1),
                  (this.selection = y.rA),
                  (this.initialLocatePredefined = !1),
                  (this.showSecurityRatingNotification = !0),
                  (this.editCliEnabled = !0),
                  (this.editCliParams = new de.t(1)),
                  (this.switchingLayout = !1),
                  (this.previousLayoutOption = null),
                  (this.selectedView = this.DEFAULT_TABLE_VIEW),
                  (this.tableViewOptionSubject = new hn.x()),
                  (this.tableViews = [
                    re.H.InterfacePairView,
                    re.H.SequenceGroupingView,
                    re.H.BySequenceView,
                  ]),
                  (this.exceedsPerformanceThreshold = !1),
                  (this.updateStatisticsLabel = "Update statistics"),
                  (this.policyTableManagerReadySubject = new de.t(1)),
                  (this.getLazySectionLocateParamsFnObs =
                    this.policyTableManagerReadySubject.pipe(
                      (0, Se.U)(() =>
                        this.selectedView === re.H.BySequenceView
                          ? null
                          : (j) =>
                              (0, d.mG)(this, void 0, void 0, function* () {
                                var K, H, B, k, T;
                                const [te] =
                                  (yield null ===
                                    (H =
                                      null === (K = this.policyTableManager) ||
                                      void 0 === K
                                        ? void 0
                                        : K.policySource) || void 0 === H
                                    ? void 0
                                    : H.load({ keys: [j] })) || [];
                                if (te)
                                  return null ===
                                    (B = this.policyTableManager) ||
                                    void 0 === B
                                    ? void 0
                                    : B.getLocateParams(
                                        {
                                          q_origin_key: te[_.go],
                                          srcintf: (0, X.xP)(
                                            null === (k = te.data) ||
                                              void 0 === k
                                              ? void 0
                                              : k.srcintf[0],
                                          ),
                                          dstintf: (0, X.xP)(
                                            null === (T = te.data) ||
                                              void 0 === T
                                              ? void 0
                                              : T.dstintf[0],
                                          ),
                                        },
                                        this.selectedView,
                                      );
                              }),
                      ),
                      (0, ye.d)({ refCount: !0, bufferSize: 1 }),
                    )),
                  (this.showLookup = (0, Ee.a)([
                    this.fortigate.pipe(
                      (0, ce.w)((j) => j.config.getOperationMode()),
                    ),
                    this.routeParams.params,
                  ]).pipe(
                    (0, Se.U)(
                      ([j, { type: K, subType: H }]) =>
                        K === ie.a.Policy &&
                        H === ie.J.Standard &&
                        j !== Ve.BM.TRANSPARENT,
                    ),
                  )),
                  (this.showFortiView = this.fortigate.pipe(
                    (0, ce.w)((j) =>
                      (0, d.mG)(this, void 0, void 0, function* () {
                        var K;
                        return (
                          (yield j.admin.adminHasReadPermission(
                            Ve.Z0.FORTIVIEW,
                          )) &&
                          !this.implicitPolicySelected() &&
                          this.onePolicySelected() &&
                          !(
                            null !== (K = this.policyTableManager) &&
                            void 0 !== K &&
                            K.isNgfwPolicyMode
                          ) &&
                          !this.ztnaPolicySelected()
                        );
                      }),
                    ),
                    (0, Ge.x)(),
                  )),
                  (this.showViewInLog = this.fortigate.pipe(
                    (0, ce.w)((j) =>
                      (0, d.mG)(this, void 0, void 0, function* () {
                        var K, H;
                        return (
                          (yield j.admin.adminHasReadPermission(Ve.Z0.LOG)) &&
                          this.onePolicySelected() &&
                          !(
                            (null === (K = this.policyTableManager) ||
                            void 0 === K
                              ? void 0
                              : K.viewTypeManager.type) === ie.a.Policy &&
                            (null === (H = this.policyTableManager) ||
                            void 0 === H
                              ? void 0
                              : H.isNgfwPolicyMode)
                          )
                        );
                      }),
                    ),
                    (0, Ge.x)(),
                  )),
                  (this.deleteEntryAction = (j) =>
                    (0, d.mG)(this, void 0, void 0, function* () {
                      var K;
                      if (
                        !this.policyTableManager ||
                        !this.policyTableManager.tableSource ||
                        !this.policyTableManager.policySource
                      )
                        return void M.cM.error(
                          "Unable to proceed with delete right now.",
                        );
                      const H =
                          null === (K = j.data) || void 0 === K
                            ? void 0
                            : K["global-label"],
                        B = j[_.go];
                      if (
                        this.policyTableManager.tableSource.leadingPolicyOfGroups.has(
                          parseInt(B, 10),
                        ) &&
                        H
                      ) {
                        const T =
                          yield this.policyTableManager.policySource.getPolicyGroupLabelInfo(
                            B,
                          );
                        if (!T)
                          return void M.cM.error(
                            `Unable parse sequence group info of policy ${B}. Cannot delete leading policy now.`,
                          );
                        const te = T.startIndexOfGroup,
                          ue =
                            (yield this.policyTableManager.policySource.getTargetGroupPolicyInfo(
                              [H],
                              te,
                            )).at(1);
                        if ((yield j.delete(), ue)) {
                          const xe = yield j[_.Hx].load({
                            keys: [String(ue.policyid)],
                          });
                          if (Array.isArray(xe))
                            try {
                              const se = xe[0];
                              (null != se &&
                                se.data &&
                                (se.data["global-label"] = H),
                                yield se.save({ skipChangeSummary: !0 }));
                            } catch (se) {}
                        }
                      } else yield j.delete();
                    })),
                  Q && (this.insideSlide = !0));
              }
              ngOnInit() {
                let t = !0;
                (0, Ee.a)([
                  this.fortigate,
                  this.routeParams.params,
                  this.routeParams.queryParams,
                  this.tableViewOptionSubject.pipe(
                    (0, Ae.O)({
                      tableView: this.DEFAULT_TABLE_VIEW,
                      layoutOption: fe.Xe.New,
                    }),
                  ),
                  this.reloaded.pipe((0, Ae.O)(null)),
                ])
                  .pipe((0, je.b)(0), (0, We.R)(this.destroyed))
                  .subscribe(([i, n, l, a]) =>
                    (0, d.mG)(this, void 0, void 0, function* () {
                      const s = yield this.checkTableViewOption(a),
                        u = s.tableView;
                      (this.selectedView !== u && (this.selectedView = u),
                        s.layoutOption !== this.previousLayoutOption &&
                          ((this.previousLayoutOption = s.layoutOption),
                          (this.switchingLayout = !0)),
                        this.checkExceedPerformanceThreshold(n.type),
                        t
                          ? (t = !1)
                          : this.sourceManagerFactory.clearTableSourceManager(),
                        (this.readOnly =
                          !(yield i.admin.adminHasWritePermissionForTable(
                            "firewall",
                            n.type,
                          ))),
                        n.type === ie.a.SecurityPolicy &&
                          (this.updateStatisticsLabel =
                            "Update all statistics"));
                      const g = this.policyTableManagerFactory.create(
                        i,
                        (0, Oe.T)(
                          this.routeParams.paramsChanged,
                          this.destroyed,
                          this.fortigateChanged,
                          this.reloaded,
                          this.tableViewOptionSubject,
                        ),
                        { type: n.type, subType: n.subType },
                      );
                      ((this.dialogUrl = g.getDialogUrl()),
                        yield g.initForRender(
                          this.insideSlide,
                          this.readOnly,
                          s.layoutOption === fe.Xe.New,
                          this.selectedView,
                        ),
                        yield g.setupTable(this.selectedView),
                        g.viewTypeManager.setReloadWithCurrentTableViewCallback(
                          this.reloadWithCurrentTableView.bind(this),
                        ),
                        this.initialLocatePredefined
                          ? (this.initialLocatePredefined = !1)
                          : (this.initialLocate = yield g.getLocateParams(
                              l.showInList ? JSON.parse(l.showInList) : {},
                              this.selectedView,
                            )),
                        (this.policyTableManager = g),
                        this.policyTableManagerReadySubject.next(!0),
                        (this.showSecurityRatingNotification =
                          this.isSecurityRatingNotificationVisible()),
                        (this.switchingLayout = !1),
                        (this.copiedPolicy = void 0),
                        (this.exportFilename = g.getTableExportFilename()),
                        this.changeDetectorRef.markForCheck());
                    }),
                  );
              }
              tableSizeExceedsPerformanceThreshold(t, i) {
                return (0, d.mG)(this, void 0, void 0, function* () {
                  try {
                    const n = yield (0, be.z)(this.fortigate),
                      l = new Sn.C({ csfProxy: n }, { action: "meta" }),
                      a =
                        "/api/v2/cmdb/firewall/" +
                        (i === ie.a.SecurityPolicy
                          ? "security-policy"
                          : "policy");
                    return (
                      (yield (0, De.n)(
                        this.http
                          .get(a, { params: l })
                          .pipe((0, Se.U)((u) => u.results)),
                      )).size > t
                    );
                  } catch (n) {
                    return (
                      M.cM.error("Could not find table size:"),
                      M.cM.error(n),
                      !1
                    );
                  }
                });
              }
              checkExceedPerformanceThreshold(t) {
                return (0, d.mG)(this, void 0, void 0, function* () {
                  const n = yield this.tableSizeExceedsPerformanceThreshold(
                    5e3,
                    t,
                  );
                  this.exceedsPerformanceThreshold = n;
                });
              }
              policyStatsSupported(t) {
                var i;
                const n = new Set([ie.a.Policy, ie.a.SecurityPolicy]),
                  l = this.selection.rightClickTargetColumnID
                    ? V.Um.statsColumnIds.has(
                        this.selection.rightClickTargetColumnID,
                      )
                    : !t;
                return (
                  !(
                    null === (i = this.policyTableManager) ||
                    void 0 === i ||
                    !i.viewTypeManager.type
                  ) &&
                  n.has(this.policyTableManager.viewTypeManager.type) &&
                  l &&
                  (this.policyTableManager.viewTypeManager.type ===
                    ie.a.SecurityPolicy ||
                    this.selection.entries.length > 0)
                );
              }
              ngOnDestroy() {
                ((this.policyTableManager = void 0),
                  this.sourceManagerFactory.clearTableSourceManager(),
                  this.destroyed.next(),
                  this.destroyed.complete());
              }
              onSelectionChange(t) {
                var i, n, l, a, s, u, g;
                return (0, d.mG)(this, void 0, void 0, function* () {
                  ((this.selection = t),
                    (this.editCliEnabled =
                      1 === this.selection.entries.length &&
                      void 0 !==
                        (null ===
                          (n =
                            null === (i = this.selection.entries[0]) ||
                            void 0 === i
                              ? void 0
                              : i.data) || void 0 === n
                          ? void 0
                          : n.q_type)));
                  const h = this.selection.entries[0],
                    P = yield (0, be.z)(this.fortigate);
                  this.editCliParams.next({
                    path:
                      null !==
                        (a =
                          null === (l = null == h ? void 0 : h.data) ||
                          void 0 === l
                            ? void 0
                            : l.q_path) && void 0 !== a
                        ? a
                        : "",
                    name:
                      null !==
                        (u =
                          null === (s = null == h ? void 0 : h.data) ||
                          void 0 === s
                            ? void 0
                            : s.q_name) && void 0 !== u
                        ? u
                        : "",
                    mkey:
                      null !== (g = null == h ? void 0 : h[_.go]) &&
                      void 0 !== g
                        ? g
                        : "",
                    fortigate: P,
                  });
                });
              }
              editPolicy() {
                const t = this.selection.entries[0];
                t &&
                  this.router.navigate([this.dialogUrl, this.getEntryMkey(t)]);
              }
              createPolicy() {
                var t;
                null !== (t = this.policyTableManager) &&
                  void 0 !== t &&
                  t.policySource &&
                  this.router.navigate([this.dialogUrl]);
              }
              getEntryMkey(t) {
                return t.implicit ? "implicit" : t[_.go];
              }
              ztnaPolicySelected() {
                var t;
                return (
                  1 === this.selection.entries.length &&
                  (null === (t = this.selection.entries[0]) || void 0 === t
                    ? void 0
                    : t.isZTNAFirewallPolicy())
                );
              }
              implicitPolicySelected() {
                var t;
                return (
                  1 === this.selection.entries.length &&
                  (null === (t = this.selection.entries[0]) || void 0 === t
                    ? void 0
                    : t.implicit)
                );
              }
              canDeleteEntry({ result: t, entry: i }) {
                t.next(!i.implicit);
              }
              multiplePoliciesSelected() {
                return this.selection.entries.length > 1;
              }
              onePolicySelected() {
                return 1 === this.selection.entries.length;
              }
              updatePolicyStats() {
                var t, i, n, l, a;
                const s = this.selection.entries;
                !s.length ||
                  (this.isAllFirewallPolicies(s) &&
                  (null === (t = this.policyTableManager) || void 0 === t
                    ? void 0
                    : t.policySource) instanceof pe.m
                    ? null ===
                        (n =
                          null === (i = this.policyTableManager) || void 0 === i
                            ? void 0
                            : i.policySource) ||
                      void 0 === n ||
                      n.updatePolicyStats(s.map((u) => u[_.go]))
                    : null ===
                        (a =
                          null === (l = this.policyTableManager) || void 0 === l
                            ? void 0
                            : l.policySource) ||
                      void 0 === a ||
                      a.updatePolicyStats());
              }
              isAllFirewallPolicies(t) {
                return t.every((i) => i instanceof me.j);
              }
              clearPolicyStats() {
                var t, i, n, l, a, s, u;
                const g = this.selection.entries;
                if (
                  this.isAllFirewallPolicies(g) &&
                  (null === (t = this.policyTableManager) || void 0 === t
                    ? void 0
                    : t.policySource) instanceof pe.m
                ) {
                  const h = [],
                    P = [];
                  (g.forEach((N) => {
                    var L;
                    const J = N[_.go];
                    "ztna" ===
                    (null === (L = N.data) || void 0 === L
                      ? void 0
                      : L["policy-behaviour-type"])
                      ? P.push(J)
                      : h.push(J);
                  }),
                    h.length &&
                      (null ===
                        (n =
                          null === (i = this.policyTableManager) || void 0 === i
                            ? void 0
                            : i.policySource) ||
                        void 0 === n ||
                        n.clearPolicyStatCounters(h)),
                    P.length &&
                      (null ===
                        (a =
                          null === (l = this.policyTableManager) || void 0 === l
                            ? void 0
                            : l.policySource) ||
                        void 0 === a ||
                        a.clearZtnaPolicyStatCounters(P)));
                } else {
                  const h = g.map((P) => P[_.go]);
                  null ===
                    (u =
                      null === (s = this.policyTableManager) || void 0 === s
                        ? void 0
                        : s.policySource) ||
                    void 0 === u ||
                    u.clearPolicyStatCounters(h);
                }
              }
              showAuditTrail() {
                var t, i, n;
                const l = this.selection.entries;
                return !(
                  null === (t = this.policyTableManager) ||
                  void 0 === t ||
                  !t.workflowManagementVisible ||
                  1 !== l.length ||
                  l[0].implicit ||
                  !(l[0] instanceof me.j) ||
                  (null !== (i = this.policyTableManager) &&
                    void 0 !== i &&
                    i.isNgfwPolicyMode) ||
                  null === (n = this.policyTableManager) ||
                  void 0 === n ||
                  !n.logDeviceEnabled
                );
              }
              openAuditTrail() {
                var t, i;
                const n =
                  null === (t = this.selection.lastSelectedRow) || void 0 === t
                    ? void 0
                    : t.entry;
                this.selectedFortigate &&
                  n &&
                  (null === (i = n.data) || void 0 === i ? void 0 : i.uuid) &&
                  this.auditTrailService.openAuditTrail({
                    cmdbPath: n[_.Hx].datasource,
                    mkey: n[_.go],
                    uuid: n.data.uuid,
                    fortigate: this.selectedFortigate,
                  });
              }
              isSecurityRatingNotificationVisible() {
                var t, i;
                return !(
                  (null === (t = this.policyTableManager) || void 0 === t
                    ? void 0
                    : t.isNgfwPolicyMode) &&
                  (null === (i = this.policyTableManager) || void 0 === i
                    ? void 0
                    : i.viewTypeManager.type) === ie.a.Policy
                );
              }
              navigateToMatchingLogs() {
                var t, i, n, l, a, s, u;
                const g =
                  null === (t = this.selection.lastSelectedRow) || void 0 === t
                    ? void 0
                    : t.entry;
                if (!g) return;
                const h =
                    "enable" ===
                      (null ===
                        (n =
                          null === (i = this.policyTableManager) || void 0 === i
                            ? void 0
                            : i.logSettingSource) || void 0 === n
                        ? void 0
                        : n.data["brief-traffic-format"]) || g.implicit
                      ? {
                          policyid: { value: g[_.go] },
                          policytype: {
                            value:
                              null !==
                                (u =
                                  null === (s = this.policyTableManager) ||
                                  void 0 === s
                                    ? void 0
                                    : s.viewTypeManager.type) && void 0 !== u
                                ? u
                                : "",
                          },
                        }
                      : {
                          poluuid: {
                            value:
                              null !==
                                (a =
                                  null === (l = g.data) || void 0 === l
                                    ? void 0
                                    : l.uuid) && void 0 !== a
                                ? a
                                : "",
                          },
                        },
                  P = g.isZTNAFirewallPolicy()
                    ? st.TrafficLogSubType.ZTNA
                    : st.TrafficLogSubType.Forward;
                this.logViewer.showMatchingLogs(st.LogMainType.Traffic, P, h);
              }
              navigateFortiView() {
                var t, i, n, l, a;
                const s =
                  null === (t = this.selection.lastSelectedRow) || void 0 === t
                    ? void 0
                    : t.entry;
                s &&
                  this.fortiviewService.drilldownFortiviewPolicy({
                    policyId:
                      null !==
                        (n =
                          null === (i = s.data) || void 0 === i
                            ? void 0
                            : i.policyid) && void 0 !== n
                        ? n
                        : 0,
                    policyType:
                      null !==
                        (a =
                          null === (l = s.data) || void 0 === l
                            ? void 0
                            : l.q_name) && void 0 !== a
                        ? a
                        : "",
                  });
              }
              insertPolicy(t) {
                var i, n, l;
                const a = t.orientation === y.wQ.Above,
                  s =
                    null === (i = this.selection.lastSelectedRow) ||
                    void 0 === i
                      ? void 0
                      : i.entry;
                if (
                  s &&
                  (null === (n = this.policyTableManager) || void 0 === n
                    ? void 0
                    : n.policySource)
                ) {
                  const u =
                    null === (l = this.policyTableManager) || void 0 === l
                      ? void 0
                      : l.policySource;
                  t.resolve(
                    new Promise((g, h) => {
                      var P, N, L, J, Q, j, K;
                      const H = {
                          insert: !0,
                          insertAbove: a || "",
                          anchorPolicy: String(
                            null === (P = s.data) || void 0 === P
                              ? void 0
                              : P.policyid,
                          ),
                        },
                        B = {};
                      (!(
                        null ===
                          (L =
                            null === (N = this.policyTableManager) ||
                            void 0 === N
                              ? void 0
                              : N.viewTypeManager) || void 0 === L
                      ) &&
                        L.interfacePairView &&
                        Object.assign(B, {
                          autoFillData: {
                            srcintf:
                              null !==
                                (Q =
                                  null === (J = s.data) || void 0 === J
                                    ? void 0
                                    : J.srcintf) && void 0 !== Q
                                ? Q
                                : [],
                            dstintf:
                              null !==
                                (K =
                                  null === (j = s.data) || void 0 === j
                                    ? void 0
                                    : j.dstintf) && void 0 !== K
                                ? K
                                : [],
                          },
                        }),
                        u
                          .openDialogInSlide({
                            entry: void 0,
                            routeParams: H,
                            searchParams: B,
                          })
                          .then(
                            (k) =>
                              (0, d.mG)(this, void 0, void 0, function* () {
                                var T;
                                if (k) {
                                  const te = s[_.go];
                                  (a
                                    ? (yield null ===
                                        (T = this.policyTableManager) ||
                                      void 0 === T
                                        ? void 0
                                        : T.processGroupLabel(a, s, k),
                                      yield k.moveBefore(te, !0))
                                    : yield k.moveAfter(te, !0),
                                    this.notify.success(
                                      this.translation.translate(
                                        "Your changes have been saved",
                                      ),
                                    ),
                                    g(k));
                                } else h();
                              }),
                            (k) => {
                              (M.cM.error(
                                `Failed to insert ${a ? "above" : "below"}:`,
                              ),
                                M.cM.error(k),
                                h(k));
                            },
                          ));
                    }),
                  );
                }
              }
              getTableViewOptionLocalStorageKey() {
                return (0, d.mG)(this, void 0, void 0, function* () {
                  const t = yield (yield (0, be.z)(
                    this.fortigate,
                  )).admin.getAdminName();
                  return `${this.TABLE_VIEW_OPTION_KEY}#${t}`;
                });
              }
              checkTableViewOption(t) {
                return (0, d.mG)(this, void 0, void 0, function* () {
                  const i = yield this.getTableViewOptionLocalStorageKey(),
                    n = localStorage.getItem(i);
                  return n
                    ? JSON.parse(n)
                    : {
                        layoutOption: yield this.toggleInlineMenuLayout(
                          t.layoutOption === fe.Xe.New,
                          !0,
                        ),
                        tableView: this.selectedView,
                      };
                });
              }
              toggleInlineMenuLayout(t, i) {
                return (0, d.mG)(this, void 0, void 0, function* () {
                  let n = !0;
                  const l = !i && t;
                  try {
                    const g = this.translation.translate(
                      !i && t
                        ? "The classic policy list layout lacks performance enhancements and is not recommended for large policy lists. You can switch layouts any time."
                        : "The new policy list layout is designed to enhance user experience and performance, especially for larger policy lists. You can switch layouts any time.",
                    );
                    (yield this.prompt.confirm(
                      g,
                      l ? p.P7.Warning : p.P7.Success,
                      {
                        okButtonLabel: this.translation.translate(
                          l ? "Use classic layout" : "Use new layout",
                        ),
                        title: this.translation.translate(
                          l
                            ? "Use Classic Policy List Layout"
                            : "Use New Policy List Layout",
                        ),
                      },
                    ),
                      (n = !l));
                  } catch (g) {
                    n = l;
                  }
                  const a = yield this.getTableViewOptionLocalStorageKey(),
                    u = {
                      layoutOption: n ? fe.Xe.New : fe.Xe.Old,
                      tableView: this.selectedView,
                    };
                  return (
                    localStorage.setItem(a, JSON.stringify(u)),
                    n !== t && this.tableViewOptionSubject.next(u),
                    n ? fe.Xe.New : fe.Xe.Old
                  );
                });
              }
              onTableViewChange(t) {
                var i, n;
                return (0, d.mG)(this, void 0, void 0, function* () {
                  if (t && this.selectedView !== t) {
                    this.selectedView = t;
                    const l = yield this.getTableViewOptionLocalStorageKey(),
                      a = {
                        layoutOption:
                          null !==
                            (n =
                              null === (i = this.policyTableManager) ||
                              void 0 === i
                                ? void 0
                                : i.viewTypeManager) &&
                          void 0 !== n &&
                          n.optInForInlineMenu
                            ? fe.Xe.New
                            : fe.Xe.Old,
                        tableView: this.selectedView,
                      };
                    (localStorage.setItem(l, JSON.stringify(a)),
                      this.tableViewOptionSubject.next(a));
                  }
                });
              }
              filterIssue(t) {
                var i;
                const n =
                  (null === (i = t.target) || void 0 === i
                    ? void 0
                    : i.policyId) || t.id;
                return { mkey: "string" == typeof n ? n : String(n) };
              }
              reloadWithCurrentTableView(t) {
                this.zone.runOutsideAngular(() => {
                  var i, n;
                  (t &&
                    ((this.initialLocate = t),
                    (this.initialLocatePredefined = !0)),
                    this.previousLayoutOption ||
                      (this.previousLayoutOption =
                        null !==
                          (n =
                            null === (i = this.policyTableManager) ||
                            void 0 === i
                              ? void 0
                              : i.viewTypeManager) &&
                        void 0 !== n &&
                        n.optInForInlineMenu
                          ? fe.Xe.New
                          : fe.Xe.Old),
                    this.tableViewOptionSubject.next({
                      tableView: this.selectedView,
                      layoutOption: this.previousLayoutOption,
                    }));
                });
              }
            }
            return (
              (r.ɵfac = function (t) {
                return new (t || r)(
                  e.Y36(e.SBq),
                  e.Y36(Pn.AuditTrailService),
                  e.Y36(e.sBO),
                  e.Y36(w.Router),
                  e.Y36(Qe.Cq),
                  e.Y36(G.D7),
                  e.Y36(at.lK),
                  e.Y36(Tn.FortiviewService),
                  e.Y36(C.eN),
                  e.Y36(Cn.LogViewerService),
                  e.Y36(ct.n),
                  e.Y36(lo),
                  e.Y36(e.R0b),
                  e.Y36($.o6, 8),
                );
              }),
              (r.ɵcmp = e.Xpm({
                type: r,
                selectors: [["fos-policy-table"]],
                features: [e.qOj],
                decls: 2,
                vars: 2,
                consts: [
                  ["class", "mutable-container", 4, "ngIf"],
                  [1, "mutable-container"],
                  [
                    3,
                    "source",
                    "settings",
                    "initialLocate",
                    "forceTraditionalMenu",
                    "selection",
                  ],
                  ["nuMutableTopMenuItems", ""],
                  ["nuMutableSecondaryTopMenuItems", ""],
                  ["nuMutableControlMenuItems", ""],
                  ["nuMutableSelectionMenuItems", ""],
                  ["nuMutableMultiselectionMenuItems", ""],
                  ["nuMutableHiddenMenuItems", ""],
                  ["nuMutableFooterContent", ""],
                  [
                    3,
                    "policyTableManager",
                    "dialogUrl",
                    "insideSlide",
                    "topMenu",
                    "implicitPolicySelected",
                    "selection",
                    "menu",
                  ],
                  [
                    3,
                    "menu",
                    "firewallPolicy",
                    "firewallInterface",
                    "localUser",
                    "webFilterProfile",
                    "webFilterFtgdCat",
                    "webFilterFtgdLocalCat",
                    "policyTableManager",
                    4,
                    "ngIf",
                  ],
                  [
                    3,
                    "menu",
                    "firewallPolicy",
                    "firewallInterface",
                    "localUser",
                    "webFilterProfile",
                    "webFilterFtgdCat",
                    "webFilterFtgdLocalCat",
                    "policyTableManager",
                  ],
                  [3, "menu", "name"],
                  [3, "menu", "nuPopUpMenuToggle", "nuTip", "nuTipDisabled"],
                  [3, "icon", 4, "ngIf"],
                  [3, "ngClass"],
                  ["tableViewToggleMenu", ""],
                  [
                    "style",
                    "border: 0",
                    3,
                    "nuTip",
                    "nuTipDisabled",
                    "ngClass",
                    "action",
                    4,
                    "ngFor",
                    "ngForOf",
                  ],
                  [3, "menu", "nuPopUpMenuToggle"],
                  ["layoutToggleMenu", ""],
                  [2, "border", "0", 3, "action"],
                  [3, "icon"],
                  [
                    2,
                    "border",
                    "0",
                    3,
                    "nuTip",
                    "nuTipDisabled",
                    "ngClass",
                    "action",
                  ],
                  [3, "menu", "insert", 4, "ngIf"],
                  [3, "menu", "columnId", "binaryMode", 4, "ngIf"],
                  [
                    3,
                    "menu",
                    "fortigate",
                    "deleteEntryAction",
                    "canDeleteEntry",
                  ],
                  [3, "menu", "insert"],
                  [3, "menu", "columnId", "binaryMode"],
                  [3, "menu", "columnId", 4, "ngIf"],
                  [3, "menu", "columnId"],
                  [4, "ngIf"],
                  [
                    3,
                    "menu",
                    "multiplePoliciesSelected",
                    "implicitPolicySelected",
                    "policyTableManager",
                    "selection",
                    "copiedPolicy",
                    "copiedPolicyChange",
                    4,
                    "ngIf",
                  ],
                  [3, "menu", "policyTableManager", "selection", 4, "ngIf"],
                  ["class", "separator", 4, "ngIf"],
                  [3, "menu", "action", 4, "ngIf"],
                  [3, "menu", "fortigate", "disabled", "editParams", 4, "ngIf"],
                  [3, "menu", "action"],
                  [
                    3,
                    "menu",
                    "multiplePoliciesSelected",
                    "implicitPolicySelected",
                    "policyTableManager",
                    "selection",
                    "copiedPolicy",
                    "copiedPolicyChange",
                  ],
                  [3, "menu", "policyTableManager", "selection"],
                  [1, "separator"],
                  [3, "menu", "fortigate", "disabled", "editParams"],
                  [
                    3,
                    "filter",
                    "useTableSource",
                    "getLazySectionLocateParamsFn",
                  ],
                  [
                    3,
                    "source",
                    "settings",
                    "popUpMenu",
                    "initialLocate",
                    "selection",
                  ],
                  ["nuMenuContent", ""],
                  [1, "left-menu-items"],
                  [3, "menu", "disabled", "fortigate", "editParams", 4, "ngIf"],
                  [
                    3,
                    "menu",
                    "fortigate",
                    "label",
                    "deleteEntryAction",
                    "canDeleteEntry",
                  ],
                  ["class", "center-menu-items", 4, "ngIf"],
                  ["class", "right-menu-items", 4, "ngIf"],
                  [1, "heading"],
                  [3, "menu", "separatorBelow", 4, "ngIf"],
                  [3, "menu", "separatorBelow"],
                  [3, "menu", "disabled", "fortigate", "editParams"],
                  [1, "center-menu-items"],
                  [1, "right-menu-items"],
                ],
                template: function (t, i) {
                  (1 & t &&
                    (e.YNc(0, Ml, 9, 4, "div", 0),
                    e.YNc(1, ql, 4, 4, "div", 0)),
                    2 & t &&
                      (e.Q6J(
                        "ngIf",
                        !i.switchingLayout &&
                          !(
                            null == i.policyTableManager ||
                            null == i.policyTableManager.viewTypeManager ||
                            !i.policyTableManager.viewTypeManager
                              .optInForInlineMenu
                          ),
                      ),
                      e.xp6(1),
                      e.Q6J(
                        "ngIf",
                        !(
                          i.switchingLayout ||
                          (null != i.policyTableManager &&
                            null != i.policyTableManager.viewTypeManager &&
                            i.policyTableManager.viewTypeManager
                              .optInForInlineMenu)
                        ),
                      )));
                },
                dependencies: [
                  D._g,
                  O.mk,
                  O.sg,
                  O.O5,
                  y.MW,
                  y.PY,
                  y.LL,
                  y.ab,
                  y.zy,
                  y.Or,
                  y.mD,
                  A.lD,
                  E.C6,
                  E.Zo,
                  E.qT,
                  E.KT,
                  E.HP,
                  E.B$,
                  E.ZC,
                  E.j$,
                  E.$6,
                  E.wk,
                  f.oJ,
                  At.V,
                  Ft.Z,
                  ro.i,
                  ao.J,
                  so.K,
                  wo,
                  Wo,
                  jo,
                  zo,
                  O.Ov,
                  Re.X,
                ],
                styles: [
                  "[_nghost-%COMP%]{display:flex;flex-direction:column}[_nghost-%COMP%]   .is-hidden[_ngcontent-%COMP%]{display:none}.mutable-container[_ngcontent-%COMP%]{position:relative;flex-grow:1}",
                ],
              })),
              r
            );
          })(),
        },
      ];
      let $l = (() => {
        class r {}
        return (
          (r.ɵfac = function (t) {
            return new (t || r)();
          }),
          (r.ɵmod = e.oAB({ type: r })),
          (r.ɵinj = e.cJS({
            imports: [
              D.jK,
              O.ez,
              I.Su,
              x.rw,
              S.u5,
              S.UX,
              W.C,
              _.rX,
              v.I,
              w.RouterModule.forChild(Hl),
              G.qw,
              b.h,
              q.Dt,
              y.A4,
              A.z8,
              E.$9,
              f.pc,
              R.f,
              Z.p,
            ],
          })),
          r
        );
      })();
    },
    7846: (ne, U, c) => {
      c.d(U, { I: () => R });
      var O = c(69808),
        S = c(57892),
        w = c(67829),
        D = c(90652),
        I = c(22638),
        f = c(5e3);
      function x(Z, q) {
        (1 & Z && (f.TgZ(0, "span"), f._uU(1), f.ALo(2, "translate"), f.qZA()),
          2 & Z && (f.xp6(1), f.hij(" (", f.lcZ(2, 1, "disabled"), ") ")));
      }
      function E(Z, q) {
        if (
          (1 & Z &&
            (f.TgZ(0, "tr")(1, "td"),
            f._uU(2),
            f.ALo(3, "translate"),
            f.qZA(),
            f.TgZ(4, "td"),
            f._uU(5),
            f.YNc(6, x, 3, 3, "span", 1),
            f.qZA()()),
          2 & Z)
        ) {
          const W = f.oxw();
          (f.xp6(2),
            f.Oqu(f.lcZ(3, 3, "Policy ID")),
            f.xp6(3),
            f.hij(" ", W.id, " "),
            f.xp6(1),
            f.Q6J("ngIf", W.disabled));
        }
      }
      function y(Z, q) {
        if (
          (1 & Z &&
            (f.TgZ(0, "tr")(1, "td"),
            f._uU(2),
            f.ALo(3, "translate"),
            f.qZA(),
            f.TgZ(4, "td"),
            f._uU(5),
            f.ALo(6, "translate"),
            f.qZA()()),
          2 & Z)
        ) {
          const W = f.oxw();
          (f.xp6(2),
            f.Oqu(f.lcZ(3, 2, "implicit")),
            f.xp6(3),
            f.Oqu(
              f.lcZ(6, 4, null == W.policy.data ? null : W.policy.data.action),
            ));
        }
      }
      function _(Z, q) {
        if (
          (1 & Z &&
            (f.TgZ(0, "tr")(1, "td"),
            f._uU(2),
            f.ALo(3, "translate"),
            f.qZA(),
            f.TgZ(4, "td"),
            f._uU(5),
            f.qZA()()),
          2 & Z)
        ) {
          const W = f.oxw();
          (f.xp6(2),
            f.Oqu(f.lcZ(3, 2, "Policy Name")),
            f.xp6(3),
            f.Oqu(null == W.policy.data ? null : W.policy.data.name));
        }
      }
      function A(Z, q) {
        if (
          (1 & Z &&
            (f.TgZ(0, "li")(1, "span"),
            f._uU(2),
            f.ALo(3, "translate"),
            f.qZA()()),
          2 & Z)
        ) {
          const W = q.$implicit;
          (f.xp6(2), f.Oqu(f.lcZ(3, 1, W)));
        }
      }
      function G(Z, q) {
        if (
          (1 & Z &&
            (f.TgZ(0, "table", 3)(1, "tbody")(2, "tr")(3, "td")(4, "span"),
            f._uU(5),
            f.ALo(6, "translate"),
            f.qZA(),
            f.TgZ(7, "ul"),
            f.YNc(8, A, 4, 3, "li", 4),
            f.qZA()()()()()),
          2 & Z)
        ) {
          const W = f.oxw();
          (f.xp6(5),
            f.Oqu(f.lcZ(6, 2, "policy_issues")),
            f.xp6(3),
            f.Q6J("ngForOf", W.warnings));
        }
      }
      let R = (() => {
        class Z {
          constructor(W) {
            var b;
            ((this.policy = W.entry),
              (this.id =
                (this.policy.data &&
                  "policyid" in this.policy.data &&
                  this.policy.data.policyid) ||
                this.policy.policyId),
              (this.disabled =
                "disable" ===
                (null === (b = this.policy.data) || void 0 === b
                  ? void 0
                  : b.status)),
              (this.warnings =
                ("warnings" in this.policy && this.policy.warnings) || []));
          }
        }
        return (
          (Z.ɵfac = function (W) {
            return new (W || Z)(f.Y36(w.uB));
          }),
          (Z.ɵcmp = f.Xpm({
            type: Z,
            selectors: [["fos-firewall-policy-warnings"]],
            standalone: !0,
            features: [f.jDz],
            decls: 7,
            vars: 4,
            consts: [
              [1, "nu-table", "nu-table-key-value"],
              [4, "ngIf"],
              ["class", "nu-table", 4, "ngIf"],
              [1, "nu-table"],
              [4, "ngFor", "ngForOf"],
            ],
            template: function (W, b) {
              (1 & W &&
                (f.TgZ(0, "div")(1, "table", 0)(2, "tbody"),
                f.YNc(3, E, 7, 5, "tr", 1),
                f.YNc(4, y, 7, 6, "tr", 1),
                f.YNc(5, _, 6, 4, "tr", 1),
                f.qZA()(),
                f.YNc(6, G, 9, 4, "table", 2),
                f.qZA()),
                2 & W &&
                  (f.xp6(3),
                  f.Q6J("ngIf", 0 !== b.id),
                  f.xp6(1),
                  f.Q6J("ngIf", 0 === b.id),
                  f.xp6(1),
                  f.Q6J(
                    "ngIf",
                    0 !== b.id &&
                      (null == b.policy.data ? null : b.policy.data.name),
                  ),
                  f.xp6(1),
                  f.Q6J("ngIf", b.warnings.length)));
            },
            dependencies: [O.ez, O.sg, O.O5, S.jK, I.qw, I.X$, D.z8],
          })),
          Z
        );
      })();
    },
    3073: (ne, U, c) => {
      c.d(U, {
        $o: () => y,
        Aq: () => C,
        Bd: () => I,
        Dq: () => M,
        ES: () => d,
        Gr: () => _,
        IT: () => x,
        LS: () => f,
        P4: () => G,
        QK: () => p,
        R7: () => q,
        R9: () => Y,
        Tw: () => $,
        W$: () => z,
        ZC: () => R,
        b$: () => E,
        dC: () => A,
        dP: () => v,
        em: () => w,
        gg: () => W,
        l_: () => D,
        li: () => b,
        pj: () => Z,
      });
      var O = c(29142),
        S = c(57420);
      const w = 10,
        D = ["valid_in_policy", "is_virtual_wan_link_member"];
      var I = (() => {
          return (
            ((F = I || (I = {})).IPVersion = "ipVersion"),
            (F.IncomingInterface = "incomingInterface"),
            (F.Protocol = "protocol"),
            (F.ProtocolNumber = "protocolNumber"),
            (F.ICMPType = "icmpType"),
            (F.ICMPTypeNumber = "icmpTypeNumber"),
            (F.ICMPCode = "icmpCode"),
            (F.SourceIP = "sourceIp"),
            (F.SourcePort = "sourcePort"),
            (F.Destination = "destination"),
            (F.DestinationPort = "destinationPort"),
            (F.UserType = "userType"),
            (F.User = "user"),
            (F.LDAPServer = "ldapServer"),
            (F.CustomLDAPFilter = "customLdapFilter"),
            I
          );
          var F;
        })(),
        f = (() => {
          return (
            ((F = f || (f = {})).PolicyAction = "Policy action"),
            (F.RedirectedPolicy = "Redirected policy"),
            (F.WebFilterProfile = "Web filter profile"),
            (F.WebFilterAction = "Web filter action"),
            (F.UrlFilter = "Matching static URL filter"),
            (F.CategoryFilter = "Matching FortiGuard category filter"),
            (F.CategoryFilterUrl = "Filter URL"),
            (F.FromRemoteGroup = "From remote groups"),
            f
          );
          var F;
        })(),
        x = (() => {
          return (((F = x || (x = {})).IPv4 = "ipv4"), (F.IPv6 = "ipv6"), x);
          var F;
        })(),
        E = (() => {
          return (
            ((F = E || (E = {})).HTTPS = "https"),
            (F.HTTP = "http"),
            (F.OTHER = "other"),
            (F.TCP = "tcp"),
            (F.UDP = "udp"),
            (F.SCTP = "sctp"),
            (F.ICMP = "icmp"),
            (F.ICMP6 = "icmp6"),
            E
          );
          var F;
        })(),
        y = (() => {
          return (
            ((F = y || (y = {})).Lookup = "lookup"),
            (F.Match = "match"),
            y
          );
          var F;
        })(),
        _ = (() => {
          return (((F = _ || (_ = {})).User = "user"), (F.Group = "group"), _);
          var F;
        })(),
        A = (() => {
          return (
            ((F = A || (A = {})).Any = "Any"),
            (F.User = "User"),
            (F.Group = "Group"),
            A
          );
          var F;
        })(),
        G = (() => {
          return (
            ((F = G || (G = {})).PingRequest = "Ping request"),
            (F.PingReply = "Ping reply"),
            (F.Other = "Other"),
            G
          );
          var F;
        })();
      const R = "/firewall/policy/policy/standard",
        Z = "/api/v2/monitor/firewall/policy-lookup",
        q =
          "No custom LDAP filters have been provided. Policy lookup will discard any LDAP related lookup information.",
        W = {
          [I.IPVersion]: "IP version",
          [I.IncomingInterface]: "Incoming interface",
          [I.Protocol]: "Protocol",
          [I.ProtocolNumber]: "Protocol number",
          [I.ICMPType]: "ICMP type",
          [I.ICMPTypeNumber]: "Type",
          [I.ICMPCode]: "Code",
          [I.SourceIP]: "Source",
          [I.SourcePort]: "Source port",
          [I.Destination]: "Destination address",
          [I.DestinationPort]: "Destination port",
          [I.UserType]: "User",
          [I.LDAPServer]: "LDAP server",
          [I.CustomLDAPFilter]: "Custom LDAP filter",
        },
        b = {
          allow: "Allow",
          deny: "Block",
          ovrd: "Override with user authentication",
          warn: "Warning",
          redir: "Cookie redirect",
          block_http_response: "Response contains banned word",
          unknown: "Unknown",
        },
        v = {
          accept: "Accepted",
          deny: "Denied",
          redirect: "Redirected",
          ipsec: "",
          unknown: "",
        },
        d = { allow: "Allowed", deny: "Denied" },
        C = {
          allow: S.J,
          deny: S.wD,
          warn: O.$I,
          ovrd: void 0,
          redir: void 0,
          block_http_response: void 0,
          unknown: void 0,
        },
        p = {
          deny: S.wD,
          accept: S.J,
          ipsec: void 0,
          redirect: void 0,
          unknown: void 0,
        },
        z = { [E.HTTP]: 80, [E.HTTPS]: 443 },
        M = { allow: S.J, deny: S.wD },
        $ = 1e3,
        Y = "recentLookupPolicy";
    },
    72300: (ne, U, c) => {
      c.d(U, { $c: () => x, If: () => E, It: () => I });
      var O = c(29730),
        S = c(18125),
        w = c(79056),
        D = c(51620);
      const I = (y, _, A) => {
          var G, R;
          if (_.data) {
            const Z = _.data[D.oJ.InternetService] === D.vu.Enable,
              q = _.data[D.oJ.InternetService6] === D.vu.Enable,
              W = !(null === (G = _.data.dstaddr) || void 0 === G || !G.length),
              b = !(
                null === (R = _.data.dstaddr6) ||
                void 0 === R ||
                !R.length
              ),
              v = {
                nafEnabled: _.isNafEnabled(),
                hasIpv4DestinationAddressOrIsdb: Z || W,
                hasIpv6DestinationAddressOrIsdb: q || b,
                isZTNAFirewallPolicy: _.isZTNAFirewallPolicy(),
              };
            if (v.nafEnabled) return;
            let d = !1,
              C = !1,
              p = !1;
            const z = Array.from(A.values());
            for (const M of z) {
              if (C && p) break;
              M instanceof S.B ? (C = !0) : M instanceof w.X && (p = !0);
            }
            return (
              (d =
                (C === v.hasIpv4DestinationAddressOrIsdb &&
                  p === v.hasIpv6DestinationAddressOrIsdb) ||
                v.isZTNAFirewallPolicy),
              d
                ? void 0
                : y.translate(
                    "IP Pools with the matching IP version as destination addresses or Internet Services must be set.",
                  )
            );
          }
        },
        f = "invalidConsolidatedSrcDst",
        x = { [f]: "{ERROR}" },
        E = (y, _) => (A) => {
          if (Array.isArray(A.value)) {
            const G = I(_, y(), new O.xZ(A.value));
            if (G) return { [f]: [G] };
          }
          return null;
        };
    },
    27169: (ne, U, c) => {
      c.d(U, { JE: () => x, YW: () => E, dH: () => y });
      var O = c(29730),
        S = c(78719),
        w = c(87480),
        D = c(31161),
        I = c(38095);
      const f = "Virtual IPs cannot be negated.",
        x = { NO_NEGATED_VIP_ERROR_MESSAGE: f },
        E = ({ getPolicy: _, entries: A }) => {
          const G = _(),
            R = new Map(),
            Z = G[O.Hx].translation.translate(f);
          if (
            (G &&
              A.forEach((q) => {
                var W, b;
                ((q instanceof I.Z || q instanceof w.kN) &&
                  "enable" ===
                    (null === (W = null == G ? void 0 : G.data) || void 0 === W
                      ? void 0
                      : W["dstaddr-negate"]) &&
                  R.set(q, { message: Z }),
                  (q instanceof S.Q || q instanceof D.wN) &&
                    "enable" ===
                      (null === (b = null == G ? void 0 : G.data) ||
                      void 0 === b
                        ? void 0
                        : b["dstaddr6-negate"]) &&
                    R.set(q, { message: Z }));
              }),
            R.size)
          )
            return new O.kT(R, Z);
        },
        y =
          ({ getPolicy: _ }) =>
          (A) => {
            if (!Array.isArray(A.value)) return null;
            const G = E({ entries: A.value, getPolicy: _ });
            return G ? { NO_NEGATED_VIP_ERROR_MESSAGE: G } : null;
          };
    },
    18125: (ne, U, c) => {
      c.d(U, { B: () => D });
      var O = c(29730),
        S = c(66776),
        w = c(39560);
      class D extends w.mT {
        getDescriptorValue() {
          return { name: this[O.go], icon: S.iRu };
        }
        nat64Enabled() {
          var f;
          return (
            "enable" ===
            (null === (f = this.data) || void 0 === f ? void 0 : f.nat64)
          );
        }
      }
    },
    3868: (ne, U, c) => {
      c.d(U, { tE: () => E, zg: () => x });
      var O = c(70655),
        S = c(29142),
        w = c(29730),
        D = c(71748),
        I = c(87428),
        f = c(18125);
      class x extends D.C {
        constructor(A) {
          (super(A.csfParams || {}),
            (this.props = { hideShowInList: A.hideShowInList }));
        }
        serialize() {
          return "";
        }
      }
      class E extends I.WF {
        constructor(A, G, R, Z) {
          var q, W;
          (super(
            Object.assign(
              {
                path: "firewall",
                name: "ippool",
                label: "firewall.ippool",
                cmdbSourceDi: A,
                variant: R,
                pool: Z,
                EntryClass: f.B,
              },
              R.cgn && { filter: { type: "cgn-resource-allocation" } },
            ),
          ),
            (this.firewallIppoolStatisticsSourceFactoryService = G),
            (this.tooltipActions =
              null !==
                (W =
                  null === (q = this.variant) || void 0 === q
                    ? void 0
                    : q.props) &&
              void 0 !== W &&
              W.hideShowInList
                ? [this.getEditToolTipAction()]
                : [
                    this.getEditToolTipAction(),
                    this.getShowInListTooltipAction({
                      showInListSearchFormatter: (b) => {
                        var v;
                        return {
                          type: "ippool",
                          locate:
                            (null === (v = null == b ? void 0 : b.data) ||
                            void 0 === v
                              ? void 0
                              : v.q_origin_key) || "",
                        };
                      },
                    }),
                  ]),
            (this.tooltipProperties = [
              {
                label: this.translation.translate("comment"),
                descriptor: (b) => {
                  var v;
                  if (
                    b.data &&
                    (null === (v = b.data) || void 0 === v
                      ? void 0
                      : v.comments)
                  )
                    return { name: b.data.comments };
                },
              },
              {
                label: this.translation.translate("type"),
                descriptor: (b) => {
                  if (b.data)
                    return { name: this.translation.translate(b.data.type) };
                },
              },
              {
                label: this.translation.translate("Mode"),
                descriptor: (b) => {
                  var v;
                  if (
                    "cgn-resource-allocation" ===
                    (null === (v = b.data) || void 0 === v ? void 0 : v.type)
                  ) {
                    const C = [
                      "cgn-fixedalloc",
                      "cgn-overload",
                      "cgn-spa",
                    ].filter((p) => !!b.data && "enable" === b.data[p]);
                    return (
                      (!C.length ||
                        (1 === C.length && "cgn-overload" === C[0])) &&
                        C.push("port-block-allocation"),
                      {
                        name: C.map((p) => this.translation.translate(p)).join(
                          ", ",
                        ),
                      }
                    );
                  }
                },
              },
              {
                label: this.translation.translate("External IP range"),
                descriptor: (b) => {
                  if (b.data)
                    return { name: `${b.data.startip} - ${b.data.endip}` };
                },
              },
              {
                label: this.translation.translate("internal_ip_range"),
                descriptor: (b) => {
                  var v;
                  if (
                    b.data &&
                    "fixed-port-range" ===
                      (null === (v = b.data) || void 0 === v ? void 0 : v.type)
                  )
                    return {
                      name: `${b.data["source-startip"]} - ${b.data["source-endip"]}`,
                    };
                },
              },
              {
                label: this.translation.translate("NAT64"),
                descriptor: (b) => {
                  var v;
                  if (
                    "enable" ===
                    (null === (v = b.data) || void 0 === v ? void 0 : v.nat64)
                  )
                    return {
                      name: this.translation.translate("enabled"),
                      icon: S.nI,
                    };
                },
              },
              {
                label: this.translation.translate("Excluded IPs"),
                descriptor: (b) => {
                  var v;
                  if (
                    "cgn-resource-allocation" ===
                      (null === (v = b.data) || void 0 === v
                        ? void 0
                        : v.type) &&
                    "exclude-ip" in b.data
                  ) {
                    const d = b.data["exclude-ip"];
                    if (d && d.length > 0)
                      return d.map((C) => ({ name: C.ip }));
                  }
                },
              },
              {
                label: this.translation.translate("arp-reply"),
                descriptor: (b) => {
                  var v;
                  if (
                    b.data &&
                    "enable" !==
                      (null === (v = b.data) || void 0 === v ? void 0 : v.nat64)
                  ) {
                    const C = "enable" === b.data["arp-reply"] ? S.nI : S.oc;
                    return {
                      name: this.translation.translate(
                        `${b.data["arp-reply"]}d`,
                      ),
                      icon: C,
                    };
                  }
                },
              },
              {
                label: this.translation.translate("block-size"),
                descriptor: (b) => {
                  var v, d;
                  return null !=
                    (null === (v = b.data) || void 0 === v
                      ? void 0
                      : v["block-size"]) &&
                    "port-block-allocation" === b.data.type
                    ? { name: b.data["block-size"].toString() }
                    : "cgn-resource-allocation" ===
                          (null === (d = b.data) || void 0 === d
                            ? void 0
                            : d.type) &&
                        "enable" !== b.data["cgn-spa"] &&
                        "number" == typeof b.data["cgn-block-size"]
                      ? { name: b.data["cgn-block-size"].toString() }
                      : void 0;
                },
              },
              {
                label: this.translation.translate("num-blocks-per-user"),
                descriptor: (b) => {
                  var v;
                  if (
                    null !=
                      (null === (v = b.data) || void 0 === v
                        ? void 0
                        : v["num-blocks-per-user"]) &&
                    "port-block-allocation" === b.data.type
                  )
                    return { name: b.data["num-blocks-per-user"].toString() };
                },
              },
              {
                label: this.translation.translate("Blocks Per IP"),
                descriptor: (b) => {
                  const v = this.getStatsForEntry(b);
                  if (
                    (null == v ? void 0 : v.data) &&
                    "pba_per_ip" in v.data &&
                    v.data.pba_per_ip
                  )
                    return { name: v.data.pba_per_ip.toString() };
                },
              },
              {
                label: this.translation.translate("External IPs in Use"),
                descriptor: (b) => {
                  var v;
                  const d = this.getStatsForEntry(b);
                  if (
                    (null == d ? void 0 : d.data) &&
                    "natip_in_use" in d.data &&
                    "number" ==
                      typeof (null === (v = null == d ? void 0 : d.data) ||
                      void 0 === v
                        ? void 0
                        : v.natip_in_use) &&
                    (null == d ? void 0 : d.data.natip_total)
                  )
                    return {
                      name: `${d.data.natip_in_use}/${d.data.natip_total}`,
                    };
                },
              },
              {
                label: this.translation.translate("Clients Online"),
                descriptor: (b) => {
                  var v, d;
                  const C = this.getStatsForEntry(b);
                  if (
                    "cgn-resource-allocation" !==
                      (null === (v = b.data) || void 0 === v
                        ? void 0
                        : v.type) &&
                    (null == C ? void 0 : C.data) &&
                    "clients" in C.data &&
                    null !=
                      (null === (d = null == C ? void 0 : C.data) ||
                      void 0 === d
                        ? void 0
                        : d.clients)
                  )
                    return { name: C.data.clients.toString() };
                },
              },
              {
                label: this.translation.translate("Blocks Available"),
                descriptor: (b) => {
                  const v = this.getStatsForEntry(b),
                    d = null == v ? void 0 : v.data;
                  if (d && "available" in d)
                    return this.availableFormatFunction({
                      available: d.available,
                      total: d.total,
                      used: d.used,
                    });
                },
              },
              {
                label: this.translation.translate("IPs Sharing External IP"),
                descriptor: (b) => {
                  var v;
                  const d = this.getStatsForEntry(b);
                  if (
                    (null == d ? void 0 : d.data) &&
                    "ip_shared" in d.data &&
                    null !=
                      (null === (v = null == d ? void 0 : d.data) ||
                      void 0 === v
                        ? void 0
                        : v.ip_shared)
                  )
                    return { name: d.data.ip_shared.toString() };
                },
              },
              {
                label: this.translation.translate("Ports Per IP"),
                descriptor: (b) => {
                  var v;
                  if (
                    !(
                      "fixed-port-range" ===
                        (null === (v = b.data) || void 0 === v
                          ? void 0
                          : v.type) && b.data["port-per-user"] > 0
                    )
                  ) {
                    const d = this.getStatsForEntry(b);
                    if (
                      (null == d ? void 0 : d.data) &&
                      "ports_per_ip" in d.data &&
                      null != d.data.ports_per_ip
                    )
                      return { name: d.data.ports_per_ip.toString() };
                  }
                },
              },
              {
                label: this.translation.translate("Ports Per User"),
                descriptor: (b) => {
                  var v, d;
                  if (
                    "fixed-port-range" ===
                      (null === (v = b.data) || void 0 === v
                        ? void 0
                        : v.type) &&
                    b.data["port-per-user"] > 0 &&
                    null !=
                      (null === (d = b.data) || void 0 === d
                        ? void 0
                        : d["port-per-user"])
                  )
                    return { name: b.data["port-per-user"].toString() };
                },
              },
              {
                label: this.translation.translate("Client IP Range"),
                descriptor: (b) => {
                  var v;
                  if (
                    "cgn-resource-allocation" ===
                      (null === (v = b.data) || void 0 === v
                        ? void 0
                        : v.type) &&
                    "cgn-fixedalloc" in b.data &&
                    "cgn-client-startip" in b.data &&
                    b.data["cgn-client-startip"] &&
                    "cgn-client-endip" in b.data &&
                    b.data["cgn-client-endip"] &&
                    "enable" === b.data["cgn-fixedalloc"]
                  )
                    return {
                      name: `${b.data["cgn-client-startip"]} - ${b.data["cgn-client-endip"]}`,
                    };
                },
              },
              {
                label: this.translation.translate("Port Range"),
                descriptor: (b) => {
                  var v;
                  if (
                    "cgn-resource-allocation" ===
                      (null === (v = b.data) || void 0 === v
                        ? void 0
                        : v.type) &&
                    "cgn-port-start" in b.data &&
                    "cgn-port-end" in b.data &&
                    b.data["cgn-port-start"] &&
                    b.data["cgn-port-end"]
                  )
                    return {
                      name: `${b.data["cgn-port-start"]} - ${b.data["cgn-port-end"]}`,
                    };
                },
              },
              {
                label: this.translation.translate("External IPs in Use"),
                descriptor: (b) => {
                  var v, d;
                  const C = this.getStatsForEntry(b);
                  if (
                    "cgn-resource-allocation" ===
                      (null === (v = b.data) || void 0 === v
                        ? void 0
                        : v.type) &&
                    (null == C ? void 0 : C.data) &&
                    "npu_natip_in_use" in C.data &&
                    "number" ==
                      typeof (null === (d = null == C ? void 0 : C.data) ||
                      void 0 === d
                        ? void 0
                        : d.npu_natip_in_use) &&
                    null != (null == C ? void 0 : C.data.natip_total)
                  )
                    return {
                      name: `${C.data.npu_natip_in_use}/${C.data.natip_total}`,
                    };
                },
              },
              {
                label: this.translation.translate("Clients Online"),
                descriptor: (b) => {
                  var v, d;
                  const C = this.getStatsForEntry(b);
                  if (
                    "cgn-resource-allocation" ===
                      (null === (v = b.data) || void 0 === v
                        ? void 0
                        : v.type) &&
                    (null == C ? void 0 : C.data) &&
                    "npu_clients" in C.data &&
                    null !=
                      (null === (d = null == C ? void 0 : C.data) ||
                      void 0 === d
                        ? void 0
                        : d.npu_clients)
                  )
                    return { name: C.data.npu_clients.toString() };
                },
              },
              {
                label: this.translation.translate("Blocks Available (TCP)"),
                descriptor: (b) => {
                  var v;
                  if (
                    "cgn-resource-allocation" ===
                    (null === (v = b.data) || void 0 === v ? void 0 : v.type)
                  ) {
                    const d = this.getStatsForEntry(b),
                      C = null == d ? void 0 : d.data;
                    if (C && "npu_tcp_available" in C)
                      return this.availableFormatFunction({
                        available: C.npu_tcp_available,
                        used: C.npu_tcp_used,
                        total: C.npu_total,
                      });
                  }
                },
              },
              {
                label: this.translation.translate("Blocks Available (UDP)"),
                descriptor: (b) => {
                  var v;
                  if (
                    "cgn-resource-allocation" ===
                    (null === (v = b.data) || void 0 === v ? void 0 : v.type)
                  ) {
                    const d = this.getStatsForEntry(b),
                      C = null == d ? void 0 : d.data;
                    if (C && "npu_udp_available" in C)
                      return this.availableFormatFunction({
                        available: C.npu_udp_available,
                        used: C.npu_udp_used,
                        total: C.npu_total,
                      });
                  }
                },
              },
              this.tooltipFactory.createReferences(),
            ]));
        }
        get statsSource() {
          return (
            this._statsSource ||
              (this._statsSource = this.getAncillarySource(
                this.firewallIppoolStatisticsSourceFactoryService,
                this.variant,
              )),
            this._statsSource
          );
        }
        edit(A) {
          return (0, O.mG)(this, void 0, void 0, function* () {
            return this.slideBridge.ngEditOmniEntry(this, A);
          });
        }
        data(A) {
          const G = Object.create(null, { data: { get: () => super.data } });
          return (0, O.mG)(this, void 0, void 0, function* () {
            const R = yield G.data.call(this, A);
            return (yield this.statsSource.load(), R);
          });
        }
        availableFormatFunction(A) {
          if (A && null != A.available && null != A.used && null != A.total) {
            const G = this.translation.translate(
              "({COUNT}/{TOTAL} blocks used)",
              [A.used, A.total],
            );
            return {
              name: `${A.available.toFixed(2)}% ${G}`,
              icon: (null == A ? void 0 : A.available) < 10 ? S.$I : void 0,
            };
          }
        }
        getStatsForEntry(A) {
          return this.statsSource.getEntry(A[w.go]);
        }
        create() {
          return (0, O.mG)(this, void 0, void 0, function* () {
            const A = yield this.getEditUrl();
            return this.slideBridge.ngCreateOmniEntry(this, A);
          });
        }
      }
    },
    79056: (ne, U, c) => {
      c.d(U, { X: () => D });
      var O = c(29730),
        S = c(66776),
        w = c(39560);
      class D extends w.mT {
        getDescriptorValue() {
          return { name: this[O.go], icon: S.iRu };
        }
        nat46Enabled() {
          var f;
          return (
            "enable" ===
            (null === (f = this.data) || void 0 === f ? void 0 : f.nat46)
          );
        }
      }
    },
    57420: (ne, U, c) => {
      c.d(U, { J: () => x, wD: () => E, yr: () => f });
      var O = c(69051);
      const f = { icon: O.eQZ, classes: "nu-green-icon" },
        x = { icon: O.Mlz, classes: "nu-green-icon" },
        E = { icon: O.zBZ, classes: "nu-red-icon" };
    },
    74042: (ne, U, c) => {
      c.d(U, { m: () => p });
      var O = c(70655),
        S = c(40520),
        w = c(41833),
        D = c(29730),
        I = c(4707),
        f = c(14818),
        x = c(39300),
        E = c(63900),
        y = c(13099),
        _ = c(80188),
        A = c(82722),
        G = c(34782),
        R = c(49808),
        Z = c(83905),
        q = c(54004),
        W = c(17414),
        b = c(28091),
        v = c(30073),
        d = c(59145),
        C = c(52059);
      class p extends d.AX {
        constructor(M, $, Y, F) {
          (super(
            {
              path: "firewall",
              name: "policy",
              label: "firewall.policy",
              cmdbSourceDi: M,
              variant: Y,
              pool: F,
              EntryClass: C.j,
            },
            "/api/v2/monitor/firewall/policy",
            "/api/v2/monitor/firewall/policy/update-global-label",
          ),
            (this.ng1BridgeService = $),
            (this.ZTNA_POL_CLEAR_STATS_URL =
              "/api/v2/monitor/firewall/ztna-firewall-policy/clear-counters"),
            (this.idStatsRequestTriggerSubject = new I.t(1)),
            (this.idStatsRequestTrigger =
              this.idStatsRequestTriggerSubject.pipe(
                (0, f.e)(500),
                (0, x.h)((le) => le.length > 0),
                (0, E.w)((le) => this.getPolicyStatsPromise(new Set(le))),
                (0, y.B)(),
              )),
            (this.throttleStatsRequest = !1),
            (this.isHyperscalePolicy = (0, v.n)((0, _.D)(this.fortigate)).pipe(
              (0, A.R)(this.destroyedObservable),
              (0, G.d)({ refCount: !1, bufferSize: 1 }),
            )));
        }
        enablethrottleStatsRequest() {
          this.throttleStatsRequest || (this.throttleStatsRequest = !0);
        }
        processMissingReference(M) {
          if (this.providedEntryClass)
            return "0" === M[D.go]
              ? C.j.generateImplicitPolicy(this)
              : new this.EntryClass(M[D.go], void 0, this);
        }
        getPolicyStats(M, $) {
          const Y = Object.create(null, {
            getPolicyStats: { get: () => super.getPolicyStats },
          });
          return (0, O.mG)(this, void 0, void 0, function* () {
            if ($) return null;
            if (!this.policyStats[M] && this.throttleStatsRequest)
              try {
                yield this.getPolicyStatsWithThrottle(M);
              } catch (F) {
                return (
                  w.cM.error("Failed to fetch policy stats:"),
                  w.cM.error(F),
                  null
                );
              }
            return Y.getPolicyStats.call(this, M, $);
          });
        }
        getPolicyStatsPromise(M) {
          let $;
          if (M) {
            const Y = {
              body: { policyid: [...M] },
              headers: new S.WM({ "X-HTTP-Method-Override": b.rh.Get }),
            };
            $ = (0, R.n)(this.http.request(b.rh.Post, this.policyStatsUrl, Y));
          } else $ = (0, R.n)(this.http.get(this.policyStatsUrl));
          return (
            ($ = $.then((Y) => {
              for (const F of Y.results)
                this.policyStats[F.policyid] = this.getFormattedStat(F);
              return Y;
            })),
            $
          );
        }
        getPolicyStatsWithThrottle(M) {
          return (0, O.mG)(this, void 0, void 0, function* () {
            return (
              this.idStatsRequestTriggerSubject.next(M),
              (0, Z.z)(
                this.idStatsRequestTrigger.pipe(
                  (0, q.U)(() => this.getPolicyStatsSync(M)),
                  (0, x.h)(($) => null != $),
                  (0, W.V)(5e3),
                ),
              )
            );
          });
        }
        getEditUrl(M, $) {
          const Y = Object.create(null, {
            getEditUrl: { get: () => super.getEditUrl },
          });
          return (0, O.mG)(this, void 0, void 0, function* () {
            const F = yield Y.getEditUrl.call(this, M, $);
            return (yield (0, Z.z)(this.isHyperscalePolicy)) ? `/ng${F}` : F;
          });
        }
        openDialogInSlide(M = {}) {
          var $, Y, F, le, ge, de, Oe, he, Ee;
          return (0, O.mG)(this, void 0, void 0, function* () {
            if (yield (0, Z.z)(this.isHyperscalePolicy))
              return M.entry
                ? this.slideBridge.ngEditOmniEntry(this, M.entry, {
                    searchParams: M.searchParams,
                  })
                : this.slideBridge.ngCreateOmniEntry(
                    this,
                    yield this.getEditUrl(),
                    M.searchParams,
                  );
            const ke =
                null === ($ = M.entry) || void 0 === $ ? void 0 : $.implicit,
              be = ke
                ? yield Promise.all([c.e(63010), c.e(59835), c.e(1349)])
                    .then(c.bind(c, 93703))
                    .then(
                      ({ ImplicityFirewallPolicyDialogComponent: ce }) => ce,
                    )
                : yield Promise.all([
                    c.e(63010),
                    c.e(55209),
                    c.e(72014),
                    c.e(98456),
                    c.e(36038),
                    c.e(42289),
                    c.e(59835),
                    c.e(82869),
                    c.e(3910),
                  ])
                    .then(c.bind(c, 51402))
                    .then(({ FirewallPolicyDialogComponent: ce }) => ce),
              De = yield this.openDialogComponentInSlide({
                dialogComponent: be,
                routeParams: Object.assign(
                  Object.assign(
                    Object.assign(
                      { subType: "standard" },
                      null !==
                        (F =
                          null === (Y = M.entry) || void 0 === Y
                            ? void 0
                            : Y.data) &&
                        void 0 !== F &&
                        F.policyid
                        ? {
                            policyid:
                              null ===
                                (ge =
                                  null === (le = M.entry) || void 0 === le
                                    ? void 0
                                    : le.data) || void 0 === ge
                                ? void 0
                                : ge.policyid,
                          }
                        : {},
                    ),
                    null !== (de = M.routeParams) && void 0 !== de ? de : {},
                  ),
                  ke
                    ? {
                        type:
                          null ===
                            (he =
                              null === (Oe = M.entry) || void 0 === Oe
                                ? void 0
                                : Oe.data) || void 0 === he
                            ? void 0
                            : he.q_name,
                      }
                    : {},
                ),
                searchParams:
                  null !== (Ee = M.searchParams) && void 0 !== Ee ? Ee : {},
              });
            return null != De && De.new
              ? this.load({ keys: [De[D.go]] }).then((ce) => ce[0])
              : De;
          });
        }
        create() {
          return this.openDialogInSlide();
        }
        edit(M) {
          return this.openDialogInSlide({ entry: M });
        }
        destroy() {
          (this.destroyPolicyStats(),
            (this.sequenceGroupStats = void 0),
            super.destroy());
        }
        getWorkflowManagementSettings() {
          var M, $, Y;
          return (0, O.mG)(this, void 0, void 0, function* () {
            if (
              yield null === (M = this.selectedFortigate.subject.value) ||
              void 0 === M
                ? void 0
                : M.config.isNgfwPolicyMode()
            )
              return {
                changeSummaryEnforced: !1,
                changeSummaryConfig: "",
                defaultPolicyExpiryDays: 0,
              };
            if (
              !this._changeSummaryConfig ||
              null === this.defaultPolicyExpiryDate
            ) {
              const le = new S.LE().set(
                  "format",
                  "gui-enforce-change-summary|default-policy-expiry-days",
                ),
                ge = yield (0, R.n)(
                  this.http.request("GET", "/api/v2/cmdb/system/settings", {
                    params: le,
                  }),
                );
              ((this._changeSummaryConfig =
                ge.results["gui-enforce-change-summary"]),
                (this.defaultPolicyExpiryDate =
                  ge.results["default-policy-expiry-days"]));
            }
            return {
              changeSummaryEnforced:
                (yield (yield this.fortigate).feature.featureVisible(
                  "workflow_management",
                )) &&
                ["require", "optional"].some(
                  (le) => le === this._changeSummaryConfig,
                ),
              changeSummaryConfig:
                null !== ($ = this._changeSummaryConfig) && void 0 !== $
                  ? $
                  : "",
              defaultPolicyExpiryDays:
                null !== (Y = this.defaultPolicyExpiryDate) && void 0 !== Y
                  ? Y
                  : 0,
            };
          });
        }
        clearZtnaPolicyStatCounters(M) {
          return (0, O.mG)(this, void 0, void 0, function* () {
            (yield (0, R.n)(
              this.http.post(this.ZTNA_POL_CLEAR_STATS_URL, { policy: M }),
            ),
              this.updatePolicyStats());
          });
        }
        openChangeSummaryDialog(M, $, Y) {
          return (0, O.mG)(this, void 0, void 0, function* () {
            return this.slideBridge.openChangeSummaryDialog(M, $, Y);
          });
        }
        notifyAngularJsSourceChange() {
          this.ng1BridgeService.notifyOmniSourceChangedSubject.next(
            "firewall.policy",
          );
        }
        getTargetGroupPolicyInfo(M, $) {
          return (0, O.mG)(this, void 0, void 0, function* () {
            let Y;
            return (
              M && (Y = this.generateGroupLabelMutableFilters(M)),
              (yield this.getByFormat(["policyid", "global-label"], Y, $)).map(
                (le) => {
                  var ge, de, Oe, he;
                  return {
                    policyid:
                      null !==
                        (de =
                          null === (ge = le.data) || void 0 === ge
                            ? void 0
                            : ge.policyid) && void 0 !== de
                        ? de
                        : -1,
                    "global-label":
                      null !==
                        (he =
                          null === (Oe = le.data) || void 0 === Oe
                            ? void 0
                            : Oe["global-label"]) && void 0 !== he
                        ? he
                        : "",
                  };
                },
              )
            );
          });
        }
        getPolicyGroupLabelInfo(M, $, Y) {
          return (0, O.mG)(this, void 0, void 0, function* () {
            let F;
            $ && (F = this.generateGroupLabelMutableFilters($));
            const le = "global-label",
              ge = yield this.getStatsWithPrimaryKey(String(M), le, F, Y),
              de = this.parseSequenceGroupLabelInfo(M, ge.columnStats.get(le));
            return de.valid ? de : void 0;
          });
        }
        shouldTableStatsBeLoadedInParallel(M) {
          return this.shouldTableStatsBeLoadedInParallelHelper(M);
        }
      }
    },
    60277: (ne, U, c) => {
      (c.r(U), c.d(U, { ProxyPolicyOmniSourceFactoryService: () => f }));
      var O = c(29730),
        S = c(28667),
        w = c(5e3),
        D = c(32422),
        I = c(80580);
      let f = (() => {
        class x extends O.Dp {
          constructor(y, _) {
            (super(),
              (this.cmdbSourceDi = y),
              (this.ng1BridgeService = _),
              (this.OmniSourceClass = S.x));
          }
          createSource(y, _) {
            return new S.x(this.cmdbSourceDi, this.ng1BridgeService, y, _);
          }
        }
        return (
          (x.ɵfac = function (y) {
            return new (y || x)(w.LFG(D.y), w.LFG(I.Ng1BridgeService));
          }),
          (x.ɵprov = w.Yz7({ token: x, factory: x.ɵfac, providedIn: "root" })),
          x
        );
      })();
    },
    28667: (ne, U, c) => {
      c.d(U, { x: () => D });
      var O = c(29730),
        S = c(59145),
        w = c(90245);
      class D extends S.K {
        constructor(f, x, E, y) {
          (super(
            {
              path: "firewall",
              name: "proxy-policy",
              label: "firewall.proxy-policy",
              cmdbSourceDi: f,
              variant: E,
              pool: y,
              EntryClass: w.k,
            },
            "/api/v2/monitor/firewall/proxy-policy",
          ),
            (this.ng1BridgeService = x));
        }
        notifyAngularJsSourceChange() {
          this.ng1BridgeService.notifyOmniSourceChangedSubject.next(
            "firewall.proxy-policy",
          );
        }
        processMissingReference(f) {
          if (this.providedEntryClass)
            return "0" === f[O.go]
              ? w.k.generateImplicitPolicy(this)
              : new this.EntryClass(f[O.go], void 0, this);
        }
      }
    },
    40300: (ne, U, c) => {
      c.d(U, { u: () => I });
      var O = c(70655),
        S = c(29730),
        w = c(59145),
        D = c(39556);
      class I extends w.AX {
        constructor(x, E, y, _) {
          (super(
            {
              path: "firewall",
              name: "security-policy",
              label: "firewall.security-policy",
              cmdbSourceDi: x,
              variant: y,
              pool: _,
              EntryClass: D.P,
            },
            "/api/v2/monitor/firewall/security-policy",
            "/api/v2/monitor/firewall/security-policy/update-global-label",
          ),
            (this.ng1BridgeService = E));
        }
        openDialogInSlide(x = {}) {
          var E, y, _, A, G, R, Z, q, W;
          return (0, O.mG)(this, void 0, void 0, function* () {
            const b =
                null === (E = x.entry) || void 0 === E ? void 0 : E.implicit,
              v = b
                ? yield Promise.all([c.e(63010), c.e(59835), c.e(1349)])
                    .then(c.bind(c, 93703))
                    .then(({ ImplicityFirewallPolicyDialogComponent: C }) => C)
                : yield Promise.all([
                    c.e(63010),
                    c.e(55209),
                    c.e(72014),
                    c.e(98456),
                    c.e(36038),
                    c.e(42289),
                    c.e(59835),
                    c.e(82869),
                    c.e(63938),
                    c.e(68592),
                  ])
                    .then(c.bind(c, 85666))
                    .then(({ SecurityPolicyDialogComponent: C }) => C),
              d = yield this.openDialogComponentInSlide({
                dialogComponent: v,
                routeParams: Object.assign(
                  Object.assign(
                    Object.assign(
                      { subType: "standard" },
                      null !==
                        (_ =
                          null === (y = x.entry) || void 0 === y
                            ? void 0
                            : y.data) &&
                        void 0 !== _ &&
                        _.policyid
                        ? {
                            policyid:
                              null ===
                                (G =
                                  null === (A = x.entry) || void 0 === A
                                    ? void 0
                                    : A.data) || void 0 === G
                                ? void 0
                                : G.policyid,
                          }
                        : {},
                    ),
                    null !== (R = x.routeParams) && void 0 !== R ? R : {},
                  ),
                  b
                    ? {
                        type:
                          null ===
                            (q =
                              null === (Z = x.entry) || void 0 === Z
                                ? void 0
                                : Z.data) || void 0 === q
                            ? void 0
                            : q.q_name,
                      }
                    : {},
                ),
                searchParams:
                  null !== (W = x.searchParams) && void 0 !== W ? W : {},
              });
            return null != d && d.new
              ? this.load({ keys: [d[S.go]] }).then((C) => C[0])
              : d;
          });
        }
        create() {
          return this.openDialogInSlide();
        }
        edit(x) {
          return this.openDialogInSlide({ entry: x });
        }
        destroy() {
          (this.destroyPolicyStats(), super.destroy());
        }
        notifyAngularJsSourceChange() {
          this.ng1BridgeService.notifyOmniSourceChangedSubject.next(
            "firewall.security",
          );
        }
        getTargetGroupPolicyInfo(x, E) {
          return (0, O.mG)(this, void 0, void 0, function* () {
            let y;
            return (
              x && (y = this.generateGroupLabelMutableFilters(x)),
              (yield this.getByFormat(["policyid", "global-label"], y, E)).map(
                (A) => {
                  var G, R, Z, q;
                  return {
                    policyid:
                      null !==
                        (R =
                          null === (G = A.data) || void 0 === G
                            ? void 0
                            : G.policyid) && void 0 !== R
                        ? R
                        : -1,
                    "global-label":
                      null !==
                        (q =
                          null === (Z = A.data) || void 0 === Z
                            ? void 0
                            : Z["global-label"]) && void 0 !== q
                        ? q
                        : "",
                  };
                },
              )
            );
          });
        }
        getPolicyGroupLabelInfo(x, E, y) {
          return (0, O.mG)(this, void 0, void 0, function* () {
            let _;
            E && (_ = this.generateGroupLabelMutableFilters(E));
            const A = "global-label",
              G = yield this.getStatsWithPrimaryKey(String(x), A, _, y),
              R = this.parseSequenceGroupLabelInfo(x, G.columnStats.get(A));
            return R.valid ? R : void 0;
          });
        }
        shouldTableStatsBeLoadedInParallel(x) {
          return this.shouldTableStatsBeLoadedInParallelHelper(x);
        }
        processMissingReference(x) {
          if (this.providedEntryClass)
            return "0" === x[S.go]
              ? D.P.generateImplicitPolicy(this)
              : new this.EntryClass(x[S.go], void 0, this);
        }
      }
    },
    49824: (ne, U, c) => {
      c.d(U, { v: () => f });
      var O = c(20956),
        S = c(73116);
      class w extends S.v {
        constructor(E, y) {
          super({
            path: "log",
            name: "setting",
            label: "logsetting",
            cmdbSourceDi: E,
            variant: y,
          });
        }
      }
      var D = c(5e3),
        I = c(32422);
      let f = (() => {
        class x extends O.u {
          constructor(y) {
            (super(), (this.cmdbSourceDi = y), (this.OmniSourceClass = w));
          }
          createSource(y) {
            return new w(this.cmdbSourceDi, y);
          }
        }
        return (
          (x.ɵfac = function (y) {
            return new (y || x)(D.LFG(I.y));
          }),
          (x.ɵprov = D.Yz7({ token: x, factory: x.ɵfac, providedIn: "root" })),
          x
        );
      })();
    },
    75522: (ne, U, c) => {
      c.d(U, { Z: () => I });
      var O = c(20956),
        S = c(94885),
        w = c(5e3),
        D = c(32422);
      let I = (() => {
        class f extends O.u {
          constructor(E) {
            (super(), (this.cmdbSourceDi = E));
          }
          createSource(E) {
            return new S.o(this.cmdbSourceDi, E);
          }
        }
        return (
          (f.ɵfac = function (E) {
            return new (E || f)(w.LFG(D.y));
          }),
          (f.ɵprov = w.Yz7({ token: f, factory: f.ɵfac, providedIn: "root" })),
          f
        );
      })();
    },
    94885: (ne, U, c) => {
      c.d(U, { o: () => S });
      var O = c(73116);
      class S extends O.v {
        constructor(D, I) {
          super({
            path: "system",
            name: "global",
            label: "Global",
            cmdbSourceDi: D,
            variant: I,
          });
        }
        get supportExplicitProxy() {
          return (
            !("proxy-and-explicit-proxy" in this.data) ||
            "disable" !== this.data["proxy-and-explicit-proxy"]
          );
        }
      }
    },
    80161: (ne, U, c) => {
      c.d(U, { T: () => f });
      var O = c(20956),
        S = c(73116);
      class w extends S.v {
        constructor(E, y) {
          super({
            path: "system",
            name: "settings",
            label: "system.settings",
            cmdbSourceDi: E,
            variant: y,
          });
        }
      }
      var D = c(5e3),
        I = c(32422);
      let f = (() => {
        class x extends O.u {
          constructor(y) {
            (super(), (this.cmdbSourceDi = y), (this.OmniSourceClass = w));
          }
          createSource(y) {
            return new w(this.cmdbSourceDi, y);
          }
        }
        return (
          (x.ɵfac = function (y) {
            return new (y || x)(D.LFG(I.y));
          }),
          (x.ɵprov = D.Yz7({ token: x, factory: x.ɵfac, providedIn: "root" })),
          x
        );
      })();
    },
    84435: (ne, U, c) => {
      (c.r(U), c.d(U, { UserLdapOmniSourceFactoryService: () => I }));
      var O = c(29730),
        S = c(67198),
        w = c(5e3),
        D = c(32422);
      let I = (() => {
        class f extends O.Dp {
          constructor(E) {
            (super(), (this.cmdbSourceDi = E), (this.OmniSourceClass = S.eg));
          }
          createSource(E, y) {
            return new S.eg(this.cmdbSourceDi, E, y);
          }
        }
        return (
          (f.ɵfac = function (E) {
            return new (E || f)(w.LFG(D.y));
          }),
          (f.ɵprov = w.Yz7({ token: f, factory: f.ɵfac, providedIn: "root" })),
          f
        );
      })();
    },
    67198: (ne, U, c) => {
      c.d(U, { NJ: () => E, eg: () => x });
      var O = c(29730),
        S = c(66776),
        w = c(27975),
        D = c(87428),
        I = c(39560);
      class f extends I.mT {
        getDescriptorValue() {
          return { name: this[O.go], icon: S.TDI };
        }
      }
      class x extends D.WF {
        constructor(_, A, G) {
          (super({
            path: "user",
            name: "ldap",
            label: "user.ldap",
            cmdbSourceDi: _,
            variant: A,
            pool: G,
            EntryClass: f,
          }),
            (this.tooltipProperties = [
              {
                label: this.translation.translate("Server IP/Name"),
                descriptor: (R) => {
                  var Z;
                  return (
                    R.data && {
                      name:
                        (null === (Z = R.data) || void 0 === Z
                          ? void 0
                          : Z.server) || "",
                    }
                  );
                },
              },
              {
                label: this.translation.translate("Server Port"),
                descriptor: (R) => {
                  var Z;
                  return (
                    R.data && {
                      name: String(
                        null === (Z = R.data) || void 0 === Z ? void 0 : Z.port,
                      ),
                    }
                  );
                },
              },
              {
                label: this.translation.translate("Common Name Identifier"),
                descriptor: (R) => {
                  var Z;
                  return (
                    R.data && {
                      name:
                        (null === (Z = R.data) || void 0 === Z
                          ? void 0
                          : Z.cnid) || "",
                    }
                  );
                },
              },
              {
                label: this.translation.translate("dn"),
                descriptor: (R) => {
                  var Z;
                  return (
                    R.data && {
                      name:
                        (null === (Z = R.data) || void 0 === Z
                          ? void 0
                          : Z.dn) || "",
                    }
                  );
                },
              },
              {
                label: this.translation.translate("Bind Type"),
                descriptor: (R) => {
                  var Z;
                  return (
                    R.data && {
                      name: this.translation.translate(
                        `LdapServer::bind-type.${null === (Z = R.data) || void 0 === Z ? void 0 : Z.type}`,
                      ),
                    }
                  );
                },
              },
              this.tooltipFactory.createReferences(),
            ]));
        }
      }
      class E extends w.L {}
    },
    30365: (ne, U, c) => {
      (c.r(U), c.d(U, { UserLocalOmniSourceFactoryService: () => I }));
      var O = c(29730),
        S = c(35320),
        w = c(5e3),
        D = c(32422);
      let I = (() => {
        class f extends O.Dp {
          constructor(E) {
            (super(), (this.cmdbSourceDi = E), (this.OmniSourceClass = S.i4));
          }
          createSource(E, y) {
            return new S.i4(this.cmdbSourceDi, E, y);
          }
        }
        return (
          (f.ɵfac = function (E) {
            return new (E || f)(w.LFG(D.y));
          }),
          (f.ɵprov = w.Yz7({ token: f, factory: f.ɵfac, providedIn: "root" })),
          f
        );
      })();
    },
    72815: (ne, U, c) => {
      (c.r(U), c.d(U, { WebFilterProfileOmniSourceFactoryService: () => b }));
      var O = c(29730),
        S = c(88776),
        w = c(5e3),
        D = c(64717),
        I = c(32422),
        f = c(87428);
      c(39560);
      class y extends f.WF {
        constructor(d, C, p) {
          super({
            path: "webfilter",
            name: "content",
            label: "webfilter.content",
            cmdbSourceDi: d,
            variant: C,
            pool: p,
          });
        }
      }
      let _ = (() => {
        class v extends O.Dp {
          constructor(C) {
            (super(), (this.cmdbSourceDi = C), (this.OmniSourceClass = y));
          }
          createSource(C, p) {
            return new y(this.cmdbSourceDi, C, p);
          }
        }
        return (
          (v.ɵfac = function (C) {
            return new (C || v)(w.LFG(I.y));
          }),
          (v.ɵprov = w.Yz7({ token: v, factory: v.ɵfac, providedIn: "root" })),
          v
        );
      })();
      class G extends f.WF {
        constructor(d, C, p) {
          super({
            path: "webfilter",
            name: "urlfilter",
            label: "webfilter.urlfilter",
            cmdbSourceDi: d,
            variant: C,
            pool: p,
          });
        }
      }
      let R = (() => {
        class v extends O.Dp {
          constructor(C) {
            (super(), (this.cmdbSourceDi = C), (this.OmniSourceClass = G));
          }
          createSource(C, p) {
            return new G(this.cmdbSourceDi, C, p);
          }
        }
        return (
          (v.ɵfac = function (C) {
            return new (C || v)(w.LFG(I.y));
          }),
          (v.ɵprov = w.Yz7({ token: v, factory: v.ɵfac, providedIn: "root" })),
          v
        );
      })();
      class q extends f.WF {
        constructor(d, C, p) {
          super({
            path: "web-proxy",
            name: "profile",
            label: "web-proxy.profile",
            cmdbSourceDi: d,
            variant: C,
            pool: p,
          });
        }
      }
      let W = (() => {
          class v extends O.Dp {
            constructor(C) {
              (super(), (this.cmdbSourceDi = C), (this.OmniSourceClass = q));
            }
            createSource(C, p) {
              return new q(this.cmdbSourceDi, C, p);
            }
          }
          return (
            (v.ɵfac = function (C) {
              return new (C || v)(w.LFG(I.y));
            }),
            (v.ɵprov = w.Yz7({
              token: v,
              factory: v.ɵfac,
              providedIn: "root",
            })),
            v
          );
        })(),
        b = (() => {
          class v extends O.Dp {
            constructor(C, p, z, M, $) {
              (super(),
                (this.licenseService = C),
                (this.cmdbSourceDi = p),
                (this.contentfilterSourceFactory = z),
                (this.urlFilterSourceFactory = M),
                (this.webfilterProxyOptionSourceFactory = $),
                (this.OmniSourceClass = S._f));
            }
            createSource(C, p) {
              return new S._f(
                this.licenseService,
                this.contentfilterSourceFactory,
                this.urlFilterSourceFactory,
                this.webfilterProxyOptionSourceFactory,
                this.cmdbSourceDi,
                C,
                p,
              );
            }
          }
          return (
            (v.ɵfac = function (C) {
              return new (C || v)(
                w.LFG(D.LicenseService),
                w.LFG(I.y),
                w.LFG(_),
                w.LFG(R),
                w.LFG(W),
              );
            }),
            (v.ɵprov = w.Yz7({
              token: v,
              factory: v.ɵfac,
              providedIn: "root",
            })),
            v
          );
        })();
    },
    81242: (ne, U, c) => {
      (c.r(U), c.d(U, { WebfilterFtgdCatSourceFactoryService: () => v }));
      var O = c(29730),
        S = c(79177),
        w = c(5e3),
        D = c(32422),
        I = c(70655),
        f = c(40520),
        x = c(41833),
        E = c(49808),
        y = c(24934),
        _ = c(71748),
        A = c(87428),
        G = c(39560);
      class R extends G.mT {
        constructor() {
          (super(...arguments),
            (this.q_origin_key = Number(this.data.categoryid)));
        }
      }
      const q =
        "Downloading web filter categories failed, FortiGuard returned unexpected data format.";
      class W extends A.WF {
        constructor(C, p, z) {
          super({
            label: "FortiGuard Web Filter Category Information",
            noCmdbPath: !0,
            cmdbSourceDi: C,
            variant: p,
            pool: z,
            EntryClass: R,
          });
        }
        data(C) {
          return (0, I.mG)(this, void 0, void 0, function* () {
            let p;
            p = C.variant instanceof _.C ? new y.C(C.variant) : new f.LE();
            try {
              const z = yield (0, E.n)(
                this.http.get("/api/v2/monitor/fortiguard/wf-categories", {
                  params: p,
                }),
              );
              return z instanceof Array && z.length
                ? z.map((M) => new R(M.categoryid, M, this))
                : (x.cM.error(q), []);
            } catch (z) {
              return (x.cM.error(q), []);
            }
          });
        }
      }
      let b = (() => {
          class d extends O.Dp {
            constructor(p) {
              (super(), (this.cmdbSourceDi = p), (this.OmniSourceClass = W));
            }
            createSource(p, z) {
              return new W(this.cmdbSourceDi, p, z);
            }
          }
          return (
            (d.ɵfac = function (p) {
              return new (p || d)(w.LFG(D.y));
            }),
            (d.ɵprov = w.Yz7({
              token: d,
              factory: d.ɵfac,
              providedIn: "root",
            })),
            d
          );
        })(),
        v = (() => {
          class d extends O.Dp {
            constructor(p, z) {
              (super(),
                (this.cmdbSourceDi = p),
                (this.fortiguardWebfilterCategoriesSourceFactoryService = z),
                (this.OmniSourceClass = S.h));
            }
            createSource(p, z) {
              return new S.h(
                this.cmdbSourceDi,
                this.fortiguardWebfilterCategoriesSourceFactoryService,
                p,
                z,
              );
            }
          }
          return (
            (d.ɵfac = function (p) {
              return new (p || d)(w.LFG(D.y), w.LFG(b));
            }),
            (d.ɵprov = w.Yz7({
              token: d,
              factory: d.ɵfac,
              providedIn: "root",
            })),
            d
          );
        })();
    },
    94040: (ne, U, c) => {
      (c.r(U), c.d(U, { WebfilterFtgdLocalCatSourceFactoryService: () => I }));
      var O = c(29730),
        S = c(85643),
        w = c(5e3),
        D = c(32422);
      let I = (() => {
        class f extends O.Dp {
          constructor(E) {
            (super(), (this.cmdbSourceDi = E), (this.OmniSourceClass = S.k));
          }
          createSource(E, y) {
            return new S.k(this.cmdbSourceDi, E, y);
          }
        }
        return (
          (f.ɵfac = function (E) {
            return new (E || f)(w.LFG(D.y));
          }),
          (f.ɵprov = w.Yz7({ token: f, factory: f.ɵfac, providedIn: "root" })),
          f
        );
      })();
    },
    62469: (ne, U, c) => {
      c.d(U, { C: () => I });
      var O = c(93075),
        S = c(57892),
        w = c(18419),
        D = c(5e3);
      let I = (() => {
        class f {}
        return (
          (f.ɵfac = function (E) {
            return new (E || f)();
          }),
          (f.ɵmod = D.oAB({ type: f })),
          (f.ɵinj = D.cJS({ imports: [S.jK, O.UX, O.u5, w.rw] })),
          f
        );
      })();
    },
    43069: (ne, U, c) => {
      c.d(U, { b: () => I, i: () => f });
      var O = c(93075),
        S = c(41833),
        w = c(5e3);
      const D = "fosPatterns",
        I = (x) => {
          return (
            x instanceof RegExp
              ? (x = { [D]: [x] })
              : Array.isArray(x) && (x = { [D]: x }),
            (y) => {
              if (!y.value) return null;
              for (const [_, A] of Object.entries(x))
                if (!A.some((G) => E(G, y.value))) return { [_]: !0 };
              return null;
            }
          );
          function E(y, _) {
            return y.test(_);
          }
        };
      let f = (() => {
        class x {
          validate(y) {
            return this.patterns
              ? I(this.patterns)(y)
              : (S.cM.error("Missing `patterns` for `fosPatterns` validator."),
                null);
          }
        }
        return (
          (x.ɵfac = function (y) {
            return new (y || x)();
          }),
          (x.ɵdir = w.lG2({
            type: x,
            selectors: [["", "fosPatterns", ""]],
            inputs: { patterns: ["fosPatterns", "patterns"] },
            features: [w._Bn([{ provide: O.Cf, useExisting: x, multi: !0 }])],
          })),
          x
        );
      })();
    },
    64065: (ne, U, c) => {
      c.d(U, { t: () => O });
      const O = (S, w) => (D) => {
        let I;
        return (
          (I = "function" == typeof S ? S() : S),
          "function" != typeof w &&
            (w = (f, x) => "string" == typeof x && f.has(x)),
          w(I, D.value) ? { fosNameUnique: !0 } : null
        );
      };
    },
  },
]);
