(self.webpackChunkFOS_LIB = self.webpackChunkFOS_LIB || []).push([
  [5398],
  {
    80973: (module, exports, __webpack_require__) => {
      "use strict";
      var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;
      (__WEBPACK_AMD_DEFINE_ARRAY__ = [
        __webpack_require__(19755),
        __webpack_require__(58718),
        __webpack_require__(95829),
        __webpack_require__(48858),
      ]),
        void 0 ===
          (__WEBPACK_AMD_DEFINE_RESULT__ = function (
            $,
            Notify,
            location,
            inject
          ) {
            class RouteListMenu extends inject.Collectable {
              $onInit($INJECTABLE$, state) {
                return () => {
                  this.state = state;
                };
              }
              getRoute($INJECTABLE$, ftntRoute) {
                return (version, action) => {
                  const params = {
                    type: this.type + (6 === version ? "6" : ""),
                    action,
                  };
                  return ftntRoute.interpolate(
                    "/ng/routing/:type/:action/",
                    params
                  );
                };
              }
              newRoute($INJECTABLE$, $location) {
                return function (ver) {
                  const url = this.getRoute(ver, "edit");
                  $location.path(url);
                };
              }
              editFn($INJECTABLE$, $location) {
                return function () {
                  const route = this.menu.lastSelectedEntry,
                    url =
                      this.getRoute(this.getIpVersion(route), "edit") +
                      route.q_origin_key;
                  $location.path(url);
                };
              }
              clone($INJECTABLE$, $location) {
                return function () {
                  const route = this.menu.lastSelectedEntry,
                    url =
                      this.getRoute(this.getIpVersion(route), "edit") +
                      route.q_origin_key;
                  $location.path(url).search({ clone: "true" });
                };
              }
              statusToggleEnabled(targetStatus) {
                return this.menu.entries.some(
                  (entry) => entry.status !== targetStatus
                );
              }
              setRouteStatus($INJECTABLE$, $q) {
                return (status) => {
                  const that = this;
                  let promise;
                  this.menu.entries &&
                    this.menu.entries.length &&
                    ((promise = (function () {
                      const promises = that.menu.rowInstances
                        .filter(
                          (row) => row.entry && row.entry.status !== status
                        )
                        .map(
                          (row) => (
                            (row.entry.status = status),
                            row.updateEntry({ status }),
                            row.entry.$save().$promise
                          )
                        );
                      return $q.all(promises);
                    })()),
                    promise.then(
                      () => {
                        Notify.post(
                          $.getInfo("changes_saved"),
                          Notify.LEVEL.SUCCESS
                        );
                      },
                      (error) => {
                        Notify.post(
                          $.getInfo(error.message),
                          Notify.LEVEL.ERROR
                        );
                      }
                    ));
                };
              }
              getIpVersion(route) {
                let qName = route.q_name;
                return "6" === qName[qName.length - 1] ? 6 : 4;
              }
            }
            (RouteListMenu.prototype.$onInit.$inject = [
              "$INJECTABLE$",
              "state",
            ]),
              (RouteListMenu.prototype.getRoute.$inject = [
                "$INJECTABLE$",
                "ftntRoute",
              ]),
              (RouteListMenu.prototype.newRoute.$inject = [
                "$INJECTABLE$",
                "$location",
              ]),
              (RouteListMenu.prototype.editFn.$inject = [
                "$INJECTABLE$",
                "$location",
              ]),
              (RouteListMenu.prototype.clone.$inject = [
                "$INJECTABLE$",
                "$location",
              ]),
              (RouteListMenu.prototype.setRouteStatus.$inject = [
                "$INJECTABLE$",
                "$q",
              ]);
            var fRouteListMenu = {
              bindings: { type: "@", menu: "=" },
              controller: RouteListMenu,
              templateUrl: __webpack_require__(44042),
            };
            return (providers) => {
              providers.$compile.component("fRouteListMenu", fRouteListMenu);
            };
          }.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) ||
          (module.exports = __WEBPACK_AMD_DEFINE_RESULT__);
    },
    85398: (module, exports, __webpack_require__) => {
      "use strict";
      var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;
      (__WEBPACK_AMD_DEFINE_ARRAY__ = [
        __webpack_require__(66695),
        __webpack_require__(48858),
        __webpack_require__(6649),
        __webpack_require__(31326),
        __webpack_require__(6117),
      ]),
        void 0 ===
          (__WEBPACK_AMD_DEFINE_RESULT__ = function (
            angular,
            inject,
            fdom,
            fip,
            Tooltip
          ) {
            class StaticRouteList extends inject.Collectable {
              $onInit($INJECTABLE$, state) {
                return () => {
                  (this.isTpMode =
                    state.getOperationMode() ===
                    state.OPERATION_MODE.TRANSPARENT),
                    (this.ipv6Enabled = state.featureEnabled("gui-ipv6")),
                    (this.muTable = {
                      source: this.getSource(),
                      settings: this.getMutableSettings(),
                    });
                };
              }
              processEntry($INJECTABLE$, lang, $q, $http) {
                return (ipv4, intfMap, ipsecMap) => (entries) => {
                  const promises = [],
                    promiseMap = new Map();
                  return (
                    (entries || []).forEach((entry) => {
                      let promise;
                      if (
                        ((entry.type = lang(ipv4 ? "ipv4" : "ipv6").toString()),
                        (entry.ipVersion = ipv4 ? 4 : 6),
                        entry["sdwan-zone"] && entry["sdwan-zone"].length > 0)
                      )
                        entry.$intf = null;
                      else {
                        if (
                          entry.device &&
                          ((entry.$intf = Object.assign(
                            {},
                            intfMap[entry.device.name],
                            { datasource: "firewallInterfaces" }
                          )),
                          entry.$intf.is_tunnel &&
                            !entry.$intf.is_ipsec_aggregate)
                        ) {
                          const ipsecEntry = ipsecMap[entry.$intf.q_origin_key];
                          ipsecEntry &&
                            (entry.tunnelid =
                              ipsecEntry[ipv4 ? "tun_id" : "tun_id6"]);
                        }
                        if ("enable" === entry["dynamic-gateway"]) {
                          const intfName = entry.device && entry.device.name;
                          intfName &&
                            (promiseMap.has(intfName)
                              ? (promise = promiseMap.get(intfName))
                              : ((promise = $http
                                  .get(
                                    "/api/v2/monitor/system/interface/dhcp-status",
                                    { params: { mkey: intfName } }
                                  )
                                  .catch(angular.noop)),
                                promiseMap.set(intfName, promise)),
                            (promise = promise.then((dhcpResult) => {
                              if (
                                dhcpResult &&
                                dhcpResult.data &&
                                dhcpResult.data.results
                              ) {
                                const dynamicInfo = dhcpResult.data.results;
                                "status_succ" === dynamicInfo.status &&
                                  dynamicInfo.dynamic_gateway &&
                                  (entry.$dynamicGatewayAddr =
                                    dynamicInfo.dynamic_gateway);
                              }
                            })),
                            promises.push(promise));
                        }
                      }
                    }),
                    $q.all(promises).then(() => entries)
                  );
                };
              }
              getSource($INJECTABLE$, CMDB, $q, Omniselect, $http) {
                return () => {
                  const routeList = this,
                    cmdbParams = { prune: !0, datasource: 1, with_meta: !0 };
                  return $q
                    .all([
                      Omniselect.getSourceData("firewallInterfaces"),
                      $http
                        .get("/api/v2/monitor/vpn/ipsec")
                        .catch(() => ({ data: { results: [] } }))
                        .then((res) =>
                          res.data.results.reduce(
                            (prev, tunnel) => (
                              (prev[tunnel.name] = tunnel), prev
                            ),
                            {}
                          )
                        ),
                    ])
                    .then(function ([intfs, ipsec]) {
                      const promises = [],
                        intfMap = intfs.mapping;
                      promises.push(
                        new CMDB("router", "static", cmdbParams)
                          .fetch()
                          .$promise.then(
                            routeList.processEntry(!0, intfMap, ipsec)
                          )
                      ),
                        routeList.ipv6Enabled &&
                          promises.push(
                            new CMDB("router", "static6", cmdbParams)
                              .fetch()
                              .$promise.then(
                                routeList.processEntry(!1, intfMap, ipsec)
                              )
                          );
                      return $q.all(promises).then((resp) => {
                        const allRoutes = resp.reduce(
                          (result, data) =>
                            data ? result.concat(data) : result,
                          []
                        );
                        return allRoutes.filter(
                          (route) =>
                            !(
                              route &&
                              route.comment &&
                              typeof route.comment === "string" &&
                              route.comment.startsWith("T-")
                            )
                        );
                      });
                    });
                };
              }
              getMutableSettings($INJECTABLE$, lang, state, staticRouteUtils) {
                return () => {
                  const advancedRoutingEnabled = state.featureEnabled(
                    "gui-dynamic-routing"
                  );
                  return {
                    defaultColumns: [
                      "dst",
                      "gateway",
                      "$intf",
                      "status",
                      "comment",
                    ],
                    columns: [
                      {
                        id: "status",
                        cellValueFunction: (entry) =>
                          lang(
                            { enable: "enabled", disable: "disabled" }[
                              entry.status
                            ]
                          ).toString(),
                        cellFormatter: (entry, column, value) => {
                          const iconClass =
                            "enable" === entry[column.id]
                              ? "fa-enabled"
                              : "fa-disabled";
                          return fdom.elem("div", null, {
                            children: [
                              fdom.elem("f-icon", { className: iconClass }),
                              fdom.elem("span", { textContent: value }),
                            ],
                          });
                        },
                      },
                      {
                        id: "dst",
                        langKey: "destination",
                        type: "omniselect",
                        omniselectAllowFallback: !0,
                        collectionFallbackValueFunction: (entry) =>
                          4 === entry.ipVersion
                            ? fip.IpMask.parse(entry.dst).fullNetwork()
                            : entry.dst,
                        cellIsValidCollectionFunction: (entry) =>
                          (entry["internet-service"] &&
                            entry["internet-service"].id) ||
                          (entry["internet-service-custom"] &&
                            entry["internet-service-custom"].name) ||
                          (entry.dstaddr && entry.dstaddr.name),
                        cellValueFunction: (entry) =>
                          entry["internet-service"] &&
                          entry["internet-service"].id
                            ? entry["internet-service"]
                            : entry["internet-service-custom"] &&
                              entry["internet-service-custom"].name
                            ? entry["internet-service-custom"]
                            : entry.dstaddr && entry.dstaddr.name
                            ? entry.dstaddr
                            : entry.dst,
                      },
                      {
                        id: "gateway",
                        cellValueFunction: (entry) =>
                          "enable" === entry["dynamic-gateway"]
                            ? `${lang("Dynamic Gateway")} (${
                                entry.$dynamicGatewayAddr || lang("unknown")
                              })`
                            : "enable" === entry.blackhole ||
                              (entry["sdwan-zone"] &&
                                entry["sdwan-zone"].length > 0) ||
                              (entry.$intf &&
                                (entry.$intf.is_ipsec_aggregate ||
                                  entry.$intf.is_tunnel))
                            ? void 0
                            : entry.gateway,
                        cellFormatter: (entry, column, value) => {
                          if (this._isGatewayUnreachable(entry)) {
                            const iconClass = "fa-info-circle";
                            return fdom.elem("div", null, {
                              children: [
                                fdom.elem("f-icon", { className: iconClass }),
                                fdom.elem("span", { textContent: value }),
                              ],
                            });
                          }
                          return value;
                        },
                        onCellRendered: (cell, entry) => {
                          if (this._isGatewayUnreachable(entry)) {
                            const wanAddresses = [],
                              isIpv6 = "static6" === entry.$cmdb.name;
                            staticRouteUtils
                              .interfaceAddresses(entry.$intf, isIpv6)
                              .forEach((address) => {
                                let listContent = `${address.ip}/${address.cidr_netmask}`;
                                wanAddresses.push(
                                  fdom.elem("li", { textContent: listContent })
                                );
                              });
                            const content = fdom.elem("div", null, {
                                children: [
                                  fdom.elem("f-icon", {
                                    className: "fa-info-circle",
                                  }),
                                  fdom.elem("span", {
                                    textContent: lang(
                                      "Gateway IP {IP} could be unreachable. It is not in any subnet of the interface {INTERFACE}:",
                                      [entry.gateway, entry.$intf.name]
                                    ),
                                  }),
                                  fdom.elem("ul", null, {
                                    children: wanAddresses,
                                  }),
                                ],
                              }),
                              tooltip = Tooltip.addToElement(cell, content);
                            return cell.classList.add("tooltip-hint"), tooltip;
                          }
                        },
                      },
                      {
                        id: "$intf",
                        langKey: "Interface",
                        type: "omniselect",
                        hidden: this.isTpMode,
                        cellValueFunction: (entry) =>
                          entry["sdwan-zone"] && entry["sdwan-zone"].length > 0
                            ? entry["sdwan-zone"].map((zone) => ({
                                q_origin_key: zone.name,
                                datasource: "firewallInterfaces",
                              }))
                            : entry.$intf,
                        collectionFallbackValueFunction: (entry) => {
                          if ("enable" === entry.blackhole)
                            return lang("blackhole");
                        },
                        cellIsValidCollectionFunction: (entry) =>
                          "enable" !== entry.blackhole,
                      },
                      { id: "distance", type: "number" },
                      { id: "priority", type: "number" },
                      {
                        id: "vrf",
                        langKey: "VRF",
                        type: "number",
                        hidden: !advancedRoutingEnabled,
                        cellValueFunction: (entry, column) => {
                          if ("enable" === entry.blackhole)
                            return entry[column.id];
                        },
                      },
                      "comment",
                      { id: "type" },
                      { id: "tunnelid" },
                    ],
                    sections: this.ipv6Enabled,
                    defaultSectionColumn: "type",
                    onRowRendered: (row, entry) => {
                      "disable" === entry.status &&
                        row.classList.add("disabled");
                    },
                  };
                };
              }
              _isGatewayUnreachable($INJECTABLE$, staticRouteUtils) {
                return (entry) => {
                  const gatewayIPIsReachable =
                    ["0.0.0.0", "::"].includes(entry.gateway) ||
                    staticRouteUtils.ipInInterfaceSubnet(
                      entry.gateway,
                      entry.$intf,
                      !0,
                      "static6" === entry.$cmdb.name
                    );
                  return (
                    entry.$intf &&
                    !entry.$intf.is_tunnel &&
                    !entry.$intf.is_sslvpn_client_tunnel &&
                    !gatewayIPIsReachable
                  );
                };
              }
            }
            (StaticRouteList.prototype.$onInit.$inject = [
              "$INJECTABLE$",
              "state",
            ]),
              (StaticRouteList.prototype.processEntry.$inject = [
                "$INJECTABLE$",
                "lang",
                "$q",
                "$http",
              ]),
              (StaticRouteList.prototype.getSource.$inject = [
                "$INJECTABLE$",
                "CMDB",
                "$q",
                "Omniselect",
                "$http",
              ]),
              (StaticRouteList.prototype.getMutableSettings.$inject = [
                "$INJECTABLE$",
                "lang",
                "state",
                "staticRouteUtils",
              ]),
              (StaticRouteList.prototype._isGatewayUnreachable.$inject = [
                "$INJECTABLE$",
                "staticRouteUtils",
              ]);
            const fStaticRouteList = {
              controller: StaticRouteList,
              templateUrl: __webpack_require__(64161),
            };
            return (providers, loader) => (
              providers.$compile.component(
                "fStaticRouteList",
                fStaticRouteList
              ),
              loader.initModules([
                __webpack_require__(80973),
                __webpack_require__(90398),
              ])
            );
          }.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) ||
          (module.exports = __WEBPACK_AMD_DEFINE_RESULT__);
    },
    90398: (module, __unused_webpack_exports, __webpack_require__) => {
      "use strict";
      const fwebAddrSearch = __webpack_require__(35567);
      goog.require("goog.net.IpAddress"), goog.require("goog.math.Integer");
      class StaticRouteUtils {
        ipInInterfaceSubnet(ip, intf, sameIpAllowed, isIpv6) {
          const intfAddrs = this.interfaceAddresses(intf, isIpv6);
          let isPPPoe = !!intf && intf.pppoe_interface;
          return (
            !intfAddrs ||
            !ip ||
            isPPPoe ||
            intfAddrs.some((subnetObj) =>
              this.ipInSubnet(ip, subnetObj, sameIpAllowed)
            )
          );
        }
        interfaceAddresses(intf, isIpv6) {
          return intf && intf[isIpv6 ? "ipv6_addresses" : "ipv4_addresses"];
        }
        ipInSubnet(ipStr, subnetObj, sameIpAllowed) {
          const ip = goog.net.IpAddress.fromString(ipStr),
            subnet = goog.net.IpAddress.fromString(subnetObj.ip);
          if (!ip || !subnet) return !0;
          const ipInt = ip.toInteger(),
            subInt = subnet.toInteger(),
            prefixInt = goog.math.Integer.fromNumber(subnetObj.cidr_netmask),
            sameIp =
              ipInt.greaterThanOrEqual(subInt) && ipInt.lessThanOrEqual(subInt);
          return (
            (sameIpAllowed || !sameIp) &&
            fwebAddrSearch.subnet_util.contains(subnet, prefixInt, ip)
          );
        }
      }
      module.exports = function (providers) {
        providers.$provide.service("staticRouteUtils", StaticRouteUtils);
      };
    },
    44042: (module) => {
      var path = "/migadmin/ng/menu/router/routelist.html";
      window.angular.module("ng").run([
        "$templateCache",
        function (c) {
          c.put(
            path,
            '<div class="left-menu-items">\n    <div f-menu-item-submenu="$ctrl.createMenu"\n        emphasized="true"\n        ng-if="!$ctrl.state.readOnlyForPage && $ctrl.menu.menuBar && $ctrl.state.featureEnabled(\'gui-ipv6\')">\n        <f-icon class="fa-plus"></f-icon>\n        {{::\'Create New\' | lang}}\n    </div>\n    <div f-pop-up-menu="$ctrl.createMenu" ng-if="!$ctrl.state.readOnlyForPage && $ctrl.menu.menuBar && $ctrl.state.featureEnabled(\'gui-ipv6\')">\n        <div f-menu-item-button click="$ctrl.newRoute(4)">\n            {{::\'IPv4 Static Route\' | lang}}\n        </div>\n        <div f-menu-item-button click="$ctrl.newRoute(6)">\n            {{::\'IPv6 Static Route\' | lang}}\n        </div>\n    </div>\n    <div f-menu-item-create action="$ctrl.newRoute()" ng-if="!$ctrl.state.readOnlyForPage && $ctrl.menu.menuBar && !$ctrl.state.featureEnabled(\'gui-ipv6\')"></div>\n    <div f-menu-item-edit action="$ctrl.editFn()"></div>\n    <div f-menu-item-edit-cli></div>\n    <div f-menu-item-clone action="$ctrl.clone()"></div>\n    <div f-menu-item-delete></div>\n    <div ng-if="!$ctrl.state.readOnlyForPage && $ctrl.menu.popUpMenu">\n        <div f-menu-item-button click="$ctrl.setRouteStatus(\'enable\')"\n            enabled="$ctrl.statusToggleEnabled(\'enable\')">\n            <f-icon class="fa-enabled"></f-icon>\n            {{::\'enable\' | lang}}\n        </div>\n        <div f-menu-item-button click="$ctrl.setRouteStatus(\'disable\')"\n            enabled="$ctrl.statusToggleEnabled(\'disable\')">\n            <f-icon class="fa-disabled"></f-icon>\n            {{::\'disable\' | lang}}\n        </div>\n    </div>\n</div>\n\n<div class="center-menu-items">\n    <f-mutable-search></f-mutable-search>\n</div>\n'
          );
        },
      ]),
        (module.exports = path);
    },
    64161: (module) => {
      var path = "/migadmin/ng/routing/static/f-static-route-list.html";
      window.angular.module("ng").run([
        "$templateCache",
        function (c) {
          c.put(
            path,
            '<f-mutable\n    source="$ctrl.muTable.source"\n    settings="$ctrl.muTable.settings"\n    context-menu="::true">\n    <f-route-list-menu type="static" menu="menu" class="menu-bar-component"></f-route-list-menu>\n</f-mutable>\n'
          );
        },
      ]),
        (module.exports = path);
    },
  },
]);
